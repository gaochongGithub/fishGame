var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var EmojiView = (function (_super) {
    __extends(EmojiView, _super);
    function EmojiView() {
        return _super.call(this) || this;
    }
    EmojiView.prototype.itemChange = function () {
        var data = this.emoji_list.selectedItem;
        App.MessageCenter.dispatch(GameEvent.GAME_CHAT_BQ, data);
    };
    EmojiView.prototype.initView = function () {
        // 原始数组
        var dataArr = ["😐", "😂", "😪", "😏", "😊", "😄", "😜", "😇", "😫", "😌", "😙", "😧", "😷", "😑", "😶", "😟", "😰", "😟", "😎", "😨", "😆", "😭", "😉", "😘", "😅", "😖", "😡", "😍", "😲", "😆"];
        // 转成eui数据
        var euiArr = new eui.ArrayCollection(dataArr);
        this.emoji_list.dataProvider = euiArr;
        this.emoji_list.itemRenderer = EmojiItem;
        this.emoji_list.addEventListener(eui.ItemTapEvent.ITEM_TAP, this.itemChange, this);
    };
    return EmojiView;
}(ComponentParent));
__reflect(EmojiView.prototype, "EmojiView");
//# sourceMappingURL=EmojiView.js.map