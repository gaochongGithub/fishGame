var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ChatItem = (function (_super) {
    __extends(ChatItem, _super);
    function ChatItem() {
        return _super.call(this) || this;
    }
    ChatItem.prototype.dataChanged = function () {
        if (this.data.type != 0) {
            this.skinName = ChatItemSkin;
            // this.labelDisplay.text=this.utf8ByteToUnicodeStr(this.data.content);
            this.labelDisplay.text = this.data.content;
            this.name_text.text = this.textAbbreviation(this.data.sender) + ":";
        }
        else {
            this.skinName = RewardItemSkin;
            // this.rewadText.textFlow = new egret.HtmlTextParser().parser(this.utf8ByteToUnicodeStr(this.data.content));
            this.rewadText.textFlow = new egret.HtmlTextParser().parser(this.data.content);
        }
        // if(this.data.type==0){
        //     this.chatItem=this.getChatXTItem();
        //     this.chatItem.type=0;
        //     this.chatItem.children[0].getComponent(cc.RichText).string=cmkj.Utils.utf8ByteToUnicodeStr(chatData.content);
        // }else{
        //     this.chatItem=this.getChatItem();
        //     this.chatItem.type=1;
        //     if(this.chatItem.getComponent("chatItem")){
        //         this.chatItem.getComponent("chatItem").setText(chatData.type,chatData.sender,cmkj.Utils.utf8ByteToUnicodeStr(chatData.content));
        //     }else{
        //         this.chatItem.getComponent("mobileChatItem").setText(chatData.type,chatData.sender,cmkj.Utils.utf8ByteToUnicodeStr(chatData.content));
        //     }
        // }
    };
    ChatItem.prototype.textAbbreviation = function (text) {
        if (escape(text).indexOf("%u") < 0) {
            if (text.length > 6) {
                var abbrText = text.substr(5, text.length);
                return "…" + abbrText;
            }
            else {
                return text;
            }
        }
        else {
            if (text.length > 4) {
                var abbrText = text.substr(3, text.length);
                return "…" + abbrText;
            }
            else {
                return text;
            }
        }
    };
    ChatItem.prototype.utf8ByteToUnicodeStr = function (utf8Bytes) {
        var unicodeStr = "";
        for (var pos = 0; pos < utf8Bytes.length;) {
            var flag = utf8Bytes[pos];
            var unicode = 0;
            if ((flag >>> 7) === 0) {
                unicodeStr += String.fromCharCode(utf8Bytes[pos]);
                pos += 1;
            }
            else if ((flag & 0xFC) === 0xFC) {
                unicode = (utf8Bytes[pos] & 0x3) << 30;
                unicode |= (utf8Bytes[pos + 1] & 0x3F) << 24;
                unicode |= (utf8Bytes[pos + 2] & 0x3F) << 18;
                unicode |= (utf8Bytes[pos + 3] & 0x3F) << 12;
                unicode |= (utf8Bytes[pos + 4] & 0x3F) << 6;
                unicode |= (utf8Bytes[pos + 5] & 0x3F);
                unicodeStr += String.fromCharCode(unicode);
                pos += 6;
            }
            else if ((flag & 0xF8) === 0xF8) {
                unicode = (utf8Bytes[pos] & 0x7) << 24;
                unicode |= (utf8Bytes[pos + 1] & 0x3F) << 18;
                unicode |= (utf8Bytes[pos + 2] & 0x3F) << 12;
                unicode |= (utf8Bytes[pos + 3] & 0x3F) << 6;
                unicode |= (utf8Bytes[pos + 4] & 0x3F);
                unicodeStr += String.fromCharCode(unicode);
                pos += 5;
            }
            else if ((flag & 0xF0) === 0xF0) {
                unicode = (utf8Bytes[pos] & 0xF) << 18;
                unicode |= (utf8Bytes[pos + 1] & 0x3F) << 12;
                unicode |= (utf8Bytes[pos + 2] & 0x3F) << 6;
                unicode |= (utf8Bytes[pos + 3] & 0x3F);
                unicodeStr += String.fromCharCode(unicode);
                pos += 4;
            }
            else if ((flag & 0xE0) === 0xE0) {
                unicode = (utf8Bytes[pos] & 0x1F) << 12;
                ;
                unicode |= (utf8Bytes[pos + 1] & 0x3F) << 6;
                unicode |= (utf8Bytes[pos + 2] & 0x3F);
                unicodeStr += String.fromCharCode(unicode);
                pos += 3;
            }
            else if ((flag & 0xC0) === 0xC0) {
                unicode = (utf8Bytes[pos] & 0x3F) << 6;
                unicode |= (utf8Bytes[pos + 1] & 0x3F);
                unicodeStr += String.fromCharCode(unicode);
                pos += 2;
            }
            else {
                unicodeStr += String.fromCharCode(utf8Bytes[pos]);
                pos += 1;
            }
        }
        return unicodeStr;
    };
    return ChatItem;
}(ItemParent));
__reflect(ChatItem.prototype, "ChatItem");
//# sourceMappingURL=ChatItem.js.map