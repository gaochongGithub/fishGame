var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var chat = (function (_super) {
    __extends(chat, _super);
    function chat() {
        var _this = _super.call(this) || this;
        _this.chatData = new Array();
        return _this;
    }
    chat.prototype.initEventListener = function () {
        this.emojiBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickView, this);
        this.sendBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickSendBtn, this);
        this.close_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
        App.MessageCenter.addListener(GameEvent.GAME_CHAT_PUSH, this.onChatMsgPush, this);
        App.MessageCenter.addListener(GameEvent.GAME_CHAT_SUCCES, this.onChatSucces, this);
        App.MessageCenter.addListener(GameEvent.GAME_CHAT_BQ, this.onChatBQ, this);
        App.MessageCenter.addListener(LobbyEvent.LOAD_CHAT_ACK, this.onLoadChat, this);
    };
    chat.prototype.removeMyEventListener = function () {
        this.emojiBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickView, this);
        this.sendBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickSendBtn, this);
        this.close_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
        App.MessageCenter.removeListener(GameEvent.GAME_CHAT_PUSH, this.onChatMsgPush, this);
        App.MessageCenter.removeListener(GameEvent.GAME_CHAT_SUCCES, this.onChatSucces, this);
        App.MessageCenter.removeListener(GameEvent.GAME_CHAT_BQ, this.onChatBQ, this);
        App.MessageCenter.removeListener(LobbyEvent.LOAD_CHAT_ACK, this.onLoadChat, this);
    };
    chat.prototype.onCloseBtn = function () {
        this.parent.removeChild(this);
    };
    chat.prototype.onChatMsgPush = function (chatVOList) {
        if (chatVOList.tableId == this.tableID) {
            var counts = chatVOList.chatVOS.length;
            for (var i = 0; i < counts; i++) {
                this.chatData.push(chatVOList.chatVOS[i]);
            }
        }
        this.addChat();
    };
    chat.prototype.addChat = function () {
        if (!this.euiArr) {
            this.euiArr = new eui.ArrayCollection(this.chatData);
            this.chat_List.dataProvider = this.euiArr;
            this.chat_List.itemRenderer = ChatItem;
        }
        else {
            this.euiArr.replaceAll(this.chatData);
        }
        App.TimerManager.setTimeOut(500, this.setScrollerContentV, this);
    };
    //滚动视图位置调整
    chat.prototype.setScrollerContentV = function () {
        if (this.chat_scroller.viewport.height < this.chat_scroller.viewport.contentHeight) {
            this.chat_scroller.viewport.scrollV = this.chat_scroller.viewport.contentHeight - this.chat_scroller.viewport.height;
        }
    };
    chat.prototype.onChatSucces = function (command) {
        switch (command.code) {
            case proto.CommonReply.Code.SUCCESS:
                this.editText.text = "";
                break;
            case proto.CommonReply.Code.ERR_CHAT_FAST_LIMIT:
                App.ToastViewManager.toastTextView("TEXT_CHAT_FREQUENT");
                break;
            case proto.CommonReply.Code.ERR_CHAT_LIMIT:
                App.ToastViewManager.toastTextView("TEXT_CHAT_BANNED");
                break;
        }
    };
    chat.prototype.onChatBQ = function (data) {
        this.editText.text = this.editText.text + data;
        this.removeChild(this.emojiView);
        this.emojiView = null;
    };
    chat.prototype.onLoadChat = function (loadChat) {
        if (loadChat.code == 0) {
            var data = loadChat.chatVOList;
            if (data) {
                if (data.tableId == this.tableID) {
                    var counts = data.chatVOS.length;
                    for (var i = 0; i < counts; i++) {
                        this.chatData.push(data.chatVOS[i]);
                    }
                }
                this.addChat();
            }
        }
    };
    chat.prototype.onClickSendBtn = function () {
        if (this.editText.text.length > 0) {
            App.GameServer.sendChat(this.tableID, this.editText.text);
        }
    };
    chat.prototype.onClickView = function () {
        if (this.emojiView) {
            this.removeChild(this.emojiView);
            this.emojiView = null;
        }
        else {
            this.emojiView = new EmojiView();
            this.addChild(this.emojiView);
            this.emojiView.bottom = 10;
            this.emojiView.left = 5;
        }
    };
    chat.prototype.initView = function () {
        this.tableID = HallDataCtrl.instance.getLoadGameData.getTableID;
        if (App.DeviceUtils.IsMobile) {
            this.close_btn.visible = true;
            this.width = 817;
            this.height = 375;
        }
    };
    return chat;
}(ComponentParent));
__reflect(chat.prototype, "chat");
//# sourceMappingURL=chat.js.map