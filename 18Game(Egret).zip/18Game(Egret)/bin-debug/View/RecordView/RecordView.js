var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RecordView = (function (_super) {
    __extends(RecordView, _super);
    function RecordView() {
        var _this = _super.call(this) || this;
        _this.gameType = 0;
        _this.tableID = 0;
        _this.shoeID = 0;
        _this.totalCount = 0;
        _this.pageRatio = 11;
        _this.pageIndex = 0;
        _this.pageTotalCount = 0;
        return _this;
    }
    RecordView.prototype.initEventListener = function () {
        App.MessageCenter.addListener(GameEvent.GET_GAMERECORD, this.reciveRecordData, this);
        this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this);
        this.dateBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onDateBtn, this);
        //this.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
        App.MessageCenter.addListener(RecordEvent.GET_CALENDAR_DATE, this.getDate, this);
        this.checkBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCheckBtn, this);
        this.gameBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.choseGameBtn, this);
        this.AllGameRadio.addEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.BGameRadio.addEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.LGameRadio.addEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.HomePage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.PreviousPage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.NextPage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.LastPage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
    };
    RecordView.prototype.removeMyEventListener = function () {
        App.MessageCenter.removeListener(GameEvent.GET_GAMERECORD, this.reciveRecordData, this);
        this.closeBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this);
        this.dateBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onDateBtn, this);
        //this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
        App.MessageCenter.removeListener(RecordEvent.GET_CALENDAR_DATE, this.getDate, this);
        this.checkBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCheckBtn, this);
        this.gameBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.choseGameBtn, this);
        this.AllGameRadio.removeEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.BGameRadio.removeEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.LGameRadio.removeEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.HomePage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.PreviousPage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.NextPage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
        this.LastPage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.pageChange, this);
    };
    RecordView.prototype.gameRadioChange = function (e) {
        var radioButton = e.target;
        switch (Number(radioButton.value)) {
            case proto.GameType.Baccarat:
                this.gameType = proto.GameType.Baccarat;
                this.gameText.text = App.LangUtils.getStr("TEXT_BACCARAT");
                break;
            case proto.GameType.Roulette:
                this.gameType = proto.GameType.Roulette;
                this.gameText.text = App.LangUtils.getStr("TEXT_Roulette");
                break;
            default:
                this.gameType = 0;
                this.gameText.text = App.LangUtils.getStr("TEXT_All_Games");
        }
        this.choseGameView.visible = false;
    };
    RecordView.prototype.choseGameBtn = function () {
        this.choseGameView.visible = !this.choseGameView.visible;
    };
    //判断按钮是否可以点击
    RecordView.prototype.initBtnView = function () {
        if (this.pageIndex == 0 || this.pageTotalCount == 1 || this.pageTotalCount == 0) {
            this.HomePage.touchEnabled = false;
            this.PreviousPage.touchEnabled = false;
            this.NextPage.touchEnabled = false;
            this.LastPage.touchEnabled = false;
            this.HomePage.alpha = 0.6;
            this.PreviousPage.alpha = 0.6;
            this.NextPage.alpha = 0.6;
            this.LastPage.alpha = 0.6;
        }
        else {
            if (this.pageTotalCount > this.pageIndex) {
                this.NextPage.touchEnabled = true;
                this.LastPage.touchEnabled = true;
                this.NextPage.alpha = 1;
                this.LastPage.alpha = 1;
            }
            else if (this.pageTotalCount <= this.pageIndex) {
                this.NextPage.touchEnabled = false;
                this.LastPage.touchEnabled = false;
                this.NextPage.alpha = 0.6;
                this.LastPage.alpha = 0.6;
            }
            if (this.pageIndex == 1) {
                this.HomePage.touchEnabled = false;
                this.PreviousPage.touchEnabled = false;
                this.HomePage.alpha = 0.6;
                this.PreviousPage.alpha = 0.6;
            }
            else {
                this.HomePage.touchEnabled = true;
                this.PreviousPage.touchEnabled = true;
                this.HomePage.alpha = 1;
                this.PreviousPage.alpha = 1;
            }
        }
    };
    RecordView.prototype.pageChange = function (e) {
        var pageBtn = e.target;
        switch (pageBtn.name) {
            case "HomePage":
                this.pageIndex = 1;
                break;
            case "PreviousPage":
                this.pageIndex > 1 && this.pageIndex--;
                break;
            case "NextPage":
                this.pageTotalCount > this.pageIndex && this.pageIndex++;
                break;
            case "LastPage":
                this.pageTotalCount > 0 ? (this.pageIndex = this.pageTotalCount) : (this.pageIndex = 1);
                break;
        }
        this.onCheckBtn();
    };
    // private touchBegin(){
    //     // if(this.timeCompentView){
    //     //     this.removeChild(this.timeCompentView);
    //     //     this.timeCompentView=null;
    //     // }
    // }
    RecordView.prototype.onCheckBtn = function () {
        var nowDate = new Date();
        this.startTime = new Date(this.textDateModel.getYears(), this.textDateModel.getMonth() - 1, this.textDateModel.getDay()).getTime();
        this.startTime = Math.round(this.startTime / 1000);
        //判断table 是否整数,是取整数否则取当前游戏桌子ID
        if (/^\d+$/.test(this.tableEdit.text))
            this.tableID = Number(this.tableEdit.text);
        else
            this.tableID = 0; //HallDataCtrl.instance.getLoadGameData.getTableID;
        if (/^\d+$/.test(this.xueEdit.text))
            this.shoeID = Number(this.xueEdit.text);
        else
            this.shoeID = 0;
        // App.GameServer.sendGameRecord(this.startTime,this.endTime,this.gameType,this.tableID,this.shoeID,this.pageRatio,this.pageIndex);
        this.pageIndex == 0 && (this.pageIndex = 1);
        //App.GameServer.sendGameRecord(this.startTime,this.endTime,0,0,0,this.pageRatio,this.pageIndex);
        App.GameServer.sendGameRecord(this.startTime, this.endTime, this.gameType, this.tableID, this.shoeID, this.pageRatio, this.pageIndex);
        // App.GameServer.sendGameRecord(1574352000, 1574438400, 0,0,0,this.pageRatio,this.pageIndex);
    };
    RecordView.prototype.initPageData = function () {
        this.totalPage.text = this.pageTotalCount + "";
        this.currentPage.text = this.pageIndex + "";
        this.initBtnView();
    };
    RecordView.prototype.getDate = function (date) {
        this.textDateModel = date;
        this.setDateText();
        if (this.timeCompentView) {
            this.removeChild(this.timeCompentView);
            this.timeCompentView = null;
        }
    };
    RecordView.prototype.onDateBtn = function () {
        if (this.timeCompentView) {
            this.removeChild(this.timeCompentView);
            this.timeCompentView = null;
        }
        else {
            this.timeCompentView = new TimeCompentView(this);
            this.timeCompentView.top = 144;
            this.timeCompentView.touchEnabled = true;
            this.addChild(this.timeCompentView);
        }
    };
    RecordView.prototype.onClose = function (event) {
        App.ToastViewManager.clearAll();
    };
    RecordView.prototype.reciveRecordData = function (data) {
        this.pageTotalCount = Math.ceil(data.totalCount / this.pageRatio);
        var results = JSON.parse(data.results);
        if (results) {
            this.initGameRecord(results);
        }
        else {
            this.pageIndex = 0;
            this.nothingView.visible = true;
        }
        this.initPageData();
    };
    //设置游戏记录表
    RecordView.prototype.initGameRecord = function (result) {
        this.listData = [];
        if (result.length == 0) {
            this.pageIndex = 0;
            this.nothingView.visible = true;
            this.initPageData();
            return;
        }
        for (var i = 0; i < result.length; i++) {
            // var isLessThen10 = this.node.childrenCount <= this.pageRatio;
            // if(result[i].GameKind !== 311){
            //     this.totalCount++;
            //     this.addItem(this.totalCount, result[i]);
            //     this.node.height = this.totalCount*this.itemPrefab.data.height;
            // }else{
            //     this.getRouletteRecord(i,result[i]);
            // }
            //if(result[i].GameKind == 311){
            this.getRouletteRecord(i, result[i]);
            // }else{
            //     this.totalCount++;
            //      this.addItem(this.totalCount, result[i]);
            //     // var widget = this.node.addComponent(cc.Widget);
            //     // widget.isAlignTop = true;
            //     // widget.top = 0;
            //     //this.node.height = this.totalCount*this.itemPrefab.data.height;
            // }
        }
        if (!this.euiArr) {
            this.euiArr = new eui.ArrayCollection(this.listData);
            this.listView.dataProvider = this.euiArr;
            this.listView.itemRenderer = RecordItem;
        }
        else {
            this.euiArr.replaceAll(this.listData);
        }
        this.nothingView.visible = false;
    };
    RecordView.prototype.getRouletteRecord = function (index, data) {
        var recordModel = new RecordModel();
        recordModel.setOderNum(data.OrderNum);
        var date = new Date(data.AddTime);
        recordModel.setOderDate(App.DateUtils.format(new Date(data.AddTime), "yyyy/MM/dd hh:mm:ss"));
        recordModel.setTableID(data.TableId);
        recordModel.setShoeId(data.Stage + "-" + data.Inning);
        recordModel.setBetsAmount(parseInt(data.BettingAmount) + "");
        recordModel.setResult(this.getGameResult(data));
        recordModel.setBetsArea(this.getBetAmount(data));
        recordModel.setWinloseAmount(parseInt(data.WinloseAmount));
        recordModel.setGameType(data.ResultType);
        if (data.GameKind == 311) {
            var text = data.GameBetting;
            var betting = text.split(",");
            var string = [];
            for (var i = 0; i < betting.length; i++) {
                string.push(betting[i].split("^"));
            }
            for (var i = 0; i < string.length; i++) {
                if (string[i] !== "") {
                    for (var j = 0; j < string[i].length; j++) {
                        if (string[i][j] !== "") {
                            this.totalCount++;
                            data.GameBetting = App.LangUtils.getStr(this.getBetType(string[i][0]));
                            recordModel.setBetsArea(this.getBetAmount(data));
                            this.addItem(this.totalCount, recordModel);
                        }
                        break;
                    }
                }
            }
        }
        else {
            this.addItem(this.totalCount, recordModel);
        }
    };
    RecordView.prototype.getGameResult = function (data) {
        var gameResult = "";
        var numStr = data.GameResult.substr(-2);
        var num = data.GameResult.length;
        if (data.GameKind == proto.Game.Subtype.LongHu) {
            var lhNumStr = data.GameResult.substr(-(num - 1));
            var lhNumArr = lhNumStr.split("@");
        }
        var numArr = numStr.split("");
        var player = "";
        var banker = "";
        if (data.GameKind == proto.Game.Subtype.LongHu) {
            player = App.LangUtils.getStr("TEXT_DRAGON_ICON");
            banker = App.LangUtils.getStr("TEXT_TIGER_ICON");
            gameResult = player + lhNumArr[0] + " " + banker + lhNumArr[1];
        }
        else if (data.GameKind == proto.Game.Subtype.Roulette) {
            gameResult = data.GameResult;
        }
        else if (data.GameKind == proto.Game.Subtype.SicBo) {
            gameResult = data.GameResult;
        }
        else {
            player = App.LangUtils.getStr("TEXT_PLAYER_ICON");
            banker = App.LangUtils.getStr("TEXT_BANKER_ICON");
            gameResult = player + numArr[0] + " " + banker + numArr[1];
        }
        return gameResult;
    };
    RecordView.prototype.getBetAmount = function (data) {
        var betAmount = "";
        if (data.GameKind == 411) {
            betAmount = this.setBettingArea(data.GameBetting);
        }
        else {
            switch (data.GameBetting) {
                case "闲":
                    betAmount = App.LangUtils.getStr("TEXT_Player");
                    break;
                case "闲对":
                    betAmount = App.LangUtils.getStr("TEXT_Player_Pair");
                    break;
                case "和":
                    betAmount = App.LangUtils.getStr("TEXT_Tie");
                    break;
                case "庄":
                    betAmount = App.LangUtils.getStr("TEXT_Banker");
                    break;
                case "庄对":
                    betAmount = App.LangUtils.getStr("TEXT_Banker_Pair");
                    break;
                case "免佣":
                    betAmount = App.LangUtils.getStr("TEXT_Super_Six");
                    break;
                case "龙":
                    betAmount = App.LangUtils.getStr("TEXT_Dragon");
                    break;
                case "虎":
                    betAmount = App.LangUtils.getStr("TEXT_Tiger");
                    break;
                case "大":
                    betAmount = App.LangUtils.getStr("TEXT_Big");
                    break;
                case "小":
                    betAmount = App.LangUtils.getStr("TEXT_Small");
                    break;
                case "任意对子":
                    betAmount = App.LangUtils.getStr("TEXT_AnyPair");
                    break;
                case "完美对子":
                    betAmount = App.LangUtils.getStr("TEXT_PerfectPair");
                    break;
                default:
                    betAmount = data.GameBetting;
            }
        }
        return betAmount;
    };
    RecordView.prototype.setBettingArea = function (gameBetting) {
        var betAmount = "";
        var areaNumArr = gameBetting.split("^");
        var areaNum = Number(areaNumArr[0]);
        switch (areaNum) {
            case SicboBetKey.sum_4:
            case SicboBetKey.sum_5:
            case SicboBetKey.sum_6:
            case SicboBetKey.sum_7:
            case SicboBetKey.sum_8:
            case SicboBetKey.sum_9:
            case SicboBetKey.sum_10:
            case SicboBetKey.sum_11:
            case SicboBetKey.sum_12:
            case SicboBetKey.sum_13:
            case SicboBetKey.sum_14:
            case SicboBetKey.sum_15:
            case SicboBetKey.sum_16:
            case SicboBetKey.sum_17:
                betAmount = App.LangUtils.getStr("SICBO_SUM") + " " + (Number(areaNum) - 397);
                break;
            case SicboBetKey.big:
                betAmount = App.LangUtils.getStr("SICBO_BIG");
                break;
            case SicboBetKey.small:
                betAmount = App.LangUtils.getStr("SICBO_SMALL");
                break;
            case SicboBetKey.dice_1:
            case SicboBetKey.dice_2:
            case SicboBetKey.dice_3:
            case SicboBetKey.dice_4:
            case SicboBetKey.dice_5:
            case SicboBetKey.dice_6:
                betAmount = App.LangUtils.getStr("SICBO_DICE") + " " + (Number(areaNum) - 416);
                break;
            case SicboBetKey.pair_11:
            case SicboBetKey.pair_22:
            case SicboBetKey.pair_33:
            case SicboBetKey.pair_44:
            case SicboBetKey.pair_55:
            case SicboBetKey.pair_66:
                betAmount = App.LangUtils.getStr("SICBO_PAIR") + " " + (Number(areaNum) - 422);
                break;
            case SicboBetKey.triple_111:
            case SicboBetKey.triple_222:
            case SicboBetKey.triple_333:
            case SicboBetKey.triple_444:
            case SicboBetKey.triple_555:
            case SicboBetKey.triple_666:
                betAmount = App.LangUtils.getStr("SICBO_TRIPLE") + " " + (Number(areaNum) - 428);
                break;
            case SicboBetKey.anyTriple:
                betAmount = App.LangUtils.getStr("SICBO_ANY_TRIPLE");
                break;
            case SicboBetKey.combination_12:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 12;
                break;
            case SicboBetKey.combination_13:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 13;
                break;
            case SicboBetKey.combination_14:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 14;
                break;
            case SicboBetKey.combination_15:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 15;
                break;
            case SicboBetKey.combination_16:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 16;
                break;
            case SicboBetKey.combination_23:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 23;
                break;
            case SicboBetKey.combination_24:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 24;
                break;
            case SicboBetKey.combination_25:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 25;
                break;
            case SicboBetKey.combination_26:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 26;
                break;
            case SicboBetKey.combination_34:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 34;
                break;
            case SicboBetKey.combination_35:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 35;
                break;
            case SicboBetKey.combination_36:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 36;
                break;
            case SicboBetKey.combination_45:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 45;
                break;
            case SicboBetKey.combination_46:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 46;
                break;
            case SicboBetKey.combination_56:
                betAmount = App.LangUtils.getStr("SICBO_COMBINATION") + " " + 56;
                break;
            case SicboBetKey.odd:
                betAmount = App.LangUtils.getStr("SICBO_ODD");
                break;
            case SicboBetKey.even:
                betAmount = App.LangUtils.getStr("SICBO_EVEN");
                break;
            default:
                break;
        }
        return betAmount;
    };
    //增加一个记录
    RecordView.prototype.addItem = function (index, recordModel) {
        // var node = cc.instantiate(this.itemPrefab);
        // node.__data = data;
        // node.__index = (this.pageIndex - 1) * this.pageRatio + index + 1;
        // node.parent = this.node;
        this.listData.push(recordModel);
    };
    RecordView.prototype.getBetType = function (char) {
        var string = "";
        if (char > 500 && char <= 537) {
            string = "TEXT_Roulette_Bet_Single";
        }
        else if (char > 537 && char <= 597) {
            string = "TEXT_Roulette_Bet_Two";
        }
        else if (char >= 598 && char <= 599) {
            string = "TEXT_Roulette_Bet_Three1";
        }
        else if (char >= 600 && char <= 611) {
            string = "TEXT_Roulette_Bet_Three2";
        }
        else if (char == 634) {
            string = "TEXT_Roulette_Bet_Fou1";
        }
        else if (char >= 612 && char <= 633) {
            string = "TEXT_Roulette_Bet_Four2";
        }
        else if (char >= 635 && char <= 645) {
            string = "TEXT_Roulette_Bet_Six";
        }
        else if (char >= 646 && char <= 648) {
            string = "TEXT_Roulette_Bet_Column";
        }
        else if (char >= 649 && char <= 651) {
            string = "TEXT_Roulette_Bet_Dozen1";
        }
        else if (char == 652) {
            string = "TEXT_Small";
        }
        else if (char == 653) {
            string = "TEXT_Double";
        }
        else if (char == 654) {
            string = "TEXT_Red";
        }
        else if (char == 655) {
            string = "TEXT_Black";
        }
        else if (char == 656) {
            string = "TEXT_Single";
        }
        else if (char == 657) {
            string = "TEXT_Big";
        }
        return string;
    };
    RecordView.prototype.initView = function () {
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        if (App.DeviceUtils.IsMobile) {
            this.scaleX = 0.5;
            this.scaleY = 0.5;
        }
        this.initEventListener();
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        var nowDate = new Date();
        this.endTime = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate() + 1).getTime();
        this.endTime = Math.round(this.endTime / 1000);
        this.textDateModel = new DateModel();
        this.textDateModel.setYears(nowDate.getFullYear());
        this.textDateModel.setMonth(nowDate.getMonth() + 1);
        this.textDateModel.setDay(nowDate.getDate());
        this.setDateText();
        this.initPageData();
        this.onCheckBtn();
    };
    RecordView.prototype.setDateText = function () {
        this.dateText.text = this.textDateModel.getYears() + "/" + this.textDateModel.getMonth() + "/" + this.textDateModel.getDay();
    };
    return RecordView;
}(ComponentParent));
__reflect(RecordView.prototype, "RecordView");
//# sourceMappingURL=RecordView.js.map