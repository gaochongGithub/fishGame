var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RecordItem = (function (_super) {
    __extends(RecordItem, _super);
    function RecordItem() {
        return _super.call(this) || this;
    }
    RecordItem.prototype.dataChanged = function () {
        this.itemData = this.data;
        this.oderDate.text = this.itemData.getOderDate;
        this.oderNum.text = this.itemData.getOderNum;
        this.tableID.text = this.itemData.getTableID + "";
        this.shoeId.text = this.itemData.getShoeId + "";
        this.betsArea.text = this.itemData.getBetsArea;
        this.betsAmount.text = this.itemData.getBetsAmount + "";
        this.result.text = this.itemData.getResult;
        this.winloseAmount.text = this.itemData.getWinloseAmount + "";
        this.gameType.text = this.itemData.getGameType;
    };
    return RecordItem;
}(ItemParent));
__reflect(RecordItem.prototype, "RecordItem");
//# sourceMappingURL=RecordItem.js.map