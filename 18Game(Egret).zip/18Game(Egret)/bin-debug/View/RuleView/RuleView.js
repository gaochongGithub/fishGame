var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RuleView = (function (_super) {
    __extends(RuleView, _super);
    function RuleView() {
        return _super.call(this) || this;
    }
    RuleView.prototype.initEventListener = function () {
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
        this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
    };
    RuleView.prototype.removeMyEventListener = function () {
        this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
        this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
    };
    RuleView.prototype.onCloseBtn = function () {
        App.ToastViewManager.clearAll();
    };
    RuleView.prototype.initView = function () {
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        if (App.DeviceUtils.IsMobile) {
            this.scaleX = 0.5;
            this.scaleY = 0.5;
        }
        this.initEventListener();
        var game = HallDataCtrl.instance.getLoadGameData;
        if (game) {
            switch (game.getGameType) {
                case proto.GameType.Baccarat:
                    this.text_img.texture = RES.getRes("wz_png");
                    break;
                case proto.GameType.Roulette:
                    this.text_img.texture = RES.getRes("lp_png");
                    break;
                default:
                    this.text_img.texture = RES.getRes("wz_png");
            }
        }
        else {
            this.text_img.texture = RES.getRes("wz_png");
        }
    };
    return RuleView;
}(ComponentParent));
__reflect(RuleView.prototype, "RuleView");
//# sourceMappingURL=RuleView.js.map