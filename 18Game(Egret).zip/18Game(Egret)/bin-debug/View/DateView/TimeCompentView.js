var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TimeCompentView = (function (_super) {
    __extends(TimeCompentView, _super);
    function TimeCompentView(loadObj) {
        var _this = _super.call(this) || this;
        _this.loadType = 0;
        _this.isClick = false;
        _this.years = 2017;
        _this.month = 4;
        _this.day = 1;
        _this.hour = 23;
        _this.minute = 59;
        _this.second = 59;
        _this.localyears = 2017;
        _this.localmonth = 4;
        _this.localday = 1;
        _this.dateArr = [0, 1, 2, 0, 0, 0];
        //this.data = data;
        _this.loadObj = loadObj;
        _this.skinName = TimeCompent;
        return _this;
    }
    TimeCompentView.prototype.initEventListener = function () {
        this.btn_pre.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        this.btn_next.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        this.txt_hour.addEventListener(egret.FocusEvent.FOCUS_OUT, this.checkHour, this); //失去焦点时调度
        this.txt_minute.addEventListener(egret.FocusEvent.FOCUS_OUT, this.checkMinute, this);
        this.txt_second.addEventListener(egret.FocusEvent.FOCUS_OUT, this.checkSecond, this);
        this.btn_today.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseClick, this);
        this.btn_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseClick, this);
    };
    TimeCompentView.prototype.removeMyEventListener = function () {
        this.btn_pre.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        this.autoList.removeEventListener(eui.ItemTapEvent.ITEM_TAP, this.onChange, this);
        this.btn_next.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        this.txt_hour.removeEventListener(egret.FocusEvent.FOCUS_OUT, this.checkHour, this); //失去焦点时调度
        this.txt_minute.removeEventListener(egret.FocusEvent.FOCUS_OUT, this.checkMinute, this);
        this.txt_second.removeEventListener(egret.FocusEvent.FOCUS_OUT, this.checkSecond, this);
        this.btn_today.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseClick, this);
        this.btn_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseClick, this);
    };
    TimeCompentView.prototype.initView = function () {
        // this.x = this.data["xs"];
        // this.y = this.data["ys"];
        // this.loadType = this.data["loadType"];
        this.getLocalDate();
        this.initTime();
        this.btn_close.selected = true;
    };
    TimeCompentView.prototype.onCloseClick = function (evt) {
        var data = new DateModel;
        switch (evt.currentTarget) {
            case this.btn_today:
                this.getLocalDate();
                // return;
                break;
            case this.btn_close:
                break;
        }
        //data["loadType"] = this.loadType;
        //this.dateArr[1] = this.dateArr[1];
        //data["date"] = this.dateArr;
        data.setYears(this.dateArr[0]);
        data.setMonth(this.dateArr[1]);
        data.setDay(this.dateArr[2]);
        App.MessageCenter.dispatch(RecordEvent.GET_CALENDAR_DATE, data);
        //this.loadObj.removeChild(this);
    };
    /**
     * 得到当前时间
     */
    TimeCompentView.prototype.getLocalDate = function () {
        var date = new Date();
        this.years = date.getFullYear();
        this.month = date.getMonth() + 1;
        this.day = date.getDate();
        this.localyears = date.getFullYear();
        this.localmonth = date.getMonth() + 1;
        this.localday = date.getDate();
        // if (this.loadType == 1) {
        // 	this.hour = 0;//date.getHours();
        // 	this.minute = 0;//date.getMinutes();
        // 	this.second = 0; //date.getSeconds();
        // } else {
        // 	this.hour = 23;//date.getHours();
        // 	this.minute = 59;//date.getMinutes();
        // 	this.second = 59; //date.getSeconds();
        // }
        this.initDate();
        this.initDateUI(this.years, this.month);
    };
    /**
     * 检查"时"
     */
    TimeCompentView.prototype.checkHour = function () {
        // this.txt_hour.text = dateArr[3] > 9 ? dateArr[3] + '' : "0" + dateArr[3];
        var dateArr = this.dateArr;
        var hour = parseInt(this.txt_hour.text);
        if (hour < 0) {
            hour = 0;
        }
        else if (hour > 23) {
            hour = 23;
        }
        else if (hour <= 23 && hour > 0) {
            hour = hour;
        }
        else {
            hour = 0;
        }
        this.hour = hour;
        dateArr[3] = hour;
        this.txt_hour.text = '';
        this.txt_hour.prompt = dateArr[3] > 9 ? dateArr[3] + '' : "0" + dateArr[3];
    };
    /**
     * 检查"分"
     */
    TimeCompentView.prototype.checkMinute = function () {
        var dateArr = this.dateArr;
        // this.txt_minute.text = dateArr[4] > 9 ? dateArr[4] + '' : "0" + dateArr[4];
        var minute = parseInt(this.txt_minute.text);
        if (minute < 0) {
            minute = 0;
            // this.txt_minute.text = '' + this.minute;
        }
        else if (minute > 59) {
            minute = 59;
            // this.txt_minute.text = '' + this.minute;
        }
        else if (minute <= 59 && minute > 0) {
            minute = minute;
        }
        else {
            minute = 0;
        }
        this.minute = minute;
        dateArr[4] = minute;
        this.txt_minute.text = '';
        this.txt_minute.prompt = minute > 9 ? minute + '' : "0" + dateArr[4];
    };
    /**
     * 检查"秒"
     */
    TimeCompentView.prototype.checkSecond = function () {
        var dateArr = this.dateArr;
        var second = parseInt(this.txt_second.text);
        if (second < 0) {
            second = 0;
            // this.txt_second.text = '' + this.second;
        }
        else if (second > 59) {
            second = 59;
            // this.txt_second.text = '' + this.second;
        }
        else if (second <= 59 && second > 0) {
            second = second;
        }
        else {
            second = 0;
        }
        this.second = second;
        dateArr[5] = this.second;
        this.txt_second.text = '';
        this.txt_second.prompt = dateArr[5] > 9 ? dateArr[5] + '' : "0" + dateArr[5];
    };
    /**
     * 年月切换
     */
    TimeCompentView.prototype.onClick = function (evt) {
        var years = this.years;
        var month = this.month;
        switch (evt.currentTarget) {
            case this.btn_pre:
                month--;
                break;
            case this.btn_next:
                month++;
                break;
        }
        if (month == 13) {
            years++;
            month = 1;
        }
        else if (month == 0) {
            years--;
            month = 12;
        }
        this.initDateUI(years, month);
    };
    TimeCompentView.prototype.initDate = function () {
        var timeArr = this.dateArr;
        timeArr[0] = this.years;
        timeArr[1] = this.month;
        timeArr[2] = this.day;
        timeArr[3] = this.hour;
        timeArr[4] = this.minute;
        timeArr[5] = this.second;
        this.showDateUI();
    };
    TimeCompentView.prototype.showDateUI = function () {
        var dateArr = this.dateArr;
        this.txt_year.text = dateArr[0] + '';
        this.txt_month.text = dateArr[1] > 9 ? dateArr[1] + '' : "0" + dateArr[1];
        // this.txt_month.text = timeArr[1] + '';
        // this.txt_hour.prompt = dateArr[3] > 9 ? dateArr[3] + '' : "0" + dateArr[3];
        // this.txt_minute.prompt = dateArr[4] > 9 ? dateArr[4] + '' : "0" + dateArr[4];
        // this.txt_second.prompt = dateArr[5] > 9 ? dateArr[5] + '' : "0" + dateArr[5];
        // this.txt_hour.text = dateArr[3] > 9 ? dateArr[3] + '' : "0" + dateArr[3];
        // this.txt_minute.text = dateArr[4] > 9 ? dateArr[4] + '' : "0" + dateArr[4];
        // this.txt_second.text = dateArr[5] > 9 ? dateArr[5] + '' : "0" + dateArr[5];
    };
    /**
     * 初始化月历的ui
     */
    TimeCompentView.prototype.initDateUI = function (years, month) {
        this.years = years;
        this.month = month;
        var days = this.calculateDays(years, month);
        var times = '' + years + "," + month + "," + 1;
        var weeks = new Date(times).getDay();
        this.txt_year.text = years + '';
        this.txt_month.text = month + '';
        this.init(weeks, days);
    };
    /**
     * 计算当前月的第一天是星期几
     */
    TimeCompentView.prototype.calculateWeek = function () {
        return 0;
    };
    /**
     * 是否是闰年
     */
    TimeCompentView.prototype.isLeapYear = function (year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    };
    /**
     * 计算这个月有多少天
     */
    TimeCompentView.prototype.calculateDays = function (year, month) {
        var months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        var days = months[month - 1];
        // 2月比较特殊，非闰年28天，闰年29天，如2008年2月为29天
        if (1 == month && this.isLeapYear(year)) {
            days = 29;
        }
        return days;
    };
    TimeCompentView.prototype.init = function (lastMonth, days) {
        var select = 0;
        var dateArr = this.dateArr;
        var timeArr = new Array();
        for (var i = 0; i < lastMonth; i++) {
            timeArr.push({ times: null, selected: select });
        }
        for (var i = 1; i <= days; i++) {
            if (!this.isClick && this.localyears == this.years && this.localmonth == this.month && this.localday == this.day) {
                if (this.localday == i) {
                    select = 1;
                }
                else {
                    select = 0;
                }
            }
            else if (dateArr[0] == this.years && dateArr[1] == this.month && dateArr[2] == this.day) {
                if (dateArr[2] == i) {
                    select = 1;
                }
                else {
                    select = 0;
                }
            }
            timeArr.push({ times: i, selected: select });
        }
        this.autoList.dataProvider = new eui.ArrayCollection(timeArr);
        this.autoList.itemRenderer = TimeList;
        if (!this.autoList.hasEventListener(eui.ItemTapEvent.ITEM_TAP)) {
            this.autoList.addEventListener(eui.ItemTapEvent.ITEM_TAP, this.onChange, this);
        }
    };
    TimeCompentView.prototype.onChange = function () {
        this.isClick = true;
        var dateArr = this.dateArr;
        dateArr[0] = this.years;
        dateArr[1] = this.month;
        dateArr[2] = this.autoList.selectedItem["times"];
        this.day = this.autoList.selectedItem["times"];
    };
    TimeCompentView.prototype.initToday = function () {
    };
    /**
     *
     */
    TimeCompentView.prototype.initTime = function () {
        //初始化测试
        // this.txt_hour.text = "23";
        // this.txt_minute.text = "59";
        // this.txt_second.text = "59";
        this.txt_hour.restrict = "0-9";
        this.txt_minute.restrict = "0-9";
        this.txt_second.restrict = "0-9";
        this.txt_hour.maxChars = 2;
        this.txt_minute.maxChars = 2;
        this.txt_second.maxChars = 2;
    };
    return TimeCompentView;
}(ComponentParent));
__reflect(TimeCompentView.prototype, "TimeCompentView");
var TimeList = (function (_super) {
    __extends(TimeList, _super);
    // private TimeArr: Array<number> = ManageTime.TimeArr;
    function TimeList() {
        var _this = _super.call(this) || this;
        _this.skinName = listSkin;
        return _this;
    }
    // private dates: eui.Label;
    TimeList.prototype.dataChanged = function () {
        var dateGroup = this.radios.getChildByName("dateGroup");
        var dates = dateGroup.getChildByName("dates");
        var date = this.data["times"];
        if (date == null) {
            this.radios.touchEnabled = false;
        }
        dates.text = date;
        if (this.data["selected"] == 1) {
            this.radios.selected = true;
        }
        /*if (this.radios.selected) {
            this.dates.textColor = 0x05314a;
        } else {
            this.dates.textColor = 0x69c3de;
        }*/
    };
    return TimeList;
}(ItemParent));
__reflect(TimeList.prototype, "TimeList");
//# sourceMappingURL=TimeCompentView.js.map