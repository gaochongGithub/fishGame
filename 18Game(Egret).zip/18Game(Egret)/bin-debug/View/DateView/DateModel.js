var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var DateModel = (function () {
    function DateModel() {
    }
    DateModel.prototype.setYears = function (years) {
        this.years = years;
    };
    DateModel.prototype.getYears = function () {
        return this.years;
    };
    DateModel.prototype.setMonth = function (month) {
        this.month = month;
    };
    DateModel.prototype.getMonth = function () {
        return this.month;
    };
    DateModel.prototype.setDay = function (day) {
        this.day = day;
    };
    DateModel.prototype.getDay = function () {
        return this.day;
    };
    return DateModel;
}());
__reflect(DateModel.prototype, "DateModel");
//# sourceMappingURL=DateModel.js.map