var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var SettingView = (function (_super) {
    __extends(SettingView, _super);
    function SettingView() {
        return _super.call(this) || this;
    }
    SettingView.prototype.initEventListener = function () {
        this.langCheckBox.addEventListener(egret.Event.CHANGE, this.onLangChange, this);
        this.musicCheckBox.addEventListener(egret.Event.CHANGE, this.onMusicChange, this);
        this.effectCheckBox.addEventListener(egret.Event.CHANGE, this.onEffectChange, this);
        this.super6CheckBox.addEventListener(egret.Event.CHANGE, this.super6Change, this);
        this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
    };
    SettingView.prototype.removeMyEventListener = function () {
        this.langCheckBox.removeEventListener(egret.Event.CHANGE, this.onLangChange, this);
        this.musicCheckBox.removeEventListener(egret.Event.CHANGE, this.onMusicChange, this);
        this.effectCheckBox.removeEventListener(egret.Event.CHANGE, this.onEffectChange, this);
        this.super6CheckBox.removeEventListener(egret.Event.CHANGE, this.super6Change, this);
        this.closeBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCloseBtn, this);
    };
    SettingView.prototype.onCloseBtn = function () {
        // if(this.parent){
        // 	this.parent.removeChild(this);
        // }
        App.ToastViewManager.clearAll();
    };
    SettingView.prototype.onLangChange = function (e) {
        var lang;
        this.langCheckBox.selected ? lang = "ZH" : lang = "EN";
        App.LangUtils.changeLang(lang);
    };
    SettingView.prototype.onMusicChange = function (e) {
        App.SoundManager.setBgOn(this.musicCheckBox.selected);
    };
    SettingView.prototype.onEffectChange = function (e) {
        App.SoundManager.setEffectOn(this.effectCheckBox.selected);
    };
    SettingView.prototype.super6Change = function (e) {
        egret.localStorage.setItem("Super6", this.super6CheckBox.selected ? "1" : "0");
        App.MessageCenter.dispatch(GlobalEvent.SET_SUPER6);
    };
    SettingView.prototype.initView = function () {
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        if (App.DeviceUtils.IsMobile) {
            this.scaleX = 0.8;
            this.scaleY = 0.8;
        }
        App.SoundManager.bgIsOn ? this.musicCheckBox.selected = true : this.musicCheckBox.selected = false;
        App.SoundManager.effectIsOn ? this.effectCheckBox.selected = true : this.effectCheckBox.selected = false;
        var super6 = egret.localStorage.getItem("Super6");
        this.super6CheckBox.selected = super6 == "1";
        App.LangUtils.kind == "ZH" ? this.langCheckBox.selected = true : this.langCheckBox.selected = false;
    };
    return SettingView;
}(ComponentParent));
__reflect(SettingView.prototype, "SettingView");
//# sourceMappingURL=SettingView.js.map