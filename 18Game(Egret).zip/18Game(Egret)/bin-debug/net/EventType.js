var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ServerEvent = (function () {
    function ServerEvent() {
    }
    /**
     * 大厅用户事件
     */
    ServerEvent.GET_LOBBY_PLAYER_INFO = "GET_LOBBY_PLAYER_INFO";
    /**
     * 大厅状态事件
     */
    ServerEvent.GET_LOBBY_TABLE_INFO = "GET_LOBBY_TABLE_INFO";
    /**
     * 大厅用户人数事件
     */
    ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO = "GET_LOBBY_PLAYERCOUNT_INFO";
    /**
     * 游戏状态事件
     */
    ServerEvent.GET_GAME_STATUS = "GET_GAME_STATUS";
    /**
     * 游戏桌面信息事件
     */
    ServerEvent.GET_GAME_TABLE_HISTORY = "GET_GAME_TABLE_HISTORY";
    /**
     * 游戏用户信息事件
     */
    ServerEvent.GET_GAME_USER_INFO = "GET_GAME_USER_INFO";
    /**
     * 游戏桌面配置事件
     */
    ServerEvent.GET_GAME_TABLE_CONFIG = "GET_GAME_TABLE_CONFIG";
    /**
     * 游戏包间数据
     */
    ServerEvent.UPDATE_VIRTUAL_TABLE = "UPDATE_VIRTUAL_TABLE";
    /**
     * 游戏包间下注数据
     */
    ServerEvent.UPDATE_VIRTUAL_TABLE_BET = "UPDATE_VIRTUAL_TABLE_BET";
    /**
     * 下注成功事件
     */
    ServerEvent.BET_INFO_SUSSESS = "BET_INFO_SUSSESS";
    /**
     * 下注超过限红事件
     */
    ServerEvent.ERR_EXCEED_LIMIT = "ERR_EXCEED_LIMIT";
    /**
     * 下注出错事件
     */
    ServerEvent.BET_INFO_ERROR = "BET_INFO_ERROR";
    /**
     * 游戏记录事件
     */
    ServerEvent.GET_GAME_RECORD = "GET_GAME_RECORD";
    /**
     * 游戏报告事件
     */
    ServerEvent.GET_GAME_REPORTS = "GET_GAME_REPORTS";
    /**
     * 公告事件
     */
    ServerEvent.GET_ANNOUNCE = "GET_ANNOUNCE";
    return ServerEvent;
}());
__reflect(ServerEvent.prototype, "ServerEvent");
var GlobalEvent = (function () {
    function GlobalEvent() {
    }
    /**
     * 改变语言事件
     */
    GlobalEvent.CHANGE_LANGUAGE = "CHANGE_LANGUAGE";
    /**
     * 超级6
     */
    GlobalEvent.SET_SUPER6 = "SET_SUPER6";
    return GlobalEvent;
}());
__reflect(GlobalEvent.prototype, "GlobalEvent");
var LobbyEvent = (function () {
    function LobbyEvent() {
    }
    /**
     * 增加大厅路单事件
     */
    LobbyEvent.ADD_LOBBY_ROAD_ITEM = "ADD_LOBBY_ROAD_ITEM";
    /**
     * 登录成功
     */
    LobbyEvent.LOGIN_SUCCES = "LOGIN_SUCCES";
    /**
     * 选择限红
     */
    LobbyEvent.SHOW_LIMIT_VIEW = "SHOW_LIMIT_VIEW";
    LobbyEvent.LIMIT_CHOOSE = "LIMIT_CHOOSE";
    /**
     * 聊天记录
     */
    LobbyEvent.LOAD_CHAT_ACK = "LOADCHAT_ACK";
    /**
     * 加载完成事件
     */
    LobbyEvent.LOAD_GAME_ACK = "LOADGAME_ASK";
    /**
     * 音效音乐修改
     */
    LobbyEvent.MUISC_SOUND_CHANGE = "MUISC_SOUND_CHANGE";
    return LobbyEvent;
}());
__reflect(LobbyEvent.prototype, "LobbyEvent");
var GameEvent = (function () {
    function GameEvent() {
    }
    /**
     * 游戏洗牌事件
     */
    GameEvent.GAME_STATUS_SHUFFLE = "GAME_STATUS_SHUFFLE";
    /**
     * 游戏开始事件
     */
    GameEvent.GAME_STATUS_START = "GAME_STATUS_START";
    /**
     * 停止下注
     */
    GameEvent.GAME_STATUS_STOP = "GAME_STATUS_STOP";
    /**
     * 发牌事件
     */
    GameEvent.SHOW_POKER = "SHOW_POKER";
    /**
     * 游戏场数事件
     */
    GameEvent.GET_GAME_STAGE_INNING = "GET_GAME_STAGE_INNING";
    /**
     * 游戏倒计时事件
     */
    GameEvent.GET_GAME_TIME = "GET_GAME_TIME";
    /**
     * 游戏结算事件
     */
    GameEvent.GET_GAME_STAGE_PAYOUT = "GET_GAME_STAGE_PAYOUT";
    /**
     * 休息等待状态
     */
    GameEvent.GAME_STATUS_OK = "GAME_STATUS_OK";
    /**
     * 下注事件
     */
    GameEvent.ADD_BETAREA_AND_BETAMOUNT = "ADD_BETAREA_AND_BETAMOUNT";
    /**
     * 获取当前筹码事件
     */
    GameEvent.GET_CURRENT_BET_CHIP_NUM = "GET_CURRENT_BET_CHIP_NUM";
    /**
     * 设置当前使用的筹码组事件
     */
    GameEvent.SET_USING_CHIP_GROUP = "SET_USING_CHIP_GROUP";
    /**
     * 设置筹码确认按钮能否下注事件
     */
    GameEvent.SET_CHIPS_CONFIRM_BTN = "SET_CHIPS_CONFIRM_BTN";
    /**
     * 取消下注事件
     */
    GameEvent.CANCEL_BET_AMOUNT = "CANCEL_BET_AMOUNT";
    /**
     * 确认下注事件
     */
    GameEvent.CONFIRM_BET_AMOUNT = "CONFIRM_BET_AMOUNT";
    /**
     * 确认是否已经下注
     */
    GameEvent.ASK_IS_BET = "ASK_IS_BET";
    /**
     * 设置筹码成功
     */
    GameEvent.SET_CHIPS_SUCCESS = "SET_CHIPS_SUCCESS";
    /**
     * 获取玩家网络质量
     */
    GameEvent.GET_PLAYER_NETWORK = "GET_PLAYER_NETWORK";
    /**
     * 退出桌号
     */
    GameEvent.QUITE_TABLE = "QUITE_TABLE";
    /**
     * 发送聊天
     */
    GameEvent.GAME_CHAT_PUSH = "GAME_CHAT_PUSH";
    /**
     * 发送聊天成功
     */
    GameEvent.GAME_CHAT_SUCCES = "GAME_CHAT_SUCCES";
    /**
     *发送表情
     */
    GameEvent.GAME_CHAT_BQ = "GAME_CHAT_BQ";
    /**
     *重复下注
     */
    GameEvent.REBET_BET_AMOUNT = "REBET_BET_AMOUNT";
    /**
     *筹码变化
     */
    GameEvent.ALL_CHIPS_CHANGE = "ALL_CHIPS_CHANGE";
    /**
     *筹码修改返回变化
     */
    GameEvent.CHANGE_CHIPS_BACK = "CHANGE_CHIPS_BACK";
    /**
     *记录
     */
    GameEvent.GET_GAMERECORD = "GET_GAMERECORD";
    /**
     * 显示选择筹码界面
     */
    GameEvent.SHOW_ALLCHIPS = "SHOW_ALLCHIPS";
    return GameEvent;
}());
__reflect(GameEvent.prototype, "GameEvent");
var RouletteEvent = (function () {
    function RouletteEvent() {
    }
    /**
     * 游戏状态
     */
    RouletteEvent.GAME_STATE_START = "GAME_STATE_START";
    /**
     * 下注去是否可点击
     */
    RouletteEvent.SET_BET_BTN_CAN_CLICK = "SET_BET_BTN_CAN_CLICK";
    /**
     * 游戏状态OK
     */
    RouletteEvent.GAME_STATUS_OK = "GAME_STATUS_OK";
    /**
     * 获取游戏结果
     */
    RouletteEvent.GET_GAME_RESULT = "GET_GAME_RESULT";
    /**
     * 获取结果的值
     */
    RouletteEvent.RESULT_BET_BTN_ADD_MASK = "RESULT_BET_BTN_ADD_MASK";
    /**
     * 下注筹码
     */
    RouletteEvent.ADD_BETAREA_AND_BETAMOUNT = "ADD_BETAREA_AND_BETAMOUNT";
    /**
     * 取消没有确定的下注筹码
     */
    RouletteEvent.REMOVE_UNCONFIRM_CHIP = "REMOVE_UNCONFIRM_CHIP";
    /**
     * 确认下注
     */
    RouletteEvent.CONFIRM_CHIP = "CONFIRM_CHIP";
    /**
     * 停止下注
     */
    RouletteEvent.GAME_STATE_STOP = "GAME_STATE_STOP";
    /**
     * 获取桌号信息
     */
    RouletteEvent.GET_GAME_TABLE_CONFIG = "GET_GAME_TABLE_CONFIG";
    /**
     * 发送重复下注数据
     */
    RouletteEvent.SEND_REPEAT_DATA = "SEND_REPEAT_DATA";
    /**
     * 小费打赏成功
     */
    RouletteEvent.GET_REWARD_ANCHOR = "GET_REWARD_ANCHOR";
    /**
     * 法式下注区
     */
    RouletteEvent.FRENCH_CLICK_BET_BTN = "FRENCH_CLICK_BET_BTN";
    RouletteEvent.FRENCH_CLICK_END_BET_BTN = "FRENCH_CLICK_END_BET_BTN";
    RouletteEvent.FRENCH_CLICK_BET_DATA = "FRENCH_CLICK_BET_DATA";
    /**
     * 手机端法式下注区
     */
    RouletteEvent.MOBILE_FRENCH_AREA = "MOBILE_FRENCH_AREA";
    /**
     * 点击下注
     */
    RouletteEvent.BEGIN_CLICK_BET_AREA = "GET_CLICK_BET_AREA";
    RouletteEvent.END_CLICK_BET_AREA = "END_CLICK_BET_AREA";
    return RouletteEvent;
}());
__reflect(RouletteEvent.prototype, "RouletteEvent");
var RecordEvent = (function () {
    function RecordEvent() {
    }
    /**
     *设置日期表日期事件
     */
    RecordEvent.GET_CALENDAR_DATE = "GET_CALENDAR_DATE";
    /**
     *设置日期表日期事件
     */
    RecordEvent.SET_CALENDAR_DATE = "SET_CALENDAR_DATE";
    /**
     *设置游戏类型事件
     */
    RecordEvent.SET_GAME_TYPE = "SET_GAME_TYPE";
    /**
     *设置游戏记录日期事件
     */
    RecordEvent.SET_GAMERECORD_DATA = "SET_GAMERECORD_DATA";
    /**
     *翻页事件
     */
    RecordEvent.CHANGE_PAGEINDEX = "CHANGE_PAGEINDEX";
    /**
     *初始化页面事件
     */
    RecordEvent.SET_PAGEINDEX = "SET_PAGEINDEX";
    /**
     *设置页面总数事件
     */
    RecordEvent.SET_PAGE_TOTALCOUNT = "SET_PAGE_TOTALCOUNT";
    return RecordEvent;
}());
__reflect(RecordEvent.prototype, "RecordEvent");
var VideoEvent = (function () {
    function VideoEvent() {
    }
    /**
     * 更新视频事件
     */
    VideoEvent.UPDATE_VIDEO = "UPDATE_VIDEO";
    /**
     * 修改视频线路事件
     */
    VideoEvent.CHANGE_VIDEO_LINE = "CHANGE_VIDEO_LINE";
    /**
     * 修改视频清晰度
     */
    VideoEvent.CHANGE_VIDEO_TYPE = "CHANGE_VIDEO_TYPE";
    /**
     * 播放
     */
    VideoEvent.PLAYING_VIDEO = "PLAYING_VIDEO";
    /**
     * 多台模式切换
     */
    VideoEvent.TABLE_CHANGE_VIDEO = "TABLE_CHANGE_VIDEO";
    return VideoEvent;
}());
__reflect(VideoEvent.prototype, "VideoEvent");
var ReportEvent = (function () {
    function ReportEvent() {
    }
    /**
     * 设置日期表日期事件
     */
    ReportEvent.SET_CLICK_DATE = "SET_CLICK_DATE";
    /**
     * 设置开始日期事件
     */
    ReportEvent.SET_REPORTS_START_DATE = "SET_REPORTS_START_DATE";
    /**
     * 设置结束日期事件
     */
    ReportEvent.SET_REPORTS_END_DATE = "SET_REPORTS_END_DATE";
    return ReportEvent;
}());
__reflect(ReportEvent.prototype, "ReportEvent");
var MyMouseEvent = (function () {
    function MyMouseEvent() {
    }
    /**
     *下注去鼠标点击
     */
    MyMouseEvent.MOUSE_OVER_BET_BTN = "MOUSE_OVER_BET_BTN";
    /**
     *下注去鼠标离去
     */
    MyMouseEvent.MOUSE_OUT_BET_BTN = "MOUSE_OUT_BET_BTN";
    /**
     * 法式下注区
     */
    MyMouseEvent.FRENCH_MOUSE_OVER_BET_BTN = "FRENCH_MOUSE_OVER_BET_BTN";
    /**
     * 法式下注去鼠标离去
     */
    MyMouseEvent.FRENCH_MOUSE_OUT_BET_BTN = "FRENCH_MOUSE_OUT_BET_BTN";
    /**
     * 法式下注区数据
     */
    MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA = "FRENCH_MOUSE_OVER_BET_DATA";
    /**
     * 法式下注区数据
     */
    MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA = "FRENCH_MOUSE_OUT_BET_DATA";
    return MyMouseEvent;
}());
__reflect(MyMouseEvent.prototype, "MyMouseEvent");
//# sourceMappingURL=EventType.js.map