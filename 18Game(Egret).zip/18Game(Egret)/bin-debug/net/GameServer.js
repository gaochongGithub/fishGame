var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GameServer = (function (_super) {
    __extends(GameServer, _super);
    function GameServer() {
        return _super.call(this) || this;
    }
    GameServer.prototype.connectServer = function () {
        var _this = this;
        App.Socket.connect();
        App.MessageCenter.addListener(SocketConst.SOCKET_CONNECT, function () {
            Log.debug("与服务器连接上");
            App.TimerManager.doTimer(3000, 0, _this.sendAutoID, _this);
            //this.sendLogin();
        }, this);
    };
    GameServer.prototype.sendAutoID = function () {
        var msg = {};
        msg.key = "proto.AutoID";
        msg.command = proto.Command.client_heart_beat;
        msg.body = {
            id: 0,
        };
        App.Socket.send(msg);
    };
    GameServer.prototype.sendLogin = function (name, pwd, way, ip, platform, version, time) {
        var msg = {};
        msg.key = "proto.UserRequest.LobbyLogin";
        msg.body = {
            name: name,
            passwd: md5.getSingtonInstance().hex_md5(pwd),
            way: way,
            ip: ip,
            platform: platform,
            version: version,
            time: time
        };
        msg.command = proto.Command.user_lobby_login;
        App.Socket.send(msg);
    };
    //发送筹码组
    GameServer.prototype.sendchipGroup = function (chipGroup, selectedLimit) {
        var msg = {};
        msg.key = "proto.Lobby.ChangeChipGroup";
        msg.body = {
            chipgroup: chipGroup,
            selectedLimit: selectedLimit,
        };
        msg.command = proto.Command.lobby_change_chipgroup;
        App.Socket.send(msg);
    };
    //大厅登出
    GameServer.prototype.sendLobbyLogout = function () {
        var msg = {};
        msg.key = "proto.UserRequest.LobbyLogout";
        msg.body = {};
        msg.command = proto.Command.user_lobby_logout;
        App.Socket.send(msg);
    };
    GameServer.prototype.sendGameLogin = function () {
    };
    //进入连环桌前拉取数据
    GameServer.prototype.sendChainPrepare = function () {
    };
    //进桌
    GameServer.prototype.sendJoinTable = function (gameType, tableID, joinType) {
        var msg = {};
        msg.key = "proto.Game.JoinTable";
        msg.body = {
            gameType: gameType,
            tableID: tableID,
            joinType: joinType
        };
        msg.command = proto.Command.game_join_table;
        App.Socket.send(msg);
    };
    //离桌
    GameServer.prototype.sendLeaveTable = function (tableID, gameType) {
        var msg = {};
        msg.key = "proto.Game.LeaveTable";
        msg.body = {
            gameType: gameType,
            tableID: tableID,
        };
        msg.command = proto.Command.game_leave_table;
        App.Socket.send(msg);
    };
    //退出游戏
    GameServer.prototype.sendGameExit = function () {
    };
    //下注
    GameServer.prototype.sendBet = function (tableID, subtype, detail, selectedLimit) {
        var msg = {};
        msg.key = "proto.Game.Bet";
        msg.body = {
            tableID: tableID,
            subtype: subtype,
            detail: detail,
            selectedLimit: selectedLimit
        };
        msg.command = proto.Command.game_bet;
        App.Socket.send(msg);
    };
    //发送Report.GameRecord数据
    GameServer.prototype.sendGameRecord = function (starttime, endtime, gameType, tableID, shoe, pageSize, pageIndex) {
        var msg = {};
        msg.key = "proto.Report.GameResult";
        msg.body = {
            starttime: starttime,
            endtime: endtime,
            gameType: gameType,
            tableID: tableID,
            shoe: shoe,
            pageSize: pageSize,
            pageIndex: pageIndex
        };
        msg.command = proto.Command.report_game_report;
        App.Socket.send(msg);
    };
    //报表查询
    GameServer.prototype.sendReportWinlose = function (starttime, endtime) {
        var msg = {};
        msg.key = "proto.Report.WinLose";
        msg.body = {
            starttime: starttime,
            endtime: endtime
        };
        msg.command = proto.Command.report_winlose;
        App.Socket.send(msg);
    };
    //发送聊天数据
    GameServer.prototype.sendChat = function (tableId, message) {
        var msg = {};
        msg.key = "proto.Chat.ChatReq";
        msg.body = {
            tableId: tableId,
            message: message
        };
        msg.command = proto.Command.game_chat;
        App.Socket.send(msg);
    };
    //发送小费
    GameServer.prototype.sendReward = function (tableId, type, amount) {
        var msg = {};
        msg.key = "proto.Game.Tip";
        msg.body = {
            tableID: tableId,
            type: type,
            amount: amount
        };
        msg.command = proto.Command.game_tip;
        App.Socket.send(msg);
    };
    //请求历史聊天记录
    GameServer.prototype.loadChatReq = function (tableId) {
        var msg = {};
        msg.key = "proto.Chat.LoadChatReq";
        msg.body = {
            tableId: tableId,
        };
        msg.command = proto.Command.game_load_chat;
        App.Socket.send(msg);
    };
    return GameServer;
}(SingtonClass));
__reflect(GameServer.prototype, "GameServer");
//# sourceMappingURL=GameServer.js.map