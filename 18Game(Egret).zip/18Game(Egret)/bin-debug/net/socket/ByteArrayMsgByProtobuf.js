var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 数据封装，接收
 */
var ByteArrayMsgByProtobuf = (function (_super) {
    __extends(ByteArrayMsgByProtobuf, _super);
    /**
     * 构造函数
     */
    function ByteArrayMsgByProtobuf() {
        var _this = _super.call(this) || this;
        _this.msgClass = null;
        _this.protoConfig = null;
        _this.protoConfigSymmetry = null;
        _this.heartCount = 0;
        _this.msgClass = {};
        _this.protoConfig = App.ProtoConfig;
        _this.protoConfigSymmetry = {};
        var keys = Object.keys(_this.protoConfig);
        for (var i = 0, len = keys.length; i < len; i++) {
            var key = keys[i];
            var value = _this.protoConfig[key];
            _this.protoConfigSymmetry[value] = key;
        }
        return _this;
    }
    /**
     * 获取msgID对应的类
     * @param key
     * @returns {any}
     */
    ByteArrayMsgByProtobuf.prototype.getMsgClass = function (key) {
        var cls = this.msgClass[key];
        if (cls == null) {
            cls = egret.getDefinitionByName(key);
            this.msgClass[key] = cls;
        }
        return cls;
    };
    /**
     * 获取msgID
     * @param key
     * @returns {any}
     */
    ByteArrayMsgByProtobuf.prototype.getMsgID = function (key) {
        return this.protoConfigSymmetry[key];
    };
    /**
     * 获取msgKey
     * @param msgId
     * @returns {any}
     */
    ByteArrayMsgByProtobuf.prototype.getMsgKey = function (msgId) {
        return this.protoConfig[msgId];
    };
    ByteArrayMsgByProtobuf.prototype.decodeDetail = function (command, bytes) {
        // console.log("收到消息"+command);
        switch (command) {
            case proto.Command.client_heart_beat_ack:
                this.receiveHeart(bytes);
                break;
            case proto.Command.user_lobby_login_ack:
                this.receiveLogin(bytes);
                break;
            case proto.Command.user_lobby_logout_ack:
                this.receiveLogout(bytes);
                break;
            case proto.Command.lobby_player_push:
                this.receiveLobbyPlayerInfo(bytes);
                break;
            case proto.Command.lobby_videourl_push:
                this.receiveLiveVideoUrl(bytes);
                break;
            case proto.Command.lobby_status_push:
                this.receiveLobbyTableInfo(bytes);
                break;
            case proto.Command.lobby_playercount_push:
                this.receivePlayerCountInfo(bytes);
                break;
            case proto.Command.game_join_table_ack:
                this.receiveJoinTableLogin(bytes);
                break;
            case proto.Command.game_table_status_push:
                this.receiveGameTableStatus(bytes);
                break;
            case proto.Command.game_table_config_push:
                this.receiveGameTableConfig(bytes);
                break;
            case proto.Command.game_table_history_push:
                this.receiveGameTableHistory(bytes);
                break;
            case proto.Command.game_player_push:
                this.receiveGameUserSnapshot(bytes);
                break;
            case proto.Command.game_virtual_table_push:
                this.receiveGamVirtualTable(bytes);
                break;
            case proto.Command.game_virtual_bet_push:
                this.receiveGamVirtualTableBet(bytes);
                break;
            case proto.Command.game_bet_ack:
                this.receiveGameBetInfo(bytes);
                break;
            case proto.Command.report_game_report_ack:
                this.receiveGameRecord(bytes);
                break;
            case proto.Command.report_winlose_ack:
                this.receiveReportWinlose(bytes);
                break;
            case proto.Command.server_message_push:
                this.receiveServerMessagePush(bytes);
                break;
            case proto.Command.server_announce_push:
                this.receiveAnnounce(bytes);
                break;
            case proto.Command.lobby_change_chipgroup_ack:
                this.receiveChangeChip(bytes);
                break;
            case proto.Command.game_chain_prepare_ack:
                this.receiveChainPrePare(bytes);
                break;
            case proto.Command.game_round_count_push:
                this.receiveGameRoundCount(bytes);
            case proto.Command.game_chat_ack:
                this.receiveGameChatAck(bytes);
                break;
            case proto.Command.game_chat_push:
                this.receiveGameChatPush(bytes);
                break;
            case proto.Command.game_tip_ack:
                this.receiveReward(bytes);
                break;
            case proto.Command.game_load_chat_ack:
                this.receiveLoadChat(bytes);
                break;
            default:
                break;
        }
    };
    /**
     * 解析数据包
     */
    //心跳返回
    ByteArrayMsgByProtobuf.prototype.getAutoID = function (bytes) {
        return proto.AutoID.decode(bytes);
    };
    //获取proto.CommonReley
    ByteArrayMsgByProtobuf.prototype.getCommonReply = function (bytes) {
        return proto.CommonReply.decode(bytes);
    };
    //获取proto.Str数据
    ByteArrayMsgByProtobuf.prototype.getStr = function (bytes) {
        return proto.String.decode(bytes);
    };
    //获取Lobby.UserSnapshot数据
    ByteArrayMsgByProtobuf.prototype.getLobbyUserSnapshot = function (bytes) {
        return proto.Lobby.UserSnapshot.decode(bytes);
    };
    //获取Lobby.TableSnapshot数据
    ByteArrayMsgByProtobuf.prototype.getLobbyTableSanpshot = function (bytes) {
        return proto.Lobby.TableSnapshot.decode(bytes);
    };
    //获取Game.TableStatus数据
    ByteArrayMsgByProtobuf.prototype.getGameTableStatus = function (bytes) {
        return proto.Game.TableStatus.decode(bytes);
    };
    //获取Game.TableConfig
    ByteArrayMsgByProtobuf.prototype.getGameTableConfig = function (bytes) {
        return proto.Game.TableConfig.decode(bytes);
    };
    //获取Game.TableHistory
    ByteArrayMsgByProtobuf.prototype.getGameTableHistory = function (bytes) {
        return proto.Game.TableHistory.decode(bytes);
    };
    //获取Game.UserSnapshot数据
    ByteArrayMsgByProtobuf.prototype.getGameUserSanpshot = function (bytes) {
        return proto.Game.UserSnapshot.decode(bytes);
    };
    //获取Game.VirtualTable.Table数据
    ByteArrayMsgByProtobuf.prototype.getGameVirtualTable = function (bytes) {
        return proto.Game.VirtualTable.Table.decode(bytes);
    };
    //获取Game.VirtualTable.Bet数据
    ByteArrayMsgByProtobuf.prototype.getGameVirtualTableBet = function (bytes) {
        return proto.Game.VirtualTable.Bet.decode(bytes);
    };
    //获取Report.GameResultReply数据
    ByteArrayMsgByProtobuf.prototype.getGameResultReply = function (bytes) {
        return proto.Report.GameResultReply.decode(bytes);
    };
    //获取Report.WinloseReply数据
    ByteArrayMsgByProtobuf.prototype.getWinloseReply = function (bytes) {
        return proto.Report.WinLoseReply.decode(bytes);
    };
    //AnnouncePush数据
    ByteArrayMsgByProtobuf.prototype.getAnnouncePush = function (bytes) {
        return proto.AnnouncePush.decode(bytes);
    };
    //拉取数据返回
    ByteArrayMsgByProtobuf.prototype.getPrepareReply = function (bytes) {
        return proto.Game.EnterChainTable.decode(bytes);
    };
    //获取是否成功小费
    ByteArrayMsgByProtobuf.prototype.getRewardAnchor = function (bytes) {
        return proto.CommonReply.decode(bytes);
    };
    //拉取每局下注统计
    ByteArrayMsgByProtobuf.prototype.getRoundCount = function (bytes) {
        return proto.Game.RoundCount.decode(bytes);
    };
    //聊天
    ByteArrayMsgByProtobuf.prototype.getChatVOList = function (bytes) {
        return proto.Chat.ChatVOList.decode(bytes);
    };
    //聊天历史
    ByteArrayMsgByProtobuf.prototype.getLoadChat = function (bytes) {
        return proto.Chat.LoadChatResponse.decode(bytes);
    };
    ByteArrayMsgByProtobuf.prototype.getPlayerCount = function (bytes) {
        return proto.Lobby.PlayerCount.decode(bytes);
    };
    /**
     * 处理相关业务逻辑
     */
    ByteArrayMsgByProtobuf.prototype.receiveLoadChat = function (bytes) {
        var loadChat = this.getLoadChat(bytes);
        if (loadChat)
            App.MessageCenter.dispatch(LobbyEvent.LOAD_CHAT_ACK, loadChat);
    };
    ByteArrayMsgByProtobuf.prototype.receiveChangeChip = function (bytes) {
        var changchip = this.getCommonReply(bytes);
        App.MessageCenter.dispatch(GameEvent.CHANGE_CHIPS_BACK, changchip);
    };
    ByteArrayMsgByProtobuf.prototype.receiveHeart = function (bytes) {
        var obj = this.getAutoID(bytes);
        //Log.debug("heartAck",obj);
    };
    //11
    ByteArrayMsgByProtobuf.prototype.receiveLogin = function (bytes) {
        var login = this.getCommonReply(bytes);
        if (login)
            App.MessageCenter.dispatch(LobbyEvent.LOGIN_SUCCES, login);
    };
    ByteArrayMsgByProtobuf.prototype.getLoginCode = function (login) {
        // switch(login.code) {
        //     case proto.CommonReply.Code.SUCCESS:
        //         App.MessageCenter.dispatch(LobbyEvent.LOGIN_SUCCES,login);
        //         break;
        //     case proto.CommonReply.Code.ERR_SERVER_INTERNAL_ERROR : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_500");
        //         break;
        //     case proto.CommonReply.Code.ERR_AUTHFAIL : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_401");
        //         break;
        //     case proto.CommonReply.Code.ERR_USER_UNUSABLE : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_6");
        //         break;
        // }
    };
    ByteArrayMsgByProtobuf.prototype.receiveLogout = function (bytes) {
        var logout = this.getCommonReply(bytes);
    };
    //600
    ByteArrayMsgByProtobuf.prototype.receiveLobbyPlayerInfo = function (bytes) {
        HallDataCtrl.instance.setLobbyPlayer(this.getLobbyUserSnapshot(bytes));
        App.MessageCenter.dispatch(ServerEvent.GET_LOBBY_PLAYER_INFO);
    };
    //601
    ByteArrayMsgByProtobuf.prototype.receiveLiveVideoUrl = function (bytes) {
        var liveVideoUrl = this.getStr(bytes);
        //Log.debug("liveVideoUrl",liveVideoUrl);
    };
    //602
    ByteArrayMsgByProtobuf.prototype.receiveLobbyTableInfo = function (bytes) {
        var lobbyTableInfo = this.getLobbyTableSanpshot(bytes);
        if (lobbyTableInfo.tableID && lobbyTableInfo.tableID != 0) {
            LobbyTableInfoCtrl.instance.setLobbyTableInfo(lobbyTableInfo);
        }
    };
    //603
    ByteArrayMsgByProtobuf.prototype.receivePlayerCountInfo = function (bytes) {
        var playerCount = this.getPlayerCount(bytes);
        HallDataCtrl.instance.setPlayerCount(playerCount.count);
        App.MessageCenter.dispatch(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO);
    };
    ByteArrayMsgByProtobuf.prototype.receiveChainPrePare = function (bytes) {
        var enterchainTable = this.getPrepareReply(bytes);
    };
    ByteArrayMsgByProtobuf.prototype.receiveJoinTableLogin = function (bytes) {
        var joinTable = this.getCommonReply(bytes);
    };
    // private receiveGameExit(bytes){
    // }
    ByteArrayMsgByProtobuf.prototype.receiveGameTableStatus = function (bytes) {
        var gamestatus = this.getGameTableStatus(bytes);
        App.MessageCenter.dispatch(ServerEvent.GET_GAME_STATUS, gamestatus);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameTableConfig = function (bytes) {
        var gameTableConfig = this.getGameTableConfig(bytes);
        // console.log(gameTableConfig , "gameTableConfig");
        App.MessageCenter.dispatch(RouletteEvent.GET_GAME_TABLE_CONFIG, gameTableConfig);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameTableHistory = function (bytes) {
        var tableHistory = this.getGameTableHistory(bytes);
        App.MessageCenter.dispatch(ServerEvent.GET_GAME_TABLE_HISTORY, tableHistory);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameUserSnapshot = function (bytes) {
        var gameUserInfo = this.getGameUserSanpshot(bytes);
        App.MessageCenter.dispatch(ServerEvent.GET_GAME_USER_INFO, gameUserInfo);
        //Log.debug(gameUserInfo);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGamVirtualTable = function (bytes) {
        var virtualTable = this.getGameVirtualTable(bytes);
        // console.log(virtualTable , "进桌获取信息");
        App.MessageCenter.dispatch(ServerEvent.UPDATE_VIRTUAL_TABLE, virtualTable);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGamVirtualTableBet = function (bytes) {
        var virtualTableBet = this.getGameVirtualTableBet(bytes);
        App.MessageCenter.dispatch(ServerEvent.UPDATE_VIRTUAL_TABLE_BET, virtualTableBet);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameBetInfo = function (bytes) {
        var betInfo = this.getCommonReply(bytes);
        if (betInfo.code == 0) {
            // App.MessageCenter.dispatch(GameEvent.CONFIRM_BET_AMOUNT);
            // GameDataCtrl.instance.isBet = true;
        }
        else {
            //弹出提示内容
            // alert(betInfo.desc)
        }
        switch (betInfo.code) {
            case proto.CommonReply.Code.SUCCESS:
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_0");
                App.MessageCenter.dispatch(GameEvent.CONFIRM_BET_AMOUNT);
                GameDataCtrl.instance.isBet = true;
                break;
            case proto.CommonReply.Code.ERR_EXCEED_LIMIT:
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_7");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
            case proto.CommonReply.Code.ERR_ACCOUT_LOCK:
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_5");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
            default:
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_8");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
        }
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameRecord = function (bytes) {
        var gameRecord = this.getGameResultReply(bytes);
        App.MessageCenter.dispatch(GameEvent.GET_GAMERECORD, gameRecord);
    };
    ByteArrayMsgByProtobuf.prototype.receiveReportWinlose = function (bytes) {
        var winlose = this.getWinloseReply(bytes);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameRoundCount = function (bytes) {
        var roundCount = this.getRoundCount(bytes);
    };
    ByteArrayMsgByProtobuf.prototype.receiveServerMessagePush = function (bytes) {
        var command = this.getCommonReply(bytes);
        switch (command.code) {
            case proto.CommonReply.Code.ERR_OTHER_LOGIN:
                App.ToastViewManager.toastServerView("TEXT_OUT");
                break;
            case proto.CommonReply.Code.ERR_LAST_3_GAME:
                App.ToastViewManager.toastTextView("TEXT_Last_3_Times");
                break;
            case proto.CommonReply.Code.ERR_KICKED:
                var game = HallDataCtrl.instance.getLoadGameData;
                App.GameServer.sendLeaveTable(game.getTableID, game.getGameType);
                GameSceneCtrl.instance.toHallScene();
                break;
        }
    };
    ByteArrayMsgByProtobuf.prototype.receiveAnnounce = function (bytes) {
        this.getAnnouncePush(bytes);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameChatAck = function (bytes) {
        var command = this.getCommonReply(bytes);
        if (command)
            App.MessageCenter.dispatch(GameEvent.GAME_CHAT_SUCCES, command);
    };
    ByteArrayMsgByProtobuf.prototype.receiveGameChatPush = function (bytes) {
        var chatVOList = this.getChatVOList(bytes);
        if (chatVOList)
            App.MessageCenter.dispatch(GameEvent.GAME_CHAT_PUSH, chatVOList);
    };
    ByteArrayMsgByProtobuf.prototype.receiveReward = function (bytes) {
        var result = this.getRewardAnchor(bytes);
        if (result.code == 0) {
            App.MessageCenter.dispatch(RouletteEvent.GET_REWARD_ANCHOR);
            App.ToastViewManager.toastTextView("TEXT_REWARD_SUCCESSFUL");
        }
        else if (result.code == 2) {
            App.ToastViewManager.toastTextView("TEXT_BET_RESULT_4");
        }
        else {
            App.ToastViewManager.toastTextView("TEXT_REWARD_FAILURE");
        }
    };
    /**
     * 消息解析
     * @param msg
     */
    ByteArrayMsgByProtobuf.prototype.decode = function (msg) {
        var msgID = msg.readInt();
        var command = msg.readShort();
        var len = msg.byteLength;
        var byteArray = new egret.ByteArray();
        var buffer = msg.readBytes(byteArray);
        var obj = {};
        App.DebugUtils.start("Protobuf Decode");
        //obj.body = proto.AutoID.decode(byteArray.bytes);
        this.decodeDetail(command, byteArray.bytes);
        App.DebugUtils.stop("Protobuf Decode");
        //Log.debug("收到数据：",command,obj);
        return obj;
    };
    /**
     * 消息封装
     * @param msg
     */
    ByteArrayMsgByProtobuf.prototype.encode = function (msg) {
        //var msgID = this.getMsgID(msg.key);
        var msgClass = this.getMsgClass(msg.key);
        var msgBody = msgClass.fromObject(msg.body);
        var msgBuffer = msgClass.encode(msgBody).finish();
        App.DebugUtils.start("Protobuf Encode");
        var bodyBytes = new egret.ByteArray(msgBuffer);
        App.DebugUtils.stop("Protobuf Encode");
        // Log.debug("发送数据：", msg.body);
        var sendMsg = new egret.ByteArray();
        sendMsg.writeInt(this.heartCount);
        sendMsg.writeShort(msg.command);
        sendMsg.writeBytes(bodyBytes);
        this.heartCount++;
        return sendMsg;
    };
    return ByteArrayMsgByProtobuf;
}(ByteArrayMsg));
__reflect(ByteArrayMsgByProtobuf.prototype, "ByteArrayMsgByProtobuf");
//# sourceMappingURL=ByteArrayMsgByProtobuf.js.map