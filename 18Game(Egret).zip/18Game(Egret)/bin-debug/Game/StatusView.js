var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 状态显示，pc Mobile通用
 */
var StatusView = (function (_super) {
    __extends(StatusView, _super);
    function StatusView() {
        var _this = _super.call(this) || this;
        _this.isStart = false;
        _this.isStop = false;
        _this.skinName = "resource/skins/baccarat/StatusViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    StatusView.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
    };
    StatusView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
    };
    StatusView.prototype.getGameStatus = function (data) {
        var status = data.status;
        //console.log("状态"+status);
        switch (status) {
            case Status.Shuffle:
                //App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
                this.hideTime();
                this.shuffleDelay();
                //},this);
                break;
            case Status.Start:
                this.getGameStatusStart(data);
                break;
            case Status.Stop:
                this.getGameStatusStop();
                break;
            case Status.Payout:
                this.getGameStatusPayout();
                break;
            case Status.OK:
                //App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
                this.hideTime();
                this.restDelay();
                //},this);
                break;
            case Status.Invalied:
                break;
            default:
                break;
        }
    };
    StatusView.prototype.getGameStatusStart = function (getGameStatus) {
        if (!this.isStart) {
            //this.clearDelay();
            this.isStart = true;
            this.startDelay();
        }
        //App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
        this.getCountDownTimeEvent(getGameStatus.time);
        //},this);
    };
    StatusView.prototype.getGameStatusStop = function () {
        if (!this.isStop) {
            this.isStop = true;
        }
        //App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
        this.hideTime();
        this.stopDelay();
        //},this);
    };
    StatusView.prototype.getGameStatusPayout = function () {
        this.isStart = false;
        //App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
        this.hideTime();
        this.payoutDelay();
        //},this);
    };
    StatusView.prototype.hideTime = function () {
        this.image_status.horizontalCenter = 0;
        this.label_time.visible = false;
    };
    StatusView.prototype.getCountDownTimeEvent = function (time) {
        this.label_time.text = time.toString();
        if (time <= 10 && time > 0) {
            this.label_time.textColor = 0xFF0000;
            egret.Tween.get(this.label_time, { loop: false })
                .to({ scaleX: 1.8, scaleY: 1.8 }, 200)
                .to({ scaleX: 1, scaleY: 1 }, 200)
                .call(function () { });
        }
        else {
            this.label_time.textColor = 0xFFFFFF;
        }
    };
    StatusView.prototype.shuffleDelay = function () {
        this.image_status.texture = RES.getRes("status_shuffle_png");
    };
    StatusView.prototype.startDelay = function () {
        this.image_status.horizontalCenter = -40;
        this.label_time.visible = true;
        this.image_status.texture = RES.getRes("status_begin_png");
    };
    StatusView.prototype.stopDelay = function () {
        this.image_status.texture = RES.getRes("status_poker_png");
    };
    StatusView.prototype.payoutDelay = function () {
        this.image_status.texture = RES.getRes("status_payout_png");
    };
    StatusView.prototype.restDelay = function () {
        this.image_status.texture = RES.getRes("status_rest_png");
    };
    StatusView.prototype.clearDelay = function () {
        App.TimerManager.removeAll(this);
    };
    return StatusView;
}(eui.Component));
__reflect(StatusView.prototype, "StatusView");
//# sourceMappingURL=StatusView.js.map