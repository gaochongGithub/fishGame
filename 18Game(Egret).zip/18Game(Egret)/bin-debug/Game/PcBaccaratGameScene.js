var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 百家乐主场景
 */
var PcBaccaratGameScene = (function (_super) {
    __extends(PcBaccaratGameScene, _super);
    function PcBaccaratGameScene() {
        var _this = _super.call(this) || this;
        _this.isStart = false;
        _this.isStop = false;
        _this.imageWinStr = "";
        _this.gameReuslt = "";
        _this.skinName = "resource/skins/baccarat/PcBaccaratGameSceneSkin.exml";
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        return _this;
    }
    PcBaccaratGameScene.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        App.MessageCenter.removeListener(GameEvent.SHOW_ALLCHIPS, this.showAllChips, this);
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
        this.btn_showRoom.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnShowRoom, this);
    };
    PcBaccaratGameScene.prototype.onAddtoStage = function () {
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        App.MessageCenter.addListener(GameEvent.SHOW_ALLCHIPS, this.showAllChips, this);
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
        this.btn_showRoom.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnShowRoom, this);
        this.joinTable();
    };
    PcBaccaratGameScene.prototype.getGameUserInfoEvent = function (gameUserInfo) {
        if (GameDataCtrl.instance.gameStatus.status == Status.Payout) {
            var winlose = gameUserInfo.winlose;
            var winStr = "";
            if (Number(winlose) >= 0) {
                winStr = App.LangUtils.getStr("TEXT_TABLE_WIN");
            }
            else {
                winStr = App.LangUtils.getStr("TEXT_TABLE_LOSE");
            }
            App.ToastViewManager.toastResultView(this.gameReuslt, winStr + winlose, this.imageWinStr);
        }
    };
    PcBaccaratGameScene.prototype.updateVirtualTable = function (table) {
        for (var key in table.seats) {
            if (HallDataCtrl.instance.getLobbyPlayer.uid == table.seats[key].uid) {
                if (JSON.stringify(table.seats[key].betinfo) !== '{}' && GameDataCtrl.instance.gameStatus.status !== 3) {
                    GameDataCtrl.instance.isBet = true;
                }
            }
        }
    };
    PcBaccaratGameScene.prototype.joinTable = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        var gameType = loadGameModel.getGameType;
        var tableID = loadGameModel.getTableID;
        var joinType = Number(loadGameModel.getJoinType);
        App.GameServer.sendJoinTable(gameType, tableID, joinType);
    };
    PcBaccaratGameScene.prototype.getGameStatus = function (gameStatus) {
        App.MessageCenter.dispatch(GameEvent.GET_GAME_TIME, gameStatus.time);
        App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_INNING, { stage: gameStatus.stage, inning: gameStatus.inning });
        var status = gameStatus.status;
        GameDataCtrl.instance.gameStatus = gameStatus;
        switch (status) {
            case Status.Shuffle:
                App.ToastViewManager.toastBaseView("TEXT_SHUFFLE");
                break;
            case Status.Start:
                this.getStatusStart();
                break;
            case Status.Stop:
                this.getStatusStop(gameStatus.poker);
                break;
            case Status.Payout:
                this.getStatusPayout(gameStatus);
                break;
            case Status.OK:
                break;
            case Status.Invalied:
                break;
            default:
                break;
        }
    };
    PcBaccaratGameScene.prototype.getStatusShuffle = function () {
        App.MessageCenter.dispatch(GameEvent.GAME_STATUS_SHUFFLE);
        App.ToastViewManager.toastBaseView("TEXT_SHUFFLE");
    };
    PcBaccaratGameScene.prototype.getStatusStart = function () {
        if (!this.isStart) {
            this.isStart = true;
            App.ToastViewManager.toastBaseView("TEXT_MESSAGE_1");
            App.MessageCenter.dispatch(GameEvent.GAME_STATUS_START);
            //播放音频
            //下注状态重置
        }
    };
    PcBaccaratGameScene.prototype.getStatusStop = function (poker) {
        if (!this.isStop) {
            this.isStop = true;
            App.ToastViewManager.toastBaseView("TEXT_MESSAGE_2");
            App.MessageCenter.dispatch(GameEvent.GAME_STATUS_STOP);
            //this.pokerView.visible = true;
        }
        App.MessageCenter.dispatch(GameEvent.SHOW_POKER, poker);
    };
    PcBaccaratGameScene.prototype.getStatusPayout = function (data) {
        this.isStart = false;
        this.isStop = false;
        var hasBet = GameDataCtrl.instance.isBet;
        GameDataCtrl.instance.isBet = false;
        App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_PAYOUT, data);
        var result = data.result;
        this.gameReuslt = result;
        var imageStr = "";
        if (result == "a" || result == "b" || result == "c" || result == "d") {
            imageStr = "bankeWin_png";
        }
        else if (result == "e" || result == "f" || result == "g" || result == "h") {
            imageStr = "playerWin_png";
        }
        else if (result == "i" || result == "j" || result == "k" || result == "l") {
            imageStr = "tieWin_png";
        }
        else {
            return;
        }
        this.imageWinStr = imageStr;
        if (hasBet == false) {
            App.ToastViewManager.toastResultView(result, "", imageStr);
        }
    };
    PcBaccaratGameScene.prototype.getStatusOK = function () {
        App.MessageCenter.dispatch(GameEvent.GAME_STATUS_OK);
    };
    PcBaccaratGameScene.prototype.getStatusInvalid = function () {
        //无效状态
    };
    //清除delay
    PcBaccaratGameScene.prototype.clearDelay = function () {
    };
    PcBaccaratGameScene.prototype.showAllChips = function () {
        this.allChipsView.visible = !this.allChipsView.visible;
    };
    PcBaccaratGameScene.prototype.onClickBtnShowRoom = function () {
        this.changeTableView.visible = !this.changeTableView.visible;
    };
    return PcBaccaratGameScene;
}(eui.Component));
__reflect(PcBaccaratGameScene.prototype, "PcBaccaratGameScene");
//# sourceMappingURL=PcBaccaratGameScene.js.map