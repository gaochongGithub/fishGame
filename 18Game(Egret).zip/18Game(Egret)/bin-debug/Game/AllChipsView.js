var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 选择筹码界面
 */
var AllChipsView = (function (_super) {
    __extends(AllChipsView, _super);
    function AllChipsView() {
        var _this = _super.call(this) || this;
        _this.checkArr = [];
        _this.skinName = "resource/skins/baccarat/AllChipsViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    AllChipsView.prototype.onAddtoStage = function (event) {
        this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnConfirm, this);
        this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnCancel, this);
        App.MessageCenter.addListener(GameEvent.ALL_CHIPS_CHANGE, this.chipsChange, this);
        //监听修改筹码后返回
        App.MessageCenter.addListener(GameEvent.CHANGE_CHIPS_BACK, this.getChangChipsBack, this);
        this.init();
    };
    AllChipsView.prototype.init = function () {
    };
    AllChipsView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GameEvent.ALL_CHIPS_CHANGE, this.chipsChange, this);
    };
    AllChipsView.prototype.getChangChipsBack = function (data) {
        if (data.code == 0) {
            var gameType = HallDataCtrl.instance.getLoadGameData.getGameType;
            HallDataCtrl.instance.setChips(gameType, this.checkArr);
            App.MessageCenter.dispatch(GameEvent.SET_USING_CHIP_GROUP);
        }
        else {
            //提示修改筹码不成功
        }
    };
    AllChipsView.prototype.chipsChange = function (data) {
        this.checkArr = MyUtils.deeCopy(data, this.checkArr);
    };
    AllChipsView.prototype.onClickBtnConfirm = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        var selectedLimitID = loadGameModel.getLimitRedID;
        App.GameServer.sendchipGroup(this.checkArr, selectedLimitID);
        console.log(this.checkArr, selectedLimitID);
        this.visible = false;
    };
    AllChipsView.prototype.onClickBtnCancel = function () {
        this.visible = false;
    };
    AllChipsView.prototype.onClickChipBtn = function () {
    };
    return AllChipsView;
}(eui.Component));
__reflect(AllChipsView.prototype, "AllChipsView");
//# sourceMappingURL=AllChipsView.js.map