var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LangLabel = (function (_super) {
    __extends(LangLabel, _super);
    function LangLabel() {
        var _this = _super.call(this) || this;
        _this.langStr = "";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    LangLabel.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE, this.updateLang, this);
        this.updateLang();
    };
    LangLabel.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE, this.updateLang, this);
    };
    LangLabel.prototype.updateLang = function () {
        if (this.langStr) {
            //this.text = Lang.getStr(this.langStr);
            this.text = App.LangUtils.getStr(this.langStr);
        }
    };
    return LangLabel;
}(eui.Label));
__reflect(LangLabel.prototype, "LangLabel");
//# sourceMappingURL=LangLabel.js.map