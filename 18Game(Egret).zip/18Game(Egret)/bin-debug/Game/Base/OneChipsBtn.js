var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 筹码界面单个筹码
 */
var OneChipsBtn = (function (_super) {
    __extends(OneChipsBtn, _super);
    function OneChipsBtn() {
        var _this = _super.call(this) || this;
        _this.chipNum = 0;
        _this.chipIndex = 0;
        _this.skinName = "resource/skins/baccarat/OneChipsBtnSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    OneChipsBtn.prototype.onAddtoStage = function (event) {
        this.addEventListener(eui.UIEvent.CHANGE, this.onClickBtn, this);
        App.MessageCenter.addListener(GameEvent.SET_USING_CHIP_GROUP, this.updateChips, this);
        this.initChipNum();
    };
    OneChipsBtn.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GameEvent.SET_USING_CHIP_GROUP, this.updateChips, this);
        this.removeEventListener(eui.UIEvent.CHANGE, this.onClickBtn, this);
    };
    OneChipsBtn.prototype.initChipNum = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        var chips = loadGameModel.getChip;
        var allChips = loadGameModel.getAllChip;
        if (App.DeviceUtils.IsMobile) {
            this.chipNum = Number(allChips[this.chipIndex]);
        }
        else {
            this.chipNum = Number(chips[this.chipIndex]);
        }
        this.label_chipNum.text = this.chipNum.toString();
        for (var i = 0; i < allChips.length; i++) {
            if (allChips[i] == this.chipNum) {
                var key = (i == 9 ? 10 : "0" + (i + 1));
                this.image_up.source = RES.getRes("chips_normal_" + key + "_png");
                this.image_upAndSelected.source = RES.getRes("chips_select_" + key + "_png");
                break;
            }
        }
        if (this.chipIndex == 0) {
            this.selected = true;
            GameDataCtrl.instance.setCurrentBetChip = this.chipNum;
        }
    };
    OneChipsBtn.prototype.updateChips = function () {
        this.initChipNum();
    };
    OneChipsBtn.prototype.onClickBtn = function () {
        App.MessageCenter.dispatch(GameEvent.GET_CURRENT_BET_CHIP_NUM, this.chipNum);
        GameDataCtrl.instance.setCurrentBetChip = this.chipNum;
    };
    return OneChipsBtn;
}(eui.RadioButton));
__reflect(OneChipsBtn.prototype, "OneChipsBtn");
//# sourceMappingURL=OneChipsBtn.js.map