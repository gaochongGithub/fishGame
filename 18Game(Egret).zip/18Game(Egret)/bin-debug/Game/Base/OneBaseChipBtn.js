var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 选择筹码界面的单个筹码
 */
var OneBaseChipBtn = (function (_super) {
    __extends(OneBaseChipBtn, _super);
    function OneBaseChipBtn() {
        var _this = _super.call(this) || this;
        _this.chipIndex = 0;
        _this.indexArr = [];
        _this.checkArr = [];
        _this.skinName = "resource/skins/baccarat/OneBaseChipBtnSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    OneBaseChipBtn.prototype.onAddtoStage = function (event) {
        this.addEventListener(eui.UIEvent.CHANGE, this.onClickBtn, this);
        App.MessageCenter.addListener(GameEvent.ALL_CHIPS_CHANGE, this.chipsChange, this);
        this.initChipNum();
    };
    OneBaseChipBtn.prototype.onRemoveStage = function (event) {
        this.removeEventListener(eui.UIEvent.CHANGE, this.onClickBtn, this);
        App.MessageCenter.removeListener(GameEvent.ALL_CHIPS_CHANGE, this.chipsChange, this);
    };
    OneBaseChipBtn.prototype.chipsChange = function (data) {
        this.checkArr = MyUtils.deeCopy(data, this.checkArr);
        for (var i = 0; i < this.checkArr.length; i++) {
            if (this.checkArr[i] == this.chipNum) {
                this.selected = true;
                break;
            }
            else {
                this.selected = false;
            }
        }
    };
    OneBaseChipBtn.prototype.onClickBtn = function () {
        this.checkArr.sort(function (n1, n2) {
            return n1 - n2;
        });
        if (this.chipNum && this.selected) {
            if (this.checkArr.length > 4) {
                this.checkArr.splice(0, 1);
                this.checkArr.push(this.chipNum);
            }
            else {
                this.checkArr.push(this.chipNum);
            }
        }
        else {
            for (var i = 0; i < this.checkArr.length; i++) {
                if (this.checkArr[i] == this.chipNum) {
                    this.checkArr.splice(i, 1);
                }
            }
        }
        App.MessageCenter.dispatch(GameEvent.ALL_CHIPS_CHANGE, this.checkArr);
    };
    OneBaseChipBtn.prototype.initChipNum = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        var chips = loadGameModel.getChip;
        var allChips = loadGameModel.getAllChip;
        this.chipNum = allChips[this.chipIndex];
        this.label_chipNum.text = this.chipNum.toString();
        for (var i = 0; i < chips.length; i++) {
            this.checkArr[i] = chips[i];
        }
        for (var i = 0; i < chips.length; i++) {
            if (this.chipNum == chips[i]) {
                this.selected = true;
            }
        }
    };
    return OneBaseChipBtn;
}(eui.CheckBox));
__reflect(OneBaseChipBtn.prototype, "OneBaseChipBtn");
//# sourceMappingURL=OneBaseChipBtn.js.map