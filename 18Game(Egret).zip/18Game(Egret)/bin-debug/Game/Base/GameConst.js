var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var GameConst = (function () {
    function GameConst() {
    }
    // public constructor() {
    // }
    GameConst.delayBetTime = 3000;
    GameConst.dalayTime = 8000;
    GameConst.rateMap = { 101: 1, 102: 1, 103: 8, 104: 11, 105: 11, 106: 8, 107: 5, 108: 5, 109: 1, 110: 1 };
    return GameConst;
}());
__reflect(GameConst.prototype, "GameConst");
var Status;
(function (Status) {
    Status[Status["Shuffle"] = 0] = "Shuffle";
    Status[Status["Start"] = 1] = "Start";
    Status[Status["Stop"] = 2] = "Stop";
    Status[Status["Payout"] = 3] = "Payout";
    Status[Status["OK"] = 4] = "OK";
    Status[Status["Invalied"] = 5] = "Invalied";
})(Status || (Status = {}));
//# sourceMappingURL=GameConst.js.map