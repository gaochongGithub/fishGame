var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ConfirmCancelButton = (function (_super) {
    __extends(ConfirmCancelButton, _super);
    function ConfirmCancelButton() {
        var _this = _super.call(this) || this;
        _this.betInfo = {};
        _this.skinName = "resource/skins/baccarat/ConfirmCancelButtonSkin.exml";
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.hideBtns();
        return _this;
    }
    ConfirmCancelButton.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(GameEvent.CANCEL_BET_AMOUNT, this.hideBtns, this);
        App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.showBtns, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_STOP, this.hideBtns, this);
        App.MessageCenter.removeListener(GameEvent.CONFIRM_BET_AMOUNT, this.hideBtns, this);
        App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAmount, this);
        this.btn_cancel.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnCancel, this);
        this.btn_confirm.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnConfirm, this);
    };
    ConfirmCancelButton.prototype.onAddtoStage = function () {
        App.MessageCenter.addListener(GameEvent.CANCEL_BET_AMOUNT, this.hideBtns, this);
        App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.showBtns, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_STOP, this.hideBtns, this);
        App.MessageCenter.addListener(GameEvent.CONFIRM_BET_AMOUNT, this.hideBtns, this);
        App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAmount, this);
        this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnCancel, this);
        this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnConfirm, this);
        this.hideBtns();
    };
    ConfirmCancelButton.prototype.onClickBtnCancel = function () {
        //播放声音
        App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
        this.clearBetInfo();
    };
    ConfirmCancelButton.prototype.onClickBtnConfirm = function () {
        var tableID = HallDataCtrl.instance.getLoadGameData.getTableID;
        var subType = HallDataCtrl.instance.getLoadGameData.getSubType;
        //let betInfo = GameDataCtrl.instance.getUnConfirmBetAmount;
        var limitRedID = HallDataCtrl.instance.getLoadGameData.getLimitRedID;
        //检测否各个下注区的金额大于0
        var betInfoBigThen0 = false;
        for (var key in this.betInfo) {
            if (this.betInfo[key] < 1)
                delete this.betInfo[key];
        }
        //检测是否小于最低下注额
        if (!this.checkMoreThanMinLimit) {
            return;
        }
        App.GameServer.sendBet(tableID, subType, this.betInfo, limitRedID);
        this.clearBetInfo();
    };
    ConfirmCancelButton.prototype.showBtns = function () {
        this.btn_cancel.enabled = true;
        this.btn_confirm.enabled = true;
    };
    ConfirmCancelButton.prototype.hideBtns = function () {
        this.btn_cancel.enabled = false;
        this.btn_confirm.enabled = false;
    };
    ConfirmCancelButton.prototype.addBetAmount = function (data) {
        var key = data;
        var value = GameDataCtrl.instance.getCurrentBetChip;
        this.betInfo[key] = this.betInfo[key] || 0;
        this.betInfo[key] = this.betInfo[key] + value;
    };
    //检测下注金额是否大于最小限红
    ConfirmCancelButton.prototype.checkMoreThanMinLimit = function () {
        var betInfo = GameDataCtrl.instance.getUnConfirmBetAmount;
        var limitStr = HallDataCtrl.instance.getLoadGameData.getLimitRed;
        var minLimit = 0;
        var arr = limitStr.split("-");
        if (arr[0]) {
            minLimit = Number(arr[0]);
        }
        else {
            return false;
        }
        for (var key in betInfo) {
            if (betInfo[key] < minLimit) {
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_9");
                return false;
            }
        }
        return true;
    };
    ConfirmCancelButton.prototype.clearBetInfo = function () {
        this.betInfo = {};
    };
    return ConfirmCancelButton;
}(eui.Component));
__reflect(ConfirmCancelButton.prototype, "ConfirmCancelButton");
//# sourceMappingURL=ConfirmCancelButton.js.map