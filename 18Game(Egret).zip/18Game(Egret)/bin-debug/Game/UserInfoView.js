var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var UserInfoView = (function (_super) {
    __extends(UserInfoView, _super);
    function UserInfoView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/UserInfoViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    UserInfoView.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
        //App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_CONFIG,this.getGameUserInfoEvent,this);
        this.initData();
    };
    UserInfoView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
        //App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_CONFIG,this.getGameUserInfoEvent,this);
    };
    UserInfoView.prototype.initData = function () {
        var lobbyPlayer = HallDataCtrl.instance.getLobbyPlayer;
        this.label_name.text = MyUtils.userCut_Previouss(lobbyPlayer.name);
        this.label_balance.text = "¥ " + MyUtils.numFormatToThousand(lobbyPlayer.balance);
    };
    UserInfoView.prototype.setLobbyPlayerInfo = function (lobbyPlayerInfo) {
        if (lobbyPlayerInfo.name) {
            if (this.label_name) {
                this.label_name.text = lobbyPlayerInfo.name;
            }
        }
        if (this.label_balance) {
            this.label_balance.text = lobbyPlayerInfo.balance;
        }
        if (this.label_test) {
            this.label_test.visible = lobbyPlayerInfo.isTestMember;
        }
    };
    UserInfoView.prototype.getGameUserInfoEvent = function (data) {
        if (this.label_name) {
            this.label_name.text = MyUtils.userCut_Previouss(data.name);
        }
        if (this.label_balance) {
            //这里要延迟更新
            this.label_balance.text = "¥ " + MyUtils.numFormatToThousand(data.balance);
        }
        if (this.label_test) {
            this.label_test.visible = data.isTestMember;
        }
    };
    return UserInfoView;
}(eui.Component));
__reflect(UserInfoView.prototype, "UserInfoView");
//# sourceMappingURL=UserInfoView.js.map