var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var BetInfoView = (function (_super) {
    __extends(BetInfoView, _super);
    function BetInfoView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/BetInfoViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    BetInfoView.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.setChipAndPeopleLabel, this);
        this.initLimit();
    };
    BetInfoView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.setChipAndPeopleLabel, this);
    };
    BetInfoView.prototype.initLimit = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        this.label_limit.text = loadGameModel.getLimitRed;
    };
    BetInfoView.prototype.setChipAndPeopleLabel = function (data) {
        var betInfo = data.betinfo;
        this.label_table.text = data.tableID;
        this.label_shoe.text = data.stage + "-" + data.inning;
        var obj = GameDataCtrl.instance.getConfirmBetAmount;
        var total = 0;
        for (var key in obj) {
            if (obj[key]) {
                total += obj[key];
            }
        }
        this.label_total.text = (total || 0).toString();
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        if (loadGameModel.getGameType == proto.GameType.Baccarat) {
            this.setBetLabel(this.player_bet, this.player_people, 101, betInfo);
            this.setBetLabel(this.banker_bet, this.banker_people, 102, betInfo);
            this.setBetLabel(this.tie_bet, this.tie_people, 103, betInfo);
            this.setBetLabel(this.playerPair_bet, this.playerPair_people, 104, betInfo);
            this.setBetLabel(this.bankerPair_bet, this.bankerPair_people, 105, betInfo);
            this.setBetLabel(this.superSix_bet, this.superSix_people, 106, betInfo);
            this.setBetLabel(this.anyPair_bet, this.anyPair_people, 107, betInfo);
            this.setBetLabel(this.perfectPair_bet, this.perfectPair_people, 108, betInfo);
            this.setBetLabel(this.big_bet, this.big_people, 109, betInfo);
            this.setBetLabel(this.small_bet, this.small_people, 110, betInfo);
        }
    };
    BetInfoView.prototype.setBetLabel = function (betLabel, peopleLabel, key, betInfo) {
        betLabel.text = (betInfo[key] && betInfo[key].amount) || 0;
        peopleLabel.text = (betInfo[key] && betInfo[key].player_count) || 0;
    };
    return BetInfoView;
}(eui.Component));
__reflect(BetInfoView.prototype, "BetInfoView");
//# sourceMappingURL=BetInfoView.js.map