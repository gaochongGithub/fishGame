var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ChangeTableView = (function (_super) {
    __extends(ChangeTableView, _super);
    function ChangeTableView() {
        var _this = _super.call(this) || this;
        //当前显示那种列表，0表示所有 11百家乐  13轮盘
        _this.currentGameType = 0;
        _this.skinName = "resource/skins/baccarat/ChangeTableViewSkin.exml";
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        return _this;
    }
    ChangeTableView.prototype.updateTables = function () {
        var allTables = [];
        if (this.currentGameType == 0) {
            allTables = LobbyTableInfoCtrl.instance.getLobbyTableArr();
        }
        else {
            allTables = LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.currentGameType);
        }
        if (allTables) {
            if (!this.myCollection) {
                this.myCollection = new eui.ArrayCollection(allTables);
                this.list_all.dataProvider = this.myCollection;
                this.list_all.itemRenderer = OneTableItem;
                console.log("tableArr", allTables);
            }
            else {
                this.myCollection.replaceAll(allTables);
            }
        }
    };
    ChangeTableView.prototype.changeType = function () {
        var allTables = [];
        if (this.currentGameType == 0) {
            allTables = LobbyTableInfoCtrl.instance.getLobbyTableArr();
        }
        else {
            allTables = LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.currentGameType);
        }
        if (allTables) {
            this.myCollection = new eui.ArrayCollection(allTables);
            this.list_all.dataProvider = this.myCollection;
            this.list_all.itemRenderer = OneTableItem;
        }
    };
    ChangeTableView.prototype.onAddtoStage = function () {
        this.groupC.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideView, this);
        App.MessageCenter.addListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM, this.updateTables, this);
        this.btn_all.addEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
        this.btn_baccarat.addEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
        this.btn_roulette.addEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
        this.updateTables();
    };
    ChangeTableView.prototype.onRemoveFromStage = function () {
        this.groupC.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideView, this);
        App.MessageCenter.removeListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM, this.updateTables, this);
        this.btn_all.removeEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
        this.btn_baccarat.removeEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
        this.btn_roulette.removeEventListener(eui.UIEvent.CHANGE, this.onChangeGameType, this);
    };
    ChangeTableView.prototype.onChangeGameType = function (e) {
        var radioButton = e.target;
        if (this.currentGameType != radioButton.value) {
            this.currentGameType = radioButton.value;
            this.changeType();
        }
    };
    ChangeTableView.prototype.hideView = function () {
        this.visible = false;
    };
    return ChangeTableView;
}(eui.Component));
__reflect(ChangeTableView.prototype, "ChangeTableView");
//# sourceMappingURL=ChangeTableView.js.map