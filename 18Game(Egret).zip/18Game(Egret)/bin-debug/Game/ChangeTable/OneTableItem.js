var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var OneTableItem = (function (_super) {
    __extends(OneTableItem, _super);
    function OneTableItem() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/OneTableItemSkin.exml";
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        return _this;
    }
    OneTableItem.prototype.dataChanged = function () {
        this.label_table.text = this.data.getGameTable;
        switch (this.data.getGameType) {
            case proto.GameType.Baccarat:
                this.label_gameName.text = App.LangUtils.getStr("TEXT_BACCARAT");
                break;
            case proto.GameType.Roulette:
                this.label_gameName.text = App.LangUtils.getStr("TEXT_Roulette");
                break;
            default:
                break;
        }
        this.group_shuffle.visible = this.data.getTableSnapshot.status == Status.Shuffle ? true : false;
        var tableID = HallDataCtrl.instance.getLoadGameData.getTableID;
        this.group_isCurrentPosition.visible = tableID == this.data.getGameTable ? true : false;
        this._roadScene.clear();
        this._roadScene.addString(this.data.getAllWays);
        // console.log(this.data.getGameTable,this.data.getAllWays);
    };
    OneTableItem.prototype.onAddtoStage = function () {
        this._roadScene = new TableRoadScene(25);
        this.group_road.addChild(this._roadScene);
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtn, this);
    };
    OneTableItem.prototype.onRemoveFromStage = function () {
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtn, this);
    };
    OneTableItem.prototype.onMouseOverSelf = function () {
    };
    OneTableItem.prototype.onMouseOutSelf = function () {
    };
    OneTableItem.prototype.onClickBtn = function () {
        if (GameDataCtrl.instance.isBet == false) {
            HallDataCtrl.instance.getLoadGameData.setTableID(this.data.getGameTable);
            HallDataCtrl.instance.getLoadGameData.setGameType(this.data.getGameType);
            GameSceneCtrl.instance.toGameScene(this.data.gameType);
        }
        else {
            App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
        }
    };
    return OneTableItem;
}(eui.ItemRenderer));
__reflect(OneTableItem.prototype, "OneTableItem");
//# sourceMappingURL=OneTableItem.js.map