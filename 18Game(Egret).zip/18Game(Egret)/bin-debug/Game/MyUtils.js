var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
// TypeScript file
var MyUtils = (function () {
    function MyUtils() {
    }
    MyUtils.isTestUser = function (name) {
        return !!~name.indexOf("cmkj_");
    };
    /**
     * 深度拷贝
     */
    MyUtils.deeCopy = function (obj, newObj) {
        var newObj;
        if (obj instanceof Array) {
            newObj = [];
        }
        else if (obj instanceof Object) {
            newObj = newObj || {};
        }
        else {
            return obj;
        }
        var keys = Object.keys(obj);
        for (var i = 0, len = keys.length; i < len; i++) {
            var key = keys[i];
            newObj[key] = MyUtils.deeCopy(obj[key], newObj[key]);
        }
        return newObj;
    };
    /**
     * 把数字转化为千分的数字格式
     */
    MyUtils.numFormatToThousand = function (num) {
        var num1 = parseInt(num);
        var num2 = "";
        if (num % 1)
            num2 = "." + num.toString().split(".")[1];
        var str = "";
        while (1) {
            if (num1 >= 1000) {
                var gewei = num1 % 10;
                var shiwei = Math.floor((num1 / 10) % 10);
                var baiwei = Math.floor((num1 / 100) % 10);
                str = "," + baiwei + shiwei + gewei + str;
                num1 = Math.floor(num1 / 1000);
            }
            else {
                str = num1 + str + num2;
                break;
            }
        }
        return str;
    };
    /**
     * 把文本加*
     */
    MyUtils.textAbbreviation = function (text, retainLength) {
        retainLength = retainLength || 2;
        var abbrText = text.substr(text.length - retainLength, text.length);
        return "***" + abbrText;
    };
    //把用户名的***_部分省略
    MyUtils.userCut_Previouss = function (text) {
        if (!!~text.indexOf("_")) {
            var textArr = text.split("_");
            var previous = textArr[0];
            var abbrText = text.substr(previous.length + 1, text.length);
            if (textArr.length == text.length) {
                return text;
            }
            return abbrText;
        }
        else {
            return text;
        }
    };
    return MyUtils;
}());
__reflect(MyUtils.prototype, "MyUtils");
//# sourceMappingURL=MyUtils.js.map