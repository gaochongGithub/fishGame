var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var OptionView = (function (_super) {
    __extends(OptionView, _super);
    function OptionView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/OptionViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    OptionView.prototype.onAddtoStage = function (event) {
        this.btn_deposit.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnDeposit, this);
        this.btn_record.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRecord, this);
        this.btn_client.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnClient, this);
        this.btn_rule.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRule, this);
        this.btn_exit.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnExit, this);
    };
    OptionView.prototype.onRemoveStage = function (event) {
        this.btn_deposit.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnDeposit, this);
        this.btn_record.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRecord, this);
        this.btn_client.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnClient, this);
        this.btn_rule.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRule, this);
        this.btn_exit.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnExit, this);
    };
    OptionView.prototype.onClickBtnDeposit = function () {
        //存款
    };
    OptionView.prototype.onClickBtnRecord = function () {
        //游戏记录
        App.ToastViewManager.toast(new RecordView(), false, true);
    };
    OptionView.prototype.onClickBtnClient = function () {
        //客服
    };
    OptionView.prototype.onClickBtnRule = function () {
        //游戏规则
        App.ToastViewManager.toast(new RuleView, false, true);
    };
    OptionView.prototype.onClickBtnExit = function () {
        if (GameDataCtrl.instance.isBet == false) {
            GameSceneCtrl.instance.toHallScene();
        }
        else {
            App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
        }
    };
    return OptionView;
}(eui.Component));
__reflect(OptionView.prototype, "OptionView");
//# sourceMappingURL=OptionView.js.map