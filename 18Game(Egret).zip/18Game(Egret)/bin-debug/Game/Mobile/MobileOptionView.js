var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 手机版功能界面 记录 规则 退出
 */
var MobileOptionView = (function (_super) {
    __extends(MobileOptionView, _super);
    function MobileOptionView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/MobileOptionViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    MobileOptionView.prototype.onAddtoStage = function (event) {
        this.btn_deposit.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnDeposit, this);
        this.btn_record.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRecord, this);
        this.btn_client.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnClient, this);
        this.btn_rule.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRule, this);
        this.btn_exit.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnExit, this);
        this.btn_setting.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnSetting, this);
        this.group_hide.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickHide, this);
    };
    MobileOptionView.prototype.onRemoveStage = function (event) {
        this.btn_deposit.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnDeposit, this);
        this.btn_record.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRecord, this);
        this.btn_client.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnClient, this);
        this.btn_rule.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnRule, this);
        this.btn_exit.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnExit, this);
        this.btn_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnSetting, this);
        this.group_hide.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickHide, this);
    };
    MobileOptionView.prototype.onClickBtnDeposit = function () {
        //存款
    };
    MobileOptionView.prototype.onClickBtnRecord = function () {
        //游戏记录
        App.ToastViewManager.toast(new RecordView(), false, true);
    };
    MobileOptionView.prototype.onClickBtnClient = function () {
        //客服
    };
    MobileOptionView.prototype.onClickBtnRule = function () {
        //游戏规则
        App.ToastViewManager.toast(new RuleView, false, true);
    };
    MobileOptionView.prototype.onClickBtnExit = function () {
        if (GameDataCtrl.instance.isBet == false) {
            GameSceneCtrl.instance.toMobileHallScene();
        }
        else {
            App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
        }
    };
    MobileOptionView.prototype.onClickBtnSetting = function () {
        App.ToastViewManager.toast(new SettingView, false, true);
    };
    MobileOptionView.prototype.onClickHide = function () {
        this.visible = false;
    };
    return MobileOptionView;
}(eui.Component));
__reflect(MobileOptionView.prototype, "MobileOptionView");
//# sourceMappingURL=MobileOptionView.js.map