var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 手机版路子和下注信息
 */
var MobileRoadAndBetInfoView = (function (_super) {
    __extends(MobileRoadAndBetInfoView, _super);
    function MobileRoadAndBetInfoView() {
        var _this = _super.call(this) || this;
        _this.allWay = "";
        _this.skinName = "resource/skins/baccarat/MobileBetInfoAndRoadSkin.exml";
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        return _this;
    }
    MobileRoadAndBetInfoView.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.updateRoad, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.updateShuffle, this);
        this.group_ask_banker.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.bankerAskRoad, this);
        this.group_ask_player.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.playerAskROad, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.setChipAndPeopleLabel, this);
        this.group_hide.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideView, this);
        this.image_left.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickChangeView, this);
        this.image_right.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickChangeView, this);
    };
    MobileRoadAndBetInfoView.prototype.onAddtoStage = function () {
        App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.updateRoad, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.updateShuffle, this);
        this.group_ask_banker.addEventListener(egret.TouchEvent.TOUCH_TAP, this.bankerAskRoad, this);
        this.group_ask_player.addEventListener(egret.TouchEvent.TOUCH_TAP, this.playerAskROad, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.setChipAndPeopleLabel, this);
        this.initLimit();
        this.group_hide.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideView, this);
        this.image_left.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickChangeView, this);
        this.image_right.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickChangeView, this);
    };
    MobileRoadAndBetInfoView.prototype.updateShuffle = function () {
        this.group_shuffle.visible = GameDataCtrl.instance.gameStatus.status == Status.Shuffle;
    };
    MobileRoadAndBetInfoView.prototype.updateRoad = function (data) {
        var roadScene = new RoadScene(25);
        this._roadScene = roadScene;
        this.group_road.addChild(this._roadScene);
        var gameWay = data.way;
        if (gameWay.substring(0, 1) == "q") {
            this.allWay = "";
        }
        else {
            this.allWay = this.allWay + gameWay;
        }
        this._roadScene.clear();
        this._roadScene.addString(this.allWay);
        var countsArray = data.counts.split("^");
        this.label_player.text = countsArray[0];
        this.label_banker.text = countsArray[1];
        this.label_tie.text = countsArray[2];
        this.label_playerPair.text = countsArray[3];
        this.label_bankerPair.text = countsArray[4];
        this.label_total_road.text = countsArray[5];
        var nextRoadStr = this._roadScene.getNextCode();
        if (nextRoadStr[0] == "a") {
            this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_A_png");
            this.ask_player_1.texture = RES.getRes("Ask_BigRoad_E_png");
        }
        else if (nextRoadStr[0] == "e") {
            this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_E_png");
            this.ask_player_1.texture = RES.getRes("Ask_BigRoad_A_png");
        }
        if (nextRoadStr[1] == "a") {
            this.ask_banker_2.texture = RES.getRes("Bead_A_png");
            this.ask_player_2.texture = RES.getRes("Bead_E_png");
        }
        else if (nextRoadStr[1] == "e") {
            this.ask_banker_2.texture = RES.getRes("Bead_E_png");
            this.ask_player_2.texture = RES.getRes("Bead_A_png");
        }
        if (nextRoadStr[2] == "a") {
            this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_A_png");
            this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_E_png");
        }
        else if (nextRoadStr[2] == "e") {
            this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_E_png");
            this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_A_png");
        }
    };
    MobileRoadAndBetInfoView.prototype.bankerAskRoad = function () {
        this._roadScene.askRoad("a");
    };
    MobileRoadAndBetInfoView.prototype.playerAskROad = function () {
        this._roadScene.askRoad("e");
    };
    /**
     * 下注信息
     */
    MobileRoadAndBetInfoView.prototype.initLimit = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        this.label_limit.text = loadGameModel.getLimitRed;
    };
    MobileRoadAndBetInfoView.prototype.setChipAndPeopleLabel = function (data) {
        var betInfo = data.betinfo;
        this.label_table.text = data.tableID;
        this.label_shoe.text = data.stage + "-" + data.inning;
        var obj = GameDataCtrl.instance.getConfirmBetAmount;
        var total = 0;
        for (var key in obj) {
            if (obj[key]) {
                total += obj[key];
            }
        }
        this.label_total.text = (total || 0).toString();
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        if (loadGameModel.getGameType == proto.GameType.Baccarat) {
            this.setBetLabel(this.player_bet, this.player_people, 101, betInfo);
            this.setBetLabel(this.banker_bet, this.banker_people, 102, betInfo);
            this.setBetLabel(this.tie_bet, this.tie_people, 103, betInfo);
            this.setBetLabel(this.playerPair_bet, this.playerPair_people, 104, betInfo);
            this.setBetLabel(this.bankerPair_bet, this.bankerPair_people, 105, betInfo);
            this.setBetLabel(this.superSix_bet, this.superSix_people, 106, betInfo);
            this.setBetLabel(this.anyPair_bet, this.anyPair_people, 107, betInfo);
            this.setBetLabel(this.perfectPair_bet, this.perfectPair_people, 108, betInfo);
            this.setBetLabel(this.big_bet, this.big_people, 109, betInfo);
            this.setBetLabel(this.small_bet, this.small_people, 110, betInfo);
        }
    };
    MobileRoadAndBetInfoView.prototype.setBetLabel = function (betLabel, peopleLabel, key, betInfo) {
        betLabel.text = (betInfo[key] && betInfo[key].amount) || 0;
        peopleLabel.text = (betInfo[key] && betInfo[key].player_count) || 0;
    };
    MobileRoadAndBetInfoView.prototype.hideView = function () {
        this.visible = false;
    };
    MobileRoadAndBetInfoView.prototype.onClickChangeView = function () {
        this.group_road.visible = !this.group_road.visible;
        this.group_betInfo.visible = !this.group_road.visible;
    };
    return MobileRoadAndBetInfoView;
}(eui.Component));
__reflect(MobileRoadAndBetInfoView.prototype, "MobileRoadAndBetInfoView");
//# sourceMappingURL=MobileRoadAndBetInfoView.js.map