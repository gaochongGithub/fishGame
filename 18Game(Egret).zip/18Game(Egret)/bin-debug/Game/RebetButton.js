var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RebetButton = (function (_super) {
    __extends(RebetButton, _super);
    function RebetButton() {
        var _this = _super.call(this) || this;
        _this.hadBet = false;
        _this.canReset = false;
        _this.preTempBetInfo = {};
        _this.preBetInfo = {};
        _this.skinName = "resource/skins/baccarat/RebetBtnSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    RebetButton.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
        App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAmount, this);
        App.MessageCenter.addListener(GameEvent.CANCEL_BET_AMOUNT, this.receiveCancelBetAmount, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_STOP, this.hideBtn, this);
        this.btn_rebet.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtn, this);
        this.hideBtn();
    };
    RebetButton.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
        App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAmount, this);
        App.MessageCenter.removeListener(GameEvent.CANCEL_BET_AMOUNT, this.receiveCancelBetAmount, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_STOP, this.hideBtn, this);
        this.btn_rebet.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtn, this);
    };
    RebetButton.prototype.onClickBtn = function () {
        //是否已下过注
        if (this.hadBet) {
            return;
        }
        if (this.checkMoreThanBalance()) {
            //soundM
            //toastM
            return;
        }
        App.MessageCenter.dispatch(GameEvent.REBET_BET_AMOUNT, this.preBetInfo);
    };
    RebetButton.prototype.addBetAmount = function () {
        this.hadBet = true;
        this.hideBtn();
    };
    RebetButton.prototype.receiveCancelBetAmount = function () {
        if (this.canReset) {
            this.hadBet = false;
            if ((JSON.stringify(this.preBetInfo) != "{}")) {
                this.showBtn();
            }
        }
    };
    RebetButton.prototype.gameStatusStart = function () {
        this.canReset = true;
        this.hadBet = false;
        this.clearPreTempBetInfo();
        if ((JSON.stringify(this.preBetInfo) != "{}")) {
            this.showBtn();
        }
    };
    RebetButton.prototype.confirmBetAmount = function (data) {
        var betInfo = data.betinfo;
        this.canReset = false;
        this.preTempBetInfo = MyUtils.deeCopy(betInfo, this.preTempBetInfo);
        this.setPreBetInfo();
    };
    RebetButton.prototype.hideBtn = function () {
        this.btn_rebet.enabled = false;
    };
    RebetButton.prototype.showBtn = function () {
        this.btn_rebet.enabled = true;
    };
    RebetButton.prototype.setPreBetInfo = function () {
        for (var key in this.preTempBetInfo) {
            this.preBetInfo[key] = this.preTempBetInfo[key];
        }
        for (var key in this.preBetInfo) {
            if (this.preTempBetInfo[key]) {
                this.preBetInfo[key] = this.preTempBetInfo[key];
            }
            else {
                this.preBetInfo[key] = null;
            }
        }
    };
    RebetButton.prototype.clearPreTempBetInfo = function () {
        this.preTempBetInfo = {};
    };
    RebetButton.prototype.checkMoreThanBalance = function () {
        var total = 0;
        for (var key in this.preBetInfo) {
            if (this.preBetInfo[key]) {
                total += this.preBetInfo[key];
            }
        }
        if (total > HallDataCtrl.instance.getLobbyPlayer.balance) {
            return true;
        }
        return false;
    };
    return RebetButton;
}(eui.Component));
__reflect(RebetButton.prototype, "RebetButton");
//# sourceMappingURL=RebetButton.js.map