var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var UserSeatView = (function (_super) {
    __extends(UserSeatView, _super);
    function UserSeatView() {
        var _this = _super.call(this) || this;
        _this.pos_index = 0;
        _this.skinName = "resource/skins/baccarat/UserSeatViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    UserSeatView.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
        this.hideNameBalance();
    };
    UserSeatView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
    };
    UserSeatView.prototype.updateVirtualTable = function (table) {
        for (var key in table.seats) {
            if (table.seats[key].seatID == this.pos_index + 1 && table.seats[key].uid != 0) {
                this.showNameBalance();
                if (HallDataCtrl.instance.getLobbyPlayer.name == table.seats[key].uname) {
                    this.label_name.text = MyUtils.userCut_Previouss(table.seats[key].uname);
                }
                else {
                    this.label_name.text = MyUtils.textAbbreviation(table.seats[key].uname, 2);
                }
                this.label_balance.text = (MyUtils.numFormatToThousand(table.seats[key].balance) || 0).toString();
            }
        }
    };
    UserSeatView.prototype.updateSeat = function () {
        this.label_name.text = "";
        this.label_balance.text = "";
    };
    UserSeatView.prototype.showNameBalance = function () {
        this.group_name.visible = true;
        this.group_balance.visible = true;
    };
    UserSeatView.prototype.hideNameBalance = function () {
        this.group_name.visible = false;
        this.group_balance.visible = false;
    };
    return UserSeatView;
}(eui.Component));
__reflect(UserSeatView.prototype, "UserSeatView");
//# sourceMappingURL=UserSeatView.js.map