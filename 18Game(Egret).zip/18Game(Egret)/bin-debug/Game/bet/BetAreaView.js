var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 百家乐下注区
 */
var BetAreaView = (function (_super) {
    __extends(BetAreaView, _super);
    function BetAreaView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/baccarat/BetAreaViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    BetAreaView.prototype.onAddtoStage = function (event) {
        App.MessageCenter.addListener(GlobalEvent.SET_SUPER6, this.setSuperSix, this);
        this.setSuperSix();
    };
    BetAreaView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GlobalEvent.SET_SUPER6, this.setSuperSix, this);
    };
    BetAreaView.prototype.setSuperSix = function () {
        var super6 = egret.localStorage.getItem("Super6");
        this.group_superSix.visible = super6 == "1" ? true : false;
        this.betBtn_tie.visible = super6 == "1" ? false : true;
    };
    return BetAreaView;
}(eui.Component));
__reflect(BetAreaView.prototype, "BetAreaView");
//# sourceMappingURL=BetAreaView.js.map