var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 百家乐下注按钮类
 */
var BetButton = (function (_super) {
    __extends(BetButton, _super);
    function BetButton() {
        var _this = _super.call(this) || this;
        //是否可以下注
        _this.isBetting = false;
        _this.betType = proto.Game.BettingArea.BaccaratPlayer;
        _this.label_array = [];
        _this.image_array = [];
        //座位号
        _this.seatID = 0;
        _this.hasOtherChips = false;
        _this.resultType = "";
        _this.skinName = "resource/skins/baccarat/BetButtonSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    BetButton.prototype.onAddtoStage = function (event) {
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnBet, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_STOP, this.gameStatusStop, this);
        App.MessageCenter.addListener(GameEvent.CANCEL_BET_AMOUNT, this.receiveCancel, this);
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE_BET, this.updateVipTableBet, this);
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
        App.MessageCenter.addListener(GameEvent.REBET_BET_AMOUNT, this.receiveRebetAmount, this);
        App.MessageCenter.addListener(GameEvent.GET_GAME_STAGE_PAYOUT, this.getPayoutEvent, this);
        this.init();
    };
    BetButton.prototype.onRemoveStage = function (event) {
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnBet, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_STOP, this.gameStatusStop, this);
        App.MessageCenter.removeListener(GameEvent.CANCEL_BET_AMOUNT, this.receiveCancel, this);
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE_BET, this.updateVipTableBet, this);
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVirtualTable, this);
        App.MessageCenter.removeListener(GameEvent.REBET_BET_AMOUNT, this.receiveRebetAmount, this);
        App.MessageCenter.removeListener(GameEvent.GET_GAME_STAGE_PAYOUT, this.getPayoutEvent, this);
    };
    BetButton.prototype.init = function () {
        if (this.betType == proto.Game.BettingArea.BaccaratSuper6 || this.betType == proto.Game.BettingArea.BaccaratPlayer || this.betType == proto.Game.BettingArea.BaccaratBanker || this.betType == proto.Game.BettingArea.BaccaratTie) {
            this.hasOtherChips = true;
        }
        else {
            this.hasOtherChips = false;
        }
        this.image_array.push(this.image_chip_0);
        this.image_array.push(this.image_chip_1);
        this.image_array.push(this.image_chip_2);
        this.image_array.push(this.image_chip_3);
        this.image_array.push(this.image_chip_4);
        this.image_array.push(this.image_chip_5);
        this.image_array.push(this.image_chip_6);
        this.label_array.push(this.label_chipNumber_0);
        this.label_array.push(this.label_chipNumber_1);
        this.label_array.push(this.label_chipNumber_2);
        this.label_array.push(this.label_chipNumber_3);
        this.label_array.push(this.label_chipNumber_4);
        this.label_array.push(this.label_chipNumber_5);
        this.label_array.push(this.label_chipNumber_6);
        this.clearChips();
    };
    BetButton.prototype.onClickBtnBet = function () {
        console.log(this.betType);
        //超过30局，大和小不能下注
        var currentInning = GameDataCtrl.instance.gameStatus.inning;
        if ((this.betType == proto.Game.BettingArea.BaccaratBig || this.betType == proto.Game.BettingArea.BaccaratSmall) && currentInning > 30) {
            return;
        }
        //主播不能下注
        if (this.isBetting) {
            if (this.checkIsMoreThenBalance()) {
                //播放声音playersound
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_4");
                return;
            }
            if (this.checkIsMoreLimit()) {
                //播放声音playersound
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_7");
                return;
            }
            //增加筹码
            this.addBetAmount();
        }
    };
    //接收取消下注事件
    BetButton.prototype.receiveCancel = function () {
        this.setUnConfirmBetAmount();
    };
    //把筹码设置为确定下注的数值
    BetButton.prototype.setUnConfirmBetAmount = function () {
        var confirm = Number(GameDataCtrl.instance.getConfirmBetAmount[this.betType]);
        if (GameDataCtrl.instance.getConfirmBetAmount[this.betType] == undefined) {
            return;
        }
        //console.log(this.betType,GameDataCtrl.instance.getConfirmBetAmount);
        GameDataCtrl.instance.setUnConfirmBetByKey(this.betType, confirm);
        this.setMyChipLabel();
    };
    //检查限红
    BetButton.prototype.checkIsMoreLimit = function () {
        var limitStr = HallDataCtrl.instance.getLoadGameData.getLimitRed;
        var arr = limitStr.split("-");
        var limit = 0;
        if (arr[1]) {
            limit = Number(arr[1]);
        }
        else {
            return true;
        }
        var currentChip = GameDataCtrl.instance.getCurrentBetChip;
        var obj = GameDataCtrl.instance.getUnConfirmBetAmount;
        var rate = GameConst.rateMap[this.betType] * 10;
        //console.log(rate,Math.floor(limit/rate)*10);
        if (currentChip + obj[this.betType] > Math.floor(limit / rate) * 10) {
            return true;
        }
        return false;
    };
    //接收下注事件
    BetButton.prototype.addBetAmount = function () {
        var currentChip = GameDataCtrl.instance.getCurrentBetChip;
        GameDataCtrl.instance.updateUnConfirmBet(this.betType, currentChip);
        this.setMyChipLabel();
        //发送下注事件
        App.MessageCenter.dispatch(GameEvent.ADD_BETAREA_AND_BETAMOUNT, this.betType);
    };
    BetButton.prototype.gameStatusStart = function () {
        //下注数据清空
        this.isBetting = true;
        GameDataCtrl.instance.setUnConfirmBetByKey(this.betType, 0);
        GameDataCtrl.instance.setConfirmBetByKey(this.betType, 0);
        //清除筹码
        this.clearChips();
    };
    //下注停止设置已下注信息
    BetButton.prototype.gameStatusStop = function () {
        this.isBetting = false;
        this.setUnConfirmBetAmount();
    };
    BetButton.prototype.gameStatusOK = function () {
    };
    //设置座位信息
    BetButton.prototype.updateVirtualTable = function (table) {
        for (var key in table.seats) {
            if (table.seats[key].uname == HallDataCtrl.instance.getLobbyPlayer.name) {
                this.seatID = table.seats[key].seatID;
                break;
            }
        }
    };
    //设置下注信息
    BetButton.prototype.updateVipTableBet = function (data) {
        if (GameDataCtrl.instance.gameStatus.status > 2) {
            return;
        }
        var bet = data;
        var betAmountIndex = data.seatID - 1;
        var betInfo = bet.betinfo;
        console.log(betInfo);
        if (betInfo[this.betType] && betInfo[this.betType] > 0) {
            if (this.seatID == data.seatID) {
                if (this.hasOtherChips) {
                    //只有庄闲和区域有显示其他玩家的下注
                    this.setBetInfo(this.image_array[this.seatID - 1], this.label_array[this.seatID - 1], betInfo[this.betType]);
                }
                else {
                    this.setBetInfo(this.image_chip_0, this.label_chipNumber_0, betInfo[this.betType]);
                }
                GameDataCtrl.instance.setConfirmBetByKey(this.betType, betInfo[this.betType]);
            }
            else {
                this.setBetInfo(this.image_array[betAmountIndex], this.label_array[betAmountIndex], betInfo[this.betType]);
            }
        }
    };
    //检测余额
    BetButton.prototype.checkIsMoreThenBalance = function () {
        var total = 0;
        var currentChip = GameDataCtrl.instance.getCurrentBetChip;
        var obj = GameDataCtrl.instance.getUnConfirmBetAmount;
        var balance = HallDataCtrl.instance.getLobbyPlayer.balance;
        for (var key in obj) {
            if (obj[key]) {
                total += Number(obj[key]);
            }
        }
        var chipsTotal = GameDataCtrl.instance.getUserChipsTotal();
        if (chipsTotal && total > 0) {
            total = total - chipsTotal;
        }
        if (total + currentChip > balance) {
            return true;
        }
    };
    //设置筹码显示
    BetButton.prototype.setMyChipLabel = function () {
        var unConfirmBetAmount = GameDataCtrl.instance.getUnConfirmBetAmount[this.betType];
        if (this.hasOtherChips) {
            this.label_array[this.seatID - 1].text = unConfirmBetAmount == 0 ? "" : unConfirmBetAmount.toString();
        }
        else {
            this.label_chipNumber_0.text = unConfirmBetAmount == 0 ? "" : unConfirmBetAmount.toString();
        }
        var allChips = HallDataCtrl.instance.getLoadGameData.getAllChip;
        if (unConfirmBetAmount < 1) {
            if (this.hasOtherChips) {
                this.image_array[this.seatID - 1].texture = null;
            }
            else {
                this.image_chip_0.texture = null;
            }
            return;
        }
        for (var i = 0; i < allChips.length; i++) {
            if (unConfirmBetAmount >= allChips[i]) {
                var key = (i == 9 ? 10 : "0" + (i + 1));
                if (this.hasOtherChips) {
                    this.image_array[this.seatID - 1].texture = RES.getRes("chips_normal_" + key + "_png");
                }
                else {
                    this.image_chip_0.texture = RES.getRes("chips_normal_" + key + "_png");
                }
            }
        }
    };
    //显示已确认下注
    BetButton.prototype.setBetInfo = function (image, label, betAmount) {
        if (!betAmount) {
            return;
        }
        image.visible = true;
        label.text = betAmount.toString();
        var allChips = HallDataCtrl.instance.getLoadGameData.getAllChip;
        for (var i = 0; i < allChips.length; i++) {
            if (betAmount >= allChips[i]) {
                var key = (i == 9 ? 10 : "0" + (i + 1));
                image.texture = RES.getRes("chips_normal_" + key + "_png");
            }
        }
    };
    //重复下注事件
    BetButton.prototype.receiveRebetAmount = function (betInfo) {
        for (var key in betInfo) {
            if (betInfo[key] && Number(key) == this.betType) {
                this.rebetAmount(betInfo[this.betType]);
                break;
            }
        }
    };
    BetButton.prototype.rebetAmount = function (value) {
        if (this.isBetting) {
            if (this.checkIsMoreThenBalance()) {
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_4");
                return;
            }
            this.addBetAmount();
        }
    };
    //清空筹码
    BetButton.prototype.clearChips = function () {
        if (this.betType == proto.Game.BettingArea.BaccaratTie) {
            console.log("bettype", this.betType);
        }
        if (this.hasOtherChips == true) {
            for (var i = 0; i < this.image_array.length; i++) {
                this.image_array[i].texture = null;
                this.label_array[i].text = "";
            }
        }
        else {
            this.label_chipNumber_0.text = "";
            this.image_chip_0.texture = null;
        }
    };
    BetButton.prototype.getPayoutEvent = function (data) {
        switch (this.betType) {
            case proto.Game.BettingArea.BaccaratPlayer:
            case proto.Game.BettingArea.BaccaratBanker:
            case proto.Game.BettingArea.BaccaratTie:
            case proto.Game.BettingArea.BaccaratPpair:
            case proto.Game.BettingArea.BaccaratBpair:
            case proto.Game.BettingArea.BaccaratAnyPair:
                this.actionGamePayout(data.result);
                break;
            case proto.Game.BettingArea.BaccaratBig:
            case proto.Game.BettingArea.BaccaratSmall:
                this.actionPayouBigSmall();
                break;
            case proto.Game.BettingArea.BaccaratSuper6:
                break;
            case proto.Game.BettingArea.BaccaratAnyPair:
                break;
            default:
                break;
        }
    };
    BetButton.prototype.actionGamePayout = function (result) {
        for (var i = 0; i < this.resultType.length; i++) {
            if (result && this.resultType[i] == result) {
                this.winAction();
                break;
            }
        }
    };
    BetButton.prototype.actionPerfectPair = function () {
        var gameStatus = GameDataCtrl.instance.gameStatus;
        var poker = gameStatus.poker.split("@");
        if (poker.length < 4) {
            return;
        }
        if (poker[0] == poker[1] || poker[3] == poker[4]) {
            this.winAction();
        }
    };
    BetButton.prototype.actionPayouBigSmall = function () {
        var gameStatus = GameDataCtrl.instance.gameStatus;
        if (Number(gameStatus.inning) > 30) {
            return;
        }
        var poker = gameStatus.poker.split("@");
        for (var i = 0; i < poker.length; i++) {
            if (poker[i] == "" || poker[i] == null || typeof (poker[i]) == "undefined") {
                poker.splice(i, 1);
                i = i - 1;
            }
        }
        var result = poker.length + "";
        //cc.log(result,poker);
        for (var i = 0; i < this.resultType.length; i++) {
            if (result && this.resultType[i] == result) {
                //var showVideo = setTimeout(function() {
                this.winAction();
                //}.bind(this), cmkj.Model.CurGameType.delayTime);
                break;
            }
        }
    };
    BetButton.prototype.winAction = function () {
        var _this = this;
        this.image_win.visible = true;
        egret.Tween.get(this.image_win, { loop: false }).
            to({ alpha: 0 }, 800, egret.Ease.quadInOut).
            to({ alpha: 1 }, 800, egret.Ease.quadInOut).
            to({ alpha: 0 }, 800, egret.Ease.quadInOut).
            to({ alpha: 1 }, 800, egret.Ease.quadInOut).
            to({ alpha: 0 }, 800, egret.Ease.quadInOut).
            call(function () { _this.image_win.visible = false; });
    };
    return BetButton;
}(eui.Component));
__reflect(BetButton.prototype, "BetButton");
//# sourceMappingURL=BetButton.js.map