var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 扑克牌显示界面
 */
var PokerView = (function (_super) {
    __extends(PokerView, _super);
    function PokerView() {
        var _this = _super.call(this) || this;
        _this.playerCard = 0; //闲的点数
        _this.bankerCard = 0; //庄的点数
        _this.cardViewList = [];
        _this.skinName = "resource/skins/baccarat/PokerViewSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    PokerView.prototype.onAddtoStage = function (event) {
        this.init();
        App.MessageCenter.addListener(GameEvent.SHOW_POKER, this.showPoker, this);
        App.MessageCenter.addListener(GameEvent.GET_GAME_STAGE_PAYOUT, this.getPayoutEvent, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_OK, this.gameStatusOk, this);
        App.MessageCenter.addListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
    };
    PokerView.prototype.onRemoveStage = function (event) {
        App.MessageCenter.removeListener(GameEvent.SHOW_POKER, this.showPoker, this);
        App.MessageCenter.removeListener(GameEvent.GET_GAME_STAGE_PAYOUT, this.getPayoutEvent, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_OK, this.gameStatusOk, this);
        App.MessageCenter.removeListener(GameEvent.GAME_STATUS_START, this.gameStatusStart, this);
    };
    PokerView.prototype.gameStatusStart = function () {
        this.resetData();
        this.visible = false;
    };
    PokerView.prototype.gameStatusOk = function () {
        //数据重置
        //this.visible = false;
        //this.resetData();
    };
    PokerView.prototype.init = function () {
        this.visible = false;
        this.cardViewList.push(this.card_player_1);
        this.cardViewList.push(this.card_player_2);
        this.cardViewList.push(this.card_player_3);
        this.cardViewList.push(this.card_banker_1);
        this.cardViewList.push(this.card_banker_2);
        this.cardViewList.push(this.card_banker_3);
    };
    PokerView.prototype.resetData = function () {
        this.playerCard = 0;
        this.bankerCard = 0;
        this.playerNumberLabel.text = "";
        this.bankerNumberLabel.text = "";
        for (var i = 0; i < this.cardViewList.length; i++) {
            this.cardViewList[i].texture = RES.getRes("card_bg_png");
            this.cardViewList[i].visible = false;
        }
        this.group_banker_win.alpha = 0;
        this.group_player_win.alpha = 0;
        this.group_tie_win.alpha = 0;
        this.image_banker_win.alpha = 0;
        this.image_player_win.alpha = 0;
    };
    PokerView.prototype.showPoker = function (cards) {
        var cardsList = cards.split("@");
        if (!this.visible) {
            this.visible = true;
        }
        for (var i = 0; i < cardsList.length; i++) {
            if (i > 5)
                break;
            if (!this.cardViewList[i].visible && cardsList[i]) {
                this.cardViewList[i].visible = true;
                var value = this.getCardNum(cardsList[i]);
                var type = this.getCardType(cardsList[i]);
                //console.log("--- -------" + "card_" + type + "_" + value + "_png");
                //this.cardViewList[i].texture = RES.getRes("card_" + type + "_" + value + "_png");
                this.showOneCard(this.cardViewList[i], "card_" + type + "_" + value + "_png");
                if (i < 3) {
                    this.playerCard += this.getCardValue(cardsList[i]);
                    this.playerCard = this.playerCard % 10;
                }
                else {
                    this.bankerCard += this.getCardValue(cardsList[i]);
                    this.bankerCard = this.bankerCard % 10;
                }
            }
            this.playerNumberLabel.text = this.playerCard.toString();
            this.bankerNumberLabel.text = this.bankerCard.toString();
        }
    };
    //翻牌动画
    PokerView.prototype.showOneCard = function (image, str) {
        //SoundEffectMgr.playSound("Card_Flip_mp3");
        egret.Tween.get(image, { loop: false })
            .to({ scaleX: 0 }, 500)
            .call(function () { image.texture = RES.getRes(str); })
            .to({ scaleX: 1 }, 500)
            .call(function () { });
    };
    PokerView.prototype.getPayoutEvent = function (data) {
        var result = data.result;
        this.showWinResult(result);
        this.showResult(result);
    };
    PokerView.prototype.showWinResult = function (result) {
        var resultTypeBanker = "abcdijkl";
        var reusltTypePlayer = "efghijkl";
        this.matchResult(result, resultTypeBanker, this.image_banker_win);
        this.matchResult(result, reusltTypePlayer, this.image_player_win);
    };
    PokerView.prototype.showResult = function (result) {
        var resultBanker = "abcd";
        var reusltPlayer = "efgh";
        var reusltTie = "ijkl";
        this.matchResult(result, resultBanker, this.group_banker_win);
        this.matchResult(result, reusltPlayer, this.group_player_win);
        this.matchResult(result, reusltTie, this.group_tie_win);
    };
    PokerView.prototype.matchResult = function (result, resultAll, obj) {
        for (var i = 0; i < resultAll.length; i++) {
            if (result && resultAll[i] == result) {
                obj.alpha = 1;
                break;
            }
        }
    };
    //最后点数
    PokerView.prototype.getCardValue = function (card) {
        var d = Math.floor(Number(card) / 10);
        if (d > 10)
            d = 0;
        return d;
    };
    /**
     * 用于取对应图片(点数)
     */
    PokerView.prototype.getCardNum = function (card) {
        if (card == "")
            return 0;
        var d = Math.floor(Number(card) / 10);
        return d;
    };
    /**
     * 用于取对应图片(花色)
     */
    PokerView.prototype.getCardType = function (card) {
        return Number(card) % 10;
    };
    return PokerView;
}(eui.Component));
__reflect(PokerView.prototype, "PokerView");
//# sourceMappingURL=PokerView.js.map