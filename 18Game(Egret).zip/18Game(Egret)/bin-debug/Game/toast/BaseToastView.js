var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var BaseToastView = (function (_super) {
    __extends(BaseToastView, _super);
    function BaseToastView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/common/toast/BaseToastViewSkin.exml";
        return _this;
    }
    BaseToastView.prototype.init = function (title, resultType) {
        switch (resultType) {
            case 0:
                this.setBgImage("bankerWin_png");
                break;
            case 1:
                this.setBgImage("playerWin_png");
                break;
            case 2:
                this.setBgImage("tieWin_png");
                break;
            default:
                break;
        }
        this.setTitle(title);
    };
    BaseToastView.prototype.setTitle = function (title) {
        this.label_title.langStr = title;
    };
    BaseToastView.prototype.setBgImage = function (imageName) {
        this.image_bg.texture = RES.getRes(imageName);
    };
    return BaseToastView;
}(DeletSelfView));
__reflect(BaseToastView.prototype, "BaseToastView");
//# sourceMappingURL=BaseToastView.js.map