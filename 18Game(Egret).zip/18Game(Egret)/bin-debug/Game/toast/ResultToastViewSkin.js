var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ResultToastView = (function (_super) {
    __extends(ResultToastView, _super);
    function ResultToastView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/common/toast/ResultToastViewSkin.exml";
        return _this;
    }
    ResultToastView.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    ResultToastView.prototype.setContent = function (text, resultType, imgName) {
        if (imgName === void 0) { imgName = null; }
        var gameType = HallDataCtrl.instance.getLoadGameData.getGameType;
        if (gameType == proto.GameType.Baccarat) {
            this.result_label.text = App.LangUtils.getResultStr(text) + " " + resultType;
        }
        else {
            this.result_label.text = App.LangUtils.getStr(text) + " " + resultType;
        }
        this.result_type.texture = RES.getRes(imgName);
    };
    return ResultToastView;
}(DeletSelfView));
__reflect(ResultToastView.prototype, "ResultToastView");
//# sourceMappingURL=ResultToastViewSkin.js.map