var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ToastBgView = (function (_super) {
    __extends(ToastBgView, _super);
    function ToastBgView(isAutoRemove, isShowBackRect) {
        var _this = _super.call(this) || this;
        _this.isAutoRemove = false;
        _this.isShowBackRect = false;
        _this.isAutoRemove = isAutoRemove;
        _this.isShowBackRect = isShowBackRect;
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        _this.customView();
        return _this;
    }
    ToastBgView.prototype.onAddtoStage = function (event) {
    };
    ToastBgView.prototype.onRemoveStage = function (event) {
        this.timer.stop();
        this.timer = null;
    };
    ToastBgView.prototype.childrenCreated = function () {
        this.rect.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.autoRemove, this);
    };
    ToastBgView.prototype.customView = function () {
        if (App.DeviceUtils.IsMobile) {
            this.width = 812;
            this.height = 375;
        }
        else {
            this.width = 1920;
            this.height = 1080;
        }
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        this.rect = new eui.Rect;
        this.rect.fillColor = 0X000000;
        this.rect.width = this.width;
        this.rect.height = this.height;
        this.isShowBackRect ? this.rect.alpha = 0.9 : this.rect.alpha = 0;
        this.addChild(this.rect);
        // this.zone_bg_image = new eui.Image();
        // this.zone_bg_image.texture = RES.getRes("bg_loading_png");
        // this.zone_bg_image.width = this.width;
        // this.zone_bg_image.height = this.height;
        // this.zone_bg_image.alpha = 0.5;
        //this.addChild(this.zone_bg_image);
        this.timer = new egret.Timer(2000, 1);
        this.timer.addEventListener(egret.TimerEvent.TIMER, this.onbg_btn, this);
        this.timer.start();
    };
    ToastBgView.prototype.onbg_btn = function () {
        if (this.parent && this.isAutoRemove) {
            this.parent.removeChild(this);
        }
    };
    ToastBgView.prototype.autoRemove = function () {
        if (this.parent && this.isAutoRemove) {
            this.parent.removeChild(this);
        }
    };
    return ToastBgView;
}(eui.Group));
__reflect(ToastBgView.prototype, "ToastBgView");
//# sourceMappingURL=ToastBgView.js.map