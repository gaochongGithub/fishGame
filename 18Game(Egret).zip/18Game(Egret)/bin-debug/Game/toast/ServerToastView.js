var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ServerToastView = (function (_super) {
    __extends(ServerToastView, _super);
    function ServerToastView() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/common/toast/ServerToastViewSkin.exml";
        return _this;
    }
    ServerToastView.prototype.childrenCreated = function () {
        this.horizontalCenter = 0;
        this.verticalCenter = 0;
        this.btn_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnCLose, this);
    };
    ServerToastView.prototype.onClickBtnCLose = function () {
        if (!App.DeviceUtils.IsNative) {
            window.opener = null;
            window.open('', '_self');
            window.close();
            window.history.back();
            window.location.reload();
        }
    };
    ServerToastView.prototype.setTitle = function (title) {
        this.label_title.langStr = title;
    };
    ServerToastView.prototype.setContent = function (content) {
        this.label_content.langStr = content;
    };
    return ServerToastView;
}(eui.Component));
__reflect(ServerToastView.prototype, "ServerToastView");
//# sourceMappingURL=ServerToastView.js.map