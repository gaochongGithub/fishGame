var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var DeletSelfView = (function (_super) {
    __extends(DeletSelfView, _super);
    function DeletSelfView(isAutoRemove) {
        if (isAutoRemove === void 0) { isAutoRemove = true; }
        var _this = _super.call(this) || this;
        _this.isAutoRemove = isAutoRemove;
        return _this;
    }
    DeletSelfView.prototype.childrenCreated = function () {
        if (App.DeviceUtils.IsMobile) {
            this.viewWidth = 812;
            this.viewHeight = 375;
        }
        else {
            this.viewWidth = 1920;
            this.viewHeight = 1080;
        }
        this.updataPosition();
        //    var rect=new eui.Rect;
        // 	rect.fillColor=0X000000;
        // 	rect.width=this.width;
        // 	rect.height=this.height;
        // 	//this.isShowBackRect?this.rect.alpha=0.9:this.rect.alpha=0;
        // 	this.addChild(rect);
        // rect.addEventListener(egret.TouchEvent.TOUCH_BEGIN, ()=>{
        //     this.onbg_btn();
        // }, this);
        if (this.isAutoRemove) {
            this.timer = new egret.Timer(2000, 1);
            this.timer.addEventListener(egret.TimerEvent.TIMER, this.onbg_btn, this);
            this.timer.start();
        }
    };
    DeletSelfView.prototype.updataPosition = function () {
        this.x = this.viewWidth / 2 - this.width / 2;
        this.y = this.viewHeight / 2 - this.height / 2;
    };
    DeletSelfView.prototype.onbg_btn = function () {
        if (this.parent) {
            this.parent.removeChild(this);
        }
    };
    return DeletSelfView;
}(eui.Component));
__reflect(DeletSelfView.prototype, "DeletSelfView");
//# sourceMappingURL=DeletSelfView.js.map