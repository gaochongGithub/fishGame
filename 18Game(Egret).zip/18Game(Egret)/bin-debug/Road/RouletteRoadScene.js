var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteRoadScene = (function (_super) {
    __extends(RouletteRoadScene, _super);
    function RouletteRoadScene(width) {
        var _this = _super.call(this) || this;
        _this.mask = new egret.Rectangle(0, 0, width * 29, width * 6);
        _this.markRoadScene = new MarkRoadScene(width, width, 29, 6);
        _this.markRoadScene.x = 0;
        _this.addChild(_this.markRoadScene);
        return _this;
    }
    RouletteRoadScene.prototype.onAddtoStage = function () {
    };
    RouletteRoadScene.prototype.addString = function (str) {
        this.markRoadScene.addWithString(str, proto.GameType.Roulette);
    };
    RouletteRoadScene.prototype.clear = function () {
        this.markRoadScene.clear();
    };
    return RouletteRoadScene;
}(eui.Component));
__reflect(RouletteRoadScene.prototype, "RouletteRoadScene");
//# sourceMappingURL=RouletteRoadScene.js.map