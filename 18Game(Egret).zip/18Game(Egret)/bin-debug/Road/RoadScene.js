var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RoadScene = (function (_super) {
    __extends(RoadScene, _super);
    function RoadScene(width) {
        var _this = _super.call(this) || this;
        _this.mask = new egret.Rectangle(0, 0, width * 10 + width / 2 * 38, width * 6);
        _this.markRoadScene = new MarkRoadScene(width, width, 10, 6);
        _this.addChild(_this.markRoadScene);
        _this.bigRoadScene = new BigRoadScene(width / 2, width / 2, 38, 6);
        _this.bigRoadScene.x = _this.markRoadScene.x + _this.markRoadScene.width;
        _this.addChild(_this.bigRoadScene);
        _this.jyRoadScene = new JyRoadScene(width / 2, width / 2, 38, 3);
        _this.jyRoadScene.x = _this.markRoadScene.x + _this.markRoadScene.width;
        _this.jyRoadScene.y = _this.bigRoadScene.y + _this.bigRoadScene.height;
        _this.addChild(_this.jyRoadScene);
        function onJyRoadSceneClick() {
            if (this.jyRoadScene.scaleX > 1) {
                egret.Tween.get(this.jyRoadScene).to({ scaleX: 1, scaleY: 1 }, 300).
                    call(this.setChildIndex, this, [this.jyRoadScene, 1]);
                this.jyRoadScene.lineNum *= 2;
            }
            else {
                egret.Tween.get(this.jyRoadScene).to({ scaleX: 2, scaleY: 2 }, 300);
                this.setChildIndex(this.jyRoadScene, 10);
                this.jyRoadScene.lineNum /= 2;
            }
            this.jyRoadScene.moveAll();
        }
        _this.jyRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onJyRoadSceneClick, _this);
        _this.smallRoadScene = new SmallRoadScene(width / 2, width / 2, 19, 3);
        _this.smallRoadScene.x = _this.markRoadScene.x + _this.markRoadScene.width;
        _this.smallRoadScene.y = _this.jyRoadScene.y + _this.jyRoadScene.height;
        _this.addChild(_this.smallRoadScene);
        function onSmallRoadSceneClick() {
            if (this.smallRoadScene.scaleX > 1) {
                egret.Tween.get(this.smallRoadScene).
                    to({ y: this.jyRoadScene.y + this.jyRoadScene.height, scaleX: 1, scaleY: 1 }, 300).
                    call(this.setChildIndex, this, [this.smallRoadScene, 1]);
                this.smallRoadScene.lineNum *= 2;
            }
            else {
                egret.Tween.get(this.smallRoadScene).
                    to({ y: this.jyRoadScene.y, scaleX: 2, scaleY: 2 }, 300);
                this.setChildIndex(this.smallRoadScene, 10);
                this.smallRoadScene.lineNum /= 2;
            }
            // this.smallRoadScene.moveAll();
        }
        _this.smallRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onSmallRoadSceneClick, _this);
        _this.zlRoadScene = new ZlRoadScene(width / 2, width / 2, 19, 3);
        _this.zlRoadScene.x = _this.smallRoadScene.x + _this.smallRoadScene.width;
        _this.zlRoadScene.y = _this.jyRoadScene.y + _this.jyRoadScene.height;
        function onZlRoadSceneClick() {
            if (this.zlRoadScene.scaleX > 1) {
                egret.Tween.get(this.zlRoadScene).
                    to({ x: this.smallRoadScene.x + this.smallRoadScene.width, y: this.jyRoadScene.y + this.jyRoadScene.height, scaleX: 1, scaleY: 1 }, 300).
                    call(this.setChildIndex, this, [this.zlRoadScene, 1]);
                this.zlRoadScene.lineNum *= 2;
            }
            else {
                egret.Tween.get(this.zlRoadScene).
                    to({ x: this.markRoadScene.x + this.markRoadScene.width, y: this.jyRoadScene.y, scaleX: 2, scaleY: 2 }, 300);
                this.setChildIndex(this.zlRoadScene, 10);
                this.zlRoadScene.lineNum /= 2;
            }
            // this.zlRoadScene.moveAll();
        }
        _this.zlRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onZlRoadSceneClick, _this);
        _this.addChild(_this.zlRoadScene);
        _this.customView();
        return _this;
        //this.updateLang();
    }
    RoadScene.prototype.onAddtoStage = function () {
        //EventPoster.getDispatcher().addEventListener(MyEvent.LANG_CHANGE, this.updateLang, this);
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE, this.updateLang, this);
        this.updateLang();
    };
    RoadScene.prototype.updateLang = function () {
        this.text_beadRoad.text = App.LangUtils.getStr('TEXT_Bead_Road');
        this.text_bigRoad.text = App.LangUtils.getStr('TEXT_Big_Road');
        this.text_bigEyeRoad.text = App.LangUtils.getStr('TEXT_Big_ye_Road');
        this.text_smallRoad.text = App.LangUtils.getStr('SMALLTEXT_Small_Road_ROAD');
        this.text_cockroachRoad.text = App.LangUtils.getStr('TEXT_CockRoach_Road');
    };
    RoadScene.prototype.getNextCode = function () {
        return this.bigRoadScene.getNextCode();
    };
    RoadScene.prototype.addString = function (str) {
        this.markRoadScene.addWithString(str);
        this.bigRoadScene.addWithString(str);
        this.jyRoadScene.addWithString(str);
        this.smallRoadScene.addWithString(str);
        this.zlRoadScene.addWithString(str);
    };
    RoadScene.prototype.clear = function () {
        this.markRoadScene.clear();
        this.bigRoadScene.clear();
        this.jyRoadScene.clear();
        this.smallRoadScene.clear();
        this.zlRoadScene.clear();
    };
    RoadScene.prototype.customView = function () {
        var label1 = new eui.Label();
        label1.text = "珠盘路";
        label1.right = 5;
        label1.bottom = 5;
        label1.textAlign = egret.HorizontalAlign.RIGHT;
        label1.width = 222;
        label1.textColor = 0xE0E0E0;
        label1.size = 25;
        label1.alpha = 0.8;
        this.text_beadRoad = label1;
        this.markRoadScene.addChild(this.text_beadRoad);
        var label2 = new eui.Label();
        label2.text = "大路";
        label2.right = 5;
        label2.bottom = 5;
        label2.textAlign = egret.HorizontalAlign.RIGHT;
        label2.width = 263;
        label2.textColor = 0xE0E0E0;
        label2.size = 25;
        label2.alpha = 0.8;
        this.text_bigRoad = label2;
        this.bigRoadScene.addChild(this.text_bigRoad);
        var label3 = new eui.Label();
        label3.text = "大眼仔";
        label3.right = 5;
        label3.bottom = 5;
        label3.textAlign = egret.HorizontalAlign.RIGHT;
        label3.width = 263;
        label3.textColor = 0xE0E0E0;
        label3.size = 25;
        label3.alpha = 0.8;
        this.text_bigEyeRoad = label3;
        this.jyRoadScene.addChild(this.text_bigEyeRoad);
        var label4 = new eui.Label();
        label4.text = "小路";
        label4.right = 5;
        label4.bottom = 5;
        label4.textAlign = egret.HorizontalAlign.RIGHT;
        label4.width = 200;
        label4.textColor = 0xE0E0E0;
        label4.size = 25;
        label4.alpha = 0.8;
        this.text_smallRoad = label4;
        this.smallRoadScene.addChild(this.text_smallRoad);
        var label5 = new eui.Label();
        label5.text = "曱甴";
        label5.right = 5;
        label5.bottom = 5;
        label5.textAlign = egret.HorizontalAlign.RIGHT;
        label5.width = 259;
        label5.textColor = 0xE0E0E0;
        label5.size = 25;
        label5.alpha = 0.8;
        this.text_cockroachRoad = label5;
        this.zlRoadScene.addChild(this.text_cockroachRoad);
    };
    RoadScene.prototype.askRoad = function (str) {
        var isShow;
        if (!isShow) {
            egret.setTimeout(function () {
                isShow = false;
            }, this, 2500);
            this.markRoadScene.addNextString(str);
            this.bigRoadScene.addNextString(str);
            this.jyRoadScene.addNextString(str);
            this.smallRoadScene.addNextString(str);
            this.zlRoadScene.addNextString(str);
            isShow = true;
        }
    };
    return RoadScene;
}(eui.Component));
__reflect(RoadScene.prototype, "RoadScene");
//# sourceMappingURL=RoadScene.js.map