var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 *
 * @author
 *
 */
var BigRoad = (function (_super) {
    __extends(BigRoad, _super);
    function BigRoad() {
        var _this = _super.call(this) || this;
        _this.visualist = [];
        return _this;
    }
    BigRoad.prototype.clear = function () {
        _super.prototype.clear.call(this);
        this.listClear();
    };
    BigRoad.prototype.listClear = function () {
        var count = this.visualist.length;
        for (var i = 0; i < count; i++) {
            this.visualist.pop();
        }
    };
    //画个单路
    BigRoad.prototype.add = function (way) {
        var lastAdd = _super.prototype.addWithOne.call(this, way);
        if (lastAdd > 1 && this.listY < 100) {
            if (this.visualist.length <= this.listX) {
                this.visualist.push(this.listY + 1);
            }
            else {
                this.visualist[this.listX] = this.listY + 1;
            }
        }
        return lastAdd;
    };
    //遍历visuallist
    BigRoad.prototype.printVisuallist = function () {
        for (var i = 0; i < this.visualist.length; i++) {
            egret.log("visulaist[" + i + "] :" + this.visualist[i]);
        }
    };
    //MAKE:庄问路 int aaa,a红,e蓝,闲相反 (=)
    BigRoad.prototype.getNextCode = function () {
        var oldy = this.listY;
        var oldx = this.listX;
        var last = this.lastType;
        //虚拟庄
        if (last == 3) {
            this.listY += 1;
        }
        else {
            this.listX += 1;
            this.listY = 0;
        }
        if (this.listY >= 100) {
            this.listX = oldx;
            this.listY = oldy;
            return "";
        }
        if (this.visualist.length <= this.listX) {
            this.visualist.push(this.listY + 1);
        }
        else {
            this.visualist[this.listX] = this.listY + 1;
        }
        var a = this.getJiyanCode();
        var b = this.getSmallCode();
        var c = this.getZhanglangCode();
        if (this.listY == 0) {
            this.visualist.pop();
        }
        else {
            this.visualist[this.listX] = oldy;
        }
        this.listX = oldx;
        this.listY = oldy;
        //return String(a)+String(b)+String(c);
        return a + b + c;
    };
    /**
     * 取鸡眼路代码
     * 圈, a红,e蓝
     * @return
     */
    BigRoad.prototype.getJiyanCode = function () {
        if (this.listX >= 1) {
            if (this.listX > 1 && this.listY == 0) {
                if (this.isSnap(2)) {
                    return "a";
                }
                else {
                    return "e";
                }
            }
            return this.subCode(1);
        }
        return "";
    };
    /**
     * 取小圆路代码
     * 点, a红,e蓝
     * @return
     */
    BigRoad.prototype.getSmallCode = function () {
        if (this.listX >= 2) {
            if (this.listX > 2 && this.listY == 0) {
                if (this.isSnap(3)) {
                    return "a";
                }
                else {
                    return "e";
                }
            }
            return this.subCode(2);
        }
        return " ";
    };
    /**
     * 取蟑螂路代码
     * 杠, a红,e蓝
     * @return
     */
    BigRoad.prototype.getZhanglangCode = function () {
        if (this.listX >= 3) {
            if (this.listX > 3 && this.listY == 0) {
                if (this.isSnap(4)) {
                    return "a";
                }
                else {
                    return "e";
                }
            }
            return this.subCode(3);
        }
        return " ";
    };
    BigRoad.prototype.subCode = function (columOff) {
        if (this.listY > 0 && this.listY < 100) {
            if (this.visualist[this.listX - columOff] >= this.listY + 1) {
                return "a";
            }
            else {
                if (this.visualist[this.listX - columOff] < this.listY - 1 + 1) {
                    return "a";
                }
                else {
                    return "e";
                }
            }
        }
        return " ";
    };
    //对比相隔的两列是否对齐,相隔数:鸡眼2,小路3,甲由4
    BigRoad.prototype.isSnap = function (columnOff) {
        return this.visualist[this.listX - 1] == this.visualist[this.listX - columnOff];
    };
    return BigRoad;
}(SmallRoad));
__reflect(BigRoad.prototype, "BigRoad");
//# sourceMappingURL=BigRoad.js.map