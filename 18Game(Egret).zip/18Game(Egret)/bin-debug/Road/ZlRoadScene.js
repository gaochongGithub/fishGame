var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 *
 * @author
 *
 */
var ZlRoadScene = (function (_super) {
    __extends(ZlRoadScene, _super);
    function ZlRoadScene(gridWidth, gridHeight, lineNum, columnNum) {
        if (columnNum === void 0) { columnNum = 6; }
        var _this = _super.call(this) || this;
        _this.gridWidth = 0;
        _this.gridHeight = 0;
        _this.lineNum = 0;
        _this.columnNum = 0;
        _this.gridWidth2 = 0;
        _this.gridHeight2 = 0;
        _this.roadView = new eui.Group();
        _this.bigRoad = new BigRoad();
        _this.zlRoad = new SmallRoad();
        _this.haveSamllRoad = true;
        _this.width = gridWidth * lineNum;
        _this.height = gridHeight * columnNum;
        _this.gridWidth = gridWidth;
        _this.gridHeight = gridHeight;
        _this.lineNum = lineNum;
        _this.columnNum = columnNum;
        _this.gridWidth2 = _this.gridWidth / 2;
        _this.gridHeight2 = _this.gridHeight / 2;
        _this.createSubView();
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddedToStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemovedFromStage, _this);
        return _this;
    }
    ;
    ZlRoadScene.prototype.onAddedToStage = function () {
    };
    ZlRoadScene.prototype.onRemovedFromStage = function () {
    };
    ZlRoadScene.prototype.createSubView = function () {
        var bg = new egret.Shape();
        bg.graphics.beginFill(0xffffff);
        bg.graphics.drawRect(0, 0, this.width, this.height);
        bg.graphics.endFill();
        this.addChild(bg);
        this.addChild(this.roadView);
        var spMask = new egret.Rectangle(0, 0, this.gridWidth * this.lineNum, this.gridHeight * this.columnNum);
        this.roadView.mask = spMask;
        this.spMask = spMask;
        this.gridScene = new GridScene(this.gridWidth, this.gridHeight, this.lineNum, this.columnNum);
        this.gridScene.setDrawLine();
        this.addChild(this.gridScene);
    };
    //根据字符来决定
    ZlRoadScene.prototype.addWithString = function (aString) {
        for (var i = 0; i < aString.length; i++) {
            if (aString[i] == "q") {
                this.clear();
                break;
            }
            else {
                this.addWithOneCharacter(aString[i]);
            }
        }
        this.moveAll();
    };
    ZlRoadScene.prototype.addOneImage = function (road) {
        var oneMark = new eui.Image();
        oneMark.width = this.gridWidth2;
        oneMark.height = this.gridHeight2;
        oneMark.x = this.gridWidth2 * road.currentX;
        oneMark.y = this.gridHeight2 * road.currentY;
        var imageStr;
        if (road.lastWay >= "a" && road.lastWay <= "d") {
            // 画庄  红
            imageStr = "Cockcroach_A_png";
        }
        else if (road.lastWay >= "e" && road.lastWay <= "h") {
            //画闲   蓝
            imageStr = "Cockcroach_E_png";
        }
        oneMark.texture = RES.getRes(imageStr);
        return oneMark;
    };
    ZlRoadScene.prototype.addNextString = function (way) {
        var nextBig = new BigRoad();
        //nextBig = Global.deepCopy(this.bigRoad, nextBig);
        nextBig = MyUtils.deeCopy(this.bigRoad, nextBig);
        var add = nextBig.add(way);
        var nextZlRoad = new SmallRoad();
        //nextZlRoad = Global.deepCopy(this.zlRoad, nextZlRoad);
        nextZlRoad = MyUtils.deeCopy(this.zlRoad, nextZlRoad);
        if (add > 1 && nextZlRoad.addWithOne(nextBig.getZhanglangCode()) > 1) {
            var oneMark = this.addOneImage(nextZlRoad);
            egret.Tween.get(oneMark, { loop: true }).to({ alpha: 0 }, 800, egret.Ease.quadInOut).to({ alpha: 1 }, 800, egret.Ease.quadInOut);
            egret.setTimeout(function () {
                this.roadView.removeChild(oneMark);
            }, this, 2400);
            this.roadView.addChild(oneMark);
        }
    };
    ZlRoadScene.prototype.addWithOneCharacter = function (way) {
        var add = this.bigRoad.add(way);
        if (add > 1) {
            if (this.zlRoad.addWithOne(this.bigRoad.getZhanglangCode()) > 1) {
                var oneMark = this.addOneImage(this.zlRoad);
                this.roadView.addChild(oneMark);
            }
        }
    };
    // private addWithOneCharacter(way: string) {
    //     var add = this.bigRoad.add(way);
    //     if (this.haveSamllRoad && add > 1) {
    //         if (this.zlRoad.addWithOne(this.bigRoad.getZhanglangCode()) > 1) {
    //             var oneMark: eui.Image = new eui.Image();
    //             oneMark.width = this.gridWidth2;
    //             oneMark.height = this.gridHeight2;
    //             oneMark.x = this.gridWidth2 * this.zlRoad.currentX;
    //             oneMark.y = this.gridHeight2 * this.zlRoad.currentY;
    //             var imageStr:string ;
    //             if (this.zlRoad.lastWay >= "a" && this.zlRoad.lastWay <= "d") {
    //                 // 画庄  红
    //                 imageStr = "PC_B_ZL_png";
    //             } else if (this.zlRoad.lastWay >= "e" && this.zlRoad.lastWay <= "h") {
    //                 //画闲   蓝
    //                 imageStr = "PC_P_ZL_png";
    //             }
    //             oneMark.texture = RES.getRes(imageStr);
    //             this.roadView.addChild(oneMark);
    //         }
    //     }
    // }
    ZlRoadScene.prototype.clear = function () {
        this.bigRoad.clear();
        if (!this.haveSamllRoad) {
            return;
        }
        this.roadView.removeChildren();
        this.zlRoad.clear();
    };
    ZlRoadScene.prototype.moveAll = function () {
        this.roadView.x = this.zlRoad.currentX > this.lineNum * 2 - 2 ? (-(this.zlRoad.currentX - this.lineNum * 2 + 2) * this.gridWidth2) : 0;
        this.spMask.x = -this.roadView.x;
        this.roadView.mask = this.spMask;
    };
    ZlRoadScene.prototype.getNextCode = function () {
        return this.bigRoad.getNextCode();
    };
    return ZlRoadScene;
}(eui.Component));
__reflect(ZlRoadScene.prototype, "ZlRoadScene");
//# sourceMappingURL=ZlRoadScene.js.map