var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 *
 * @author
 *
 */
var MarkRoadScene = (function (_super) {
    __extends(MarkRoadScene, _super);
    function MarkRoadScene(gridWidth, gridHeight, lineNum, columnNum) {
        var _this = _super.call(this) || this;
        _this.gridWidth = 0;
        _this.gridHeight = 0;
        _this.lineNum = 0;
        _this.columnNum = 0;
        _this.markRoad = new MarkRoad();
        _this.roadView = new eui.Group();
        _this.width = gridWidth * lineNum;
        _this.height = gridHeight * columnNum;
        _this.gridWidth = gridWidth;
        _this.gridHeight = gridHeight;
        _this.lineNum = lineNum;
        _this.columnNum = columnNum;
        _this.initScene();
        return _this;
    }
    ;
    MarkRoadScene.prototype.initScene = function () {
        var bg = new egret.Shape();
        bg.graphics.beginFill(0xffffff);
        bg.graphics.drawRect(0, 0, this.width, this.height);
        bg.graphics.endFill();
        this.addChild(bg);
        this.addChild(this.roadView);
        var spMask = new egret.Rectangle(0, 0, this.gridWidth * this.lineNum, this.gridHeight * this.columnNum);
        this.roadView.mask = spMask;
        this.spMask = spMask;
        this.gridScene = new GridScene(this.gridWidth, this.gridHeight, this.lineNum, this.columnNum);
        ;
        this.gridScene.setDrawLine();
        this.addChild(this.gridScene);
    };
    //根据字符来决定
    MarkRoadScene.prototype.addWithString = function (aString, gameType) {
        if (gameType === void 0) { gameType = null; }
        if (gameType == proto.GameType.Roulette) {
            if (aString == "q") {
                this.clear();
            }
            else {
                var arr = aString.split(",");
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] && arr[i] !== "") {
                        this.addOneMark(arr[i], gameType);
                    }
                }
            }
        }
        else {
            for (var i = 0; i < aString.length; i++) {
                if (aString[i] == "q") {
                    this.clear();
                    break;
                }
                else {
                    this.addOneMark(aString[i], gameType);
                }
            }
        }
        this.moveAll();
    };
    MarkRoadScene.prototype.addOneMark = function (markResult, gameType) {
        if (gameType === void 0) { gameType = null; }
        this.markRoad.addOne();
        if (gameType == proto.GameType.Roulette) {
            this.addWithRouletteCharacter(markResult, this.getCurrentRoadX(), this.getCurrentRoadY());
        }
        else {
            this.addWithOneCharacter(markResult, this.getCurrentRoadX(), this.getCurrentRoadY());
        }
    };
    MarkRoadScene.prototype.addNextString = function (way) {
        var next = new MarkRoad();
        //next = Global.deepCopy(this.markRoad, next);
        next = MyUtils.deeCopy(this.markRoad, next);
        console.log(this.markRoad, next);
        next.addOne();
        var oneMark = this.addWithOneCharacter(way, next.currentX, next.currentY);
        egret.Tween.get(oneMark, { loop: true }).to({ alpha: 0 }, 800, egret.Ease.quadInOut).to({ alpha: 1 }, 800, egret.Ease.quadInOut);
        egret.setTimeout(function () {
            this.roadView.removeChild(oneMark);
        }, this, 2400);
        this.roadView.addChild(oneMark);
    };
    MarkRoadScene.prototype.addWithOneCharacter = function (aCharacter, currentX, currentY) {
        var oneMark = new eui.Image();
        var num = (aCharacter.charCodeAt(0) - 97);
        // var imageStr:string[] = ["B","B_PP","B_BP","B_BP_PP",
        //                             "P","P_PP","P_BP","P_BP_PP",
        //                             "T","T_PP","T_BP","T_BP_PP"];
        var lang = App.LangUtils.kind == "ZH" ? "ZH" : "EN";
        oneMark.texture = RES.getRes(lang + "_" + aCharacter + "_png");
        oneMark.width = this.gridWidth * 9 / 10;
        oneMark.height = this.gridHeight * 9 / 10;
        oneMark.anchorOffsetX = oneMark.width / 2;
        oneMark.anchorOffsetY = oneMark.height / 2;
        oneMark.x = currentX * this.gridWidth + this.gridWidth / 2;
        oneMark.y = currentY * this.gridHeight + this.gridHeight / 2;
        this.roadView.addChild(oneMark);
        return oneMark;
    };
    /**
     * 用于问路
     */
    MarkRoadScene.prototype.getCurrentRoadX = function () {
        return this.markRoad.currentX;
    };
    MarkRoadScene.prototype.getCurrentRoadY = function () {
        return this.markRoad.currentY;
    };
    MarkRoadScene.prototype.clear = function () {
        this.roadView.removeChildren();
        this.markRoad.clear();
    };
    MarkRoadScene.prototype.moveAll = function () {
        this.roadView.x = this.markRoad.currentX > this.lineNum - 2 ? (-(this.markRoad.currentX - this.lineNum + 2) * this.gridWidth) : 0;
        this.spMask.x = -this.roadView.x;
        this.roadView.mask = this.spMask;
    };
    //轮盘路单
    MarkRoadScene.prototype.addWithRouletteCharacter = function (aCharacter, currentX, currentY) {
        if (aCharacter == ",") {
            return;
        }
        var oneMark = new eui.Group();
        var rect = new eui.Rect();
        var lable = new eui.Label(aCharacter);
        lable.size = 15;
        lable.horizontalCenter = 0;
        lable.verticalCenter = 0;
        lable.textAlign = egret.HorizontalAlign.JUSTIFY;
        lable.textAlign = egret.VerticalAlign.JUSTIFY;
        rect.fillColor = this.getMarkRoadColor(aCharacter);
        rect.width = this.gridWidth * 9 / 10;
        rect.height = this.gridHeight * 9 / 10;
        rect.anchorOffsetX = oneMark.width / 2;
        rect.anchorOffsetY = oneMark.height / 2;
        rect.horizontalCenter = 0;
        rect.verticalCenter = 0;
        oneMark.width = this.gridWidth * 9 / 10;
        oneMark.height = this.gridHeight * 9 / 10;
        oneMark.anchorOffsetX = oneMark.width / 2;
        oneMark.anchorOffsetY = oneMark.height / 2;
        oneMark.x = currentX * this.gridWidth + this.gridWidth / 2;
        oneMark.y = currentY * this.gridHeight + this.gridHeight / 2;
        oneMark.addChild(rect);
        oneMark.addChild(lable);
        this.roadView.addChild(oneMark);
        return oneMark;
    };
    MarkRoadScene.prototype.getMarkRoadColor = function (char) {
        var color = 0x000000;
        if (char == 0) {
            color = 0x50A548;
        }
        else if (char > 0 && char < 11) {
            if (char % 2 == 0) {
                color = 0x000000;
            }
            else {
                color = 0xC52022;
            }
        }
        else if (char > 10 && char < 19) {
            if (char % 2 == 0) {
                color = 0xC52022;
            }
            else {
                color = 0x000000;
            }
        }
        else if (char >= 19 && char < 29) {
            if (char % 2 == 0) {
                color = 0x000000;
            }
            else {
                color = 0xC52022;
            }
        }
        else {
            if (char % 2 == 0) {
                color = 0xC52022;
            }
            else {
                color = 0x000000;
            }
        }
        return color;
    };
    return MarkRoadScene;
}(eui.Component));
__reflect(MarkRoadScene.prototype, "MarkRoadScene");
//# sourceMappingURL=MarkRoadScene.js.map