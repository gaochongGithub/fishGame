var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TableRoadScene = (function (_super) {
    __extends(TableRoadScene, _super);
    function TableRoadScene(width) {
        var _this = _super.call(this) || this;
        _this.mask = new egret.Rectangle(0, 0, width * 10, width * 6);
        _this.bigRoadScene = new BigRoadScene(width, width, 10, 6);
        _this.bigRoadScene.x = 0;
        _this.addChild(_this.bigRoadScene);
        return _this;
    }
    TableRoadScene.prototype.onAddtoStage = function () {
    };
    TableRoadScene.prototype.getNextCode = function () {
        return this.bigRoadScene.getNextCode();
    };
    TableRoadScene.prototype.addString = function (str) {
        this.bigRoadScene.addWithString(str);
    };
    TableRoadScene.prototype.clear = function () {
        this.bigRoadScene.clear();
    };
    return TableRoadScene;
}(eui.Component));
__reflect(TableRoadScene.prototype, "TableRoadScene");
//# sourceMappingURL=TableRoadScene.js.map