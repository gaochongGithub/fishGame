var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var protobufTest = (function () {
    function protobufTest() {
    }
    return protobufTest;
}());
__reflect(protobufTest.prototype, "protobufTest");
//# sourceMappingURL=protobufTest.js.map