//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LoadingUI = (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        return _super.call(this) || this;
        //this.createView();
    }
    LoadingUI.prototype.createView = function (s) {
        this.view = s;
        this.width = s.stage.stageWidth;
        this.height = s.stage.stageHeight;
        // s.stage.stageWidth
        var exml = "<e:ProgressBar xmlns:e=\"http://ns.egret.com/eui\">\n                <e:Skin >\n                    <e:Image source=\"resource/assets/Loading/loading_bg1.png\"/>\n                    <e:Image id=\"thumb\" source=\"resource/assets/Loading/loding_bg2.png\" verticalCenter=\"0\"/>\n                </e:Skin>\n            </e:ProgressBar>";
        this.bg = new eui.Image();
        this.bg.source = "resource/assets/Loading/bg.png";
        // this.bg.bottom=0;
        // this.bg.top=0;
        // this.bg.left=0;
        // this.bg.right=0;
        this.bg.width = this.width;
        this.bg.height = this.height;
        this.view.addChild(this.bg);
        var clazz = EXML.parse(exml);
        this.loadingBar = new clazz();
        this.loadingBar.minimum = 0;
        this.loadingBar.maximum = 100;
        if (egret.Capabilities.isMobile) {
            this.loadingBar.scaleX = 0.5;
            this.loadingBar.scaleY = 0.5;
            this.loadingBar.x = (this.width - 518) / 2;
            this.loadingBar.y = this.height - 60;
        }
        else {
            this.loadingBar.x = (this.width - 1034) / 2;
            this.loadingBar.y = this.height - 100;
        }
        this.view.addChild(this.loadingBar);
    };
    LoadingUI.prototype.setBarCount = function (count) {
        this.loadingBar.value = count;
    };
    LoadingUI.prototype.onProgress = function (current, total) {
        //this.textField.text = `Loading...${current}/${total}`;
        var per = Math.floor((current / total) * 90);
        this.loadingBar.value = per;
    };
    LoadingUI.prototype.setLoginView = function (caller, any) {
        var _this = this;
        var userGrop = new eui.Group();
        var nameBg = new eui.Image();
        nameBg.source = RES.getRes("edit_box_png");
        userGrop.addChild(nameBg);
        userGrop.x = this.width / 2 - 464 / 2;
        userGrop.y = this.height / 2 - 38 / 2;
        this.userNameEdit = new eui.EditableText();
        this.userNameEdit.left = 10;
        this.userNameEdit.right = 10;
        this.userNameEdit.textAlign = "left";
        this.userNameEdit.verticalAlign = "middle";
        this.userNameEdit.textColor = 0X000000;
        this.userNameEdit.prompt = App.LangUtils.getStr("USERNAME_EDIT");
        this.userNameEdit.height = 38;
        userGrop.addChild(this.userNameEdit);
        var pdGrop = new eui.Group();
        var pdBg = new eui.Image();
        pdBg.source = RES.getRes("edit_box_png");
        pdGrop.addChild(pdBg);
        pdGrop.x = this.width / 2 - 464 / 2;
        pdGrop.y = this.height / 2 + 100;
        this.pdEdit = new eui.EditableText();
        this.pdEdit.left = 10;
        this.pdEdit.right = 10;
        this.pdEdit.textAlign = "left";
        this.pdEdit.verticalAlign = "middle";
        this.pdEdit.textColor = 0X000000;
        this.pdEdit.prompt = App.LangUtils.getStr("PASSWORD_EDIT");
        this.pdEdit.height = 38;
        pdGrop.addChild(this.pdEdit);
        this.view.addChild(userGrop);
        this.view.addChild(pdGrop);
        var loginBtn = new eui.Button;
        loginBtn.skinName = "resource/skins/hall/eui/loginBtn.exml";
        loginBtn.x = this.width / 2 - 206 / 2;
        loginBtn.y = this.height / 2 + 200;
        this.view.addChild(loginBtn);
        loginBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            any.call(caller, _this.userNameEdit.text, _this.pdEdit.text);
        }, this);
        this.loadingBar.visible = false;
    };
    return LoadingUI;
}(egret.Sprite));
__reflect(LoadingUI.prototype, "LoadingUI", ["RES.PromiseTaskReporter"]);
//# sourceMappingURL=LoadingUI.js.map