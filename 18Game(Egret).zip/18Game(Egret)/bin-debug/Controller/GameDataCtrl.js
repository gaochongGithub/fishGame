var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
 * 游戏数据控制类
 */
var GameDataCtrl = (function () {
    function GameDataCtrl() {
        this.confirmBetAmount = {};
        this.unConfirmBetAmount = {};
        this.confirmBetAmount_r = {};
        //当前选中筹码
        this._currentBetChip = 0;
        //当前局号
        this._currentInning = 0;
        //private _currentStatus:Status = 0;
        //是否已下注，确保有下注的桌不能退出或换桌
        this._isBet = false;
        //历史数据
        this.allGameTableHistory = [];
        //是否可以下注
        this._isCanClick = false;
    }
    Object.defineProperty(GameDataCtrl, "instance", {
        get: function () {
            if (!this.gameDataCtrl) {
                this.gameDataCtrl = new GameDataCtrl();
            }
            return this.gameDataCtrl;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "gameStatus", {
        /*当前状态存取*/
        get: function () {
            return this._gameStatus;
        },
        set: function (gameStatus) {
            this._gameStatus = MyUtils.deeCopy(gameStatus, this._gameStatus);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "isBet", {
        /**
         * 当前是否下注
         */
        get: function () {
            return this._isBet;
        },
        set: function (isBet) {
            this._isBet = isBet;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "currentInning", {
        /**
         * 当前局号存取
         */
        get: function () {
            return this._currentInning;
        },
        set: function (inning) {
            this._currentInning = inning;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "isCanClick", {
        get: function () {
            return this._isCanClick;
        },
        enumerable: true,
        configurable: true
    });
    GameDataCtrl.prototype.setIsCanClick = function (isCanClick) {
        this._isCanClick = isCanClick;
    };
    Object.defineProperty(GameDataCtrl.prototype, "getConfirmBetAmount", {
        /**
         * 当前状态存取
         */
        // public get currentStatus(){
        // 	return this._currentStatus;
        // }
        // public set currentStatus(status:Status){
        // 	this._currentStatus = status;
        // }
        //获取已确定的下注
        get: function () {
            return this.confirmBetAmount;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "getUnConfirmBetAmount", {
        get: function () {
            return this.unConfirmBetAmount;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "getCurrentBetChip", {
        //当前筹码存取
        get: function () {
            return this._currentBetChip;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "setCurrentBetChip", {
        set: function (chip) {
            this._currentBetChip = chip;
        },
        enumerable: true,
        configurable: true
    });
    //数据累加
    GameDataCtrl.prototype.updateUnConfirmBet = function (key, value) {
        this.unConfirmBetAmount[key] = Number(this.unConfirmBetAmount[key]) + Number(value);
    };
    //设置为特定的值
    GameDataCtrl.prototype.setUnConfirmBetByKey = function (key, value) {
        this.unConfirmBetAmount[key] = this.unConfirmBetAmount[key] || 0;
        this.unConfirmBetAmount[key] = value;
    };
    GameDataCtrl.prototype.setConfirmBetByKey = function (key, value) {
        this.confirmBetAmount[key] = this.confirmBetAmount[key] || 0;
        this.confirmBetAmount[key] = value;
    };
    //已下注的总额
    GameDataCtrl.prototype.getUserChipsTotal = function () {
        var total = 0;
        for (var key in this.confirmBetAmount) {
            total += Number(this.confirmBetAmount[key]);
        }
        return total;
    };
    Object.defineProperty(GameDataCtrl.prototype, "getConfirmBetAmount_R", {
        get: function () {
            return this.confirmBetAmount_r;
        },
        enumerable: true,
        configurable: true
    });
    GameDataCtrl.prototype.setConfirmBetAmount_R = function (key, value) {
        this.confirmBetAmount_r[key] = value;
    };
    Object.defineProperty(GameDataCtrl.prototype, "setResetData", {
        get: function () {
            this.confirmBetAmount_r = {};
            return this.confirmBetAmount_r;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameDataCtrl.prototype, "getAllGameTableHistory", {
        get: function () {
            return this.allGameTableHistory;
        },
        enumerable: true,
        configurable: true
    });
    GameDataCtrl.prototype.setAllGameTableHistory = function (data) {
        this.allGameTableHistory.push(data);
    };
    return GameDataCtrl;
}());
__reflect(GameDataCtrl.prototype, "GameDataCtrl");
//# sourceMappingURL=GameDataCtrl.js.map