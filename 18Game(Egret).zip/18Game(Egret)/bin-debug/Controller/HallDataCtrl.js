var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var HallDataCtrl = (function () {
    function HallDataCtrl() {
        this.limitRed = {};
        this.nomalLimitRedID = {};
    }
    Object.defineProperty(HallDataCtrl, "instance", {
        get: function () {
            if (!this.hallDataCtrl) {
                this.hallDataCtrl = new HallDataCtrl();
            }
            return this.hallDataCtrl;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HallDataCtrl.prototype, "getLobbyPlayer", {
        get: function () {
            return this.lobbyPlayer;
        },
        enumerable: true,
        configurable: true
    });
    HallDataCtrl.prototype.setLobbyPlayer = function (data) {
        this.lobbyPlayer = data;
        this.limitRed = {};
        this.nomalLimitRedID = {};
        this.parsebetLimitAndChip(data.rouletteChips, proto.GameType.Roulette);
        this.parsebetLimitAndChip(data.videoChips, proto.GameType.Baccarat);
    };
    HallDataCtrl.prototype.setPlayerCount = function (playerCount) {
        this.playerCount = playerCount;
    };
    Object.defineProperty(HallDataCtrl.prototype, "getPlayerCount", {
        get: function () {
            return this.playerCount;
        },
        enumerable: true,
        configurable: true
    });
    //通过游戏id获取限红组
    HallDataCtrl.prototype.getGameLimitRed = function (gameType) {
        return this.limitRed[gameType];
    };
    //通过限红ID获取限红
    HallDataCtrl.prototype.getLimitIDLimitRed = function (gameType, limitID) {
        return this.limitRed[gameType][limitID];
    };
    HallDataCtrl.prototype.setChips = function (gameType, chips) {
        var compare = function (a, b) {
            return a - b;
        };
        var chipsData = chips.sort(compare);
        this.limitRed[gameType][this.loadGameModel.getLimitRedID]["chips"] = chipsData;
        this.loadGameModel.setChip(chipsData);
    };
    //获取默认限红ID
    HallDataCtrl.prototype.getNomalLimitID = function (gameType) {
        return this.nomalLimitRedID[gameType][0];
    };
    Object.defineProperty(HallDataCtrl.prototype, "getLoadGameData", {
        //游戏数据获取
        get: function () {
            return this.loadGameModel;
        },
        enumerable: true,
        configurable: true
    });
    HallDataCtrl.prototype.setLoadGameData = function (loadGameModel) {
        this.loadGameModel = loadGameModel;
    };
    HallDataCtrl.prototype.parsebetLimitAndChip = function (betLimitAndChip, gameType) {
        this.limitRed[gameType] = {};
        //var limitRedCompare=new Array<LimitDataModel>();
        var limitRed = new Array(); //限红值数组
        this.nomalLimitRedID[gameType] = new Array();
        for (var key in betLimitAndChip) {
            var limitDataModel = new LimitDataModel();
            this.nomalLimitRedID[gameType].push(Number(key));
            var betLimitAndChipArray = betLimitAndChip[key].split(":");
            limitDataModel.setLimitRedID(Number(key));
            limitDataModel.setLimitRedCount(betLimitAndChipArray[0]);
            limitDataModel.setChips(betLimitAndChipArray[1].split(","));
            limitDataModel.setAllChips(betLimitAndChipArray[2].split(","));
            //limitRedCompare.push(limitDataModel);
            this.limitRed[gameType][key] = limitDataModel;
        }
        //console.log("数组对象排序：");
        // var sortArr = limitRedCompare.sort(this.compare);
        // for (var key in sortArr) {
        // 	var limitDataModelp:LimitDataModel=sortArr[key];
        // 	this.nomalLimitRedID[gameType].push(limitDataModelp.getLimitRedID);
        // 	this.limitRed[gameType][limitDataModelp.getLimitRedID]=limitDataModelp;
        // }
    };
    return HallDataCtrl;
}());
__reflect(HallDataCtrl.prototype, "HallDataCtrl");
//# sourceMappingURL=HallDataCtrl.js.map