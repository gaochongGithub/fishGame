var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
 * 场景控制类(单例) 两大场景，大厅及游戏
 */
var GameSceneCtrl = (function () {
    function GameSceneCtrl() {
    }
    Object.defineProperty(GameSceneCtrl, "instance", {
        //获取实例对象
        get: function () {
            if (!this.gameSceneCtrl) {
                this.gameSceneCtrl = new GameSceneCtrl();
            }
            return this.gameSceneCtrl;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 初始化管理器的一些数据，游戏初始化调用
     */
    GameSceneCtrl.prototype.init = function (s) {
        //设置根场景
        this._stage = s;
    };
    //跳转大厅场景
    GameSceneCtrl.prototype.toHallScene = function () {
        this._stage.removeChildren();
        var hallScene = new PCHallScene();
        this._stage.addChild(hallScene);
        // const gameitem=new GameItem();
        // hallScene.addChild(gameitem);
    };
    //跳转手机大厅场景
    GameSceneCtrl.prototype.toMobileHallScene = function () {
        var mobileHallScene = new MoblieHallScene();
        this._stage.addChild(mobileHallScene);
        // const gameitem=new GameItem();
        // hallScene.addChild(gameitem);
    };
    //跳转游戏场景
    GameSceneCtrl.prototype.toGameScene = function (gameType) {
        this._stage.removeChildren();
        var game;
        if (App.DeviceUtils.IsMobile) {
            if (gameType == proto.GameType.Roulette)
                game = new MobileRoulette();
            else
                game = new PcBaccaratGameScene();
        }
        else {
            if (gameType == proto.GameType.Roulette)
                game = new PcRouletteGameScene();
            else
                game = new PcBaccaratGameScene();
        }
        this._stage.addChild(game);
    };
    return GameSceneCtrl;
}());
__reflect(GameSceneCtrl.prototype, "GameSceneCtrl");
//# sourceMappingURL=GameSceneCtrl.js.map