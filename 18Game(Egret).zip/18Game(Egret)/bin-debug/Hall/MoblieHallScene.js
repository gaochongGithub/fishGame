var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var MoblieHallScene = (function (_super) {
    __extends(MoblieHallScene, _super);
    function MoblieHallScene() {
        return _super.call(this) || this;
    }
    MoblieHallScene.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    MoblieHallScene.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
    };
    MoblieHallScene.prototype.initEventListener = function () {
        this.gameBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showRadioBtn, this);
        this.game_list.addEventListener(eui.ItemTapEvent.ITEM_TAP, this.ItemSelect, this);
        App.MessageCenter.addListener(LobbyEvent.SHOW_LIMIT_VIEW, this.limitShowChange, this);
        App.MessageCenter.addListener(LobbyEvent.LIMIT_CHOOSE, this.limitChose, this);
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE, this.onLanguageChange, this);
        this.toastView.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBegin, this);
    };
    MoblieHallScene.prototype.removeMyEventListener = function () {
        this.gameBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showRadioBtn, this);
        this.game_list.removeEventListener(eui.ItemTapEvent.ITEM_TAP, this.ItemSelect, this);
        this.toastView.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBegin, this);
        App.MessageCenter.removeListener(LobbyEvent.SHOW_LIMIT_VIEW, this.limitShowChange, this);
        App.MessageCenter.removeListener(LobbyEvent.LIMIT_CHOOSE, this.limitChose, this);
        App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE, this.onLanguageChange, this);
    };
    MoblieHallScene.prototype.limitChose = function (limitViewModel) {
        // if(this.data.gameTable==limitViewModel.getGameTable){
        // 	this.data.limitRedID=limitViewModel.getLimitChoseID;
        var data = LobbyTableInfoCtrl.instance.setLobbyOneTableLimitID(limitViewModel.getGameType, limitViewModel.getGameTable, limitViewModel.getLimitChoseID);
        if (data) {
            data.setIsShwoView(false);
            this.gameItemView.dataChanged(data, false, false);
        }
    };
    MoblieHallScene.prototype.touchBegin = function (evt) {
        this.toastView.visible = false;
        if (this.gameItemView) {
            this.removeChild(this.gameItemView);
            this.gameItemView = null;
        }
    };
    MoblieHallScene.prototype.onLanguageChange = function () {
        if (this.gameItemView) {
            var data = LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType, this.data.getGameTable);
            this.gameItemView.dataChanged(data, false, true);
        }
    };
    MoblieHallScene.prototype.limitShowChange = function (isShowView) {
        var data = LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType, this.data.getGameTable);
        if (data) {
            data.setIsShwoView(isShowView);
            this.gameItemView.dataChanged(data, false, false);
        }
    };
    MoblieHallScene.prototype.ItemSelect = function () {
        this.data = this.game_list.selectedItem;
        var data = LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType, this.data.getGameTable);
        if (data) {
            this.gameItemView = new GameItemView();
            this.gameItemView.verticalCenter = 0;
            this.toastView.visible = true;
            this.addChild(this.gameItemView);
            this.gameItemView.dataChanged(data, true, false);
        }
    };
    MoblieHallScene.prototype.showRadioBtn = function () {
        if (this.radioBtnView.left == -664) {
            this.right_btn.visible = false;
            egret.Tween.get(this.radioBtnView).to({ left: 150 }, 300, egret.Ease.sineIn);
        }
        else if (this.radioBtnView.left == 150) {
            egret.Tween.get(this.radioBtnView).to({ left: -664 }, 300, egret.Ease.sineIn);
            this.right_btn.visible = true;
        }
    };
    MoblieHallScene.prototype.initView = function () {
        this.skinName = MoblieHallSceneSkin;
    };
    return MoblieHallScene;
}(HallScene));
__reflect(MoblieHallScene.prototype, "MoblieHallScene");
//# sourceMappingURL=MoblieHallScene.js.map