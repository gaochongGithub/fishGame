var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GoodTipsPageView = (function (_super) {
    __extends(GoodTipsPageView, _super);
    function GoodTipsPageView() {
        return _super.call(this) || this;
    }
    GoodTipsPageView.prototype.tipsTouchBegin = function (evt) {
        this.tips_timer.stop();
        this.tips_touchStartY = evt.localY;
    };
    GoodTipsPageView.prototype.tipsTouchCancel = function (evt) {
        this.tips_touchEndY = evt.localY;
        if (this.tips_touchStartY > this.tips_touchEndY) {
            if (this.tips_pageIndex < this.tips_pageCount) {
                this.tips_pageIndex++;
            }
        }
        else {
            if (this.tips_pageIndex > 0) {
                this.tips_pageIndex--;
            }
        }
        egret.Tween.get(this.tips_scroller.viewport).to({ scrollV: this.tips_pageIndex * 46 }, 300, egret.Ease.sineIn);
        this.tips_timer.start();
    };
    GoodTipsPageView.prototype.tipsTouchEnd = function (evt) {
        this.tips_touchEndY = evt.localY;
        this.tips_timer.start();
    };
    GoodTipsPageView.prototype.tipsScrolMove = function (evt) {
        //this.ad_scroller.viewport.scrollH=evt.localX;
    };
    GoodTipsPageView.prototype.tipsTimerFunc = function (event) {
        this.tips_pageIndex++;
        if (this.tips_pageIndex >= this.tips_pageCount) {
            this.tips_pageIndex = 0;
        }
        egret.Tween.get(this.tips_scroller.viewport).to({ scrollV: this.tips_pageIndex * 46 }, 300, egret.Ease.sineIn);
    };
    GoodTipsPageView.prototype.dataChanged = function (dataArr) {
        // 转成eui数据
        this.tips_pageCount = dataArr.length;
        if (!this.euiArr) {
            this.euiArr = new eui.ArrayCollection(dataArr);
            this.tips_list.dataProvider = this.euiArr;
            this.tips_list.itemRenderer = GoodTipsView;
        }
        else {
            this.euiArr.replaceAll(dataArr);
        }
        if (!this.tips_timer) {
            this.tips_timer = new egret.Timer(2000, 0);
            this.tips_timer.addEventListener(egret.TimerEvent.TIMER, this.tipsTimerFunc, this);
            this.tips_timer.start();
            this.tips_pageIndex = 0;
            // this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_MOVE,this.tipsScrolMove,this);
            // this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.tipsTouchBegin,this);
            // this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_CANCEL,this.tipsTouchCancel,this);
            // this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_END,this.tipsTouchEnd,this);
        }
    };
    return GoodTipsPageView;
}(eui.Scroller));
__reflect(GoodTipsPageView.prototype, "GoodTipsPageView", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=GoodTipsPageView.js.map