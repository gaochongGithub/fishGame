var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GoodTipsView = (function (_super) {
    __extends(GoodTipsView, _super);
    function GoodTipsView() {
        return _super.call(this) || this;
    }
    GoodTipsView.prototype.initEventListener = function () {
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE, this.dataChanged, this);
    };
    GoodTipsView.prototype.removeMyEventListener = function () {
        App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE, this.dataChanged, this);
    };
    GoodTipsView.prototype.dataChanged = function () {
        if (App.LangUtils.kind == "ZH") {
            this.good_tips.texture = RES.getRes("goodTips" + this.data + "_png");
        }
        else {
            this.good_tips.texture = RES.getRes("goodTips" + this.data + "_en_png");
        }
    };
    return GoodTipsView;
}(ItemParent));
__reflect(GoodTipsView.prototype, "GoodTipsView");
//# sourceMappingURL=GoodTipsView.js.map