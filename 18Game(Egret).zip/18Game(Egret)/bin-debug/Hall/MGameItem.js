var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var MGameItem = (function (_super) {
    __extends(MGameItem, _super);
    function MGameItem() {
        return _super.call(this) || this;
    }
    // 当数据改变时，更新视图
    MGameItem.prototype.dataChanged = function () {
        var _this = this;
        this.itemData = this.data;
        switch (this.itemData.getTableSnapshot.gameType) {
            case proto.GameType.Baccarat:
                this.game_name.text = App.LangUtils.getStr("TEXT_BACCARAT") + ":" + this.itemData.getTableSnapshot.tableID;
                break;
            case proto.GameType.Roulette:
                this.game_name.text = App.LangUtils.getStr("TEXT_Roulette") + ":" + this.itemData.getTableSnapshot.tableID;
                break;
        }
        this.player_count.text = this.itemData.getTableSnapshot.playerCount.toString();
        this.coin_count.text = this.itemData.getTableSnapshot.playerTotalBlance.toString();
        var reusltArr = GoodTips.instance.checkTips(this.itemData.getTableSnapshot.tableID, this.itemData.getAllWays);
        var dataArr = new Array();
        for (var _i = 0, reusltArr_1 = reusltArr; _i < reusltArr_1.length; _i++) {
            var index = reusltArr_1[_i];
            var goodTipsType = index.type;
            if (goodTipsType != -1) {
                dataArr.push(Math.floor(goodTipsType));
            }
        }
        if (dataArr.length > 0) {
            this.tips_pageview.dataChanged(dataArr);
            this.tips_pageview.visible = true;
        }
        else {
            this.tips_pageview.visible = false;
        }
        this.laddy_name.text = this.itemData.getTableSnapshot.dealer;
        var url = this.itemData.getTableSnapshot.dealerImage;
        this.imgLoader = new egret.ImageLoader();
        this.imgLoader.crossOrigin = "anonymous"; // 跨域请求
        this.imgLoader.load(url); // 去除链接中的转义字符‘\’        
        this.imgLoader.once(egret.Event.COMPLETE, function (evt) {
            if (evt.currentTarget.data) {
                var texture = new egret.Texture();
                texture.bitmapData = evt.currentTarget.data;
                _this.laddy_head.source = texture;
                // texture.bitmapData = evt.currentTarget.data;
                // let bitmap = new egret.Bitmap(texture);
                // bitmap.x = 200;
                // bitmap.y = 200;
                // this.addChild(bitmap);
            }
        }, this);
    };
    return MGameItem;
}(ItemParent));
__reflect(MGameItem.prototype, "MGameItem");
//# sourceMappingURL=MGameItem.js.map