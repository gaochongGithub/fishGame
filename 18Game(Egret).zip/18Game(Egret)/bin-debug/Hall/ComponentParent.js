var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ComponentParent = (function (_super) {
    __extends(ComponentParent, _super);
    function ComponentParent() {
        var _this = _super.call(this) || this;
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    //注册消息
    ComponentParent.prototype.initEventListener = function () {
    };
    //移除消息
    ComponentParent.prototype.removeMyEventListener = function () {
    };
    //移除消息
    ComponentParent.prototype.onRemoveStage = function (event) {
        this.removeMyEventListener();
    };
    ComponentParent.prototype.initView = function () { };
    ComponentParent.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.initEventListener();
        this.initView();
    };
    ComponentParent.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    return ComponentParent;
}(eui.Component));
__reflect(ComponentParent.prototype, "ComponentParent", ["eui.UIComponent", "egret.DisplayObject", "ViewInterface"]);
//# sourceMappingURL=ComponentParent.js.map