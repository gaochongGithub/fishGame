var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ItemParent = (function (_super) {
    __extends(ItemParent, _super);
    function ItemParent() {
        var _this = _super.call(this) || this;
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveStage, _this);
        return _this;
    }
    //注册消息
    ItemParent.prototype.initEventListener = function () {
    };
    //移除消息
    ItemParent.prototype.removeMyEventListener = function () {
    };
    //移除消息
    ItemParent.prototype.onRemoveStage = function (event) {
        this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
        this.removeMyEventListener();
    };
    ItemParent.prototype.initView = function () { };
    ItemParent.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.initEventListener();
        this.initView();
    };
    ItemParent.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    ItemParent.prototype.dataChanged = function () {
    };
    return ItemParent;
}(eui.ItemRenderer));
__reflect(ItemParent.prototype, "ItemParent", ["eui.UIComponent", "egret.DisplayObject", "ViewInterface"]);
//# sourceMappingURL=ItemParent.js.map