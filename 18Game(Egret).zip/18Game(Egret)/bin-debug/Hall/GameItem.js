var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GameItem = (function (_super) {
    __extends(GameItem, _super);
    function GameItem() {
        return _super.call(this) || this;
    }
    GameItem.prototype.initEventListener = function () {
        App.MessageCenter.addListener(LobbyEvent.SHOW_LIMIT_VIEW, this.limitShowChange, this);
        App.MessageCenter.addListener(LobbyEvent.LIMIT_CHOOSE, this.limitChose, this);
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE, this.onLanguageChange, this);
    };
    GameItem.prototype.removeMyEventListener = function () {
        App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE, this.onLanguageChange, this);
    };
    GameItem.prototype.onLanguageChange = function () {
        if (this.gameItemView) {
            this.gameItemView.dataChanged(this.data, false, true);
        }
    };
    GameItem.prototype.limitChose = function (limitViewModel) {
        if (this.data.gameTable == limitViewModel.getGameTable) {
            this.data.isShowView = false;
            this.data.limitRedID = limitViewModel.getLimitChoseID;
            this.gameItemView.dataChanged(this.data, false, false);
        }
    };
    GameItem.prototype.limitShowChange = function () {
        if (this.gameItemView) {
            this.gameItemView.dataChanged(this.data, false, false);
        }
    };
    // 当数据改变时，更新视图
    GameItem.prototype.dataChanged = function () {
        if (!this.data.getTableSnapshot) {
            this.skinName = ADItem;
            // 原始数组
            var dataArr = [
                { type: '0', name: '亚特伍德' },
                { type: '1', name: '亚特伍德1' },
                { type: '0', name: '亚特伍德2' },
                { type: '0', name: '亚特伍德3' },
                { type: '0', name: '亚特伍德4' },
                { type: '0', name: '亚特伍德5' },
                { type: '0', name: '亚特伍德6' },
            ];
            this.adPageview.dataChanged(dataArr);
        }
        else {
            this.skinName = GameItemSkin;
            this.gameItemView.dataChanged(this.data, true, false);
        }
    };
    return GameItem;
}(ItemParent));
__reflect(GameItem.prototype, "GameItem");
//# sourceMappingURL=GameItem.js.map