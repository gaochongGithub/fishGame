var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LimitView = (function (_super) {
    __extends(LimitView, _super);
    function LimitView() {
        var _this = _super.call(this) || this;
        _this.dataArr = new Array();
        return _this;
    }
    LimitView.prototype.setLimitData = function (gameType, limitID, tableID) {
        var limitRed = HallDataCtrl.instance.getGameLimitRed(gameType);
        this.dataArr = [];
        for (var key in limitRed) {
            var limitObject = limitRed[key];
            var limitViewModel = new LimitViewModel();
            if (limitObject.getLimitRedID == limitID) {
                limitViewModel.setIsChose(true);
            }
            else {
                limitViewModel.setIsChose(false);
            }
            limitViewModel.setLimitChoseID(limitObject.getLimitRedID);
            limitViewModel.setLimitChoseCount(limitObject.getLimitRedCounts);
            limitViewModel.setGameType(gameType);
            limitViewModel.setGameTable(tableID);
            this.dataArr.push(limitViewModel);
        }
        var sortArray = this.dataArr.sort(this.compare);
        if (!this.euiArr) {
            this.euiArr = new eui.ArrayCollection(sortArray);
            this.limit_list.dataProvider = this.euiArr;
            this.limit_list.itemRenderer = LImitRadioBtn;
        }
        else {
            this.euiArr.replaceAll(sortArray);
        }
    };
    //排序
    LimitView.prototype.compare = function (obj1, obj2) {
        var data1 = obj1.getLimitChoseCount.split("-");
        var data2 = obj2.getLimitChoseCount.split("-");
        if (Number(data1[0]) == Number(data2[0])) {
            var val1 = Number(data1[1]);
            var val2 = Number(data2[1]);
        }
        else {
            var val1 = Number(data1[0]);
            var val2 = Number(data2[0]);
        }
        if (val1 < val2) {
            return -1;
        }
        else if (val1 > val2) {
            return 1;
        }
        else {
            return 0;
        }
    };
    return LimitView;
}(ComponentParent));
__reflect(LimitView.prototype, "LimitView");
//# sourceMappingURL=LimitView.js.map