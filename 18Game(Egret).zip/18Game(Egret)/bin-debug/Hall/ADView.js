var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ADView = (function (_super) {
    __extends(ADView, _super);
    function ADView() {
        return _super.call(this) || this;
    }
    ADView.prototype.initView = function () {
        this.skinName = ADViewSkin;
    };
    return ADView;
}(ItemParent));
__reflect(ADView.prototype, "ADView");
//# sourceMappingURL=ADView.js.map