var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ADPageView = (function (_super) {
    __extends(ADPageView, _super);
    function ADPageView() {
        var _this = _super.call(this) || this;
        _this.ad_pageCount = 5;
        return _this;
    }
    ADPageView.prototype.adTouchBegin = function (evt) {
        this.ad_timer.stop();
        this.ad_touchStartX = evt.localX;
    };
    ADPageView.prototype.adTouchCancel = function (evt) {
        this.ad_touchEndX = evt.localX;
        if (this.ad_touchStartX > this.ad_touchEndX) {
            if (this.ad_pageIndex < this.ad_pageCount) {
                this.ad_pageIndex++;
            }
        }
        else {
            if (this.ad_pageIndex > 0) {
                this.ad_pageIndex--;
            }
        }
        egret.Tween.get(this.ad_scroller.viewport).to({ scrollH: this.ad_pageIndex * 810 }, 300, egret.Ease.sineIn);
        this.ad_timer.start();
    };
    ADPageView.prototype.adTouchEnd = function (evt) {
        this.ad_touchEndX = evt.localX;
        this.ad_timer.start();
    };
    ADPageView.prototype.adScrolMove = function (evt) {
        //this.ad_scroller.viewport.scrollH=evt.localX;
    };
    ADPageView.prototype.adTimerFunc = function (event) {
        if (this.ad_pageIndex > this.ad_pageCount) {
            this.ad_pageIndex = 0;
        }
        this.ad_pageIndex++;
        egret.Tween.get(this.ad_scroller.viewport).to({ scrollH: this.ad_pageIndex * 810 }, 300, egret.Ease.sineIn);
    };
    ADPageView.prototype.dataChanged = function (dataArr) {
        // 转成eui数据
        if (!this.euiArr) {
            this.euiArr = new eui.ArrayCollection(dataArr);
            this.ad_list.dataProvider = this.euiArr;
            this.ad_list.itemRenderer = ADView;
        }
        else {
            this.euiArr.replaceAll(dataArr);
        }
        if (!this.ad_timer) {
            this.ad_timer = new egret.Timer(2000, 0);
            this.ad_timer.addEventListener(egret.TimerEvent.TIMER, this.adTimerFunc, this);
            this.ad_timer.start();
            this.ad_pageIndex = 0;
            this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.adScrolMove, this);
            this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.adTouchBegin, this);
            this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_CANCEL, this.adTouchCancel, this);
            this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_END, this.adTouchEnd, this);
        }
    };
    return ADPageView;
}(eui.Scroller));
__reflect(ADPageView.prototype, "ADPageView");
//# sourceMappingURL=ADPageView.js.map