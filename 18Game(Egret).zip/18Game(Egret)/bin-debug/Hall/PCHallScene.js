var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PCHallScene = (function (_super) {
    __extends(PCHallScene, _super);
    function PCHallScene() {
        return _super.call(this) || this;
    }
    PCHallScene.prototype.initView = function () {
        this.skinName = HallSceneSkin;
    };
    PCHallScene.prototype.initEventListener = function () {
        App.MessageCenter.addListener(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO, this.upDataPlayerCount, this);
        this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBegin, this);
        this.downAndLogin.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showEqView, this);
    };
    PCHallScene.prototype.showEqView = function () {
        this.createdEQView();
    };
    PCHallScene.prototype.touchBegin = function (evt) {
        if (this.eq_group) {
            this.removeChild(this.eq_group);
            this.eq_group = null;
        }
    };
    PCHallScene.prototype.removeMyEventListener = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO, this.upDataPlayerCount, this);
        this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBegin, this);
        this.downAndLogin.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showEqView, this);
    };
    PCHallScene.prototype.upDataPlayerCount = function () {
        this.playerCount.text = HallDataCtrl.instance.getPlayerCount + "";
    };
    // gameRadioChange(e:egret.Event){
    // 	var radioButton = <eui.RadioButton>e.target;
    // 	this.gameType=radioButton.value
    // 	// console.log("radioButton.value222"+radioButton.value);
    // }
    // addRoadItem(){
    // 	var lobbyTableInfo=LobbyTableInfoCtrl.getLobbyTableInfoCtrl.getLobbyTableArrByGameType(this.gameType);
    // 	if(lobbyTableInfo){
    // 		if(!this.euiArr){
    // 			//插入轮播广告 暂时无数据
    // 			lobbyTableInfo.splice(1, 0, {})
    // 			this.euiArr = new eui.ArrayCollection(lobbyTableInfo);
    // 			this.game_list.dataProvider=this.euiArr;
    // 			this.game_list.itemRenderer=GameItem;
    // 		}else{
    // 			this.game_list.dataProviderRefreshed();
    // 		}
    // 	}	
    // }
    PCHallScene.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.upDataPlayerCount();
    };
    PCHallScene.prototype.createdEQView = function () {
        var uname = egret.localStorage.getItem("uname");
        var pwd = egret.localStorage.getItem("pwd");
        var data = App.Base64.encode("uname=" + uname + "&" + "pwd=" + pwd);
        //cmkj.Utils.QRCreate(this.qwNode, "http://www.baidu.com?paramStr=dW5hbWUlM0RjbWtqX3Rlc3QyMSUyNnB3ZCUzRGVhYmQ4Y2U5NDA0NTA3YWE4YzIyNzE0ZDNmNWVhZGE5");
        this.eq_group = new eui.Group();
        this.eq_group.width = 300;
        this.eq_group.height = 300;
        this.eq_group.x = this.width / 2 - this.eq_group.width / 2;
        this.eq_group.y = this.height / 2 - this.eq_group.height / 2;
        var eq_bg = new eui.Image();
        eq_bg.texture = RES.getRes("whiteBg_png");
        eq_bg.width = 300;
        eq_bg.height = 300;
        eq_bg.scale9Grid = new egret.Rectangle(4, 4, 4, 4);
        var sprite = qr.QRCode.create(App.GlobalData.DownLoadUrl + "?paramStr=" + data, 0, 300, 300);
        sprite.x = this.eq_group.width / 2 - sprite.width / 2;
        sprite.y = this.eq_group.height / 2 - sprite.height / 2;
        this.eq_group.addChild(eq_bg);
        this.eq_group.addChild(sprite);
        this.addChild(this.eq_group);
    };
    return PCHallScene;
}(HallScene));
__reflect(PCHallScene.prototype, "PCHallScene");
//# sourceMappingURL=PCHallScene.js.map