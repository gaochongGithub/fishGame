var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var HallScene = (function (_super) {
    __extends(HallScene, _super);
    function HallScene() {
        return _super.call(this) || this;
    }
    //初始化一些可以由父类实现的共同监听事件
    HallScene.prototype.initCommonEventListener = function () {
        this.rechage_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onReChangeBtn, this);
        App.MessageCenter.addListener(ServerEvent.GET_LOBBY_PLAYER_INFO, this.upDataPlayerInfo, this);
        this.bGameRadio.addEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.lGameRadio.addEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        App.MessageCenter.addListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM, this.addRoadItem, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
        this.settingBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onSettingBtn, this);
        this.ruleBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onRuleBtn, this);
        this.videoBtn.addEventListener(egret.Event.CHANGE, this.onVideoChange, this);
        this.soundBtn.addEventListener(egret.Event.CHANGE, this.onSoundBtnChange, this);
        App.MessageCenter.addListener(LobbyEvent.MUISC_SOUND_CHANGE, this.onSoundChange, this);
        this.exitBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickLoginOutBtn, this);
    };
    HallScene.prototype.removeCommonEventListener = function () {
        this.rechage_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onReChangeBtn, this);
        App.MessageCenter.removeListener(ServerEvent.GET_LOBBY_PLAYER_INFO, this.upDataPlayerInfo, this);
        this.bGameRadio.removeEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        this.lGameRadio.removeEventListener(egret.Event.CHANGE, this.gameRadioChange, this);
        App.MessageCenter.removeListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM, this.addRoadItem, this);
        this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
        this.settingBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onSettingBtn, this);
        this.ruleBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onRuleBtn, this);
        this.videoBtn.removeEventListener(egret.Event.CHANGE, this.onVideoChange, this);
        this.soundBtn.removeEventListener(egret.Event.CHANGE, this.onSoundBtnChange, this);
        App.MessageCenter.removeListener(LobbyEvent.MUISC_SOUND_CHANGE, this.onSoundChange, this);
        this.exitBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickLoginOutBtn, this);
    };
    HallScene.prototype.onRemoveStage = function (event) {
        this.removeMyEventListener();
        this.removeCommonEventListener();
    };
    HallScene.prototype.onVideoChange = function () {
        egret.localStorage.setItem("isCanPlayVideo", this.videoBtn.selected ? "1" : "0");
    };
    HallScene.prototype.onSoundBtnChange = function () {
        if (this.soundBtn.selected) {
            App.SoundManager.setBgOn(true);
            App.SoundManager.setEffectOn(true);
        }
        else {
            App.SoundManager.setBgOn(false);
            App.SoundManager.setEffectOn(false);
        }
    };
    HallScene.prototype.onSoundChange = function () {
        this.soundBtn.selected = App.SoundManager.bgIsOn || App.SoundManager.effectIsOn;
    };
    HallScene.prototype.onSettingBtn = function () {
        App.ToastViewManager.toast(new SettingView, false, true);
    };
    HallScene.prototype.onRuleBtn = function () {
        App.ToastViewManager.toast(new RuleView, false, true);
    };
    HallScene.prototype.upDataPlayerInfo = function () {
        var playerInfo = HallDataCtrl.instance.getLobbyPlayer;
        this.name_text.text = playerInfo.name;
        this.gold_text.text = "￥ " + playerInfo.balance;
    };
    HallScene.prototype.addRoadItem = function () {
        var lobbyTableInfo = LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.gameType);
        if (lobbyTableInfo) {
            if (!this.euiArr) {
                //插入轮播广告 暂时无数据
                if (App.DeviceUtils.IsMobile) {
                    this.game_list.itemRenderer = MGameItem;
                }
                else {
                    lobbyTableInfo.splice(1, 0, {});
                    this.game_list.itemRenderer = GameItem;
                }
                this.euiArr = new eui.ArrayCollection(lobbyTableInfo);
                this.game_list.dataProvider = this.euiArr;
            }
            else {
                if (!App.DeviceUtils.IsMobile)
                    lobbyTableInfo.splice(1, 0, {});
                this.euiArr.replaceAll(lobbyTableInfo);
            }
        }
    };
    HallScene.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    HallScene.prototype.onReChangeBtn = function (event) {
        // var chats=new chat();
        // this.addChild(chats);
        // chats.horizontalCenter=0;
        // chats.verticalCenter=0;
        //App.LangUtils.changeLang("EN");
        // var data=LobbyTableInfoCtrl.instance.getLobbyOneTable(11,1);
        // console.log("LobbyTableInfoCtrl"+data.getTableSnapshot.counts)
        // var aa=new TimeCompentView(this);
        // this.addChild(aa);
        //var aa=new SettingView();
        //this.addChild(aa);
        //App.ToastViewManager.toast(new SettingView,false);
        // var lobbyTableInfo=LobbyTableInfoCtrl.instance.getLobbyTableArr();
        App.ToastViewManager.toast(new RecordView(), false, true);
        // if (!App.DeviceUtils.IsNative){
        // 	var url = egret.localStorage.getItem("chargeUrl"); 
        // 	url&&window.open(url);
        // }
    };
    HallScene.prototype.onScrollerChange = function () {
    };
    HallScene.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.initView();
        this.initCommonEventListener();
        this.initEventListener();
        this.upDataPlayerInfo();
        this.gameType = proto.GameType.Baccarat;
        this.onSoundChange();
        var isCanPlayVideo = egret.localStorage.getItem("isCanPlayVideo");
        this.videoBtn.selected = isCanPlayVideo == "1";
        this.addRoadItem();
    };
    HallScene.prototype.gameRadioChange = function (e) {
        var radioButton = e.target;
        switch (Number(radioButton.value)) {
            case proto.GameType.Baccarat:
                this.gameType = proto.GameType.Baccarat;
                this.addRoadItem();
                break;
            case proto.GameType.Roulette:
                this.gameType = proto.GameType.Roulette;
                this.addRoadItem();
                break;
        }
    };
    HallScene.prototype.onClickLoginOutBtn = function () {
        if (!App.DeviceUtils.IsNative) {
            window.opener = null;
            window.open('', '_self');
            window.close();
            window.history.back();
            window.location.reload();
        }
    };
    return HallScene;
}(SceneParent));
__reflect(HallScene.prototype, "HallScene");
//# sourceMappingURL=HallScene.js.map