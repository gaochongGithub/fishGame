var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LImitRadioBtn = (function (_super) {
    __extends(LImitRadioBtn, _super);
    function LImitRadioBtn() {
        return _super.call(this) || this;
    }
    LImitRadioBtn.prototype.initEventListener = function () {
        var _this = this;
        this.radioBtn.addEventListener(eui.UIEvent.CHANGE, function (e) {
            _this.data.setIsChose(_this.radioBtn.selected);
            App.MessageCenter.dispatch(LobbyEvent.LIMIT_CHOOSE, _this.data);
        }, this);
    };
    LImitRadioBtn.prototype.removeMyEventListener = function () {
    };
    LImitRadioBtn.prototype.dataChanged = function () {
        this.radioText.text = this.data.getLimitChoseCount;
        this.radioBtn.selected = this.data.isChose;
    };
    return LImitRadioBtn;
}(ItemParent));
__reflect(LImitRadioBtn.prototype, "LImitRadioBtn");
//# sourceMappingURL=LImitRadioBtn.js.map