var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ToastViewManager = (function (_super) {
    __extends(ToastViewManager, _super);
    function ToastViewManager() {
        var _this = _super.call(this) || this;
        _this._parentLayer = null;
        return _this;
    }
    Object.defineProperty(ToastViewManager.prototype, "parentLayer", {
        get: function () {
            return this._parentLayer;
        },
        set: function (layer) {
            this._parentLayer = layer;
        },
        enumerable: true,
        configurable: true
    });
    //带底框弹出
    ToastViewManager.prototype.toastBaseView = function (title) {
        this.baseToastView = new BaseToastView();
        this.baseToastView.setTitle(title);
        this.parentLayer.addChild(this.baseToastView);
        // this.toast(this.baseToastView,true);
    };
    //开牌结果输赢
    ToastViewManager.prototype.toastResultView = function (title, resultType, imgName) {
        if (imgName === void 0) { imgName = null; }
        this.resultToastView = new ResultToastView();
        this.resultToastView.setContent(title, resultType, imgName);
        // this.toast(this.resultToastView,true,false);
        this.parentLayer.addChild(this.resultToastView);
    };
    //服务器弹框
    ToastViewManager.prototype.toastServerView = function (title) {
        this.serverToastView = new ServerToastView();
        this.serverToastView.setContent(title);
        this.toast(this.serverToastView, false, true);
    };
    //文字弹框
    ToastViewManager.prototype.toastTextView = function (title) {
        this.textToastView = new TextToastView();
        this.textToastView.setContent(title);
        //this.toast(this.textToastView,true,false);
        this.parentLayer.addChild(this.textToastView);
        this.textToastView.updataPosition();
    };
    ToastViewManager.prototype.toast = function (view, isAutoRemove, isShowBackRect) {
        if (isShowBackRect === void 0) { isShowBackRect = false; }
        this.toastBg = new ToastBgView(isAutoRemove, isShowBackRect);
        this.toastBg.addChild(view);
        this.parentLayer.addChild(this.toastBg);
    };
    ToastViewManager.prototype.clearAll = function () {
        this.toastBg && this.parentLayer.removeChild(this.toastBg);
    };
    return ToastViewManager;
}(SingtonClass));
__reflect(ToastViewManager.prototype, "ToastViewManager");
//# sourceMappingURL=ToastViewManager.js.map