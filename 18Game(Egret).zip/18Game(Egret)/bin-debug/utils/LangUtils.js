var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LangUtils = (function (_super) {
    __extends(LangUtils, _super);
    /**
    * 构造函数
    */
    function LangUtils() {
        var _this = _super.call(this) || this;
        _this._obj = new Object();
        _this._kind = "ZH";
        _this._resultObj = new Object();
        return _this;
    }
    Object.defineProperty(LangUtils.prototype, "kind", {
        get: function () {
            return this._kind;
        },
        set: function (kind) {
            this._kind = kind;
            //setCookie("LANGUAGE", this._kind);
        },
        enumerable: true,
        configurable: true
    });
    LangUtils.prototype.init = function (kind) {
        // Lang.obj[kind] = RES.getRes(kind);
        this._obj = RES.getRes('Lang_json');
        this._resultObj = RES.getRes('baccaratResult_json');
        this.kind = kind;
    };
    LangUtils.prototype.changeLang = function (kind) {
        if (this._kind != kind) {
            this.kind = kind;
            App.MessageCenter.dispatch(GlobalEvent.CHANGE_LANGUAGE);
            egret.localStorage.setItem("lang", kind);
        }
    };
    LangUtils.prototype.getStr = function (key) {
        return this._obj[key][this._kind];
    };
    LangUtils.prototype.getResultStr = function (result) {
        return this._resultObj[result][this._kind];
    };
    return LangUtils;
}(SingtonClass));
__reflect(LangUtils.prototype, "LangUtils");
//# sourceMappingURL=LangUtils.js.map