var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteResult = (function (_super) {
    __extends(RouletteResult, _super);
    function RouletteResult() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/RouletteResult.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddedToStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemovedFromStage, _this);
        return _this;
    }
    RouletteResult.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    RouletteResult.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
    };
    RouletteResult.prototype.onAddedToStage = function () {
        App.MessageCenter.addListener(RouletteEvent.GET_GAME_RESULT, this.getGameResult, this);
    };
    RouletteResult.prototype.onRemovedFromStage = function () {
        App.MessageCenter.removeListener(RouletteEvent.GET_GAME_RESULT, this.getGameResult, this);
    };
    /**
     * 获取结果
     */
    RouletteResult.prototype.getGameResult = function (event) {
        var result = event;
        this.result_label.text = result;
        // if (result == this.num) {
        //     this.sendOtherEventId();
        // }
        // console.log(RES.getRes(this.getBgImagename(result)) , "奥斯卡了");
        if (result == 0) {
            this.result_color.texture = RES.getRes("result_green_bg_png");
        }
        else {
            this.result_color.texture = RES.getRes(this.getBgImagename(result));
            this.setNumIsEven(result);
            this.setNumIsLarge(result);
            this.setNumRange(result);
            this.setNumRemainder(result);
        }
    };
    /**
     * 获取背景色
     */
    RouletteResult.prototype.getBgImagename = function (num) {
        var imageName = "";
        if (num <= 9 || (num >= 19 && num <= 27)) {
            imageName = this.getBgName1To9And19To23(num);
        }
        else if (num == 10 || num == 28) {
            imageName = "result_black_bg_png"; //
        }
        else if (num <= 18 || (num >= 29 && num <= 36)) {
            imageName = this.getBgName11To18And29To36(num);
        }
        return imageName;
    };
    /**
     * 返回1-9和19-23的按钮背景
     */
    RouletteResult.prototype.getBgName1To9And19To23 = function (index) {
        if (index % 2 == 0) {
            return "result_black_bg_png";
        }
        else {
            return "result_red_bg_png";
        }
    };
    /**
     * 返回11-18和29-36的按钮背景
     */
    RouletteResult.prototype.getBgName11To18And29To36 = function (index) {
        if (index % 2 != 0) {
            return "result_black_bg_png";
        }
        else {
            return "result_red_bg_png";
        }
    };
    RouletteResult.prototype.setNumIsEven = function (result) {
        var isEven = (result % 2 == 0) ? "双" : "单";
        this.odd_even.text = isEven;
    };
    RouletteResult.prototype.setNumIsLarge = function (result) {
        var isBig = (result >= 19) ? "大" : "小";
        this.big_small.text = isBig;
    };
    RouletteResult.prototype.setNumRange = function (result) {
        var range = Math.ceil(result / 12);
        var text = "";
        if (range == 1) {
            text = "第一打";
        }
        else if (range == 2) {
            text = "第二打";
        }
        else {
            text = "第三打";
        }
        this.column_label.text = text;
    };
    RouletteResult.prototype.setNumRemainder = function (result) {
        var remainder = result % 3;
        var text = "";
        if (remainder == 1) {
            text = "第一列";
        }
        else if (remainder == 2) {
            text = "第二列";
        }
        else {
            text = "第三列";
        }
        this.dozen_label.text = text;
    };
    return RouletteResult;
}(eui.Component));
__reflect(RouletteResult.prototype, "RouletteResult", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RouletteResult.js.map