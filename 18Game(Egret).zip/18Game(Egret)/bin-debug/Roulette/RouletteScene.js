var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteScene = (function (_super) {
    __extends(RouletteScene, _super);
    function RouletteScene() {
        var _this = _super.call(this) || this;
        _this.isStart = false;
        _this.isBet = false; //是否下注
        _this.status = 0;
        return _this;
    }
    RouletteScene.prototype.childrenCreated = function () {
        this.initCommonEventListener();
        this.initView();
        this.initEventListener();
    };
    RouletteScene.prototype.onRemoveStage = function (event) {
        this.removeMyEventListener();
        this.removeCommonEventListener();
    };
    //初始化一些可以由父类实现的共同监听事件
    RouletteScene.prototype.initCommonEventListener = function () {
        //进桌
        GameServer.getSingtonInstance().sendJoinTable(proto.GameType.Roulette, 300, proto.UserRequest.JoinType.Common);
        //接收服务器游戏状态
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVipTable, this);
        //接收确认下注事件
        App.MessageCenter.addListener(GameEvent.CONFIRM_BET_AMOUNT, this.receiveConfirmBetAmountEvent, this);
        App.MessageCenter.addListener(GameEvent.ASK_IS_BET, this.sendIsBet, this);
        //接收游戏用户信息
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
    };
    RouletteScene.prototype.removeCommonEventListener = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.getGameUserInfoEvent, this);
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE, this.updateVipTable, this);
        App.MessageCenter.removeListener(GameEvent.CONFIRM_BET_AMOUNT, this.receiveConfirmBetAmountEvent, this);
    };
    RouletteScene.prototype.getGameStatus = function (data) {
        var gameStatus = data.status;
        this.statusData = data;
        this.status = gameStatus;
        switch (gameStatus) {
            case Status.Shuffle:
                this.getGameStateShuffle();
                break;
            case Status.Start:
                this.getGameStateStart();
                break;
            case Status.Stop:
                this.getGameStateStop();
                break;
            case Status.Payout:
                this.getGameStateResult(data.result);
                break;
            case Status.OK:
                this.getGameStateOk();
                break;
            case Status.Invalied:
                console.log("");
                break;
            default:
                break;
        }
    };
    //洗牌
    RouletteScene.prototype.getGameStateShuffle = function () {
        //"洗牌"
        //alert("洗牌");
        App.ToastViewManager.toastTextView("TEXT_SHUFFLE");
    };
    //开始下注
    RouletteScene.prototype.getGameStateStart = function () {
        if (!this.isStart) {
            this.isStart = true;
            App.ToastViewManager.toastTextView("TEXT_STATUS_1");
            App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_START, this.isStart);
            App.MessageCenter.dispatch(RouletteEvent.SET_BET_BTN_CAN_CLICK, true);
        }
    };
    RouletteScene.prototype.getGameStateStop = function () {
        App.ToastViewManager.toastTextView("TEXT_MESSAGE_2");
        this.isStart = false;
        App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_START, this.isStart);
        App.MessageCenter.dispatch(RouletteEvent.SET_BET_BTN_CAN_CLICK, false);
        App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_STOP);
    };
    /**
     * 获取结果
     */
    RouletteScene.prototype.getGameStateResult = function (result) {
        this.isBet = false;
        App.MessageCenter.dispatch(RouletteEvent.GET_GAME_RESULT, result);
        this.rouletteResule = new RouletteResult();
        if (App.DeviceUtils.IsMobile) {
            this.rouletteResule.scaleX = 0.6;
            this.rouletteResule.scaleY = 0.6;
        }
        this.rouletteResule.horizontalCenter = 0;
        this.rouletteResule.top = 0;
        // this.setChildIndex(this.rouletteResule , 1);
        this.addChild(this.rouletteResule);
    };
    //获取数据
    RouletteScene.prototype.getGameUserInfoEvent = function (data) {
        if (this.status == Status.Payout) {
            var winlose = data.winlose;
            winlose = winlose > 0 ? "+" + winlose : winlose;
            var text;
            if (winlose >= 0) {
                text = "TEXT_TABLE_WIN";
            }
            else {
                text = "TEXT_TABLE_LOSE";
                winlose = Math.abs(winlose);
            }
            App.ToastViewManager.toastResultView(text, winlose);
        }
    };
    RouletteScene.prototype.getGameStateOk = function () {
        this.removeChild(this.rouletteResule);
        App.MessageCenter.dispatch(RouletteEvent.GAME_STATUS_OK);
    };
    RouletteScene.prototype.updateVipTable = function (data) {
        var playerInfo = HallDataCtrl.instance.getLobbyPlayer;
        for (var i in data.seats) {
            if (data.seats[i].uid == playerInfo.uid) {
                if (JSON.stringify(data.seats[i].betinfo) !== '{}' && this.status !== 3) {
                    this.isBet = true;
                }
            }
        }
    };
    //接收确认下注事件
    RouletteScene.prototype.receiveConfirmBetAmountEvent = function () {
        this.isBet = true;
    };
    RouletteScene.prototype.sendIsBet = function (event) {
        event.AskIsBet(this.isBet);
    };
    return RouletteScene;
}(eui.Component));
__reflect(RouletteScene.prototype, "RouletteScene", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RouletteScene.js.map