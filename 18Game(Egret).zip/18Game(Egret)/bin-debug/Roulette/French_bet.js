var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var French_bet = (function (_super) {
    __extends(French_bet, _super);
    function French_bet() {
        var _this = _super.call(this) || this;
        _this.resultTable = [];
        _this.allGameTableHistory = [];
        _this.gameTableHistory = "";
        _this.skinName = "resource/skins/roulette/bet/French_bet.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    French_bet.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    French_bet.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
    };
    French_bet.prototype.onAddtoStage = function (event) {
        this.clickBet();
        App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.getGameTableHistory, this);
    };
    French_bet.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.getGameTableHistory, this);
    };
    French_bet.prototype.clickBet = function () {
    };
    French_bet.prototype.onClickSelf = function (event) {
        // var btn:eui.Button = event.target;
        // console.log("onClickSelf" , btn);
    };
    //获取历史数据
    French_bet.prototype.getGameTableHistory = function (data) {
        if (this.resultTable.length >= 12) {
            this.resultTable.pop();
        }
        var str = data.way;
        var arr = str.split(",");
        var arr1 = str.split(",");
        this.getWinNum(arr);
        for (var i = 0; i < arr.length; i++) {
            this.gameTableHistory += "," + arr[i];
            if (i <= 11) {
                if (arr.length <= 1) {
                    this.resultTable.unshift(arr1.pop());
                }
                else {
                    this.resultTable.push(arr1.pop());
                }
            }
        }
        this.fillIn(this.resultTable);
    };
    //将数据填入label
    French_bet.prototype.fillIn = function (resultTable) {
        for (var i = 0; i < 12; i++) {
            if (resultTable[i] !== undefined) {
                var label = this.label_group.getChildByName("road_label_" + i);
                label.text = resultTable[i];
                if (Number(resultTable[i]) == 0) {
                    label.textColor = 0x1BD745;
                }
                else {
                    label.textColor = this.getBgImagename(Number(resultTable[i]));
                }
            }
        }
    };
    //获取win的数字
    French_bet.prototype.getWinNum = function (arr) {
        for (var i = 0; i < arr.length; i++) {
            this.allGameTableHistory.push(Number(arr[i]));
        }
        this.secodFunc(this.allGameTableHistory);
        var testData = [];
        for (var i = 0; i < 36; i++) {
            testData.push(i);
        }
        this.testFunc(testData, this.allGameTableHistory);
    };
    //第三的方法
    French_bet.prototype.secodFunc = function (arr) {
        var obj = {};
        arr.forEach(function (item) {
            obj[item] = (obj[item] || 0) + 1;
        });
        var list = [];
        for (var key in obj) {
            list.push(key + "," + obj[key]);
        }
        list.sort(function (a, b) { return Number(a.split(",")[1]) - Number(b.split(",")[1]); });
        // this.resultList = list;
        this.fillInMaxResuldType(list);
    };
    French_bet.prototype.testFunc = function (arr1, arr2) {
        var temp = arr1.concat(arr2);
        var rel = {};
        var end = [];
        for (var i = 0; i < temp.length; i++) {
            temp[i] in rel ? rel[temp[i]]++ : rel[temp[i]] = 1;
        }
        for (var x in rel) {
            if (rel[x] == 1) {
                end.push(x);
            }
        }
        if (end.length > 0) {
            this.fillInMinResuldType(end);
        }
    };
    //热门数据
    French_bet.prototype.fillInMaxResuldType = function (list) {
        for (var i = 0; i < 3; i++) {
            var num = list[list.length - (i + 1)].split(",")[0];
            var num1 = list[list.length - (i + 1)].split(",")[1];
            var color;
            if (num == 0) {
                color = 0x1BD745;
            }
            color = this.getBgImagename(num);
            if (this.getBgImagename(num) == 0xB9B9B9) {
                color = 0x000000;
            }
            var rect = this.hot_group.getChildByName("hot_rect_" + i);
            rect.fillColor = color;
            var hotLab = this.hot_group.getChildByName("hot_label_" + i);
            hotLab.text = num;
            var hotNum = this.hot_group.getChildByName("hot_number_" + i);
            hotNum.text = num1;
        }
    };
    //冷门数据
    French_bet.prototype.fillInMinResuldType = function (arr) {
        if (arr.length <= 3) {
            for (var i = 0; i < arr.length; i++) {
                var num = arr[i].split(",")[0];
                var num1 = arr[i].split(",")[1];
                var color;
                if (num == 0) {
                    color = 0x1BD745;
                }
                color = this.getBgImagename(num);
                if (this.getBgImagename(num) == 0xB9B9B9) {
                    color = 0x000000;
                }
                var rect = this.cold_group.getChildByName("cold_rect_" + i);
                rect.fillColor = color;
                var hotLab = this.cold_group.getChildByName("cold_label_" + i);
                hotLab.text = num;
                var hotNum = this.cold_group.getChildByName("cold_number_" + i);
                hotNum.text = num1 || "0";
            }
        }
        else {
            for (var i = 0; i < 3; i++) {
                var num = arr[i].split(",")[0];
                var num1 = arr[i].split(",")[1];
                var color;
                if (num == 0) {
                    color = 0x1BD745;
                }
                color = this.getBgImagename(num);
                if (this.getBgImagename(num) == 0xB9B9B9) {
                    color = 0x000000;
                }
                var rect = this.cold_group.getChildByName("cold_rect_" + i);
                rect.fillColor = color;
                var hotLab = this.cold_group.getChildByName("cold_label_" + i);
                hotLab.text = num;
                var hotNum = this.cold_group.getChildByName("cold_number_" + i);
                hotNum.text = "0";
            }
        }
    };
    /**
     * 获取背景色
     */
    French_bet.prototype.getBgImagename = function (num) {
        var imageName;
        if (num <= 9 || (num >= 19 && num <= 27)) {
            imageName = this.getBgName1To9And19To23(num);
        }
        else if (num == 10 || num == 28) {
            imageName = 0xB9B9B9; //
        }
        else if (num <= 18 || (num >= 29 && num <= 36)) {
            imageName = this.getBgName11To18And29To36(num);
        }
        return imageName;
    };
    /**
     * 返回1-9和19-23的按钮背景
     */
    French_bet.prototype.getBgName1To9And19To23 = function (index) {
        if (index % 2 == 0) {
            return 0xB9B9B9;
        }
        else {
            return 0xFF0000;
        }
    };
    /**
     * 返回11-18和29-36的按钮背景
     */
    French_bet.prototype.getBgName11To18And29To36 = function (index) {
        if (index % 2 != 0) {
            return 0xB9B9B9;
        }
        else {
            return 0xFF0000;
        }
    };
    return French_bet;
}(eui.Component));
__reflect(French_bet.prototype, "French_bet", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=French_bet.js.map