var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var BetButtonFrenchSkin = (function (_super) {
    __extends(BetButtonFrenchSkin, _super);
    function BetButtonFrenchSkin() {
        var _this = _super.call(this) || this;
        _this.betNumLength = 37; //中间按钮的数量0-36
        _this.myId = 0; //按钮Id
        _this.myIndex = 0; //index
        _this.otherEventIdTable = []; //显示其他按钮遮罩的事件Id数组
        _this.otherFrenchData = [];
        _this.clickFrenchData = [];
        // public textLabel:eui.Label;
        _this.canClick = false; //是否可以点击
        _this.canShowMask = false; //是否显示高亮
        _this.skinName = "resource/skins/roulette/bet/BetButtonFrench.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    BetButtonFrenchSkin.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    BetButtonFrenchSkin.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
    };
    BetButtonFrenchSkin.prototype.onAddtoStage = function (event) {
        this.setOtherEventIdTable(this.initData(this.myIndex));
        this.backImage.alpha = 0;
        if (App.DeviceUtils.IsMobile) {
            this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onClickSelf, this);
            this.addEventListener(egret.TouchEvent.TOUCH_END, this.onClickEndSelf, this);
            App.MessageCenter.addListener(RouletteEvent.FRENCH_CLICK_END_BET_BTN, this.onClickEndFrench, this);
        }
        else {
            this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OVER, this.onMouseOverSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OUT, this.onMouseOutSelf, this);
        }
        App.MessageCenter.addListener(RouletteEvent.FRENCH_CLICK_BET_BTN, this.onClickFrench, this);
        App.MessageCenter.addListener(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA, this.listenMouseOver, this);
        App.MessageCenter.addListener(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA, this.listenMouseOut, this);
        //设置是否可以点击
        App.MessageCenter.addListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        //游戏状态
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        //点击确认
        App.MessageCenter.addListener(RouletteEvent.CONFIRM_CHIP, this.confirmChip, this);
    };
    BetButtonFrenchSkin.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA, this.listenMouseOver, this);
        App.MessageCenter.removeListener(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA, this.listenMouseOut, this);
        App.MessageCenter.removeListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        App.MessageCenter.removeListener(RouletteEvent.CONFIRM_CHIP, this.confirmChip, this);
    };
    BetButtonFrenchSkin.prototype.initData = function (index) {
        if (index == 0) {
            this.otherEventIdTable[index + this.betNumLength - 2] = (index + this.betNumLength - 2).toString();
            this.otherEventIdTable[index + this.betNumLength - 1] = (index + this.betNumLength - 1).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index + 1] = (index + 1).toString();
            this.otherEventIdTable[index + 2] = (index + 2).toString();
        }
        else if (index == 1) {
            this.otherEventIdTable[index + (this.betNumLength - 2)] = (index + (this.betNumLength - 2)).toString();
            this.otherEventIdTable[index - 1] = (index - 1).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index + 1] = (index + 1).toString();
            this.otherEventIdTable[index + 2] = (index + 2).toString();
        }
        else if (index == this.betNumLength - 1) {
            this.otherEventIdTable[index - 1] = (index - 1).toString();
            this.otherEventIdTable[index - 2] = (index - 2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index - (this.betNumLength - 1)] = (index - (this.betNumLength - 1)).toString();
            this.otherEventIdTable[index - (this.betNumLength - 2)] = (index - (this.betNumLength - 2)).toString();
        }
        else if (index == this.betNumLength - 2) {
            this.otherEventIdTable[index - 1] = (index - 1).toString();
            this.otherEventIdTable[index - 2] = (index - 2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index + 1] = (index + 1).toString();
            this.otherEventIdTable[index - (this.betNumLength - 2)] = (index - (this.betNumLength - 2)).toString();
        }
        else if (index == 37) {
            for (var i = 27; i <= 37; i++) {
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[0] = "0";
            this.otherEventIdTable[1] = "1";
        }
        else if (index == 38) {
            for (var i = 2; i <= 6; i++) {
                this.otherEventIdTable[i] = i.toString();
            }
            for (var i = 24; i <= 26; i++) {
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[38] = "38";
        }
        else if (index == 39) {
            for (var i = 7; i <= 23; i++) {
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[39] = "39";
            this.otherEventIdTable[40] = "40";
        }
        else if (index == 40) {
            for (var i = 12; i <= 18; i++) {
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[40] = "40";
        }
        else {
            this.otherEventIdTable[index - 1] = (index - 1).toString();
            this.otherEventIdTable[index - 2] = (index - 2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index + 1] = (index + 1).toString();
            this.otherEventIdTable[index + 2] = (index + 2).toString();
        }
        return this.otherEventIdTable;
    };
    /**
     * 设置其他按钮的事件组
     */
    BetButtonFrenchSkin.prototype.setOtherEventIdTable = function (otherEventIdTable) {
        this.otherEventIdTable = otherEventIdTable;
        this.event_FRENCH_MOUSE_OVER_BET_BTN = new egret.Event(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA);
        this.event_FRENCH_MOUSE_OVER_BET_BTN.data = this.otherEventIdTable;
        this.event_FRENCH_MOUSE_OUT_BET_BIN = new egret.Event(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA);
        this.event_FRENCH_MOUSE_OUT_BET_BIN.data = this.otherEventIdTable;
        this.event_FRENCH_BEGIN_BET_BTN = new egret.Event(RouletteEvent.FRENCH_CLICK_BET_BTN);
        this.event_FRENCH_BEGIN_BET_BTN.data = this.otherEventIdTable;
        this.event_FRENCH_END_BET_BTN = new egret.Event(RouletteEvent.FRENCH_CLICK_END_BET_BTN);
        this.event_FRENCH_END_BET_BTN.data = this.otherEventIdTable;
    };
    BetButtonFrenchSkin.prototype.onClickSelf = function (Event) {
        App.MessageCenter.dispatch(this.event_FRENCH_BEGIN_BET_BTN.type, this.initData(this.myIndex));
    };
    BetButtonFrenchSkin.prototype.onClickEndSelf = function () {
        App.MessageCenter.dispatch(this.event_FRENCH_END_BET_BTN.type, this.initData(this.myIndex));
    };
    BetButtonFrenchSkin.prototype.onClickFrench = function (event) {
        var otherEventIdTable = event;
        if (GameDataCtrl.instance.isCanClick) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        if (App.DeviceUtils.IsMobile) {
                            this.backImage.alpha = 1;
                        }
                        // App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OVER_BET_BTN,this.otherFrenchData);
                        var data = {};
                        data[this.myId] = this.myId;
                        App.MessageCenter.dispatch(RouletteEvent.FRENCH_CLICK_BET_DATA, data);
                    }
                }
            }
        }
    };
    BetButtonFrenchSkin.prototype.onClickEndFrench = function (event) {
        var otherEventIdTable = event;
        if (GameDataCtrl.instance.isCanClick) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.backImage.alpha = 0;
                    }
                }
            }
        }
    };
    /**
     * 鼠标在按钮内
     */
    BetButtonFrenchSkin.prototype.onMouseOverSelf = function () {
        App.MessageCenter.dispatch(this.event_FRENCH_MOUSE_OVER_BET_BTN.type, this.initData(this.myIndex));
    };
    /**
     * 鼠标在按钮外
     */
    BetButtonFrenchSkin.prototype.onMouseOutSelf = function () {
        App.MessageCenter.dispatch(this.event_FRENCH_MOUSE_OUT_BET_BIN.type, this.initData(this.myIndex));
    };
    /**
     * 监听添加鼠标滑入事件
     */
    BetButtonFrenchSkin.prototype.listenMouseOver = function (event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.otherFrenchData[this.myId] = this.myId.toString();
                        App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OVER_BET_BTN, this.otherFrenchData);
                        this.backImage.alpha = 1;
                    }
                }
            }
        }
    };
    /**
     * 监听移除鼠标滑出事件
     */
    BetButtonFrenchSkin.prototype.listenMouseOut = function (event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.backImage.alpha = 0;
                        this.otherFrenchData[this.myId] = this.myId.toString();
                        App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OUT_BET_BTN, this.otherFrenchData);
                    }
                }
            }
        }
    };
    BetButtonFrenchSkin.prototype.setCanClick = function (event) {
        this.canClick = event;
    };
    /**
     * 游戏状开始态
     */
    BetButtonFrenchSkin.prototype.gameStateStart = function (event) {
        this.canShowMask = event;
        this.backImage.alpha = 0;
    };
    BetButtonFrenchSkin.prototype.confirmChip = function () {
    };
    return BetButtonFrenchSkin;
}(eui.Button));
__reflect(BetButtonFrenchSkin.prototype, "BetButtonFrenchSkin");
//# sourceMappingURL=BetButtonFrench.js.map