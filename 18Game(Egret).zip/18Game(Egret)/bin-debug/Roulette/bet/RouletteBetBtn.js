var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteBetBtn = (function (_super) {
    __extends(RouletteBetBtn, _super);
    function RouletteBetBtn() {
        var _this = _super.call(this) || this;
        _this.unConfirmBetAmount = {};
        _this.BetAreaAndAmountTable = {};
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    RouletteBetBtn.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    RouletteBetBtn.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
    };
    RouletteBetBtn.prototype.onAddtoStage = function (event) {
        this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickConfirmBtn, this);
        this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickCancelBtn, this);
        App.MessageCenter.addListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAreaAndBetAmount, this);
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_STOP, this.gameStatesStop, this);
        //重复下注
        App.MessageCenter.addListener(RouletteEvent.SEND_REPEAT_DATA, this.addBetAreaAndBetAmount, this);
    };
    RouletteBetBtn.prototype.onRemoveFromStage = function (event) {
        App.MessageCenter.removeListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAreaAndBetAmount, this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_STOP, this.gameStatesStop, this);
        App.MessageCenter.removeListener(RouletteEvent.SEND_REPEAT_DATA, this.addBetAreaAndBetAmount, this);
        this.btn_confirm.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickConfirmBtn, this);
        this.btn_cancel.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickCancelBtn, this);
    };
    /**
     * 点击确认按钮
     */
    RouletteBetBtn.prototype.onClickConfirmBtn = function () {
        this.btn_confirm.enabled = false;
        this.btn_cancel.enabled = false;
        App.MessageCenter.dispatch(RouletteEvent.CONFIRM_CHIP);
        this.sendBetMessage();
    };
    /**
     * 点击取消下注按钮
     */
    RouletteBetBtn.prototype.onClickCancelBtn = function () {
        this.btn_confirm.enabled = false;
        this.btn_cancel.enabled = false;
        this.cancelChipinBetArea();
    };
    RouletteBetBtn.prototype.gameStatesStop = function () {
        this.btn_confirm.enabled = false;
        this.btn_cancel.enabled = false;
        this.cleaBetAreaAbdBetAmount();
    };
    /**
     * 添加下注信息
     */
    RouletteBetBtn.prototype.addBetAreaAndBetAmount = function (event) {
        var betAreaAndBetAmount = event;
        // this.BetAreaAndAmountTable[betAreaAndBetAmount.betAmount] = betAreaAndBetAmount.betAmount;
        var tempBetAmount = betAreaAndBetAmount.betAmount;
        var total = 0;
        for (var key in betAreaAndBetAmount) {
            this.BetAreaAndAmountTable[key] = betAreaAndBetAmount[key];
            total += betAreaAndBetAmount[key];
        }
        if (total > 0) {
            this.btn_confirm.enabled = true;
            this.btn_cancel.enabled = true;
        }
    };
    RouletteBetBtn.prototype.pivot = function (arr) {
        for (var i in arr) {
            for (var j in arr) {
                if (arr[i].betArea == arr[j].betArea && i != j) {
                    arr[i].betAmount = arr[j].betAmount;
                    arr.splice(j, 1);
                }
                else {
                    arr[i];
                }
            }
        }
        return arr;
    };
    /**
     * 移除临时下注信息
     */
    RouletteBetBtn.prototype.removeBetAreaAndBetAmount = function () {
        App.MessageCenter.dispatch(RouletteEvent.REMOVE_UNCONFIRM_CHIP);
        this.cleaBetAreaAbdBetAmount();
    };
    /**
     * 发送下注信息
     */
    RouletteBetBtn.prototype.sendBetMessage = function () {
        var model = HallDataCtrl.instance.getLoadGameData;
        var limitID = model.getLimitRedID;
        var tableId = model.getTableID;
        GameServer.getSingtonInstance().sendBet(tableId, proto.Game.Subtype.Roulette, this.BetAreaAndAmountTable, limitID);
        this.cleaBetAreaAbdBetAmount();
    };
    /**
     * 清空下注数据
     */
    RouletteBetBtn.prototype.cleaBetAreaAbdBetAmount = function () {
        this.BetAreaAndAmountTable = {};
    };
    /**
     * 取消下注区域的筹码
     */
    RouletteBetBtn.prototype.cancelChipinBetArea = function () {
        this.removeBetAreaAndBetAmount();
    };
    return RouletteBetBtn;
}(eui.Component));
__reflect(RouletteBetBtn.prototype, "RouletteBetBtn", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RouletteBetBtn.js.map