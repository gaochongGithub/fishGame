var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var BetArea = (function (_super) {
    __extends(BetArea, _super);
    function BetArea() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/bet/Classic_bet.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    BetArea.prototype.onAddtoStage = function (event) {
        this.btnNode.touchEnabled = false;
        this.right_node.touchEnabled = false;
        //0按钮
        this.addBet0Btn();
        //添加中间按钮
        this.addCenterBtn();
        //添加打按钮
        this.addDozenBtn();
        //添加列按钮
        this.addBottom();
        //添加右侧按钮
        this.addRightBetBtn();
        //添加上层小按钮
        this.addLinesUpDown2BetBtn();
        this.add1Column3BetBtn();
        this.addLinesLeftRight2BetBtn();
        this.addLinesTopDownLeftDown4BetBtn();
        this.add2Column6BetBtn();
    };
    BetArea.prototype.onRemoveFromStage = function () { };
    /**
     * 增加按钮0
     */
    BetArea.prototype.addBet0Btn = function () {
        var betButton = new RouletteBetButton();
        var width = 128;
        var height = 137;
        var id = 537;
        betButton.setId(id);
        betButton.setTextBtn(4, 1, width, height, "bet_00_png", "0");
        var eventId = id.toString();
        betButton.setEventIdAndOthers(eventId, [eventId]);
        betButton.setInfluenceNum(1);
        this.btn_center.addChild(betButton);
    };
    BetArea.prototype.addCenterBtn = function () {
        var line = 0;
        var line1 = 0;
        var line2 = 0;
        for (var i = 1; i <= 36; i++) {
            var betButton = new NumBetButton();
            var id = 500 + i;
            var eventId = id.toString();
            betButton.setEventIdAndOthers(eventId, [eventId]);
            betButton.setId(id);
            var width = RES.getRes("bet_0" + i + "_png").textureWidth;
            var height = RES.getRes("bet_0" + i + "_png").textureHeight;
            var x = 0;
            var y = Math.floor((i - 1) % 3);
            var text = i;
            if (y == 0) {
                if (line < 3 && line > 0) {
                    x = 68 + (line * 87) + line - 1;
                }
                else if (line == 6) {
                    x = 596;
                }
                else if (line == 7) {
                    x = 68 + (line * 87) + line - 2;
                }
                else if (line == 8) {
                    x = 765;
                }
                else if (line > 8 && line < 10) {
                    x = 68 + (line * 87) - 2;
                }
                else if (line >= 10) {
                    x = 68 + (line * 87) - 5;
                }
                else {
                    x = 68 + (line * 87) + line;
                }
                line++;
                y = 90;
            }
            else if (y == 1) {
                y = 43;
                if (line1 == 1) {
                    x = 175;
                }
                else if (line1 == 2) {
                    x = 258;
                }
                else if (line1 == 3) {
                    x = 344;
                }
                else if (line1 == 4) {
                    x = 428;
                }
                else if (line1 == 5) {
                    x = 512;
                }
                else if (line1 == 6) {
                    x = 596;
                }
                else if (line1 == 7) {
                    x = 677;
                }
                else if (line1 == 8) {
                    x = 757;
                }
                else if (line1 == 9) {
                    x = 838;
                }
                else if (line1 == 10) {
                    x = 918;
                }
                else if (line1 == 11) {
                    x = 1000;
                }
                else {
                    x = 91;
                }
                line1++;
            }
            else {
                y = 1;
                if (line2 == 1) {
                    x = 194;
                }
                else if (line2 == 2) {
                    x = 273;
                }
                else if (line2 == 3) {
                    x = 355;
                }
                else if (line2 == 4) {
                    x = 435;
                }
                else if (line2 == 5) {
                    x = 516;
                }
                else if (line2 == 6) {
                    x = 596;
                }
                else if (line2 == 7) {
                    x = 673;
                }
                else if (line2 == 8) {
                    x = 750;
                }
                else if (line2 == 9) {
                    x = 827;
                }
                else if (line2 == 10) {
                    x = 904;
                }
                else if (line2 == 11) {
                    x = 982;
                }
                else {
                    x = 113;
                }
                line2++;
            }
            betButton.setInfluenceNum(1);
            betButton.setNum(i, x, y, width, height);
            betButton.setTextBtn(x, y, width, height, "bet_0" + i + "_png", i.toString());
            this.btn_center.addChild(betButton);
        }
    };
    //添加打按钮
    BetArea.prototype.addDozenBtn = function () {
        for (var i = 0; i < 3; i++) {
            var betButton = new RouletteBetButton();
            var id = 649 + i;
            var width = RES.getRes("bet_dozen_0" + (i + 1) + "_png").textureWidth;
            var height = RES.getRes("bet_dozen_0" + (i + 1) + "_png").textureHeight;
            betButton.setId(id);
            var text = "";
            switch (i) {
                case 0:
                    text = "TEXT_Dozen1"; //App.LangUtils.getStr("TEXT_Dozen1");
                    break;
                case 1:
                    text = "TEXT_Dozen2"; //App.LangUtils.getStr("TEXT_Dozen2");
                    break;
                case 2:
                    text = "TEXT_Dozen3"; //App.LangUtils.getStr("TEXT_Dozen3");
                    break;
            }
            if (i == 2) {
                betButton.setTextBtn(728, 0, width, height, "bet_dozen_0" + (i + 1) + "_png", text, true);
            }
            else {
                betButton.setTextBtn((i * 367), 0, width, height, "bet_dozen_0" + (i + 1) + "_png", text, true);
            }
            var eventId = id.toString();
            var otherEventIdTable = [];
            for (var j = i * 12 + 1; j <= (i + 1) * 12; j++) {
                otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
            }
            otherEventIdTable[eventId] = eventId;
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setInfluenceNum(12);
            this.right_group.addChild(betButton);
        }
    };
    //添加列按钮
    BetArea.prototype.addBottom = function () {
        for (var i = 0; i < 6; i++) {
            var betButton = new RouletteBetButton();
            var id = 652 + i;
            betButton.setId(id);
            var eventId = id.toString();
            var width = RES.getRes("bet_bottom_0" + (i + 1) + "_png").textureWidth;
            var height = RES.getRes("bet_bottom_0" + (i + 1) + "_png").textureHeight;
            var text = "";
            var otherEventIdTable = [];
            switch (i) {
                case 0:
                    text = "TEXT_Small"; //App.LangUtils.getStr("TEXT_Small");
                    for (var j = 1; j <= 18; j++) {
                        otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                    }
                    break;
                case 1:
                    text = "TEXT_Double"; //App.LangUtils.getStr("TEXT_Double");
                    for (var j = 1; j <= 36; j++) {
                        if (j % 2 == 0) {
                            otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                        }
                    }
                    break;
                case 2:
                    text = "";
                    var numBetbutton = new NumBetButton();
                    for (var j = 1; j <= 36; j++) {
                        if (numBetbutton.getBtnColor(j) == "red") {
                            otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                        }
                    }
                    break;
                case 3:
                    text = "";
                    for (var j = 1; j <= 36; j++) {
                        if (numBetbutton.getBtnColor(j) == "black") {
                            otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                        }
                    }
                    break;
                case 4:
                    text = "TEXT_Single"; //App.LangUtils.getStr("TEXT_Single");
                    for (var j = 1; j <= 36; j++) {
                        if (j % 2 != 0) {
                            otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                        }
                    }
                    break;
                case 5:
                    text = "TEXT_Big"; //App.LangUtils.getStr("TEXT_Big");
                    for (var j = 19; j <= 36; j++) {
                        otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                    }
                    break;
            }
            var isLang = true;
            if (text == "") {
                isLang = false;
            }
            if (i == 2) {
                betButton.setTextBtn(383, 0, width, height, "bet_bottom_0" + (i + 1) + "_png", text, isLang);
            }
            else if (i == 3) {
                betButton.setTextBtn(578, 0, width, height, "bet_bottom_0" + (i + 1) + "_png", text, isLang);
            }
            else if (i == 4) {
                betButton.setTextBtn(762, 0, width, height, "bet_bottom_0" + (i + 1) + "_png", text, isLang);
            }
            else if (i == 5) {
                betButton.setTextBtn(948, 0, width, height, "bet_bottom_0" + (i + 1) + "_png", text, isLang);
            }
            else {
                betButton.setTextBtn((i * 190), 0, width, height, "bet_bottom_0" + (i + 1) + "_png", text, isLang);
            }
            otherEventIdTable[eventId] = eventId;
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setInfluenceNum(18);
            this.bottom_group.addChild(betButton);
        }
    };
    BetArea.prototype.addRightBetBtn = function () {
        for (var i = 1; i <= 3; i++) {
            var betButton = new RouletteBetButton();
            var id = 645 + i;
            betButton.setId(id);
            var eventId = id.toString();
            var width = RES.getRes("bet_0" + i + "st_png").textureWidth;
            var height = RES.getRes("bet_0" + i + "st_png").textureHeight;
            var x = 0;
            var y = 0;
            if (i == 1) {
                x = -29;
                y = 3;
            }
            else if (i == 2) {
                x = -9;
                y = 44;
            }
            else {
                x = 13;
                y = 90;
            }
            var text = "1:2";
            var otherEventIdTable = [];
            for (var j = 1; j <= 36; j++) {
                if ((j) % 3 == (4 - i) % 3) {
                    otherEventIdTable[(j + 500).toString()] = (j + 500).toString();
                }
            }
            otherEventIdTable[eventId] = eventId;
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setInfluenceNum(12);
            betButton.setTextBtn(x, y, width, height, "bet_0" + i + "st_png", text);
            // betButton.setTextVertical();
            this.right_node.addChild(betButton);
        }
    };
    BetArea.prototype.addLinesUpDown2BetBtn = function () {
        for (var i = 1; i <= 2; i++) {
            this.addLineLeftRight2BetBtn(i);
        }
    };
    //增加一行上下两个按钮
    BetArea.prototype.addLineLeftRight2BetBtn = function (line) {
        for (var i = 0; i < 12; i++) {
            var betButton = new RouletteBetButton();
            var id = 550 + (line - 1) * 12 + 12 * (line - 1) + i;
            betButton.setId(id);
            var eventId = id.toString();
            if (line == 1) {
                betButton.setInfo(60 + (i * 81), 34, 47, 18, "invisible_png");
            }
            else if (line == 2) {
                betButton.setInfo(38 + (i * 85), 79, 47, 18, "invisible_png");
            }
            var num1 = i * 3 + (3 - line) + 500;
            var otherEventIdTable = [];
            for (var j = num1; j <= num1 + 1; j++) {
                otherEventIdTable[j.toString()] = j.toString();
            }
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setInfluenceNum(17);
            this.btnNode.addChild(betButton);
        }
    };
    //一行三列
    BetArea.prototype.add1Column3BetBtn = function () {
        for (var i = 0; i < 12; i++) {
            var betButton = new RouletteBetButton();
            var id = 600 + i;
            betButton.setId(id);
            var eventId = id.toString();
            betButton.setInfo(73 + (i * 78), -10, 47, 18, "invisible_png");
            var otherEventIdTable = [];
            for (var j = 1; j <= 3; j++) {
                var ohternEventId = (i * 3 + j + 500).toString();
                otherEventIdTable[ohternEventId] = ohternEventId;
            }
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setInfluenceNum(11);
            this.btnNode.addChild(betButton);
        }
    };
    /**
     * 增加多行左右2个按钮
     */
    BetArea.prototype.addLinesLeftRight2BetBtn = function () {
        for (var i = 1; i <= 3; i++) {
            this.addLineUpDown2BetBtn(i);
        }
    };
    //左右一行按钮 如2,4
    BetArea.prototype.addLineUpDown2BetBtn = function (line) {
        for (var i = 0; i < 12; i++) {
            var betButton = new RouletteBetButton();
            var id = 538 + (line - 1) * 12 + 12 * (line - 1) + i;
            betButton.setId(id);
            var eventId = id.toString();
            if (line == 1) {
                betButton.setInfo(50 + (i * 78), 10, 16, 31, "invisible_png");
            }
            else if (line == 2) {
                if (i < 7) {
                    betButton.setInfo(31 + (i * 82), 52, 16, 31, "invisible_png");
                }
                else {
                    betButton.setInfo(31 + (i * 81.5), 52, 16, 31, "invisible_png");
                }
            }
            else if (line == 3) {
                if (i < 7) {
                    betButton.setInfo(6 + (i * 86), 100, 16, 31, "invisible_png");
                }
                else {
                    betButton.setInfo(6 + (i * 85.5), 100, 16, 31, "invisible_png");
                }
            }
            var num1 = i * 3 + (4 - line) - 3 + 500;
            var otherEventIdTable = [];
            for (var j = num1; j <= num1 + 3; j += 3) {
                if (j > 500) {
                    otherEventIdTable[j.toString()] = j.toString();
                }
                else {
                    otherEventIdTable["537"] = "537";
                }
            }
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setSkexX(25 - i * 4);
            betButton.setInfluenceNum(17);
            this.btnNode.addChild(betButton);
        }
    };
    BetArea.prototype.addLinesTopDownLeftDown4BetBtn = function () {
        for (var i = 1; i <= 2; i++) {
            this.addLineTopDownLeftDown4BetBtn(i);
        }
    };
    //增加一行上下左右4个
    BetArea.prototype.addLineTopDownLeftDown4BetBtn = function (line) {
        for (var i = 0; i < 12; i++) {
            var betButton = new RouletteBetButton();
            var id = 612 + (line - 1) * 12 + i - line;
            if (i == 0) {
                id = 598 + line - 1;
            }
            var eventId = id.toString();
            var num = i * 3 + (3 - line) - 3 + 500;
            var otherEventIdTable = [];
            var odds = 8;
            for (var j = num; j <= num + 1; j++) {
                var otherEventId = j.toString();
                if (j > 500) {
                    otherEventIdTable[otherEventId] = otherEventId;
                    betButton.setInfluenceNum(4);
                }
                else {
                    otherEventIdTable["537"] = "537";
                    betButton.setInfluenceNum(3);
                    odds = 11;
                }
            }
            for (var j = num + 3; j <= num + 4; j++) {
                var otherEventId = j.toString();
                otherEventIdTable[otherEventId] = otherEventId;
            }
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setId(id);
            if (line == 1) {
                betButton.setInfo(30 + (i * 81), 30, 21, 21, "invisible_png");
            }
            else if (line == 2) {
                betButton.setInfo(10 + (i * 84.5), 78, 21, 21, "invisible_png");
            }
            betButton.setInfluenceNum(odds);
            this.btnNode.addChild(betButton);
        }
    };
    //增加上或下6个
    BetArea.prototype.add2Column6BetBtn = function () {
        for (var i = 0; i < 12; i++) {
            var betButton = new RouletteBetButton();
            var id = 634 + i;
            var eventId = id.toString();
            var otherEventIdTable = [];
            for (var j = 1; j <= 6; j++) {
                var othernEventId = (i * 3 + j + 500 - 3);
                var otherEventIdString = othernEventId.toString();
                if (othernEventId > 500) {
                    betButton.setInfluenceNum(5);
                    otherEventIdTable[otherEventIdString] = otherEventIdString;
                }
                else {
                    betButton.setInfluenceNum(8);
                    otherEventIdTable["537"] = "537";
                }
            }
            betButton.setEventIdAndOthers(eventId, otherEventIdTable);
            betButton.setId(id);
            betButton.setInfo(50 + (i * 77.5), -10, 21, 21, "invisible_png");
            this.btnNode.addChild(betButton);
        }
    };
    BetArea.currentChipValue = 0; //筹码数
    return BetArea;
}(eui.Component));
__reflect(BetArea.prototype, "BetArea");
//# sourceMappingURL=RouletteBetArea.js.map