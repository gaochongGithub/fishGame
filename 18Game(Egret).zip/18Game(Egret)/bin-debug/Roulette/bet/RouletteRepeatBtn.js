var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteRepeatBtn = (function (_super) {
    __extends(RouletteRepeatBtn, _super);
    function RouletteRepeatBtn() {
        var _this = _super.call(this) || this;
        _this.repeatTotal = 0;
        _this.isConfirm = false;
        _this.isStop = false;
        _this.skinName = "";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    RouletteRepeatBtn.prototype.onAddtoStage = function (event) {
        this.btn_rebet.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        //获取用户信息
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
        //游戏状态
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        //点击确认
        App.MessageCenter.addListener(RouletteEvent.CONFIRM_CHIP, this.confirmFunc, this);
        //点击取消
        App.MessageCenter.addListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP, this.cancelFunc, this);
        //点击下注区
        App.MessageCenter.addListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT, this.clickBetArea, this);
    };
    RouletteRepeatBtn.prototype.onRemoveFromStage = function () {
        this.btn_rebet.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        App.MessageCenter.removeListener(RouletteEvent.CONFIRM_CHIP, this.confirmFunc, this);
        App.MessageCenter.removeListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP, this.cancelFunc, this);
    };
    RouletteRepeatBtn.prototype.gameStateStart = function (isTrue) {
        this.isConfirm = false;
        this.isStop = !isTrue;
        this.btn_rebet.enabled = false;
        if ((isTrue && JSON.stringify(GameDataCtrl.instance.getConfirmBetAmount_R) != "{}")) {
            this.btn_rebet.enabled = true;
        }
        else {
            this.btn_rebet.enabled = false;
        }
    };
    RouletteRepeatBtn.prototype.confirmFunc = function () {
        this.isConfirm = true;
        this.btn_rebet.enabled = false;
    };
    RouletteRepeatBtn.prototype.cancelFunc = function () {
        if (this.isConfirm) {
            this.btn_rebet.enabled = false;
        }
        else {
            if (JSON.stringify(GameDataCtrl.instance.getConfirmBetAmount_R) != "{}") {
                this.btn_rebet.enabled = true;
            }
        }
    };
    RouletteRepeatBtn.prototype.confirmBetAmount = function (data) {
        this.repeatTotal = data.totalbet;
        GameDataCtrl.instance.setResetData;
        for (var key in data.betinfo) {
            GameDataCtrl.instance.setConfirmBetAmount_R(key, data.betinfo[key]);
        }
    };
    RouletteRepeatBtn.prototype.onClick = function () {
        if (this.checkMaxLimit()) {
            this.btn_rebet.enabled = false;
            App.MessageCenter.dispatch(RouletteEvent.SEND_REPEAT_DATA, GameDataCtrl.instance.getConfirmBetAmount_R);
        }
        else {
            App.ToastViewManager.toastTextView("TEXT_MESSAGE_6");
            return;
        }
    };
    /**
     * 检查是否超出余额
     */
    RouletteRepeatBtn.prototype.checkMaxLimit = function () {
        // var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
        // var limit = loadGameModel.getLimitRed;
        // var getMaxBetLimit = limit.split("-");
        var playerInfo = HallDataCtrl.instance.getLobbyPlayer;
        if (this.repeatTotal > playerInfo.balance) {
            return false;
        }
        return true;
    };
    RouletteRepeatBtn.prototype.clickBetArea = function () {
        this.btn_rebet.enabled = false;
    };
    return RouletteRepeatBtn;
}(eui.Component));
__reflect(RouletteRepeatBtn.prototype, "RouletteRepeatBtn", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RouletteRepeatBtn.js.map