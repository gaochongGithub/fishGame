var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Bottom_info = (function (_super) {
    __extends(Bottom_info, _super);
    function Bottom_info() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/Bottom_info.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    Bottom_info.prototype.onAddtoStage = function (event) {
        this.init();
        this.record_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.openRecord, this);
        this.rule_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.openRule, this);
        this.exit_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.exitGame, this);
        this.setting_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.settingGame, this);
    };
    Bottom_info.prototype.onRemoveFromStage = function () {
        this.record_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.openRecord, this);
        this.rule_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.openRule, this);
        this.exit_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.exitGame, this);
    };
    Bottom_info.prototype.exitGame = function () {
        App.MessageCenter.dispatch(GameEvent.ASK_IS_BET, this);
    };
    Bottom_info.prototype.AskIsBet = function (isBet) {
        if (!isBet) {
            GameSceneCtrl.instance.toHallScene();
            var model = HallDataCtrl.instance.getLoadGameData;
            var tableId = model.getTableID;
            GameServer.getSingtonInstance().sendLeaveTable(tableId, proto.GameType.Roulette);
        }
        else {
            App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
        }
    };
    Bottom_info.prototype.openRecord = function () {
        App.ToastViewManager.toast(new RecordView(), false);
    };
    Bottom_info.prototype.openRule = function () {
        App.ToastViewManager.toast(new RuleView(), false);
    };
    Bottom_info.prototype.settingGame = function () {
        App.ToastViewManager.toast(new SettingView(), false);
    };
    Bottom_info.prototype.init = function () {
        //添加下注按钮
        this.bet_confirm_group.addChild(new RouletteRepeatBtn());
        this.bet_confirm_group.addChild(new RouletteBetBtn());
        var reward = new RewardAnchor();
        reward.x = 1050;
        reward.y = 0;
        this.addChild(reward);
        ; //1080 10
        var info = new RouletteUserInfo();
        info.x = 130;
        info.y = 15;
        this.addChild(info);
        //添加聊天
        var chats = new chat();
        chats.x = 1200;
        chats.y = 13;
        this.addChild(chats);
        var chips = new ChipsView();
        chips.bottom = 5;
        chips.horizontalCenter = -60;
        this.addChild(chips);
    };
    return Bottom_info;
}(eui.Component));
__reflect(Bottom_info.prototype, "Bottom_info", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=Bottom_info.js.map