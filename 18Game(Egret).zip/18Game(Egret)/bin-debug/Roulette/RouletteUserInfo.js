var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RouletteUserInfo = (function (_super) {
    __extends(RouletteUserInfo, _super);
    function RouletteUserInfo() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/RouletteUserInfo.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddToStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    RouletteUserInfo.prototype.onAddToStage = function (event) {
        this.removeEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
        this.initData();
        App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG, this.getGameTableConfig, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        //下注后信息
        App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
    };
    RouletteUserInfo.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
    };
    RouletteUserInfo.prototype.initData = function () {
        var loadGameModel = HallDataCtrl.instance.getLoadGameData;
        var playerInfo = HallDataCtrl.instance.getLobbyPlayer;
        this.name_label.text = playerInfo.name;
        this.balance_label.text = "¥" + playerInfo.balance;
        this.limit_label.text = loadGameModel.getLimitRed;
    };
    RouletteUserInfo.prototype.getGameTableConfig = function (data) {
        this.tableId_label.text = data.name;
    };
    RouletteUserInfo.prototype.getGameStatus = function (data) {
        this.id_label.text = data.status + "-" + data.inning;
    };
    RouletteUserInfo.prototype.confirmBetAmount = function (data) {
        this.balance_label.text = "¥" + data.balance;
        this.total_bet_label.text = data.totalbet;
    };
    return RouletteUserInfo;
}(eui.Component));
__reflect(RouletteUserInfo.prototype, "RouletteUserInfo", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RouletteUserInfo.js.map