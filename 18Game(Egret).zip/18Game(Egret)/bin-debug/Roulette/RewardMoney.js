var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RewardMoney = (function (_super) {
    __extends(RewardMoney, _super);
    function RewardMoney() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/RewardMoney.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    RewardMoney.prototype.onAddtoStage = function () {
        this.cancel_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        this.send_data.addEventListener(egret.TouchEvent.TOUCH_TAP, this.sendData, this);
        App.MessageCenter.addListener(RouletteEvent.GET_REWARD_ANCHOR, this.onClick, this);
    };
    RewardMoney.prototype.onRemoveFromStage = function () {
        this.cancel_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        App.MessageCenter.removeListener(RouletteEvent.GET_REWARD_ANCHOR, this.onClick, this);
    };
    RewardMoney.prototype.onClick = function () {
        App.ToastViewManager.clearAll();
        App.ToastViewManager.toastTextView("TEXT_REWARD_SUCCESSFUL");
    };
    RewardMoney.prototype.sendData = function () {
        var type;
        if (this.rewardData.tvName == "") {
            type = 0;
        }
        else {
            type = 1;
        }
        if (this.number_input.text !== "" && this.textChanged(Number(this.number_input.text))) {
            GameServer.getSingtonInstance().sendReward(this.rewardData.tableID, type, Number(this.number_input.text));
        }
    };
    RewardMoney.prototype.textChanged = function (editbox) {
        var reg = /^([1-9][0-9]*)$/;
        if (!reg.test(editbox)) {
            this.number_input.text = "";
            return false;
        }
        return true;
    };
    RewardMoney.prototype.getData = function (data) {
        this.rewardData = data;
        this.name_label.text = data.dealer;
    };
    return RewardMoney;
}(eui.Component));
__reflect(RewardMoney.prototype, "RewardMoney", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RewardMoney.js.map