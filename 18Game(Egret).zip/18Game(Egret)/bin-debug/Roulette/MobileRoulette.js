var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var MobileRoulette = (function (_super) {
    __extends(MobileRoulette, _super);
    function MobileRoulette() {
        var _this = _super.call(this) || this;
        _this.moveNum = 279;
        _this.isMove = false; //是否在移动
        _this.frenchDataInfo = {};
        _this.resultTable = [];
        return _this;
    }
    MobileRoulette.prototype.initView = function () {
        this.skinName = "resource/skins/roulette/MobileRoulette.exml";
        this.addGroup();
    };
    MobileRoulette.prototype.initEventListener = function () {
        this.show_out_group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.isShowBrea, this);
        this.chat_group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.loadChatPanel, this);
        this.seting_group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showOption, this);
        this.record_group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showFrenchBetArea, this);
        App.MessageCenter.addListener(RouletteEvent.MOBILE_FRENCH_AREA, this.showFrenchBetArea, this);
        App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.getGameTableHistory, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO, this.confirmBetAmount, this);
        App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG, this.getGameTableConfig, this);
        App.MessageCenter.addListener(GameEvent.GAME_CHAT_PUSH, this.onChatMsgPush, this); //是否有消息
    };
    MobileRoulette.prototype.removeMyEventListener = function () {
        this.show_out_group.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.isShowBrea, this);
        this.record_group.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showFrenchBetArea, this);
        this.seting_group.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showOption, this);
        App.MessageCenter.removeListener(RouletteEvent.MOBILE_FRENCH_AREA, this.showFrenchBetArea, this);
        App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY, this.getGameTableHistory, this);
        App.MessageCenter.removeListener(RouletteEvent.GET_GAME_TABLE_CONFIG, this.getGameTableConfig, this);
    };
    MobileRoulette.prototype.addGroup = function () {
        var playerInfo = HallDataCtrl.instance.getLobbyPlayer;
        var name = playerInfo.name.split("_");
        this.user_name_label.text = name[1];
        this.user_balance_label.text = "¥" + playerInfo.balance;
        var repeatBtn = new RouletteRepeatBtn();
        var betBtn = new RouletteBetBtn();
        this.setScale(repeatBtn);
        this.setScale(betBtn);
        this.bet_btn_group.addChild(repeatBtn);
        this.bet_btn_group.addChild(betBtn);
        var reward = new RewardAnchor();
        reward.top = 0;
        reward.left = 10;
        this.setScale(reward);
        this.addChild(reward);
        var betArea = new MobileBetArea();
        betArea.scaleX = 0.60;
        betArea.scaleY = 0.60;
        betArea.horizontalCenter = 0;
        betArea.verticalCenter = -20;
        // this.setScale(betArea);
        this.bet_area.addChild(betArea);
    };
    MobileRoulette.prototype.setScale = function (node) {
        node.scaleX = 0.75;
        node.scaleY = 0.75;
    };
    //点击伸缩下注区域
    MobileRoulette.prototype.isShowBrea = function () {
        egret.Tween.get(this.bet_area, { loop: false, onChange: this.onChange }).to({ x: 0, y: this.moveNum }, 300, egret.Ease.sineIn).call(this.onComplete, this);
    };
    MobileRoulette.prototype.loadChatPanel = function () {
        this.is_chat.alpha = 0;
        this.addChild(new chat());
    };
    MobileRoulette.prototype.showOption = function () {
        this.optionView.visible = !this.optionView.visible;
    };
    MobileRoulette.prototype.onChange = function () {
        this.isMove = !this.isMove;
    };
    MobileRoulette.prototype.onComplete = function () {
        this.isMove = !this.isMove;
        if (this.moveNum > 100) {
            this.moveNum = 79;
        }
        else {
            this.moveNum = 299;
        }
        if (this.rotation_img.rotation == 0) {
            this.rotation_img.rotation = 180;
            this.rotation_img.y = 30;
        }
        else {
            this.rotation_img.rotation = 0;
            this.rotation_img.y = 17;
        }
    };
    MobileRoulette.prototype.getGameTableHistory = function (data) {
        this.historyData = data;
        var str = data.way;
        var arr = str.split(",");
        var arr1 = str.split(",");
        if (this.resultTable.length >= 12) {
            this.resultTable.pop();
        }
        for (var i = 0; i < arr.length; i++) {
            if (i <= 11) {
                if (arr.length <= 1) {
                    this.resultTable.unshift(arr1.pop());
                }
                else {
                    this.resultTable.push(arr1.pop());
                }
            }
        }
        for (var i = 0; i < arr.length; i++) {
            GameDataCtrl.instance.setAllGameTableHistory(Number(arr[i]));
        }
    };
    MobileRoulette.prototype.confirmBetAmount = function (data) {
        this.frenchDataInfo["gameTotalBet"] = data.totalbet;
    };
    MobileRoulette.prototype.getGameTableConfig = function (data) {
        this.frenchDataInfo["tableId"] = data.name;
    };
    MobileRoulette.prototype.showFrenchBetArea = function () {
        if (!this.frenchArea) {
            this.frenchDataInfo["gameNum"] = this.statusData.status + "-" + this.statusData.inning;
            this.frenchArea = new MobileFrenchBetArea();
            this.frenchArea.verticalCenter = -20;
            this.frenchArea.getGameTableHistory(this.resultTable);
            this.frenchArea.setLabelInfo(this.frenchDataInfo);
            this.bet_area.addChild(this.frenchArea);
        }
        else {
            this.bet_area.removeChild(this.frenchArea);
            this.frenchArea = null;
        }
    };
    MobileRoulette.prototype.onChatMsgPush = function (data) {
        if (data.chatVOS.length > 0) {
            this.is_chat.alpha = 1;
        }
        else {
            this.is_chat.alpha = 0;
        }
    };
    return MobileRoulette;
}(RouletteScene));
__reflect(MobileRoulette.prototype, "MobileRoulette");
//# sourceMappingURL=MobileRoulette.js.map