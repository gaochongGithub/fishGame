var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RewardAnchor = (function (_super) {
    __extends(RewardAnchor, _super);
    function RewardAnchor() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/roulette/RewardAnchor.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddtoStage, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.onRemoveFromStage, _this);
        return _this;
    }
    RewardAnchor.prototype.onAddtoStage = function (event) {
        this.btn_group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG, this.getGameTableConfig, this);
    };
    RewardAnchor.prototype.onRemoveFromStage = function () {
        App.MessageCenter.removeListener(RouletteEvent.GET_GAME_TABLE_CONFIG, this.getGameTableConfig, this);
    };
    RewardAnchor.prototype.getGameTableConfig = function (data) {
        var _this = this;
        this.ancharData = data;
        this.type_label.text = "荷官";
        this.name_label.text = data.dealer;
        // this.user_image.texture = data.dealerImage;
        this.imgLoader = new egret.ImageLoader();
        this.imgLoader.crossOrigin = "anonymous"; // 跨域请求
        this.imgLoader.load(data.dealerImage); // 去除链接中的转义字符‘\’        
        this.imgLoader.once(egret.Event.COMPLETE, function (evt) {
            if (evt.currentTarget.data) {
                var texture = new egret.Texture();
                texture.bitmapData = evt.currentTarget.data;
                _this.user_image.source = texture;
                // texture.bitmapData = evt.currentTarget.data;
                // let bitmap = new egret.Bitmap(texture);
                // bitmap.x = 200;
                // bitmap.y = 200;
                // this.addChild(bitmap);
            }
        }, this);
    };
    RewardAnchor.prototype.onClick = function () {
        var moneyReward = new RewardMoney();
        moneyReward.horizontalCenter = 0;
        moneyReward.verticalCenter = 0;
        moneyReward.getData(this.ancharData);
        if (App.DeviceUtils.IsMobile) {
            moneyReward.scaleX = 0.75;
            moneyReward.scaleY = 0.75;
        }
        App.ToastViewManager.toast(moneyReward, false, false);
        // this.parent.parent.addChild(moneyReward);
    };
    return RewardAnchor;
}(eui.Component));
__reflect(RewardAnchor.prototype, "RewardAnchor", ["eui.UIComponent", "egret.DisplayObject"]);
//# sourceMappingURL=RewardAnchor.js.map