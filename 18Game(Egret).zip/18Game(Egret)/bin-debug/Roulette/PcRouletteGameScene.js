var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PcRouletteGameScene = (function (_super) {
    __extends(PcRouletteGameScene, _super);
    function PcRouletteGameScene() {
        return _super.call(this) || this;
    }
    PcRouletteGameScene.prototype.initView = function () {
        this.skinName = "resource/skins/roulette/PcRouletteGameScene.exml";
        console.log(this.statusView, "不思量");
        this.addGroup();
    };
    PcRouletteGameScene.prototype.initEventListener = function () {
        App.MessageCenter.addListener(GameEvent.SHOW_ALLCHIPS, this.showAllChips, this);
        this.btn_showRoom.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnShowRoom, this);
    };
    PcRouletteGameScene.prototype.removeMyEventListener = function () {
        App.MessageCenter.removeListener(GameEvent.SHOW_ALLCHIPS, this.showAllChips, this);
        this.btn_showRoom.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtnShowRoom, this);
    };
    PcRouletteGameScene.prototype.showAllChips = function () {
        this.setChildIndex(this.allChipsView, 10);
        this.allChipsView.visible = !this.allChipsView.visible;
    };
    PcRouletteGameScene.prototype.onClickBtnShowRoom = function () {
        this.setChildIndex(this.changeTableView, 11);
        this.changeTableView.visible = !this.changeTableView.visible;
    };
    PcRouletteGameScene.prototype.addGroup = function () {
        var bet = new BetArea();
        bet.horizontalCenter = 0;
        bet.bottom = 199;
        this.addChild(bet);
        //添加下区域
        var BottomInfo = new Bottom_info();
        BottomInfo.horizontalCenter = 0;
        BottomInfo.bottom = 0;
        this.addChild(BottomInfo);
        //添加右侧下注区
        var FrenchBet = new French_bet();
        FrenchBet.verticalCenter = -240;
        FrenchBet.right = 0;
        FrenchBet.bottom = 0;
        this.addChild(FrenchBet);
    };
    return PcRouletteGameScene;
}(RouletteScene));
__reflect(PcRouletteGameScene.prototype, "PcRouletteGameScene");
//# sourceMappingURL=PcRouletteGameScene.js.map