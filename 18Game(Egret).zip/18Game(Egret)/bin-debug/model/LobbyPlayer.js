var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LobbyPlayer = (function (_super) {
    __extends(LobbyPlayer, _super);
    function LobbyPlayer() {
        var _this = _super.call(this) || this;
        _this.modelCustomPropertyMapper = function () {
            return {
                "balance": "balance",
                "isChat": "isChat",
                "isTip": "isTip",
                "limits": "limits",
                "moneysort": "moneysort",
                "name": "name",
                "nick": "nick",
                "uid": "uid",
                "parentID": "parentID",
                "playerType": "playerType",
                "rouletteChips": "rouletteChips",
                "sicoChips": "sicoChips",
                "videoChips": "videoChips",
            };
        };
        _this.modelContainerPropertyGenericClass = function () {
            return {};
        };
        return _this;
    }
    LobbyPlayer.prototype.init = function (data) {
        this.modelAddProperty.call(data);
    };
    return LobbyPlayer;
}(ModelParent));
__reflect(LobbyPlayer.prototype, "LobbyPlayer");
//# sourceMappingURL=LobbyPlayer.js.map