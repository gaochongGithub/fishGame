var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var GameHallItemModel = (function () {
    function GameHallItemModel() {
        this.isShowView = false;
    }
    GameHallItemModel.prototype.setLimitRedID = function (limitRedID) {
        this.limitRedID = limitRedID;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getLimitRedID", {
        get: function () {
            return this.limitRedID;
        },
        enumerable: true,
        configurable: true
    });
    GameHallItemModel.prototype.setTableSnapshot = function (tableSnapshot) {
        this.tableSnapshot = tableSnapshot;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getTableSnapshot", {
        get: function () {
            return this.tableSnapshot;
        },
        enumerable: true,
        configurable: true
    });
    GameHallItemModel.prototype.setIsShwoView = function (isShowView) {
        this.isShowView = isShowView;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getIsShowView", {
        get: function () {
            return this.isShowView;
        },
        enumerable: true,
        configurable: true
    });
    GameHallItemModel.prototype.setGameType = function (gameType) {
        this.gameType = gameType;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getGameType", {
        get: function () {
            return this.gameType;
        },
        enumerable: true,
        configurable: true
    });
    GameHallItemModel.prototype.setGameTable = function (gameTable) {
        this.gameTable = gameTable;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getGameTable", {
        get: function () {
            return this.gameTable;
        },
        enumerable: true,
        configurable: true
    });
    GameHallItemModel.prototype.setAllWays = function (allways) {
        this.allways = allways;
    };
    Object.defineProperty(GameHallItemModel.prototype, "getAllWays", {
        get: function () {
            return this.allways;
        },
        enumerable: true,
        configurable: true
    });
    return GameHallItemModel;
}());
__reflect(GameHallItemModel.prototype, "GameHallItemModel");
//# sourceMappingURL=GameHallItemModel.js.map