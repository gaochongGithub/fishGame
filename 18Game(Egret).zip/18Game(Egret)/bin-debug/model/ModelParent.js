var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ModelParent = (function () {
    function ModelParent() {
    }
    ModelParent.prototype.modelAddProperty = function (data) {
        if (data) {
            for (var key in data) {
                var propertyKey = key;
                if (this.hasOwnProperty('modelCustomPropertyMapper')) {
                    propertyKey = this.modelCustomPropertyMapper()[key] ? this.modelCustomPropertyMapper()[key] : key;
                }
                if (this.hasOwnProperty('modelContainerPropertyGenericClass')) {
                    if (this.modelContainerPropertyGenericClass()[propertyKey]) {
                        var Class = this.modelContainerPropertyGenericClass()[propertyKey];
                        if (data[key] instanceof Array) {
                            this[propertyKey] = [];
                            for (var _i = 0, _a = data[key]; _i < _a.length; _i++) {
                                var eachData = _a[_i];
                                var obj = new Class(eachData);
                                this[propertyKey].push(obj);
                            }
                        }
                        else {
                            this[propertyKey] = new Class(data[key]);
                        }
                        continue;
                    }
                }
                this[propertyKey] = data[key];
            }
        }
    };
    ;
    return ModelParent;
}());
__reflect(ModelParent.prototype, "ModelParent", ["ModelObjectInterface"]);
//# sourceMappingURL=ModelParent.js.map