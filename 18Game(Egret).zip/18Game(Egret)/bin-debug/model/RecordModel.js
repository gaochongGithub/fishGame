var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var RecordModel = (function () {
    function RecordModel() {
    }
    RecordModel.prototype.setOderDate = function (oderDate) {
        this.oderDate = oderDate;
    };
    Object.defineProperty(RecordModel.prototype, "getOderDate", {
        get: function () {
            return this.oderDate;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setOderNum = function (oderNum) {
        this.oderNum = oderNum;
    };
    Object.defineProperty(RecordModel.prototype, "getOderNum", {
        get: function () {
            return this.oderNum;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setTableID = function (tableID) {
        this.tableID = tableID;
    };
    Object.defineProperty(RecordModel.prototype, "getTableID", {
        get: function () {
            return this.tableID;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setShoeId = function (shoeId) {
        this.shoeId = shoeId;
    };
    Object.defineProperty(RecordModel.prototype, "getShoeId", {
        get: function () {
            return this.shoeId;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setBetsArea = function (betsArea) {
        this.betsArea = betsArea;
    };
    Object.defineProperty(RecordModel.prototype, "getBetsArea", {
        get: function () {
            return this.betsArea;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setBetsAmount = function (betsAmount) {
        this.betsAmount = betsAmount;
    };
    Object.defineProperty(RecordModel.prototype, "getBetsAmount", {
        get: function () {
            return this.betsAmount;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setResult = function (result) {
        this.result = result;
    };
    Object.defineProperty(RecordModel.prototype, "getResult", {
        get: function () {
            return this.result;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setWinloseAmount = function (winloseAmount) {
        this.winloseAmount = winloseAmount;
    };
    Object.defineProperty(RecordModel.prototype, "getWinloseAmount", {
        get: function () {
            return this.winloseAmount;
        },
        enumerable: true,
        configurable: true
    });
    RecordModel.prototype.setGameType = function (gameType) {
        this.gameType = gameType;
    };
    Object.defineProperty(RecordModel.prototype, "getGameType", {
        get: function () {
            return this.gameType;
        },
        enumerable: true,
        configurable: true
    });
    return RecordModel;
}());
__reflect(RecordModel.prototype, "RecordModel");
//# sourceMappingURL=RecordModel.js.map