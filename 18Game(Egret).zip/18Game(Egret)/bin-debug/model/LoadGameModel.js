var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var LoadGameModel = (function () {
    function LoadGameModel() {
    }
    LoadGameModel.prototype.setIsCanPlayVideo = function (isCanPlayVideo) {
        this.isCanPlayVideo = isCanPlayVideo;
    };
    Object.defineProperty(LoadGameModel.prototype, "getIsCanPlayVideo", {
        get: function () {
            return this.isCanPlayVideo;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setGameType = function (gameType) {
        this.gameType = gameType;
    };
    Object.defineProperty(LoadGameModel.prototype, "getGameType", {
        get: function () {
            return this.gameType;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setJoinType = function (joinType) {
        this.joinType = joinType;
    };
    Object.defineProperty(LoadGameModel.prototype, "getJoinType", {
        get: function () {
            return this.joinType;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setSubType = function (subType) {
        this.subType = subType;
    };
    Object.defineProperty(LoadGameModel.prototype, "getSubType", {
        get: function () {
            return this.subType;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setTableID = function (tableID) {
        this.tableID = tableID;
    };
    Object.defineProperty(LoadGameModel.prototype, "getTableID", {
        get: function () {
            return this.tableID;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setLimitRed = function (limitRed) {
        this.limitRed = limitRed;
    };
    Object.defineProperty(LoadGameModel.prototype, "getLimitRed", {
        get: function () {
            return this.limitRed;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setLimitRedID = function (limitRedID) {
        this.limitRedID = limitRedID;
    };
    Object.defineProperty(LoadGameModel.prototype, "getLimitRedID", {
        get: function () {
            return this.limitRedID;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setChip = function (chip) {
        this.chip = chip;
    };
    Object.defineProperty(LoadGameModel.prototype, "getChip", {
        get: function () {
            return this.chip;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setAllChip = function (allChip) {
        this.allChip = allChip;
    };
    Object.defineProperty(LoadGameModel.prototype, "getAllChip", {
        get: function () {
            return this.allChip;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setDealerImage = function (dealerImage) {
        this.dealerImage = dealerImage;
    };
    Object.defineProperty(LoadGameModel.prototype, "getDealerImage", {
        get: function () {
            return this.dealerImage;
        },
        enumerable: true,
        configurable: true
    });
    LoadGameModel.prototype.setPlayerType = function (playerType) {
        this.playerType = playerType;
    };
    Object.defineProperty(LoadGameModel.prototype, "getPlayerType", {
        get: function () {
            return this.playerType;
        },
        enumerable: true,
        configurable: true
    });
    return LoadGameModel;
}());
__reflect(LoadGameModel.prototype, "LoadGameModel");
//# sourceMappingURL=LoadGameModel.js.map