var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var LimitViewModel = (function () {
    function LimitViewModel() {
    }
    LimitViewModel.prototype.setLimitChoseID = function (limitChoseID) {
        this.limitChoseID = limitChoseID;
    };
    Object.defineProperty(LimitViewModel.prototype, "getLimitChoseID", {
        get: function () {
            return this.limitChoseID;
        },
        enumerable: true,
        configurable: true
    });
    LimitViewModel.prototype.setLimitChoseCount = function (limitChoseCount) {
        this.limitChoseCount = limitChoseCount;
    };
    Object.defineProperty(LimitViewModel.prototype, "getLimitChoseCount", {
        get: function () {
            return this.limitChoseCount;
        },
        enumerable: true,
        configurable: true
    });
    LimitViewModel.prototype.setIsChose = function (isChose) {
        this.isChose = isChose;
    };
    Object.defineProperty(LimitViewModel.prototype, "getIsChose", {
        get: function () {
            return this.isChose;
        },
        enumerable: true,
        configurable: true
    });
    LimitViewModel.prototype.setGameType = function (gameType) {
        this.gameType = gameType;
    };
    Object.defineProperty(LimitViewModel.prototype, "getGameType", {
        get: function () {
            return this.gameType;
        },
        enumerable: true,
        configurable: true
    });
    LimitViewModel.prototype.setGameTable = function (gameTable) {
        this.gameTable = gameTable;
    };
    Object.defineProperty(LimitViewModel.prototype, "getGameTable", {
        get: function () {
            return this.gameTable;
        },
        enumerable: true,
        configurable: true
    });
    return LimitViewModel;
}());
__reflect(LimitViewModel.prototype, "LimitViewModel");
//# sourceMappingURL=LimitViewModel.js.map