var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var LimitDataModel = (function () {
    function LimitDataModel() {
    }
    LimitDataModel.prototype.setLimitRedID = function (limitRedID) {
        this.limitRedID = limitRedID;
    };
    Object.defineProperty(LimitDataModel.prototype, "getLimitRedID", {
        get: function () {
            return this.limitRedID;
        },
        enumerable: true,
        configurable: true
    });
    LimitDataModel.prototype.setLimitRed = function (limitRed) {
        this.limitRed = limitRed;
    };
    Object.defineProperty(LimitDataModel.prototype, "getLimitRed", {
        get: function () {
            return this.limitRed;
        },
        enumerable: true,
        configurable: true
    });
    LimitDataModel.prototype.setAllChips = function (allChips) {
        this.allChips = allChips;
    };
    Object.defineProperty(LimitDataModel.prototype, "getAllChips", {
        get: function () {
            return this.allChips;
        },
        enumerable: true,
        configurable: true
    });
    LimitDataModel.prototype.setChips = function (chips) {
        this.chips = chips;
    };
    Object.defineProperty(LimitDataModel.prototype, "getChips", {
        get: function () {
            return this.chips;
        },
        enumerable: true,
        configurable: true
    });
    LimitDataModel.prototype.setLimitRedCount = function (limitRedCount) {
        this.limitRedCount = limitRedCount;
    };
    Object.defineProperty(LimitDataModel.prototype, "getLimitRedCounts", {
        get: function () {
            return this.limitRedCount;
        },
        enumerable: true,
        configurable: true
    });
    return LimitDataModel;
}());
__reflect(LimitDataModel.prototype, "LimitDataModel");
//# sourceMappingURL=LimitDataModel.js.map