var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Main.prototype.createChildren = function () {
        _super.prototype.createChildren.call(this);
        // egret.lifecycle.addLifecycleListener((context) => {
        //     // custom lifecycle plugin
        // })
        // egret.lifecycle.onPause = () => {
        //     egret.ticker.pause();
        // }
        // egret.lifecycle.onResume = () => {
        //     egret.ticker.resume();
        // }
        //inject the custom material parser
        //注入自定义的素材解析器
        var assetAdapter = new AssetAdapter();
        egret.registerImplementation("eui.IAssetAdapter", new AssetAdapter());
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());
        this.runGame().catch(function (e) {
            console.log(e);
        });
    };
    Main.prototype.runGame = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result, userInfo;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadResource()
                        //临时注释
                    ];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, RES.getResAsync("description_json")];
                    case 2:
                        result = _a.sent();
                        this.startAnimation(result);
                        return [4 /*yield*/, platform.login()];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, platform.getUserInfo()];
                    case 4:
                        userInfo = _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Main.prototype.loadResource = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 17, , 18]);
                        if (egret.Capabilities.isMobile) {
                            this.stage.setContentSize(812, 375);
                            // this.stage.width=812;
                            // this.stage.height=375;
                        }
                        else {
                            // this.stage.width=1920;
                            // this.stage.height=1080;
                            this.stage.setContentSize(1920, 1080);
                        }
                        this.loadingView = new LoadingUI();
                        return [4 /*yield*/, RES.loadConfig("resource/default.res.json", "resource/")];
                    case 1:
                        _a.sent();
                        this.stage.addChild(this.loadingView);
                        this.loadingView.createView(this.stage);
                        return [4 /*yield*/, this.loadTheme()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("preload", 0, this.loadingView)];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("hall", 0)];
                    case 4:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("gdTips", 0)];
                    case 5:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("moblieHall", 0)];
                    case 6:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("chat", 0)];
                    case 7:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("baccarat", 0)];
                    case 8:
                        _a.sent();
                        //轮盘资源
                        return [4 /*yield*/, RES.loadConfig("resource/resource_roulette.json", "resource/")];
                    case 9:
                        //轮盘资源
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("reward", 0)];
                    case 10:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("french_bet", 0)];
                    case 11:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("classic_bet", 0)];
                    case 12:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("bottom_info", 0)];
                    case 13:
                        _a.sent();
                        //通用资源
                        return [4 /*yield*/, RES.loadConfig("resource/resource_common.json", "resource/")];
                    case 14:
                        //通用资源
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("common", 0)];
                    case 15:
                        _a.sent();
                        this.loadingView.setBarCount(90);
                        //音效资源
                        return [4 /*yield*/, RES.loadGroup("sound", 0)];
                    case 16:
                        //音效资源
                        _a.sent();
                        //初始化游戏管理
                        GameSceneCtrl.instance.init(this.stage);
                        //await RES.loadConfig("resource/global.json", "resource/");
                        App.Init();
                        App.ToastViewManager.parentLayer = this.stage;
                        this.setLocalData();
                        App.GameServer.connectServer();
                        this.loadingView.setBarCount(100);
                        App.MessageCenter.addListener(SocketConst.SOCKET_START_RECONNECT, function () {
                            var name = egret.localStorage.getItem("uname");
                            var pwd = egret.localStorage.getItem("pwd");
                            var version = egret.localStorage.getItem("version");
                            App.GameServer.sendLogin(name, pwd, "-1", "", 1, _this.version, 0);
                        }, this);
                        App.MessageCenter.addListener(LobbyEvent.LOGIN_SUCCES, function (login) {
                            switch (login.code) {
                                case proto.CommonReply.Code.SUCCESS:
                                    egret.localStorage.setItem("uname", _this.uname);
                                    egret.localStorage.setItem("pwd", _this.pwd);
                                    egret.localStorage.setItem("version", _this.version);
                                    _this.chargeUrl && egret.localStorage.setItem("chargeUrl", _this.chargeUrl);
                                    _this.stage.removeChild(_this.loadingView);
                                    _this.createGameScene();
                                    break;
                                case proto.CommonReply.Code.ERR_SERVER_INTERNAL_ERROR:
                                    App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_500");
                                    break;
                                case proto.CommonReply.Code.ERR_AUTHFAIL:
                                    App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_401");
                                    break;
                                case proto.CommonReply.Code.ERR_USER_UNUSABLE:
                                    App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_6");
                                    break;
                            }
                        }, this);
                        App.MessageCenter.addListener(SocketConst.SOCKET_CONNECT, function () {
                            _this.loadLogin();
                        }, this);
                        return [3 /*break*/, 18];
                    case 17:
                        e_1 = _a.sent();
                        console.error(e_1);
                        return [3 /*break*/, 18];
                    case 18: return [2 /*return*/];
                }
            });
        });
    };
    //设置一些默认配置
    Main.prototype.setLocalData = function () {
        var lang = egret.localStorage.getItem("lang");
        if (lang) {
            App.LangUtils.init(lang);
        }
        else {
            egret.localStorage.setItem("lang", "ZH");
            App.LangUtils.init("ZH");
        }
        var super6 = egret.localStorage.getItem("Super6");
        if (!super6)
            egret.localStorage.setItem("Super6", "0");
        var isCanPlayVideo = egret.localStorage.getItem("isCanPlayVideo");
        if (!super6)
            egret.localStorage.setItem("isCanPlayVideo", "1");
    };
    //获取url参数
    Main.prototype.getRequest = function (url) {
        //var theRequest = new Object();
        var strs = "";
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("paramStr")[1].substr(1);
            // for(var i = 0; i < strs.length; i ++) {
            //     theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            // }
        }
        return strs;
    };
    Main.prototype.loadLogin = function () {
        var data = "";
        if (egret.RuntimeType.WEB) {
            // var Request = new Object();
            var url = window.location.search;
            var data = this.getRequest(url);
            //var data=Request["paramStr"]; 
        }
        var version = "web";
        if (App.DeviceUtils.IsNative)
            version = "app";
        else if (App.DeviceUtils.IsMobile)
            version = "mobile";
        if (!data) {
            //App.GameServer.sendLogin("cmkj_test14","aaa111","-1","",1,"web",0); 
            if (App.GlobalData.IsDebug) {
                App.GameServer.sendLogin("cmkj_t1013", "aaa111", "-1", "", 1, "web", 0);
            }
            else {
                this.loadingView.setLoginView(this, function (name, pwd) {
                    App.GameServer.sendLogin(name, pwd, "-1", "", 1, this.version, 0);
                });
            }
        }
        else {
            //console.log("paramStr:"+data);
            var userData = App.Base64.decode(data).split("&");
            //console.log("paramStr:"+Base64.decoder(data));
            var lang = userData[0].split("=")[1];
            this.uname = userData[1].split("=")[1];
            this.pwd = userData[2].split("=")[1];
            this.version = version;
            var time = userData[3].split("=")[1];
            this.chargeUrl = userData[4].split("=")[1];
            if (this.chargeUrl) {
                this.chargeUrl = App.Base64.decode(this.chargeUrl);
            }
            App.GameServer.sendLogin(this.uname, this.pwd, "-1", "", 1, this.version, time);
        }
        // if (cc.sys.isNative){
        //     cmkj.DataCtrl.setLocalData("isLoginScene",1);
        // }
        // cmkj.EventCtrl.sendNormalEvent(cmkj.EventType.Global.LOADED_URLSUCCESS);
    };
    Main.prototype.loadTheme = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            var theme = new eui.Theme("resource/default.thm.json", _this.stage);
            theme.addEventListener(eui.UIEvent.COMPLETE, function () {
                resolve();
            }, _this);
        });
    };
    /**
     * 创建场景界面
     * Create scene interface
     */
    Main.prototype.createGameScene = function () {
        //启用舞台的鼠标支持
        mouse.enable(this.stage);
        if (App.DeviceUtils.IsMobile) {
            GameSceneCtrl.instance.toMobileHallScene();
        }
        else {
            GameSceneCtrl.instance.toHallScene();
        }
        //
    };
    /**
     * 根据name关键字创建一个Bitmap对象。name属性请参考resources/resource.json配置文件的内容。
     * Create a Bitmap object according to name keyword.As for the property of name please refer to the configuration file of resources/resource.json.
     */
    Main.prototype.createBitmapByName = function (name) {
        var result = new egret.Bitmap();
        var texture = RES.getRes(name);
        result.texture = texture;
        return result;
    };
    /**
     * 描述文件加载成功，开始播放动画
     * Description file loading is successful, start to play the animation
     */
    Main.prototype.startAnimation = function (result) {
        var _this = this;
        var parser = new egret.HtmlTextParser();
        var textflowArr = result.map(function (text) { return parser.parse(text); });
        var textfield = this.textfield;
        var count = -1;
        var change = function () {
            count++;
            if (count >= textflowArr.length) {
                count = 0;
            }
            var textFlow = textflowArr[count];
            // 切换描述内容
            // Switch to described content
            textfield.textFlow = textFlow;
            var tw = egret.Tween.get(textfield);
            tw.to({ "alpha": 1 }, 200);
            tw.wait(2000);
            tw.to({ "alpha": 0 }, 200);
            tw.call(change, _this);
        };
        change();
    };
    /**
     * 点击按钮
     * Click the button
     */
    Main.prototype.onButtonClick = function (e) {
        var panel = new eui.Panel();
        panel.title = "Title";
        panel.horizontalCenter = 0;
        panel.verticalCenter = 0;
        this.addChild(panel);
    };
    return Main;
}(eui.UILayer));
__reflect(Main.prototype, "Main");
//# sourceMappingURL=Main.js.map