type Long = protobuf.Long;
/** Namespace proto. */
declare namespace proto {

    /** Proto enum. */
    enum Proto {
        UNKNOWN = 0,
        SeqIDSize = 4,
        CommandSize = 2
    }

    /** Command enum. */
    enum Command {
        client_heart_beat = 0,
        client_heart_beat_ack = 1,
        user_lobby_login = 10,
        user_lobby_login_ack = 11,
        user_lobby_logout = 400,
        user_lobby_logout_ack = 401,
        server_message_push = 110,
        server_announce_push = 111,
        lobby_change_avatar = 510,
        lobby_change_avatar_ack = 511,
        lobby_change_nick = 520,
        lobby_change_nick_ack = 521,
        lobby_player_push = 600,
        lobby_videourl_push = 601,
        lobby_status_push = 602,
        lobby_playercount_push = 603,
        lobby_change_chipgroup = 604,
        lobby_change_chipgroup_ack = 605,
        game_leave_table = 1000,
        game_leave_table_ack = 1001,
        game_join_table = 1010,
        game_join_table_ack = 1011,
        game_bet = 1020,
        game_bet_ack = 1021,
        game_chain_prepare = 1022,
        game_chain_prepare_ack = 1023,
        game_tip = 1030,
        game_tip_ack = 1031,
        game_chat = 1032,
        game_chat_ack = 1033,
        game_load_chat = 1034,
        game_load_chat_ack = 1035,
        game_table_status_push = 1902,
        game_table_config_push = 1903,
        game_table_history_push = 1904,
        game_player_push = 1905,
        game_virtual_table_push = 1906,
        game_virtual_bet_push = 1907,
        game_round_count_push = 1908,
        game_chat_push = 1909,
        dealer_command = 2000,
        jk_user_jointable_push = 2001,
        jk_user_leavetable_push = 2002,
        jk_user_updateinfo_push = 2003,
        report_game_report = 3000,
        report_game_report_ack = 3001,
        report_winlose = 3002,
        report_winlose_ack = 3003,
        test_oneof = 10002,
        test_map = 10003
    }

    /** ptacmd enum. */
    enum ptacmd {
        unknow = 0,
        setvip = 1,
        shuffe = 2,
        changedealer = 3,
        changeagent = 4,
        skipcard = 5,
        tips = 6,
        finaltable = 7,
        finish = 8,
        openack = 9,
        notopen = 10,
        cancelbet = 11,
        squeezecard = 12,
        opencard1 = 13,
        opencards = 14
    }

    /** Properties of a Playercmd. */
    interface IPlayercmd {

        /** Playercmd tableID */
        tableID?: (number|null);

        /** Playercmd cmd */
        cmd?: (proto.ptacmd|null);

        /** Playercmd arg1 */
        arg1?: (string|null);
    }

    /** Represents a Playercmd. */
    class Playercmd implements IPlayercmd {

        /**
         * Constructs a new Playercmd.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IPlayercmd);

        /** Playercmd tableID. */
        public tableID: number;

        /** Playercmd cmd. */
        public cmd: proto.ptacmd;

        /** Playercmd arg1. */
        public arg1: string;

        /**
         * Creates a new Playercmd instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Playercmd instance
         */
        public static create(properties?: proto.IPlayercmd): proto.Playercmd;

        /**
         * Encodes the specified Playercmd message. Does not implicitly {@link proto.Playercmd.verify|verify} messages.
         * @param message Playercmd message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IPlayercmd, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Playercmd message, length delimited. Does not implicitly {@link proto.Playercmd.verify|verify} messages.
         * @param message Playercmd message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IPlayercmd, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a Playercmd message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Playercmd
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Playercmd;

        /**
         * Decodes a Playercmd message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Playercmd
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Playercmd;

        /**
         * Verifies a Playercmd message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Playercmd message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Playercmd
         */
        public static fromObject(object: { [k: string]: any }): proto.Playercmd;

        /**
         * Creates a plain object from a Playercmd message. Also converts values to other types if specified.
         * @param message Playercmd
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Playercmd, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Playercmd to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a CommonReply. */
    interface ICommonReply {

        /** CommonReply code */
        code?: (proto.CommonReply.Code|null);

        /** CommonReply desc */
        desc?: (string|null);
    }

    /** Represents a CommonReply. */
    class CommonReply implements ICommonReply {

        /**
         * Constructs a new CommonReply.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.ICommonReply);

        /** CommonReply code. */
        public code: proto.CommonReply.Code;

        /** CommonReply desc. */
        public desc: string;

        /**
         * Creates a new CommonReply instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CommonReply instance
         */
        public static create(properties?: proto.ICommonReply): proto.CommonReply;

        /**
         * Encodes the specified CommonReply message. Does not implicitly {@link proto.CommonReply.verify|verify} messages.
         * @param message CommonReply message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.ICommonReply, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified CommonReply message, length delimited. Does not implicitly {@link proto.CommonReply.verify|verify} messages.
         * @param message CommonReply message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.ICommonReply, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a CommonReply message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CommonReply
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.CommonReply;

        /**
         * Decodes a CommonReply message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CommonReply
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.CommonReply;

        /**
         * Verifies a CommonReply message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CommonReply message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CommonReply
         */
        public static fromObject(object: { [k: string]: any }): proto.CommonReply;

        /**
         * Creates a plain object from a CommonReply message. Also converts values to other types if specified.
         * @param message CommonReply
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.CommonReply, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CommonReply to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace CommonReply {

        /** Code enum. */
        enum Code {
            SUCCESS = 0,
            ERR_INVALID_PROTOCOL = 1,
            ERR_INVALID_DATA = 2,
            ERR_INVALID_OPERATION = 3,
            ERR_USER_UNUSABLE = 6,
            ERR_ACCOUT_LOCK = 7,
            ERR_EXCEED_LIMIT = 8,
            ERR_EXCEED_PROFIT = 9,
            ERR_NOT_BET_TIME = 10,
            ERR_LAST_3_GAME = 11,
            ERR_KICKED = 12,
            ERR_OTHER_LOGIN = 13,
            ERR_CHAT_FAST_LIMIT = 14,
            ERR_CHAT_LIMIT = 15,
            ERR_AUTHFAIL = 401,
            ERR_SERVER_INTERNAL_ERROR = 500
        }
    }

    /** Properties of an AutoID. */
    interface IAutoID {

        /** AutoID id */
        id?: (number|Long|null);
    }

    /** Represents an AutoID. */
    class AutoID implements IAutoID {

        /**
         * Constructs a new AutoID.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IAutoID);

        /** AutoID id. */
        public id: (number|Long);

        /**
         * Creates a new AutoID instance using the specified properties.
         * @param [properties] Properties to set
         * @returns AutoID instance
         */
        public static create(properties?: proto.IAutoID): proto.AutoID;

        /**
         * Encodes the specified AutoID message. Does not implicitly {@link proto.AutoID.verify|verify} messages.
         * @param message AutoID message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IAutoID, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified AutoID message, length delimited. Does not implicitly {@link proto.AutoID.verify|verify} messages.
         * @param message AutoID message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IAutoID, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes an AutoID message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns AutoID
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.AutoID;

        /**
         * Decodes an AutoID message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns AutoID
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.AutoID;

        /**
         * Verifies an AutoID message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an AutoID message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns AutoID
         */
        public static fromObject(object: { [k: string]: any }): proto.AutoID;

        /**
         * Creates a plain object from an AutoID message. Also converts values to other types if specified.
         * @param message AutoID
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.AutoID, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this AutoID to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of an Announce. */
    interface IAnnounce {

        /** Announce id */
        id?: (number|Long|null);

        /** Announce category */
        category?: (number|null);

        /** Announce language */
        language?: (string|null);

        /** Announce content */
        content?: (string|null);
    }

    /** Represents an Announce. */
    class Announce implements IAnnounce {

        /**
         * Constructs a new Announce.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IAnnounce);

        /** Announce id. */
        public id: (number|Long);

        /** Announce category. */
        public category: number;

        /** Announce language. */
        public language: string;

        /** Announce content. */
        public content: string;

        /**
         * Creates a new Announce instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Announce instance
         */
        public static create(properties?: proto.IAnnounce): proto.Announce;

        /**
         * Encodes the specified Announce message. Does not implicitly {@link proto.Announce.verify|verify} messages.
         * @param message Announce message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IAnnounce, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Announce message, length delimited. Does not implicitly {@link proto.Announce.verify|verify} messages.
         * @param message Announce message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IAnnounce, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes an Announce message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Announce
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Announce;

        /**
         * Decodes an Announce message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Announce
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Announce;

        /**
         * Verifies an Announce message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an Announce message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Announce
         */
        public static fromObject(object: { [k: string]: any }): proto.Announce;

        /**
         * Creates a plain object from an Announce message. Also converts values to other types if specified.
         * @param message Announce
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Announce, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Announce to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of an AnnouncePush. */
    interface IAnnouncePush {

        /** AnnouncePush list */
        list?: (proto.IAnnounce[]|null);
    }

    /** Represents an AnnouncePush. */
    class AnnouncePush implements IAnnouncePush {

        /**
         * Constructs a new AnnouncePush.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IAnnouncePush);

        /** AnnouncePush list. */
        public list: proto.IAnnounce[];

        /**
         * Creates a new AnnouncePush instance using the specified properties.
         * @param [properties] Properties to set
         * @returns AnnouncePush instance
         */
        public static create(properties?: proto.IAnnouncePush): proto.AnnouncePush;

        /**
         * Encodes the specified AnnouncePush message. Does not implicitly {@link proto.AnnouncePush.verify|verify} messages.
         * @param message AnnouncePush message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IAnnouncePush, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified AnnouncePush message, length delimited. Does not implicitly {@link proto.AnnouncePush.verify|verify} messages.
         * @param message AnnouncePush message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IAnnouncePush, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes an AnnouncePush message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns AnnouncePush
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.AnnouncePush;

        /**
         * Decodes an AnnouncePush message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns AnnouncePush
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.AnnouncePush;

        /**
         * Verifies an AnnouncePush message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an AnnouncePush message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns AnnouncePush
         */
        public static fromObject(object: { [k: string]: any }): proto.AnnouncePush;

        /**
         * Creates a plain object from an AnnouncePush message. Also converts values to other types if specified.
         * @param message AnnouncePush
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.AnnouncePush, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this AnnouncePush to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a String. */
    interface IString {

        /** String str */
        str?: (string|null);
    }

    /** Represents a String. */
    class String implements IString {

        /**
         * Constructs a new String.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IString);

        /** String str. */
        public str: string;

        /**
         * Creates a new String instance using the specified properties.
         * @param [properties] Properties to set
         * @returns String instance
         */
        public static create(properties?: proto.IString): proto.String;

        /**
         * Encodes the specified String message. Does not implicitly {@link proto.String.verify|verify} messages.
         * @param message String message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IString, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified String message, length delimited. Does not implicitly {@link proto.String.verify|verify} messages.
         * @param message String message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IString, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a String message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns String
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.String;

        /**
         * Decodes a String message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns String
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.String;

        /**
         * Verifies a String message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a String message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns String
         */
        public static fromObject(object: { [k: string]: any }): proto.String;

        /**
         * Creates a plain object from a String message. Also converts values to other types if specified.
         * @param message String
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.String, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this String to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** GameType enum. */
    enum GameType {
        UnKnow = 0,
        Baccarat = 11,
        LongHu = 12,
        Roulette = 13,
        SicBo = 14,
        FanTan = 15,
        TexasPoker = 16
    }

    /** Properties of a UserRequest. */
    interface IUserRequest {
    }

    /** Represents a UserRequest. */
    class UserRequest implements IUserRequest {

        /**
         * Constructs a new UserRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IUserRequest);

        /**
         * Creates a new UserRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns UserRequest instance
         */
        public static create(properties?: proto.IUserRequest): proto.UserRequest;

        /**
         * Encodes the specified UserRequest message. Does not implicitly {@link proto.UserRequest.verify|verify} messages.
         * @param message UserRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IUserRequest, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified UserRequest message, length delimited. Does not implicitly {@link proto.UserRequest.verify|verify} messages.
         * @param message UserRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IUserRequest, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a UserRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns UserRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest;

        /**
         * Decodes a UserRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns UserRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest;

        /**
         * Verifies a UserRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a UserRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns UserRequest
         */
        public static fromObject(object: { [k: string]: any }): proto.UserRequest;

        /**
         * Creates a plain object from a UserRequest message. Also converts values to other types if specified.
         * @param message UserRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.UserRequest, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this UserRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace UserRequest {

        /** Properties of a HeartBeat. */
        interface IHeartBeat {

            /** HeartBeat id */
            id?: (number|Long|null);
        }

        /** Represents a HeartBeat. */
        class HeartBeat implements IHeartBeat {

            /**
             * Constructs a new HeartBeat.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.UserRequest.IHeartBeat);

            /** HeartBeat id. */
            public id: (number|Long);

            /**
             * Creates a new HeartBeat instance using the specified properties.
             * @param [properties] Properties to set
             * @returns HeartBeat instance
             */
            public static create(properties?: proto.UserRequest.IHeartBeat): proto.UserRequest.HeartBeat;

            /**
             * Encodes the specified HeartBeat message. Does not implicitly {@link proto.UserRequest.HeartBeat.verify|verify} messages.
             * @param message HeartBeat message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.UserRequest.IHeartBeat, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified HeartBeat message, length delimited. Does not implicitly {@link proto.UserRequest.HeartBeat.verify|verify} messages.
             * @param message HeartBeat message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.UserRequest.IHeartBeat, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a HeartBeat message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns HeartBeat
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest.HeartBeat;

            /**
             * Decodes a HeartBeat message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns HeartBeat
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest.HeartBeat;

            /**
             * Verifies a HeartBeat message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a HeartBeat message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns HeartBeat
             */
            public static fromObject(object: { [k: string]: any }): proto.UserRequest.HeartBeat;

            /**
             * Creates a plain object from a HeartBeat message. Also converts values to other types if specified.
             * @param message HeartBeat
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.UserRequest.HeartBeat, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this HeartBeat to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a LobbyLogin. */
        interface ILobbyLogin {

            /** LobbyLogin name */
            name?: (string|null);

            /** LobbyLogin passwd */
            passwd?: (string|null);

            /** LobbyLogin way */
            way?: (string|null);

            /** LobbyLogin ip */
            ip?: (string|null);

            /** LobbyLogin platform */
            platform?: (number|null);

            /** LobbyLogin version */
            version?: (string|null);

            /** LobbyLogin time */
            time?: (number|Long|null);
        }

        /** Represents a LobbyLogin. */
        class LobbyLogin implements ILobbyLogin {

            /**
             * Constructs a new LobbyLogin.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.UserRequest.ILobbyLogin);

            /** LobbyLogin name. */
            public name: string;

            /** LobbyLogin passwd. */
            public passwd: string;

            /** LobbyLogin way. */
            public way: string;

            /** LobbyLogin ip. */
            public ip: string;

            /** LobbyLogin platform. */
            public platform: number;

            /** LobbyLogin version. */
            public version: string;

            /** LobbyLogin time. */
            public time: (number|Long);

            /**
             * Creates a new LobbyLogin instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LobbyLogin instance
             */
            public static create(properties?: proto.UserRequest.ILobbyLogin): proto.UserRequest.LobbyLogin;

            /**
             * Encodes the specified LobbyLogin message. Does not implicitly {@link proto.UserRequest.LobbyLogin.verify|verify} messages.
             * @param message LobbyLogin message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.UserRequest.ILobbyLogin, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified LobbyLogin message, length delimited. Does not implicitly {@link proto.UserRequest.LobbyLogin.verify|verify} messages.
             * @param message LobbyLogin message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.UserRequest.ILobbyLogin, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a LobbyLogin message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LobbyLogin
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest.LobbyLogin;

            /**
             * Decodes a LobbyLogin message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LobbyLogin
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest.LobbyLogin;

            /**
             * Verifies a LobbyLogin message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LobbyLogin message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LobbyLogin
             */
            public static fromObject(object: { [k: string]: any }): proto.UserRequest.LobbyLogin;

            /**
             * Creates a plain object from a LobbyLogin message. Also converts values to other types if specified.
             * @param message LobbyLogin
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.UserRequest.LobbyLogin, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LobbyLogin to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a LobbyLogout. */
        interface ILobbyLogout {
        }

        /** Represents a LobbyLogout. */
        class LobbyLogout implements ILobbyLogout {

            /**
             * Constructs a new LobbyLogout.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.UserRequest.ILobbyLogout);

            /**
             * Creates a new LobbyLogout instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LobbyLogout instance
             */
            public static create(properties?: proto.UserRequest.ILobbyLogout): proto.UserRequest.LobbyLogout;

            /**
             * Encodes the specified LobbyLogout message. Does not implicitly {@link proto.UserRequest.LobbyLogout.verify|verify} messages.
             * @param message LobbyLogout message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.UserRequest.ILobbyLogout, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified LobbyLogout message, length delimited. Does not implicitly {@link proto.UserRequest.LobbyLogout.verify|verify} messages.
             * @param message LobbyLogout message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.UserRequest.ILobbyLogout, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a LobbyLogout message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LobbyLogout
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest.LobbyLogout;

            /**
             * Decodes a LobbyLogout message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LobbyLogout
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest.LobbyLogout;

            /**
             * Verifies a LobbyLogout message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LobbyLogout message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LobbyLogout
             */
            public static fromObject(object: { [k: string]: any }): proto.UserRequest.LobbyLogout;

            /**
             * Creates a plain object from a LobbyLogout message. Also converts values to other types if specified.
             * @param message LobbyLogout
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.UserRequest.LobbyLogout, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LobbyLogout to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** JoinType enum. */
        enum JoinType {
            Common = 0,
            Chain = 1,
            VipTable = 2
        }

        /** Properties of a GameLogin. */
        interface IGameLogin {

            /** GameLogin gameID */
            gameID?: (proto.GameType|null);

            /** GameLogin tableID */
            tableID?: (number|null);

            /** GameLogin type */
            type?: (proto.UserRequest.JoinType|null);
        }

        /** Represents a GameLogin. */
        class GameLogin implements IGameLogin {

            /**
             * Constructs a new GameLogin.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.UserRequest.IGameLogin);

            /** GameLogin gameID. */
            public gameID: proto.GameType;

            /** GameLogin tableID. */
            public tableID: number;

            /** GameLogin type. */
            public type: proto.UserRequest.JoinType;

            /**
             * Creates a new GameLogin instance using the specified properties.
             * @param [properties] Properties to set
             * @returns GameLogin instance
             */
            public static create(properties?: proto.UserRequest.IGameLogin): proto.UserRequest.GameLogin;

            /**
             * Encodes the specified GameLogin message. Does not implicitly {@link proto.UserRequest.GameLogin.verify|verify} messages.
             * @param message GameLogin message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.UserRequest.IGameLogin, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified GameLogin message, length delimited. Does not implicitly {@link proto.UserRequest.GameLogin.verify|verify} messages.
             * @param message GameLogin message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.UserRequest.IGameLogin, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a GameLogin message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns GameLogin
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest.GameLogin;

            /**
             * Decodes a GameLogin message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns GameLogin
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest.GameLogin;

            /**
             * Verifies a GameLogin message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a GameLogin message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns GameLogin
             */
            public static fromObject(object: { [k: string]: any }): proto.UserRequest.GameLogin;

            /**
             * Creates a plain object from a GameLogin message. Also converts values to other types if specified.
             * @param message GameLogin
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.UserRequest.GameLogin, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this GameLogin to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a GameExit. */
        interface IGameExit {

            /** GameExit gameID */
            gameID?: (proto.GameType|null);
        }

        /** Represents a GameExit. */
        class GameExit implements IGameExit {

            /**
             * Constructs a new GameExit.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.UserRequest.IGameExit);

            /** GameExit gameID. */
            public gameID: proto.GameType;

            /**
             * Creates a new GameExit instance using the specified properties.
             * @param [properties] Properties to set
             * @returns GameExit instance
             */
            public static create(properties?: proto.UserRequest.IGameExit): proto.UserRequest.GameExit;

            /**
             * Encodes the specified GameExit message. Does not implicitly {@link proto.UserRequest.GameExit.verify|verify} messages.
             * @param message GameExit message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.UserRequest.IGameExit, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified GameExit message, length delimited. Does not implicitly {@link proto.UserRequest.GameExit.verify|verify} messages.
             * @param message GameExit message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.UserRequest.IGameExit, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a GameExit message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns GameExit
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.UserRequest.GameExit;

            /**
             * Decodes a GameExit message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns GameExit
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.UserRequest.GameExit;

            /**
             * Verifies a GameExit message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a GameExit message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns GameExit
             */
            public static fromObject(object: { [k: string]: any }): proto.UserRequest.GameExit;

            /**
             * Creates a plain object from a GameExit message. Also converts values to other types if specified.
             * @param message GameExit
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.UserRequest.GameExit, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this GameExit to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }
    }

    /** Properties of a Lobby. */
    interface ILobby {
    }

    /** Represents a Lobby. */
    class Lobby implements ILobby {

        /**
         * Constructs a new Lobby.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.ILobby);

        /**
         * Creates a new Lobby instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Lobby instance
         */
        public static create(properties?: proto.ILobby): proto.Lobby;

        /**
         * Encodes the specified Lobby message. Does not implicitly {@link proto.Lobby.verify|verify} messages.
         * @param message Lobby message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.ILobby, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Lobby message, length delimited. Does not implicitly {@link proto.Lobby.verify|verify} messages.
         * @param message Lobby message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.ILobby, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a Lobby message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Lobby
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby;

        /**
         * Decodes a Lobby message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Lobby
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby;

        /**
         * Verifies a Lobby message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Lobby message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Lobby
         */
        public static fromObject(object: { [k: string]: any }): proto.Lobby;

        /**
         * Creates a plain object from a Lobby message. Also converts values to other types if specified.
         * @param message Lobby
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Lobby, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Lobby to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace Lobby {

        /** Properties of a ChangeAvatar. */
        interface IChangeAvatar {

            /** ChangeAvatar avatar */
            avatar?: (number|null);
        }

        /** Represents a ChangeAvatar. */
        class ChangeAvatar implements IChangeAvatar {

            /**
             * Constructs a new ChangeAvatar.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IChangeAvatar);

            /** ChangeAvatar avatar. */
            public avatar: number;

            /**
             * Creates a new ChangeAvatar instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChangeAvatar instance
             */
            public static create(properties?: proto.Lobby.IChangeAvatar): proto.Lobby.ChangeAvatar;

            /**
             * Encodes the specified ChangeAvatar message. Does not implicitly {@link proto.Lobby.ChangeAvatar.verify|verify} messages.
             * @param message ChangeAvatar message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IChangeAvatar, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChangeAvatar message, length delimited. Does not implicitly {@link proto.Lobby.ChangeAvatar.verify|verify} messages.
             * @param message ChangeAvatar message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IChangeAvatar, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChangeAvatar message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChangeAvatar
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.ChangeAvatar;

            /**
             * Decodes a ChangeAvatar message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChangeAvatar
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.ChangeAvatar;

            /**
             * Verifies a ChangeAvatar message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChangeAvatar message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChangeAvatar
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.ChangeAvatar;

            /**
             * Creates a plain object from a ChangeAvatar message. Also converts values to other types if specified.
             * @param message ChangeAvatar
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.ChangeAvatar, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChangeAvatar to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a ChangeNick. */
        interface IChangeNick {

            /** ChangeNick nickname */
            nickname?: (string|null);
        }

        /** Represents a ChangeNick. */
        class ChangeNick implements IChangeNick {

            /**
             * Constructs a new ChangeNick.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IChangeNick);

            /** ChangeNick nickname. */
            public nickname: string;

            /**
             * Creates a new ChangeNick instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChangeNick instance
             */
            public static create(properties?: proto.Lobby.IChangeNick): proto.Lobby.ChangeNick;

            /**
             * Encodes the specified ChangeNick message. Does not implicitly {@link proto.Lobby.ChangeNick.verify|verify} messages.
             * @param message ChangeNick message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IChangeNick, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChangeNick message, length delimited. Does not implicitly {@link proto.Lobby.ChangeNick.verify|verify} messages.
             * @param message ChangeNick message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IChangeNick, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChangeNick message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChangeNick
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.ChangeNick;

            /**
             * Decodes a ChangeNick message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChangeNick
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.ChangeNick;

            /**
             * Verifies a ChangeNick message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChangeNick message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChangeNick
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.ChangeNick;

            /**
             * Creates a plain object from a ChangeNick message. Also converts values to other types if specified.
             * @param message ChangeNick
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.ChangeNick, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChangeNick to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a ChangeChipGroup. */
        interface IChangeChipGroup {

            /** ChangeChipGroup chipgroup */
            chipgroup?: (number[]|null);

            /** ChangeChipGroup selectedLimit */
            selectedLimit?: (number|null);
        }

        /** Represents a ChangeChipGroup. */
        class ChangeChipGroup implements IChangeChipGroup {

            /**
             * Constructs a new ChangeChipGroup.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IChangeChipGroup);

            /** ChangeChipGroup chipgroup. */
            public chipgroup: number[];

            /** ChangeChipGroup selectedLimit. */
            public selectedLimit: number;

            /**
             * Creates a new ChangeChipGroup instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChangeChipGroup instance
             */
            public static create(properties?: proto.Lobby.IChangeChipGroup): proto.Lobby.ChangeChipGroup;

            /**
             * Encodes the specified ChangeChipGroup message. Does not implicitly {@link proto.Lobby.ChangeChipGroup.verify|verify} messages.
             * @param message ChangeChipGroup message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IChangeChipGroup, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChangeChipGroup message, length delimited. Does not implicitly {@link proto.Lobby.ChangeChipGroup.verify|verify} messages.
             * @param message ChangeChipGroup message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IChangeChipGroup, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChangeChipGroup message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChangeChipGroup
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.ChangeChipGroup;

            /**
             * Decodes a ChangeChipGroup message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChangeChipGroup
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.ChangeChipGroup;

            /**
             * Verifies a ChangeChipGroup message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChangeChipGroup message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChangeChipGroup
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.ChangeChipGroup;

            /**
             * Creates a plain object from a ChangeChipGroup message. Also converts values to other types if specified.
             * @param message ChangeChipGroup
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.ChangeChipGroup, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChangeChipGroup to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a UserSnapshot. */
        interface IUserSnapshot {

            /** UserSnapshot name */
            name?: (string|null);

            /** UserSnapshot nick */
            nick?: (string|null);

            /** UserSnapshot balance */
            balance?: (number|null);

            /** UserSnapshot videoChips */
            videoChips?: ({ [k: string]: string }|null);

            /** UserSnapshot rouletteChips */
            rouletteChips?: ({ [k: string]: string }|null);

            /** UserSnapshot limits */
            limits?: (number|Long|null);

            /** UserSnapshot moneysort */
            moneysort?: (string|null);

            /** UserSnapshot parentID */
            parentID?: (number|Long|null);

            /** UserSnapshot isTip */
            isTip?: (boolean|null);

            /** UserSnapshot isChat */
            isChat?: (boolean|null);

            /** UserSnapshot uid */
            uid?: (number|Long|null);

            /** UserSnapshot sicoChips */
            sicoChips?: ({ [k: string]: string }|null);

            /** UserSnapshot playerType */
            playerType?: (number|null);
        }

        /** Represents a UserSnapshot. */
        class UserSnapshot implements IUserSnapshot {

            /**
             * Constructs a new UserSnapshot.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IUserSnapshot);

            /** UserSnapshot name. */
            public name: string;

            /** UserSnapshot nick. */
            public nick: string;

            /** UserSnapshot balance. */
            public balance: number;

            /** UserSnapshot videoChips. */
            public videoChips: { [k: string]: string };

            /** UserSnapshot rouletteChips. */
            public rouletteChips: { [k: string]: string };

            /** UserSnapshot limits. */
            public limits: (number|Long);

            /** UserSnapshot moneysort. */
            public moneysort: string;

            /** UserSnapshot parentID. */
            public parentID: (number|Long);

            /** UserSnapshot isTip. */
            public isTip: boolean;

            /** UserSnapshot isChat. */
            public isChat: boolean;

            /** UserSnapshot uid. */
            public uid: (number|Long);

            /** UserSnapshot sicoChips. */
            public sicoChips: { [k: string]: string };

            /** UserSnapshot playerType. */
            public playerType: number;

            /**
             * Creates a new UserSnapshot instance using the specified properties.
             * @param [properties] Properties to set
             * @returns UserSnapshot instance
             */
            public static create(properties?: proto.Lobby.IUserSnapshot): proto.Lobby.UserSnapshot;

            /**
             * Encodes the specified UserSnapshot message. Does not implicitly {@link proto.Lobby.UserSnapshot.verify|verify} messages.
             * @param message UserSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IUserSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified UserSnapshot message, length delimited. Does not implicitly {@link proto.Lobby.UserSnapshot.verify|verify} messages.
             * @param message UserSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IUserSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a UserSnapshot message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns UserSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.UserSnapshot;

            /**
             * Decodes a UserSnapshot message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns UserSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.UserSnapshot;

            /**
             * Verifies a UserSnapshot message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a UserSnapshot message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns UserSnapshot
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.UserSnapshot;

            /**
             * Creates a plain object from a UserSnapshot message. Also converts values to other types if specified.
             * @param message UserSnapshot
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.UserSnapshot, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this UserSnapshot to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a VideoUrl. */
        interface IVideoUrl {

            /** VideoUrl url */
            url?: (string[]|null);
        }

        /** Represents a VideoUrl. */
        class VideoUrl implements IVideoUrl {

            /**
             * Constructs a new VideoUrl.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IVideoUrl);

            /** VideoUrl url. */
            public url: string[];

            /**
             * Creates a new VideoUrl instance using the specified properties.
             * @param [properties] Properties to set
             * @returns VideoUrl instance
             */
            public static create(properties?: proto.Lobby.IVideoUrl): proto.Lobby.VideoUrl;

            /**
             * Encodes the specified VideoUrl message. Does not implicitly {@link proto.Lobby.VideoUrl.verify|verify} messages.
             * @param message VideoUrl message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IVideoUrl, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified VideoUrl message, length delimited. Does not implicitly {@link proto.Lobby.VideoUrl.verify|verify} messages.
             * @param message VideoUrl message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IVideoUrl, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a VideoUrl message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns VideoUrl
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.VideoUrl;

            /**
             * Decodes a VideoUrl message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns VideoUrl
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.VideoUrl;

            /**
             * Verifies a VideoUrl message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a VideoUrl message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns VideoUrl
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.VideoUrl;

            /**
             * Creates a plain object from a VideoUrl message. Also converts values to other types if specified.
             * @param message VideoUrl
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.VideoUrl, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this VideoUrl to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a TableSnapshot. */
        interface ITableSnapshot {

            /** TableSnapshot gameType */
            gameType?: (number|null);

            /** TableSnapshot tableID */
            tableID?: (number|null);

            /** TableSnapshot stage */
            stage?: (number|null);

            /** TableSnapshot inning */
            inning?: (number|null);

            /** TableSnapshot status */
            status?: (number|null);

            /** TableSnapshot time */
            time?: (number|null);

            /** TableSnapshot ways */
            ways?: (string|null);

            /** TableSnapshot counts */
            counts?: (string|null);

            /** TableSnapshot isopen */
            isopen?: (boolean|null);

            /** TableSnapshot dealer */
            dealer?: (string|null);

            /** TableSnapshot limit */
            limit?: (string|null);

            /** TableSnapshot platform */
            platform?: (number|null);

            /** TableSnapshot playerCount */
            playerCount?: (number|null);

            /** TableSnapshot playerTotalBlance */
            playerTotalBlance?: (number|null);

            /** TableSnapshot betinfo */
            betinfo?: ({ [k: string]: proto.Game.IBetInfo }|null);

            /** TableSnapshot dealerImage */
            dealerImage?: (string|null);
        }

        /** Represents a TableSnapshot. */
        class TableSnapshot implements ITableSnapshot {

            /**
             * Constructs a new TableSnapshot.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.ITableSnapshot);

            /** TableSnapshot gameType. */
            public gameType: number;

            /** TableSnapshot tableID. */
            public tableID: number;

            /** TableSnapshot stage. */
            public stage: number;

            /** TableSnapshot inning. */
            public inning: number;

            /** TableSnapshot status. */
            public status: number;

            /** TableSnapshot time. */
            public time: number;

            /** TableSnapshot ways. */
            public ways: string;

            /** TableSnapshot counts. */
            public counts: string;

            /** TableSnapshot isopen. */
            public isopen: boolean;

            /** TableSnapshot dealer. */
            public dealer: string;

            /** TableSnapshot limit. */
            public limit: string;

            /** TableSnapshot platform. */
            public platform: number;

            /** TableSnapshot playerCount. */
            public playerCount: number;

            /** TableSnapshot playerTotalBlance. */
            public playerTotalBlance: number;

            /** TableSnapshot betinfo. */
            public betinfo: { [k: string]: proto.Game.IBetInfo };

            /** TableSnapshot dealerImage. */
            public dealerImage: string;

            /**
             * Creates a new TableSnapshot instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableSnapshot instance
             */
            public static create(properties?: proto.Lobby.ITableSnapshot): proto.Lobby.TableSnapshot;

            /**
             * Encodes the specified TableSnapshot message. Does not implicitly {@link proto.Lobby.TableSnapshot.verify|verify} messages.
             * @param message TableSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.ITableSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified TableSnapshot message, length delimited. Does not implicitly {@link proto.Lobby.TableSnapshot.verify|verify} messages.
             * @param message TableSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.ITableSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a TableSnapshot message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.TableSnapshot;

            /**
             * Decodes a TableSnapshot message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.TableSnapshot;

            /**
             * Verifies a TableSnapshot message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableSnapshot message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableSnapshot
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.TableSnapshot;

            /**
             * Creates a plain object from a TableSnapshot message. Also converts values to other types if specified.
             * @param message TableSnapshot
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.TableSnapshot, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableSnapshot to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a PlayerCount. */
        interface IPlayerCount {

            /** PlayerCount count */
            count?: (number|Long|null);
        }

        /** Represents a PlayerCount. */
        class PlayerCount implements IPlayerCount {

            /**
             * Constructs a new PlayerCount.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Lobby.IPlayerCount);

            /** PlayerCount count. */
            public count: (number|Long);

            /**
             * Creates a new PlayerCount instance using the specified properties.
             * @param [properties] Properties to set
             * @returns PlayerCount instance
             */
            public static create(properties?: proto.Lobby.IPlayerCount): proto.Lobby.PlayerCount;

            /**
             * Encodes the specified PlayerCount message. Does not implicitly {@link proto.Lobby.PlayerCount.verify|verify} messages.
             * @param message PlayerCount message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Lobby.IPlayerCount, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified PlayerCount message, length delimited. Does not implicitly {@link proto.Lobby.PlayerCount.verify|verify} messages.
             * @param message PlayerCount message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Lobby.IPlayerCount, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a PlayerCount message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns PlayerCount
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Lobby.PlayerCount;

            /**
             * Decodes a PlayerCount message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns PlayerCount
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Lobby.PlayerCount;

            /**
             * Verifies a PlayerCount message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a PlayerCount message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns PlayerCount
             */
            public static fromObject(object: { [k: string]: any }): proto.Lobby.PlayerCount;

            /**
             * Creates a plain object from a PlayerCount message. Also converts values to other types if specified.
             * @param message PlayerCount
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Lobby.PlayerCount, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this PlayerCount to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }
    }

    /** Properties of a Game. */
    interface IGame {
    }

    /** Represents a Game. */
    class Game implements IGame {

        /**
         * Constructs a new Game.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IGame);

        /**
         * Creates a new Game instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Game instance
         */
        public static create(properties?: proto.IGame): proto.Game;

        /**
         * Encodes the specified Game message. Does not implicitly {@link proto.Game.verify|verify} messages.
         * @param message Game message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IGame, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Game message, length delimited. Does not implicitly {@link proto.Game.verify|verify} messages.
         * @param message Game message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IGame, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a Game message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Game
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game;

        /**
         * Decodes a Game message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Game
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game;

        /**
         * Verifies a Game message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Game message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Game
         */
        public static fromObject(object: { [k: string]: any }): proto.Game;

        /**
         * Creates a plain object from a Game message. Also converts values to other types if specified.
         * @param message Game
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Game, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Game to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace Game {

        /** Properties of an EmptyReq. */
        interface IEmptyReq {
        }

        /** Represents an EmptyReq. */
        class EmptyReq implements IEmptyReq {

            /**
             * Constructs a new EmptyReq.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IEmptyReq);

            /**
             * Creates a new EmptyReq instance using the specified properties.
             * @param [properties] Properties to set
             * @returns EmptyReq instance
             */
            public static create(properties?: proto.Game.IEmptyReq): proto.Game.EmptyReq;

            /**
             * Encodes the specified EmptyReq message. Does not implicitly {@link proto.Game.EmptyReq.verify|verify} messages.
             * @param message EmptyReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IEmptyReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified EmptyReq message, length delimited. Does not implicitly {@link proto.Game.EmptyReq.verify|verify} messages.
             * @param message EmptyReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IEmptyReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes an EmptyReq message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns EmptyReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.EmptyReq;

            /**
             * Decodes an EmptyReq message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns EmptyReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.EmptyReq;

            /**
             * Verifies an EmptyReq message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an EmptyReq message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns EmptyReq
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.EmptyReq;

            /**
             * Creates a plain object from an EmptyReq message. Also converts values to other types if specified.
             * @param message EmptyReq
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.EmptyReq, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this EmptyReq to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Subtype enum. */
        enum Subtype {
            UnKnow = 0,
            ClassicBaccarat = 111,
            MianYongBaccarat = 112,
            SuperBaccarat = 113,
            ChainBaccarat = 114,
            MianYongChainBaccarat = 115,
            LongHu = 211,
            Roulette = 311,
            SicBo = 411,
            FanTan = 511,
            TexasPoker = 611
        }

        /** BettingArea enum. */
        enum BettingArea {
            Invalid = 0,
            BaccaratPlayer = 101,
            BaccaratBanker = 102,
            BaccaratTie = 103,
            BaccaratPpair = 104,
            BaccaratBpair = 105,
            BaccaratSuper6 = 106,
            BaccaratAnyPair = 107,
            BaccaratPerfectPair = 108,
            BaccaratBig = 109,
            BaccaratSmall = 110,
            LongHuLong = 201,
            LongHuHu = 202,
            LongHuHe = 203,
            Tip = 1000
        }

        /** Properties of a JoinTable. */
        interface IJoinTable {

            /** JoinTable gameType */
            gameType?: (proto.GameType|null);

            /** JoinTable tableID */
            tableID?: (number|null);

            /** JoinTable joinType */
            joinType?: (proto.UserRequest.JoinType|null);
        }

        /** Represents a JoinTable. */
        class JoinTable implements IJoinTable {

            /**
             * Constructs a new JoinTable.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IJoinTable);

            /** JoinTable gameType. */
            public gameType: proto.GameType;

            /** JoinTable tableID. */
            public tableID: number;

            /** JoinTable joinType. */
            public joinType: proto.UserRequest.JoinType;

            /**
             * Creates a new JoinTable instance using the specified properties.
             * @param [properties] Properties to set
             * @returns JoinTable instance
             */
            public static create(properties?: proto.Game.IJoinTable): proto.Game.JoinTable;

            /**
             * Encodes the specified JoinTable message. Does not implicitly {@link proto.Game.JoinTable.verify|verify} messages.
             * @param message JoinTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IJoinTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified JoinTable message, length delimited. Does not implicitly {@link proto.Game.JoinTable.verify|verify} messages.
             * @param message JoinTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IJoinTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a JoinTable message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns JoinTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.JoinTable;

            /**
             * Decodes a JoinTable message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns JoinTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.JoinTable;

            /**
             * Verifies a JoinTable message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a JoinTable message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns JoinTable
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.JoinTable;

            /**
             * Creates a plain object from a JoinTable message. Also converts values to other types if specified.
             * @param message JoinTable
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.JoinTable, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this JoinTable to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a LeaveTable. */
        interface ILeaveTable {

            /** LeaveTable tableID */
            tableID?: (number|null);

            /** LeaveTable gameType */
            gameType?: (proto.GameType|null);
        }

        /** Represents a LeaveTable. */
        class LeaveTable implements ILeaveTable {

            /**
             * Constructs a new LeaveTable.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ILeaveTable);

            /** LeaveTable tableID. */
            public tableID: number;

            /** LeaveTable gameType. */
            public gameType: proto.GameType;

            /**
             * Creates a new LeaveTable instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LeaveTable instance
             */
            public static create(properties?: proto.Game.ILeaveTable): proto.Game.LeaveTable;

            /**
             * Encodes the specified LeaveTable message. Does not implicitly {@link proto.Game.LeaveTable.verify|verify} messages.
             * @param message LeaveTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ILeaveTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified LeaveTable message, length delimited. Does not implicitly {@link proto.Game.LeaveTable.verify|verify} messages.
             * @param message LeaveTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ILeaveTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a LeaveTable message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LeaveTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.LeaveTable;

            /**
             * Decodes a LeaveTable message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LeaveTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.LeaveTable;

            /**
             * Verifies a LeaveTable message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LeaveTable message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LeaveTable
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.LeaveTable;

            /**
             * Creates a plain object from a LeaveTable message. Also converts values to other types if specified.
             * @param message LeaveTable
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.LeaveTable, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LeaveTable to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a TableBetRecod. */
        interface ITableBetRecod {

            /** TableBetRecod tableId */
            tableId?: (number|null);

            /** TableBetRecod bettingArea */
            bettingArea?: (proto.Game.BettingArea|null);

            /** TableBetRecod betAmount */
            betAmount?: (number|null);

            /** TableBetRecod winLoseAmount */
            winLoseAmount?: (number|null);

            /** TableBetRecod gamerecordId */
            gamerecordId?: (number|Long|null);
        }

        /** Represents a TableBetRecod. */
        class TableBetRecod implements ITableBetRecod {

            /**
             * Constructs a new TableBetRecod.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ITableBetRecod);

            /** TableBetRecod tableId. */
            public tableId: number;

            /** TableBetRecod bettingArea. */
            public bettingArea: proto.Game.BettingArea;

            /** TableBetRecod betAmount. */
            public betAmount: number;

            /** TableBetRecod winLoseAmount. */
            public winLoseAmount: number;

            /** TableBetRecod gamerecordId. */
            public gamerecordId: (number|Long);

            /**
             * Creates a new TableBetRecod instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableBetRecod instance
             */
            public static create(properties?: proto.Game.ITableBetRecod): proto.Game.TableBetRecod;

            /**
             * Encodes the specified TableBetRecod message. Does not implicitly {@link proto.Game.TableBetRecod.verify|verify} messages.
             * @param message TableBetRecod message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ITableBetRecod, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified TableBetRecod message, length delimited. Does not implicitly {@link proto.Game.TableBetRecod.verify|verify} messages.
             * @param message TableBetRecod message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ITableBetRecod, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a TableBetRecod message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableBetRecod
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.TableBetRecod;

            /**
             * Decodes a TableBetRecod message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableBetRecod
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.TableBetRecod;

            /**
             * Verifies a TableBetRecod message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableBetRecod message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableBetRecod
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.TableBetRecod;

            /**
             * Creates a plain object from a TableBetRecod message. Also converts values to other types if specified.
             * @param message TableBetRecod
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.TableBetRecod, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableBetRecod to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of an EnterChainTable. */
        interface IEnterChainTable {

            /** EnterChainTable code */
            code?: (proto.CommonReply.Code|null);

            /** EnterChainTable msg */
            msg?: (string|null);

            /** EnterChainTable tableBetRecods */
            tableBetRecods?: (proto.Game.ITableBetRecod[]|null);

            /** EnterChainTable tableIds */
            tableIds?: (number[]|null);
        }

        /** Represents an EnterChainTable. */
        class EnterChainTable implements IEnterChainTable {

            /**
             * Constructs a new EnterChainTable.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IEnterChainTable);

            /** EnterChainTable code. */
            public code: proto.CommonReply.Code;

            /** EnterChainTable msg. */
            public msg: string;

            /** EnterChainTable tableBetRecods. */
            public tableBetRecods: proto.Game.ITableBetRecod[];

            /** EnterChainTable tableIds. */
            public tableIds: number[];

            /**
             * Creates a new EnterChainTable instance using the specified properties.
             * @param [properties] Properties to set
             * @returns EnterChainTable instance
             */
            public static create(properties?: proto.Game.IEnterChainTable): proto.Game.EnterChainTable;

            /**
             * Encodes the specified EnterChainTable message. Does not implicitly {@link proto.Game.EnterChainTable.verify|verify} messages.
             * @param message EnterChainTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IEnterChainTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified EnterChainTable message, length delimited. Does not implicitly {@link proto.Game.EnterChainTable.verify|verify} messages.
             * @param message EnterChainTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IEnterChainTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes an EnterChainTable message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns EnterChainTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.EnterChainTable;

            /**
             * Decodes an EnterChainTable message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns EnterChainTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.EnterChainTable;

            /**
             * Verifies an EnterChainTable message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an EnterChainTable message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns EnterChainTable
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.EnterChainTable;

            /**
             * Creates a plain object from an EnterChainTable message. Also converts values to other types if specified.
             * @param message EnterChainTable
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.EnterChainTable, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this EnterChainTable to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a RoundCount. */
        interface IRoundCount {

            /** RoundCount tableBetRecods */
            tableBetRecods?: (proto.Game.ITableBetRecod[]|null);
        }

        /** Represents a RoundCount. */
        class RoundCount implements IRoundCount {

            /**
             * Constructs a new RoundCount.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IRoundCount);

            /** RoundCount tableBetRecods. */
            public tableBetRecods: proto.Game.ITableBetRecod[];

            /**
             * Creates a new RoundCount instance using the specified properties.
             * @param [properties] Properties to set
             * @returns RoundCount instance
             */
            public static create(properties?: proto.Game.IRoundCount): proto.Game.RoundCount;

            /**
             * Encodes the specified RoundCount message. Does not implicitly {@link proto.Game.RoundCount.verify|verify} messages.
             * @param message RoundCount message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IRoundCount, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified RoundCount message, length delimited. Does not implicitly {@link proto.Game.RoundCount.verify|verify} messages.
             * @param message RoundCount message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IRoundCount, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a RoundCount message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns RoundCount
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.RoundCount;

            /**
             * Decodes a RoundCount message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns RoundCount
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.RoundCount;

            /**
             * Verifies a RoundCount message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a RoundCount message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns RoundCount
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.RoundCount;

            /**
             * Creates a plain object from a RoundCount message. Also converts values to other types if specified.
             * @param message RoundCount
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.RoundCount, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this RoundCount to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a Bet. */
        interface IBet {

            /** Bet tableID */
            tableID?: (number|null);

            /** Bet subtype */
            subtype?: (proto.Game.Subtype|null);

            /** Bet detail */
            detail?: ({ [k: string]: number }|null);

            /** Bet selectedLimit */
            selectedLimit?: (number|null);
        }

        /** Represents a Bet. */
        class Bet implements IBet {

            /**
             * Constructs a new Bet.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IBet);

            /** Bet tableID. */
            public tableID: number;

            /** Bet subtype. */
            public subtype: proto.Game.Subtype;

            /** Bet detail. */
            public detail: { [k: string]: number };

            /** Bet selectedLimit. */
            public selectedLimit: number;

            /**
             * Creates a new Bet instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Bet instance
             */
            public static create(properties?: proto.Game.IBet): proto.Game.Bet;

            /**
             * Encodes the specified Bet message. Does not implicitly {@link proto.Game.Bet.verify|verify} messages.
             * @param message Bet message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IBet, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified Bet message, length delimited. Does not implicitly {@link proto.Game.Bet.verify|verify} messages.
             * @param message Bet message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IBet, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a Bet message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Bet
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.Bet;

            /**
             * Decodes a Bet message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Bet
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.Bet;

            /**
             * Verifies a Bet message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Bet message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Bet
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.Bet;

            /**
             * Creates a plain object from a Bet message. Also converts values to other types if specified.
             * @param message Bet
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.Bet, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Bet to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a Tip. */
        interface ITip {

            /** Tip tableID */
            tableID?: (number|null);

            /** Tip type */
            type?: (number|null);

            /** Tip amount */
            amount?: (number|null);
        }

        /** Represents a Tip. */
        class Tip implements ITip {

            /**
             * Constructs a new Tip.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ITip);

            /** Tip tableID. */
            public tableID: number;

            /** Tip type. */
            public type: number;

            /** Tip amount. */
            public amount: number;

            /**
             * Creates a new Tip instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Tip instance
             */
            public static create(properties?: proto.Game.ITip): proto.Game.Tip;

            /**
             * Encodes the specified Tip message. Does not implicitly {@link proto.Game.Tip.verify|verify} messages.
             * @param message Tip message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ITip, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified Tip message, length delimited. Does not implicitly {@link proto.Game.Tip.verify|verify} messages.
             * @param message Tip message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ITip, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a Tip message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Tip
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.Tip;

            /**
             * Decodes a Tip message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Tip
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.Tip;

            /**
             * Verifies a Tip message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Tip message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Tip
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.Tip;

            /**
             * Creates a plain object from a Tip message. Also converts values to other types if specified.
             * @param message Tip
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.Tip, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Tip to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a UserSnapshot. */
        interface IUserSnapshot {

            /** UserSnapshot name */
            name?: (string|null);

            /** UserSnapshot balance */
            balance?: (number|null);

            /** UserSnapshot home */
            home?: (number|null);

            /** UserSnapshot vtable */
            vtable?: (number|null);

            /** UserSnapshot vseat */
            vseat?: (number|null);

            /** UserSnapshot winlose */
            winlose?: (number|null);

            /** UserSnapshot totalbet */
            totalbet?: (number|null);

            /** UserSnapshot betinfo */
            betinfo?: ({ [k: string]: number }|null);

            /** UserSnapshot avatar */
            avatar?: (number|null);
        }

        /** Represents a UserSnapshot. */
        class UserSnapshot implements IUserSnapshot {

            /**
             * Constructs a new UserSnapshot.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IUserSnapshot);

            /** UserSnapshot name. */
            public name: string;

            /** UserSnapshot balance. */
            public balance: number;

            /** UserSnapshot home. */
            public home: number;

            /** UserSnapshot vtable. */
            public vtable: number;

            /** UserSnapshot vseat. */
            public vseat: number;

            /** UserSnapshot winlose. */
            public winlose: number;

            /** UserSnapshot totalbet. */
            public totalbet: number;

            /** UserSnapshot betinfo. */
            public betinfo: { [k: string]: number };

            /** UserSnapshot avatar. */
            public avatar: number;

            /**
             * Creates a new UserSnapshot instance using the specified properties.
             * @param [properties] Properties to set
             * @returns UserSnapshot instance
             */
            public static create(properties?: proto.Game.IUserSnapshot): proto.Game.UserSnapshot;

            /**
             * Encodes the specified UserSnapshot message. Does not implicitly {@link proto.Game.UserSnapshot.verify|verify} messages.
             * @param message UserSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IUserSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified UserSnapshot message, length delimited. Does not implicitly {@link proto.Game.UserSnapshot.verify|verify} messages.
             * @param message UserSnapshot message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IUserSnapshot, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a UserSnapshot message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns UserSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.UserSnapshot;

            /**
             * Decodes a UserSnapshot message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns UserSnapshot
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.UserSnapshot;

            /**
             * Verifies a UserSnapshot message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a UserSnapshot message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns UserSnapshot
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.UserSnapshot;

            /**
             * Creates a plain object from a UserSnapshot message. Also converts values to other types if specified.
             * @param message UserSnapshot
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.UserSnapshot, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this UserSnapshot to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a BetInfo. */
        interface IBetInfo {

            /** BetInfo amount */
            amount?: (number|null);

            /** BetInfo player_count */
            player_count?: (number|null);
        }

        /** Represents a BetInfo. */
        class BetInfo implements IBetInfo {

            /**
             * Constructs a new BetInfo.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IBetInfo);

            /** BetInfo amount. */
            public amount: number;

            /** BetInfo player_count. */
            public player_count: number;

            /**
             * Creates a new BetInfo instance using the specified properties.
             * @param [properties] Properties to set
             * @returns BetInfo instance
             */
            public static create(properties?: proto.Game.IBetInfo): proto.Game.BetInfo;

            /**
             * Encodes the specified BetInfo message. Does not implicitly {@link proto.Game.BetInfo.verify|verify} messages.
             * @param message BetInfo message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IBetInfo, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified BetInfo message, length delimited. Does not implicitly {@link proto.Game.BetInfo.verify|verify} messages.
             * @param message BetInfo message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IBetInfo, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a BetInfo message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns BetInfo
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.BetInfo;

            /**
             * Decodes a BetInfo message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns BetInfo
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.BetInfo;

            /**
             * Verifies a BetInfo message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a BetInfo message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns BetInfo
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.BetInfo;

            /**
             * Creates a plain object from a BetInfo message. Also converts values to other types if specified.
             * @param message BetInfo
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.BetInfo, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this BetInfo to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a TableStatus. */
        interface ITableStatus {

            /** TableStatus tableID */
            tableID?: (number|null);

            /** TableStatus stage */
            stage?: (number|null);

            /** TableStatus inning */
            inning?: (number|null);

            /** TableStatus status */
            status?: (number|null);

            /** TableStatus time */
            time?: (number|null);

            /** TableStatus poker */
            poker?: (string|null);

            /**
             * 结果
             * =========百家乐========
             * a 庄赢(ASCII 97) | b 庄赢，闲对(ASCII 98) | c 庄赢，庄对(ASCII 99) | d 庄赢，闲对，庄对(ASCII 100)
             * e 闲赢(ASCII 101) | f 闲赢，闲对(ASCII 102) | g 闲赢，庄对(ASCII 103) | h闲赢，闲对，庄对(ASCII 104)
             * i 和(ASCII 105) | j 和，闲对(ASCII 106) | k 和，庄对(ASCII 107) | l 和，闲对，庄对(ASCII 108)
             *
             * =========龙虎==========
             * a龙
             * e虎
             * i和
             *
             * =========轮盘=========
             * 就是一个数字，开多少就是多少
             *
             *
             * =========轮盘=========
             * 也是是一个数字，分别代表三个筛子开了多少
             */
            result?: (string|null);

            /** TableStatus betinfo */
            betinfo?: ({ [k: string]: proto.Game.IBetInfo }|null);

            /** TableStatus winlose */
            winlose?: (number|null);

            /** TableStatus pokerIndex */
            pokerIndex?: (number|null);

            /** TableStatus gamerecordId */
            gamerecordId?: (number|Long|null);
        }

        /** Represents a TableStatus. */
        class TableStatus implements ITableStatus {

            /**
             * Constructs a new TableStatus.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ITableStatus);

            /** TableStatus tableID. */
            public tableID: number;

            /** TableStatus stage. */
            public stage: number;

            /** TableStatus inning. */
            public inning: number;

            /** TableStatus status. */
            public status: number;

            /** TableStatus time. */
            public time: number;

            /** TableStatus poker. */
            public poker: string;

            /**
             * 结果
             * =========百家乐========
             * a 庄赢(ASCII 97) | b 庄赢，闲对(ASCII 98) | c 庄赢，庄对(ASCII 99) | d 庄赢，闲对，庄对(ASCII 100)
             * e 闲赢(ASCII 101) | f 闲赢，闲对(ASCII 102) | g 闲赢，庄对(ASCII 103) | h闲赢，闲对，庄对(ASCII 104)
             * i 和(ASCII 105) | j 和，闲对(ASCII 106) | k 和，庄对(ASCII 107) | l 和，闲对，庄对(ASCII 108)
             *
             * =========龙虎==========
             * a龙
             * e虎
             * i和
             *
             * =========轮盘=========
             * 就是一个数字，开多少就是多少
             *
             *
             * =========轮盘=========
             * 也是是一个数字，分别代表三个筛子开了多少
             */
            public result: string;

            /** TableStatus betinfo. */
            public betinfo: { [k: string]: proto.Game.IBetInfo };

            /** TableStatus winlose. */
            public winlose: number;

            /** TableStatus pokerIndex. */
            public pokerIndex: number;

            /** TableStatus gamerecordId. */
            public gamerecordId: (number|Long);

            /**
             * Creates a new TableStatus instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableStatus instance
             */
            public static create(properties?: proto.Game.ITableStatus): proto.Game.TableStatus;

            /**
             * Encodes the specified TableStatus message. Does not implicitly {@link proto.Game.TableStatus.verify|verify} messages.
             * @param message TableStatus message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ITableStatus, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified TableStatus message, length delimited. Does not implicitly {@link proto.Game.TableStatus.verify|verify} messages.
             * @param message TableStatus message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ITableStatus, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a TableStatus message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableStatus
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.TableStatus;

            /**
             * Decodes a TableStatus message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableStatus
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.TableStatus;

            /**
             * Verifies a TableStatus message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableStatus message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableStatus
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.TableStatus;

            /**
             * Creates a plain object from a TableStatus message. Also converts values to other types if specified.
             * @param message TableStatus
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.TableStatus, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableStatus to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a TableConfig. */
        interface ITableConfig {

            /** TableConfig tableID */
            tableID?: (number|null);

            /** TableConfig time */
            time?: (number|null);

            /** TableConfig name */
            name?: (string|null);

            /** TableConfig dealer */
            dealer?: (string|null);

            /** TableConfig date */
            date?: (string|null);

            /** TableConfig limit */
            limit?: (string|null);

            /** TableConfig tvName */
            tvName?: (string|null);

            /** TableConfig dealerImage */
            dealerImage?: (string|null);
        }

        /** Represents a TableConfig. */
        class TableConfig implements ITableConfig {

            /**
             * Constructs a new TableConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ITableConfig);

            /** TableConfig tableID. */
            public tableID: number;

            /** TableConfig time. */
            public time: number;

            /** TableConfig name. */
            public name: string;

            /** TableConfig dealer. */
            public dealer: string;

            /** TableConfig date. */
            public date: string;

            /** TableConfig limit. */
            public limit: string;

            /** TableConfig tvName. */
            public tvName: string;

            /** TableConfig dealerImage. */
            public dealerImage: string;

            /**
             * Creates a new TableConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableConfig instance
             */
            public static create(properties?: proto.Game.ITableConfig): proto.Game.TableConfig;

            /**
             * Encodes the specified TableConfig message. Does not implicitly {@link proto.Game.TableConfig.verify|verify} messages.
             * @param message TableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ITableConfig, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified TableConfig message, length delimited. Does not implicitly {@link proto.Game.TableConfig.verify|verify} messages.
             * @param message TableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ITableConfig, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a TableConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.TableConfig;

            /**
             * Decodes a TableConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.TableConfig;

            /**
             * Verifies a TableConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableConfig
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.TableConfig;

            /**
             * Creates a plain object from a TableConfig message. Also converts values to other types if specified.
             * @param message TableConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.TableConfig, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a TableHistory. */
        interface ITableHistory {

            /** TableHistory tableID */
            tableID?: (number|null);

            /** TableHistory way */
            way?: (string|null);

            /** TableHistory counts */
            counts?: (string|null);

            /** TableHistory poker */
            poker?: (string|null);
        }

        /** Represents a TableHistory. */
        class TableHistory implements ITableHistory {

            /**
             * Constructs a new TableHistory.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.ITableHistory);

            /** TableHistory tableID. */
            public tableID: number;

            /** TableHistory way. */
            public way: string;

            /** TableHistory counts. */
            public counts: string;

            /** TableHistory poker. */
            public poker: string;

            /**
             * Creates a new TableHistory instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableHistory instance
             */
            public static create(properties?: proto.Game.ITableHistory): proto.Game.TableHistory;

            /**
             * Encodes the specified TableHistory message. Does not implicitly {@link proto.Game.TableHistory.verify|verify} messages.
             * @param message TableHistory message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.ITableHistory, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified TableHistory message, length delimited. Does not implicitly {@link proto.Game.TableHistory.verify|verify} messages.
             * @param message TableHistory message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.ITableHistory, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a TableHistory message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableHistory
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.TableHistory;

            /**
             * Decodes a TableHistory message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableHistory
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.TableHistory;

            /**
             * Verifies a TableHistory message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableHistory message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableHistory
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.TableHistory;

            /**
             * Creates a plain object from a TableHistory message. Also converts values to other types if specified.
             * @param message TableHistory
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.TableHistory, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableHistory to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a VirtualTable. */
        interface IVirtualTable {
        }

        /** Represents a VirtualTable. */
        class VirtualTable implements IVirtualTable {

            /**
             * Constructs a new VirtualTable.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Game.IVirtualTable);

            /**
             * Creates a new VirtualTable instance using the specified properties.
             * @param [properties] Properties to set
             * @returns VirtualTable instance
             */
            public static create(properties?: proto.Game.IVirtualTable): proto.Game.VirtualTable;

            /**
             * Encodes the specified VirtualTable message. Does not implicitly {@link proto.Game.VirtualTable.verify|verify} messages.
             * @param message VirtualTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Game.IVirtualTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified VirtualTable message, length delimited. Does not implicitly {@link proto.Game.VirtualTable.verify|verify} messages.
             * @param message VirtualTable message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Game.IVirtualTable, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a VirtualTable message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns VirtualTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.VirtualTable;

            /**
             * Decodes a VirtualTable message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns VirtualTable
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.VirtualTable;

            /**
             * Verifies a VirtualTable message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a VirtualTable message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns VirtualTable
             */
            public static fromObject(object: { [k: string]: any }): proto.Game.VirtualTable;

            /**
             * Creates a plain object from a VirtualTable message. Also converts values to other types if specified.
             * @param message VirtualTable
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Game.VirtualTable, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this VirtualTable to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        namespace VirtualTable {

            /** Properties of a Seat. */
            interface ISeat {

                /** Seat uname */
                uname?: (string|null);

                /** Seat uid */
                uid?: (number|Long|null);

                /** Seat balance */
                balance?: (number|null);

                /** Seat avatar */
                avatar?: (number|null);

                /** Seat betinfo */
                betinfo?: ({ [k: string]: number }|null);

                /** Seat seatID */
                seatID?: (number|null);

                /** Seat isSeat */
                isSeat?: (boolean|null);
            }

            /** Represents a Seat. */
            class Seat implements ISeat {

                /**
                 * Constructs a new Seat.
                 * @param [properties] Properties to set
                 */
                constructor(properties?: proto.Game.VirtualTable.ISeat);

                /** Seat uname. */
                public uname: string;

                /** Seat uid. */
                public uid: (number|Long);

                /** Seat balance. */
                public balance: number;

                /** Seat avatar. */
                public avatar: number;

                /** Seat betinfo. */
                public betinfo: { [k: string]: number };

                /** Seat seatID. */
                public seatID: number;

                /** Seat isSeat. */
                public isSeat: boolean;

                /**
                 * Creates a new Seat instance using the specified properties.
                 * @param [properties] Properties to set
                 * @returns Seat instance
                 */
                public static create(properties?: proto.Game.VirtualTable.ISeat): proto.Game.VirtualTable.Seat;

                /**
                 * Encodes the specified Seat message. Does not implicitly {@link proto.Game.VirtualTable.Seat.verify|verify} messages.
                 * @param message Seat message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encode(message: proto.Game.VirtualTable.ISeat, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Encodes the specified Seat message, length delimited. Does not implicitly {@link proto.Game.VirtualTable.Seat.verify|verify} messages.
                 * @param message Seat message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encodeDelimited(message: proto.Game.VirtualTable.ISeat, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Decodes a Seat message from the specified reader or buffer.
                 * @param reader Reader or buffer to decode from
                 * @param [length] Message length if known beforehand
                 * @returns Seat
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.VirtualTable.Seat;

                /**
                 * Decodes a Seat message from the specified reader or buffer, length delimited.
                 * @param reader Reader or buffer to decode from
                 * @returns Seat
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.VirtualTable.Seat;

                /**
                 * Verifies a Seat message.
                 * @param message Plain object to verify
                 * @returns `null` if valid, otherwise the reason why it is not
                 */
                public static verify(message: { [k: string]: any }): (string|null);

                /**
                 * Creates a Seat message from a plain object. Also converts values to their respective internal types.
                 * @param object Plain object
                 * @returns Seat
                 */
                public static fromObject(object: { [k: string]: any }): proto.Game.VirtualTable.Seat;

                /**
                 * Creates a plain object from a Seat message. Also converts values to other types if specified.
                 * @param message Seat
                 * @param [options] Conversion options
                 * @returns Plain object
                 */
                public static toObject(message: proto.Game.VirtualTable.Seat, options?: protobuf.IConversionOptions): { [k: string]: any };

                /**
                 * Converts this Seat to JSON.
                 * @returns JSON object
                 */
                public toJSON(): { [k: string]: any };
            }

            /** Properties of a Table. */
            interface ITable {

                /** Table tableID */
                tableID?: (number|null);

                /** Table maxSeatNum */
                maxSeatNum?: (number|null);

                /** Table seats */
                seats?: ({ [k: string]: proto.Game.VirtualTable.ISeat }|null);
            }

            /** Represents a Table. */
            class Table implements ITable {

                /**
                 * Constructs a new Table.
                 * @param [properties] Properties to set
                 */
                constructor(properties?: proto.Game.VirtualTable.ITable);

                /** Table tableID. */
                public tableID: number;

                /** Table maxSeatNum. */
                public maxSeatNum: number;

                /** Table seats. */
                public seats: { [k: string]: proto.Game.VirtualTable.ISeat };

                /**
                 * Creates a new Table instance using the specified properties.
                 * @param [properties] Properties to set
                 * @returns Table instance
                 */
                public static create(properties?: proto.Game.VirtualTable.ITable): proto.Game.VirtualTable.Table;

                /**
                 * Encodes the specified Table message. Does not implicitly {@link proto.Game.VirtualTable.Table.verify|verify} messages.
                 * @param message Table message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encode(message: proto.Game.VirtualTable.ITable, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Encodes the specified Table message, length delimited. Does not implicitly {@link proto.Game.VirtualTable.Table.verify|verify} messages.
                 * @param message Table message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encodeDelimited(message: proto.Game.VirtualTable.ITable, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Decodes a Table message from the specified reader or buffer.
                 * @param reader Reader or buffer to decode from
                 * @param [length] Message length if known beforehand
                 * @returns Table
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.VirtualTable.Table;

                /**
                 * Decodes a Table message from the specified reader or buffer, length delimited.
                 * @param reader Reader or buffer to decode from
                 * @returns Table
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.VirtualTable.Table;

                /**
                 * Verifies a Table message.
                 * @param message Plain object to verify
                 * @returns `null` if valid, otherwise the reason why it is not
                 */
                public static verify(message: { [k: string]: any }): (string|null);

                /**
                 * Creates a Table message from a plain object. Also converts values to their respective internal types.
                 * @param object Plain object
                 * @returns Table
                 */
                public static fromObject(object: { [k: string]: any }): proto.Game.VirtualTable.Table;

                /**
                 * Creates a plain object from a Table message. Also converts values to other types if specified.
                 * @param message Table
                 * @param [options] Conversion options
                 * @returns Plain object
                 */
                public static toObject(message: proto.Game.VirtualTable.Table, options?: protobuf.IConversionOptions): { [k: string]: any };

                /**
                 * Converts this Table to JSON.
                 * @returns JSON object
                 */
                public toJSON(): { [k: string]: any };
            }

            /** Properties of a Bet. */
            interface IBet {

                /** Bet tableID */
                tableID?: (number|null);

                /** Bet seatID */
                seatID?: (number|null);

                /** Bet balance */
                balance?: (number|null);

                /** Bet betinfo */
                betinfo?: ({ [k: string]: number }|null);
            }

            /** Represents a Bet. */
            class Bet implements IBet {

                /**
                 * Constructs a new Bet.
                 * @param [properties] Properties to set
                 */
                constructor(properties?: proto.Game.VirtualTable.IBet);

                /** Bet tableID. */
                public tableID: number;

                /** Bet seatID. */
                public seatID: number;

                /** Bet balance. */
                public balance: number;

                /** Bet betinfo. */
                public betinfo: { [k: string]: number };

                /**
                 * Creates a new Bet instance using the specified properties.
                 * @param [properties] Properties to set
                 * @returns Bet instance
                 */
                public static create(properties?: proto.Game.VirtualTable.IBet): proto.Game.VirtualTable.Bet;

                /**
                 * Encodes the specified Bet message. Does not implicitly {@link proto.Game.VirtualTable.Bet.verify|verify} messages.
                 * @param message Bet message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encode(message: proto.Game.VirtualTable.IBet, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Encodes the specified Bet message, length delimited. Does not implicitly {@link proto.Game.VirtualTable.Bet.verify|verify} messages.
                 * @param message Bet message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encodeDelimited(message: proto.Game.VirtualTable.IBet, writer?: protobuf.Writer): protobuf.Writer;

                /**
                 * Decodes a Bet message from the specified reader or buffer.
                 * @param reader Reader or buffer to decode from
                 * @param [length] Message length if known beforehand
                 * @returns Bet
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Game.VirtualTable.Bet;

                /**
                 * Decodes a Bet message from the specified reader or buffer, length delimited.
                 * @param reader Reader or buffer to decode from
                 * @returns Bet
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Game.VirtualTable.Bet;

                /**
                 * Verifies a Bet message.
                 * @param message Plain object to verify
                 * @returns `null` if valid, otherwise the reason why it is not
                 */
                public static verify(message: { [k: string]: any }): (string|null);

                /**
                 * Creates a Bet message from a plain object. Also converts values to their respective internal types.
                 * @param object Plain object
                 * @returns Bet
                 */
                public static fromObject(object: { [k: string]: any }): proto.Game.VirtualTable.Bet;

                /**
                 * Creates a plain object from a Bet message. Also converts values to other types if specified.
                 * @param message Bet
                 * @param [options] Conversion options
                 * @returns Plain object
                 */
                public static toObject(message: proto.Game.VirtualTable.Bet, options?: protobuf.IConversionOptions): { [k: string]: any };

                /**
                 * Converts this Bet to JSON.
                 * @returns JSON object
                 */
                public toJSON(): { [k: string]: any };
            }
        }
    }

    /** Properties of a Report. */
    interface IReport {
    }

    /** Represents a Report. */
    class Report implements IReport {

        /**
         * Constructs a new Report.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IReport);

        /**
         * Creates a new Report instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Report instance
         */
        public static create(properties?: proto.IReport): proto.Report;

        /**
         * Encodes the specified Report message. Does not implicitly {@link proto.Report.verify|verify} messages.
         * @param message Report message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IReport, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Report message, length delimited. Does not implicitly {@link proto.Report.verify|verify} messages.
         * @param message Report message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IReport, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a Report message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Report
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Report;

        /**
         * Decodes a Report message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Report
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Report;

        /**
         * Verifies a Report message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Report message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Report
         */
        public static fromObject(object: { [k: string]: any }): proto.Report;

        /**
         * Creates a plain object from a Report message. Also converts values to other types if specified.
         * @param message Report
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Report, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Report to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace Report {

        /** Properties of a GameResult. */
        interface IGameResult {

            /** GameResult starttime */
            starttime?: (number|Long|null);

            /** GameResult endtime */
            endtime?: (number|Long|null);

            /** GameResult gameType */
            gameType?: (number|null);

            /** GameResult tableID */
            tableID?: (number|null);

            /** GameResult shoe */
            shoe?: (number|null);

            /** GameResult pageSize */
            pageSize?: (number|null);

            /** GameResult pageIndex */
            pageIndex?: (number|null);
        }

        /** Represents a GameResult. */
        class GameResult implements IGameResult {

            /**
             * Constructs a new GameResult.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Report.IGameResult);

            /** GameResult starttime. */
            public starttime: (number|Long);

            /** GameResult endtime. */
            public endtime: (number|Long);

            /** GameResult gameType. */
            public gameType: number;

            /** GameResult tableID. */
            public tableID: number;

            /** GameResult shoe. */
            public shoe: number;

            /** GameResult pageSize. */
            public pageSize: number;

            /** GameResult pageIndex. */
            public pageIndex: number;

            /**
             * Creates a new GameResult instance using the specified properties.
             * @param [properties] Properties to set
             * @returns GameResult instance
             */
            public static create(properties?: proto.Report.IGameResult): proto.Report.GameResult;

            /**
             * Encodes the specified GameResult message. Does not implicitly {@link proto.Report.GameResult.verify|verify} messages.
             * @param message GameResult message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Report.IGameResult, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified GameResult message, length delimited. Does not implicitly {@link proto.Report.GameResult.verify|verify} messages.
             * @param message GameResult message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Report.IGameResult, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a GameResult message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns GameResult
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Report.GameResult;

            /**
             * Decodes a GameResult message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns GameResult
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Report.GameResult;

            /**
             * Verifies a GameResult message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a GameResult message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns GameResult
             */
            public static fromObject(object: { [k: string]: any }): proto.Report.GameResult;

            /**
             * Creates a plain object from a GameResult message. Also converts values to other types if specified.
             * @param message GameResult
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Report.GameResult, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this GameResult to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a GameResultReply. */
        interface IGameResultReply {

            /** GameResultReply code */
            code?: (proto.CommonReply.Code|null);

            /** GameResultReply totalCount */
            totalCount?: (number|null);

            /** GameResultReply results */
            results?: (string|null);
        }

        /** Represents a GameResultReply. */
        class GameResultReply implements IGameResultReply {

            /**
             * Constructs a new GameResultReply.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Report.IGameResultReply);

            /** GameResultReply code. */
            public code: proto.CommonReply.Code;

            /** GameResultReply totalCount. */
            public totalCount: number;

            /** GameResultReply results. */
            public results: string;

            /**
             * Creates a new GameResultReply instance using the specified properties.
             * @param [properties] Properties to set
             * @returns GameResultReply instance
             */
            public static create(properties?: proto.Report.IGameResultReply): proto.Report.GameResultReply;

            /**
             * Encodes the specified GameResultReply message. Does not implicitly {@link proto.Report.GameResultReply.verify|verify} messages.
             * @param message GameResultReply message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Report.IGameResultReply, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified GameResultReply message, length delimited. Does not implicitly {@link proto.Report.GameResultReply.verify|verify} messages.
             * @param message GameResultReply message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Report.IGameResultReply, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a GameResultReply message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns GameResultReply
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Report.GameResultReply;

            /**
             * Decodes a GameResultReply message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns GameResultReply
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Report.GameResultReply;

            /**
             * Verifies a GameResultReply message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a GameResultReply message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns GameResultReply
             */
            public static fromObject(object: { [k: string]: any }): proto.Report.GameResultReply;

            /**
             * Creates a plain object from a GameResultReply message. Also converts values to other types if specified.
             * @param message GameResultReply
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Report.GameResultReply, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this GameResultReply to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a WinLose. */
        interface IWinLose {

            /** WinLose starttime */
            starttime?: (number|Long|null);

            /** WinLose endtime */
            endtime?: (number|Long|null);
        }

        /** Represents a WinLose. */
        class WinLose implements IWinLose {

            /**
             * Constructs a new WinLose.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Report.IWinLose);

            /** WinLose starttime. */
            public starttime: (number|Long);

            /** WinLose endtime. */
            public endtime: (number|Long);

            /**
             * Creates a new WinLose instance using the specified properties.
             * @param [properties] Properties to set
             * @returns WinLose instance
             */
            public static create(properties?: proto.Report.IWinLose): proto.Report.WinLose;

            /**
             * Encodes the specified WinLose message. Does not implicitly {@link proto.Report.WinLose.verify|verify} messages.
             * @param message WinLose message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Report.IWinLose, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified WinLose message, length delimited. Does not implicitly {@link proto.Report.WinLose.verify|verify} messages.
             * @param message WinLose message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Report.IWinLose, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a WinLose message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns WinLose
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Report.WinLose;

            /**
             * Decodes a WinLose message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns WinLose
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Report.WinLose;

            /**
             * Verifies a WinLose message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a WinLose message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns WinLose
             */
            public static fromObject(object: { [k: string]: any }): proto.Report.WinLose;

            /**
             * Creates a plain object from a WinLose message. Also converts values to other types if specified.
             * @param message WinLose
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Report.WinLose, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this WinLose to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a WinLoseReply. */
        interface IWinLoseReply {

            /** WinLoseReply code */
            code?: (proto.CommonReply.Code|null);

            /** WinLoseReply winlose */
            winlose?: (number|null);

            /** WinLoseReply rnikAmount */
            rnikAmount?: (number|null);
        }

        /** Represents a WinLoseReply. */
        class WinLoseReply implements IWinLoseReply {

            /**
             * Constructs a new WinLoseReply.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Report.IWinLoseReply);

            /** WinLoseReply code. */
            public code: proto.CommonReply.Code;

            /** WinLoseReply winlose. */
            public winlose: number;

            /** WinLoseReply rnikAmount. */
            public rnikAmount: number;

            /**
             * Creates a new WinLoseReply instance using the specified properties.
             * @param [properties] Properties to set
             * @returns WinLoseReply instance
             */
            public static create(properties?: proto.Report.IWinLoseReply): proto.Report.WinLoseReply;

            /**
             * Encodes the specified WinLoseReply message. Does not implicitly {@link proto.Report.WinLoseReply.verify|verify} messages.
             * @param message WinLoseReply message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Report.IWinLoseReply, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified WinLoseReply message, length delimited. Does not implicitly {@link proto.Report.WinLoseReply.verify|verify} messages.
             * @param message WinLoseReply message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Report.IWinLoseReply, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a WinLoseReply message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns WinLoseReply
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Report.WinLoseReply;

            /**
             * Decodes a WinLoseReply message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns WinLoseReply
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Report.WinLoseReply;

            /**
             * Verifies a WinLoseReply message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a WinLoseReply message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns WinLoseReply
             */
            public static fromObject(object: { [k: string]: any }): proto.Report.WinLoseReply;

            /**
             * Creates a plain object from a WinLoseReply message. Also converts values to other types if specified.
             * @param message WinLoseReply
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Report.WinLoseReply, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this WinLoseReply to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }
    }

    /** Properties of a Chat. */
    interface IChat {
    }

    /** Represents a Chat. */
    class Chat implements IChat {

        /**
         * Constructs a new Chat.
         * @param [properties] Properties to set
         */
        constructor(properties?: proto.IChat);

        /**
         * Creates a new Chat instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Chat instance
         */
        public static create(properties?: proto.IChat): proto.Chat;

        /**
         * Encodes the specified Chat message. Does not implicitly {@link proto.Chat.verify|verify} messages.
         * @param message Chat message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: proto.IChat, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Encodes the specified Chat message, length delimited. Does not implicitly {@link proto.Chat.verify|verify} messages.
         * @param message Chat message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: proto.IChat, writer?: protobuf.Writer): protobuf.Writer;

        /**
         * Decodes a Chat message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Chat
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat;

        /**
         * Decodes a Chat message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Chat
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat;

        /**
         * Verifies a Chat message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Chat message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Chat
         */
        public static fromObject(object: { [k: string]: any }): proto.Chat;

        /**
         * Creates a plain object from a Chat message. Also converts values to other types if specified.
         * @param message Chat
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: proto.Chat, options?: protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Chat to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    namespace Chat {

        /** Properties of a ChatReq. */
        interface IChatReq {

            /** ChatReq tableId */
            tableId?: (number|null);

            /** ChatReq message */
            message?: (string|null);
        }

        /** Represents a ChatReq. */
        class ChatReq implements IChatReq {

            /**
             * Constructs a new ChatReq.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Chat.IChatReq);

            /** ChatReq tableId. */
            public tableId: number;

            /** ChatReq message. */
            public message: string;

            /**
             * Creates a new ChatReq instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChatReq instance
             */
            public static create(properties?: proto.Chat.IChatReq): proto.Chat.ChatReq;

            /**
             * Encodes the specified ChatReq message. Does not implicitly {@link proto.Chat.ChatReq.verify|verify} messages.
             * @param message ChatReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Chat.IChatReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChatReq message, length delimited. Does not implicitly {@link proto.Chat.ChatReq.verify|verify} messages.
             * @param message ChatReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Chat.IChatReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChatReq message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChatReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat.ChatReq;

            /**
             * Decodes a ChatReq message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChatReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat.ChatReq;

            /**
             * Verifies a ChatReq message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChatReq message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChatReq
             */
            public static fromObject(object: { [k: string]: any }): proto.Chat.ChatReq;

            /**
             * Creates a plain object from a ChatReq message. Also converts values to other types if specified.
             * @param message ChatReq
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Chat.ChatReq, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChatReq to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a ChatVOList. */
        interface IChatVOList {

            /** ChatVOList tableId */
            tableId?: (number|null);

            /** ChatVOList chatVOS */
            chatVOS?: (proto.Chat.IChatVO[]|null);
        }

        /** Represents a ChatVOList. */
        class ChatVOList implements IChatVOList {

            /**
             * Constructs a new ChatVOList.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Chat.IChatVOList);

            /** ChatVOList tableId. */
            public tableId: number;

            /** ChatVOList chatVOS. */
            public chatVOS: proto.Chat.IChatVO[];

            /**
             * Creates a new ChatVOList instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChatVOList instance
             */
            public static create(properties?: proto.Chat.IChatVOList): proto.Chat.ChatVOList;

            /**
             * Encodes the specified ChatVOList message. Does not implicitly {@link proto.Chat.ChatVOList.verify|verify} messages.
             * @param message ChatVOList message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Chat.IChatVOList, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChatVOList message, length delimited. Does not implicitly {@link proto.Chat.ChatVOList.verify|verify} messages.
             * @param message ChatVOList message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Chat.IChatVOList, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChatVOList message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChatVOList
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat.ChatVOList;

            /**
             * Decodes a ChatVOList message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChatVOList
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat.ChatVOList;

            /**
             * Verifies a ChatVOList message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChatVOList message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChatVOList
             */
            public static fromObject(object: { [k: string]: any }): proto.Chat.ChatVOList;

            /**
             * Creates a plain object from a ChatVOList message. Also converts values to other types if specified.
             * @param message ChatVOList
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Chat.ChatVOList, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChatVOList to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a ChatVO. */
        interface IChatVO {

            /** ChatVO type */
            type?: (number|null);

            /** ChatVO sender */
            sender?: (string|null);

            /** ChatVO content */
            content?: (string|null);

            /** ChatVO uid */
            uid?: (number|Long|null);
        }

        /** Represents a ChatVO. */
        class ChatVO implements IChatVO {

            /**
             * Constructs a new ChatVO.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Chat.IChatVO);

            /** ChatVO type. */
            public type: number;

            /** ChatVO sender. */
            public sender: string;

            /** ChatVO content. */
            public content: string;

            /** ChatVO uid. */
            public uid: (number|Long);

            /**
             * Creates a new ChatVO instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ChatVO instance
             */
            public static create(properties?: proto.Chat.IChatVO): proto.Chat.ChatVO;

            /**
             * Encodes the specified ChatVO message. Does not implicitly {@link proto.Chat.ChatVO.verify|verify} messages.
             * @param message ChatVO message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Chat.IChatVO, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified ChatVO message, length delimited. Does not implicitly {@link proto.Chat.ChatVO.verify|verify} messages.
             * @param message ChatVO message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Chat.IChatVO, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a ChatVO message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ChatVO
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat.ChatVO;

            /**
             * Decodes a ChatVO message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ChatVO
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat.ChatVO;

            /**
             * Verifies a ChatVO message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ChatVO message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ChatVO
             */
            public static fromObject(object: { [k: string]: any }): proto.Chat.ChatVO;

            /**
             * Creates a plain object from a ChatVO message. Also converts values to other types if specified.
             * @param message ChatVO
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Chat.ChatVO, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ChatVO to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a LoadChatReq. */
        interface ILoadChatReq {

            /** LoadChatReq tableId */
            tableId?: (number|null);
        }

        /** Represents a LoadChatReq. */
        class LoadChatReq implements ILoadChatReq {

            /**
             * Constructs a new LoadChatReq.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Chat.ILoadChatReq);

            /** LoadChatReq tableId. */
            public tableId: number;

            /**
             * Creates a new LoadChatReq instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LoadChatReq instance
             */
            public static create(properties?: proto.Chat.ILoadChatReq): proto.Chat.LoadChatReq;

            /**
             * Encodes the specified LoadChatReq message. Does not implicitly {@link proto.Chat.LoadChatReq.verify|verify} messages.
             * @param message LoadChatReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Chat.ILoadChatReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified LoadChatReq message, length delimited. Does not implicitly {@link proto.Chat.LoadChatReq.verify|verify} messages.
             * @param message LoadChatReq message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Chat.ILoadChatReq, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a LoadChatReq message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LoadChatReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat.LoadChatReq;

            /**
             * Decodes a LoadChatReq message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LoadChatReq
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat.LoadChatReq;

            /**
             * Verifies a LoadChatReq message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LoadChatReq message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LoadChatReq
             */
            public static fromObject(object: { [k: string]: any }): proto.Chat.LoadChatReq;

            /**
             * Creates a plain object from a LoadChatReq message. Also converts values to other types if specified.
             * @param message LoadChatReq
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Chat.LoadChatReq, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LoadChatReq to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }

        /** Properties of a LoadChatResponse. */
        interface ILoadChatResponse {

            /** LoadChatResponse code */
            code?: (proto.CommonReply.Code|null);

            /** LoadChatResponse desc */
            desc?: (string|null);

            /** LoadChatResponse chatVOList */
            chatVOList?: (proto.Chat.IChatVOList|null);
        }

        /** Represents a LoadChatResponse. */
        class LoadChatResponse implements ILoadChatResponse {

            /**
             * Constructs a new LoadChatResponse.
             * @param [properties] Properties to set
             */
            constructor(properties?: proto.Chat.ILoadChatResponse);

            /** LoadChatResponse code. */
            public code: proto.CommonReply.Code;

            /** LoadChatResponse desc. */
            public desc: string;

            /** LoadChatResponse chatVOList. */
            public chatVOList?: (proto.Chat.IChatVOList|null);

            /**
             * Creates a new LoadChatResponse instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LoadChatResponse instance
             */
            public static create(properties?: proto.Chat.ILoadChatResponse): proto.Chat.LoadChatResponse;

            /**
             * Encodes the specified LoadChatResponse message. Does not implicitly {@link proto.Chat.LoadChatResponse.verify|verify} messages.
             * @param message LoadChatResponse message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: proto.Chat.ILoadChatResponse, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Encodes the specified LoadChatResponse message, length delimited. Does not implicitly {@link proto.Chat.LoadChatResponse.verify|verify} messages.
             * @param message LoadChatResponse message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: proto.Chat.ILoadChatResponse, writer?: protobuf.Writer): protobuf.Writer;

            /**
             * Decodes a LoadChatResponse message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LoadChatResponse
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: (protobuf.Reader|Uint8Array), length?: number): proto.Chat.LoadChatResponse;

            /**
             * Decodes a LoadChatResponse message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LoadChatResponse
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: (protobuf.Reader|Uint8Array)): proto.Chat.LoadChatResponse;

            /**
             * Verifies a LoadChatResponse message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LoadChatResponse message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LoadChatResponse
             */
            public static fromObject(object: { [k: string]: any }): proto.Chat.LoadChatResponse;

            /**
             * Creates a plain object from a LoadChatResponse message. Also converts values to other types if specified.
             * @param message LoadChatResponse
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: proto.Chat.LoadChatResponse, options?: protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LoadChatResponse to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };
        }
    }
}
