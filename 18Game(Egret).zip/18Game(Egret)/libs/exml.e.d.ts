declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class AllChipsViewSkin extends eui.Skin{
}
declare class BetAreaViewSkin extends eui.Skin{
}
declare class BetButtonSkin extends eui.Skin{
}
declare class BetInfoViewSkin extends eui.Skin{
}
declare class ChangeTableViewSkin extends eui.Skin{
}
declare class ChipRadioButton extends eui.Skin{
}
declare class ChipsViewSkin extends eui.Skin{
}
declare class ConfirmCancelButtonSkin extends eui.Skin{
}
declare class MobileBaccaratGameSceneSkin extends eui.Skin{
}
declare class MobileBetInfoAndRoadSkin extends eui.Skin{
}
declare class MobileChipsViewSkin extends eui.Skin{
}
declare class MobileOptionViewSkin extends eui.Skin{
}
declare class MobileUserInfoViewSkin extends eui.Skin{
}
declare class OneBaseChipBtnSkin extends eui.Skin{
}
declare class OneChipsBtnSkin extends eui.Skin{
}
declare class OneTableItemSkin extends eui.Skin{
}
declare class OptionBtnSkin extends eui.Skin{
}
declare class OptionViewSkin extends eui.Skin{
}
declare class PcBaccaratGameSceneSkin extends eui.Skin{
}
declare class PokerViewSkin extends eui.Skin{
}
declare class RebetBtnSkin extends eui.Skin{
}
declare class RoadViewSkin extends eui.Skin{
}
declare class StatusViewSkin extends eui.Skin{
}
declare class UserInfoViewSkin extends eui.Skin{
}
declare class UserSeatViewSkin extends eui.Skin{
}
declare class chatSkin extends eui.Skin{
}
declare class ChatItemSkin extends eui.Skin{
}
declare class EmojiItemSkin extends eui.Skin{
}
declare class EmojiViewSkin extends eui.Skin{
}
declare class RewardItemSkin extends eui.Skin{
}
declare module skins{
	class AllRadioBtn extends eui.Skin{
	}
}
declare module skins{
	class BRadioBtn extends eui.Skin{
	}
}
declare module skins{
	class LRadioBtn extends eui.Skin{
	}
}
declare class RecordItemSkin extends eui.Skin{
}
declare class RecordViewSkin extends eui.Skin{
}
declare class RuleViewSkin extends eui.Skin{
}
declare module skins{
	class CloseBtn extends eui.Skin{
	}
}
declare module skins{
	class SetENRadio extends eui.Skin{
	}
}
declare module skins{
	class SettingLangRadio extends eui.Skin{
	}
}
declare module skins{
	class SettingRaio extends eui.Skin{
	}
}
declare class SettingViewSkin extends eui.Skin{
}
declare module skins{
	class SetZHRadio extends eui.Skin{
	}
}
declare class btn_close extends eui.Skin{
}
declare class btn_today extends eui.Skin{
}
declare class DateNext extends eui.Skin{
}
declare class DatePre extends eui.Skin{
}
declare class Dates extends eui.Skin{
}
declare class InputSkin extends eui.Skin{
}
declare class listSkin extends eui.Skin{
}
declare class TimeCompent extends eui.Skin{
}
declare class BaseToastViewSkin extends eui.Skin{
}
declare class ResultToastViewSkinSkin extends eui.Skin{
}
declare class ServerToastViewSkin extends eui.Skin{
}
declare class ADItem extends eui.Skin{
}
declare class ADPageViewSkin extends eui.Skin{
}
declare class ADViewSkin extends eui.Skin{
}
declare module skins{
	class BGameRadio extends eui.Skin{
	}
}
declare module skins{
	class EGameBtn extends eui.Skin{
	}
}
declare module skins{
	class GetVipBtn extends eui.Skin{
	}
}
declare module skins{
	class GetVipBtnM extends eui.Skin{
	}
}
declare module skins{
	class HExitBtn extends eui.Skin{
	}
}
declare module skins{
	class HRuleBtn extends eui.Skin{
	}
}
declare module skins{
	class HSettingBtn extends eui.Skin{
	}
}
declare module skins{
	class HSoundBtn extends eui.Skin{
	}
}
declare module skins{
	class HVideoBtn extends eui.Skin{
	}
}
declare module skins{
	class LGameRadio extends eui.Skin{
	}
}
declare module skins{
	class LimitBtn extends eui.Skin{
	}
}
declare module skins{
	class LimitRadioBtn extends eui.Skin{
	}
}
declare module skins{
	class LoginBtn extends eui.Skin{
	}
}
declare module skins{
	class NewFile extends eui.Skin{
	}
}
declare module skins{
	class RechageBtn extends eui.Skin{
	}
}
declare module skins{
	class RechageBtnM extends eui.Skin{
	}
}
declare module skins{
	class RecordBtn extends eui.Skin{
	}
}
declare module skins{
	class SendChatBtn extends eui.Skin{
	}
}
declare class GameItemSkin extends eui.Skin{
}
declare class GameItemViewSkin extends eui.Skin{
}
declare class GoodTipsPageViewSkin extends eui.Skin{
}
declare class GoodTipsViewSkin extends eui.Skin{
}
declare class HallSceneSkin extends eui.Skin{
}
declare class LImitRadioBtnSkin extends eui.Skin{
}
declare class LimitViewSkin extends eui.Skin{
}
declare class MGameItemSkin extends eui.Skin{
}
declare class MoblieHallSceneSkin extends eui.Skin{
}
declare class BetButtonFrench extends eui.Skin{
}
declare class NewFile extends eui.Skin{
}
declare class classic_betSkin extends eui.Skin{
}
declare class French_betSkin extends eui.Skin{
}
declare class MobileBetAreaSkin extends eui.Skin{
}
declare class MobileFrenchBetAreaSkin extends eui.Skin{
}
declare class RouletteBetBtnSkin extends eui.Skin{
}
declare class RouletteRepeatBtnSkin extends eui.Skin{
}
declare class bottom_infoSkin extends eui.Skin{
}
declare class MobileRouletteSkin extends eui.Skin{
}
declare class PcRouletteGameSceneSkin extends eui.Skin{
}
declare class Anchor extends eui.Skin{
}
declare class Reward extends eui.Skin{
}
declare class RouletteResultSkin extends eui.Skin{
}
declare class userInfoSkin extends eui.Skin{
}
