declare module Global {
	function deepCopy(object, copy);
}