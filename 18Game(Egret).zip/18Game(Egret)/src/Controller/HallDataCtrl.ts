class HallDataCtrl {
	public constructor() {
	}
	private lobbyPlayer:proto.Lobby.UserSnapshot;
	private limitRed:{[key:number] : {[key:number] : LimitDataModel}} = {};
	private nomalLimitRedID:{[key:number] : Array<number>}={}
	private loadGameModel:LoadGameModel;
	private static hallDataCtrl:HallDataCtrl;
	private playerCount:any;
	static get instance(){
		if(!this.hallDataCtrl){
			this.hallDataCtrl=new HallDataCtrl();
		}
		return this.hallDataCtrl;
	}
	
	public get getLobbyPlayer(){
		return this.lobbyPlayer;
	}

	public setLobbyPlayer(data:proto.Lobby.UserSnapshot){
		this.lobbyPlayer=data;
		this.limitRed={};
		this.nomalLimitRedID={};
		this.parsebetLimitAndChip(data.rouletteChips,proto.GameType.Roulette);
		this.parsebetLimitAndChip(data.videoChips,proto.GameType.Baccarat);
		
	}

	public setPlayerCount(playerCount:any){
		this.playerCount=playerCount;
	}

	public get getPlayerCount(){
		return this.playerCount;
	}

	//通过游戏id获取限红组
	public getGameLimitRed(gameType:number){
		return this.limitRed[gameType];
	}

	//通过限红ID获取限红
	public getLimitIDLimitRed(gameType:number,limitID:number):LimitDataModel{
		return this.limitRed[gameType][limitID];
	}

	public setChips(gameType:number,chips:Array<any>){
		var compare=function(a,b){
			return a-b;
		}
		var chipsData=chips.sort(compare);
		this.limitRed[gameType][this.loadGameModel.getLimitRedID]["chips"]=chipsData;
		this.loadGameModel.setChip(chipsData);
	}



	//获取默认限红ID
	public getNomalLimitID(gameType:number){
		return this.nomalLimitRedID[gameType][0];
	}


	//游戏数据获取
	public get getLoadGameData(){
		return this.loadGameModel;
	}

	public setLoadGameData(loadGameModel:LoadGameModel){
		this.loadGameModel=loadGameModel;
	}

	private parsebetLimitAndChip(betLimitAndChip:any,gameType:number){
		
       
		this.limitRed[gameType]={};
		//var limitRedCompare=new Array<LimitDataModel>();
		let limitRed=new Array<any>();//限红值数组
		this.nomalLimitRedID[gameType]=new Array<number>();
		for (var key in betLimitAndChip) {
			var limitDataModel=new LimitDataModel();
			this.nomalLimitRedID[gameType].push(Number(key));
			var betLimitAndChipArray = betLimitAndChip[key].split(":");
			limitDataModel.setLimitRedID(Number(key));
            limitDataModel.setLimitRedCount(betLimitAndChipArray[0]);
            limitDataModel.setChips(betLimitAndChipArray[1].split(","));
            limitDataModel.setAllChips(betLimitAndChipArray[2].split(","));
			//limitRedCompare.push(limitDataModel);
			this.limitRed[gameType][key]=limitDataModel;
		}
		
			     //console.log("数组对象排序：");
        // var sortArr = limitRedCompare.sort(this.compare);
		// for (var key in sortArr) {
		// 	var limitDataModelp:LimitDataModel=sortArr[key];
		// 	this.nomalLimitRedID[gameType].push(limitDataModelp.getLimitRedID);
		// 	this.limitRed[gameType][limitDataModelp.getLimitRedID]=limitDataModelp;

		// }
	}

	


}