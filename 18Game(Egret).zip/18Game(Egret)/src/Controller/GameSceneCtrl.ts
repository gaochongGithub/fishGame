/**
 * 场景控制类(单例) 两大场景，大厅及游戏
 */
class GameSceneCtrl {
	private _stage:egret.DisplayObjectContainer // 设置所有场景所在的舞台(根)
	public constructor() {
	}
	private static gameSceneCtrl:GameSceneCtrl;
	//获取实例对象
	static get instance(){
		if(!this.gameSceneCtrl){
			this.gameSceneCtrl=new GameSceneCtrl();
		}
		return this.gameSceneCtrl;
	}

	/**
     * 初始化管理器的一些数据，游戏初始化调用
     */
    public init(s:egret.DisplayObjectContainer) {
		//设置根场景
        this._stage = s
    }


	//跳转大厅场景
	public toHallScene(){
		this._stage.removeChildren();
		const hallScene = new PCHallScene();
        this._stage.addChild(hallScene);

		// const gameitem=new GameItem();
		// hallScene.addChild(gameitem);
	}

	//跳转手机大厅场景
	public toMobileHallScene(){
		const mobileHallScene = new MoblieHallScene();
        this._stage.addChild(mobileHallScene);

		// const gameitem=new GameItem();
		// hallScene.addChild(gameitem);
	}

	//跳转游戏场景
	public toGameScene(gameType){
		this._stage.removeChildren();
		let game;
		if(App.DeviceUtils.IsMobile){
			if(gameType==proto.GameType.Roulette)
				game = new MobileRoulette();
			else
				game = new PcBaccaratGameScene();
		}else{
			if(gameType==proto.GameType.Roulette)
				game = new PcRouletteGameScene();
			else
				game = new PcBaccaratGameScene();
		}

		this._stage.addChild(game);
	}



}