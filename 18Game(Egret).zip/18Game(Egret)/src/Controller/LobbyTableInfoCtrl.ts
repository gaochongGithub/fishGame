class LobbyTableInfoCtrl {
	public constructor() {
	}
	static lobbyTableInfoCtrl:LobbyTableInfoCtrl;
    private gameHallItemModel=new GameHallItemModel();
	static get instance(){
		if(!this.lobbyTableInfoCtrl){
			this.lobbyTableInfoCtrl=new LobbyTableInfoCtrl();
		}
		return this.lobbyTableInfoCtrl;
	}
    private ways = "";
    private gameTypeItem = new Array<any>();
    private allGameArray = new Array<any>();
    //private lobbyTableArr:Array<Array<any>>= new Array<Array<any>>();
    private lobbyTableArr:{[key:number] : {[key:number] : {}}} = {};
	setLobbyTableInfo(tableSnapshot:proto.Lobby.TableSnapshot){
 		var gameType = tableSnapshot.gameType;
        var tableID = tableSnapshot.tableID;
        var limitRedGame=HallDataCtrl.instance.getNomalLimitID(gameType);
       
        
        if(!this.lobbyTableArr[gameType]) {
            this.lobbyTableArr[gameType] = [];
        }
        
         if(!this.lobbyTableArr[gameType][tableID]) {
            this.lobbyTableArr[gameType][tableID]={};
             var gameHallItemModel=new GameHallItemModel();
            gameHallItemModel.setTableSnapshot(tableSnapshot);
            gameHallItemModel.setGameType(gameType);
            gameHallItemModel.setGameTable(tableID);
            gameHallItemModel.setAllWays(this.getAllWays(tableSnapshot.ways,"",gameType));
            this.addLobbyTableArr(gameType, tableID, gameHallItemModel);
            gameHallItemModel.setLimitRedID(limitRedGame);
         } else {
             this.lobbyTableArr[gameType][tableID]["tableSnapshot"]=tableSnapshot;
             var oldWays=this.lobbyTableArr[gameType][tableID]["allways"];
             this.lobbyTableArr[gameType][tableID]["allways"]=this.getAllWays(tableSnapshot.ways,oldWays,gameType);
             this.lobbyTableArr[gameType][tableID]["limitRedID"]=limitRedGame;
            //  gameHallItemModel.setAllWays(tableSnapshot.ways);
            //  this.updateLobbyTableArr(gameType, tableID, gameHallItemModel); 
            //  gameHallItemModel.setLimitRedID(limitRedGame);
         }
        //this.lobbyTableArr[gameType][tableID] = tableSnapshot;
        //App.TimerManager.setTimeOut(500,this.sendMessage,this);
        this.sendMessage();
		
	}

    private getAllWays(ways,oldWays,gameType):string{
        var allWays="";
        if(ways.substring(0, 1) == "q") {
            allWays = "";
        }else if(gameType == proto.GameType.Roulette){
            allWays = oldWays+ways+",";
        }else if(gameType == proto.GameType.SicBo){
            if(ways){
                 allWays = oldWays+","+ways;
            }
        }else{
           allWays = oldWays+ways;
        }
        return allWays;
    }

    sendMessage(){
        App.MessageCenter.dispatch(LobbyEvent.ADD_LOBBY_ROAD_ITEM);
    }


	addLobbyTableArr(gameType, tableID, tableSnapshot:GameHallItemModel){
		 this.lobbyTableArr[gameType][tableID] = tableSnapshot;
         
	}

	updateLobbyTableArr(gameType, tableID, tableSnapshot:GameHallItemModel){
		// var lobbyTableInfo = this.lobbyTableArr[gameType][tableID];
		// var way = lobbyTableInfo.ways.substr(lobbyTableInfo.ways.length - 1, 1);
		// if(gameType == proto.GameType.Roulette||gameType == proto.GameType.SicBo){
        //     var arr = lobbyTableInfo.ways.split(",");
        //     lobbyTableInfo.setWays(arr[arr.length-1],gameType);
        // }else{
        //     lobbyTableInfo.setWays(way,gameType);
        // }
       
		this.lobbyTableArr[gameType][tableID]=tableSnapshot;
	}

	//获取大厅全部游戏数据
    getLobbyTableArr(){
        this.allGameArray=[];
        var allGame=this.lobbyTableArr;
        for(var entery in allGame) {
            var data= this.lobbyTableArr[entery];
            for(var entery in data){
                this.allGameArray.push(data[entery]);
            }
        }
        return this.allGameArray;
    }

    //获取大厅一类游戏数据
    getLobbyTableArrByGameType(gameType) {
        this.gameTypeItem=[];
        var data= this.lobbyTableArr[gameType];
        for(var entery in data) {
            this.gameTypeItem.push(data[entery]);
        }
        return this.gameTypeItem;
       
    }

    //获取大厅一桌的数据
   getLobbyOneTable(gameType, tableID){
        // cc.log(gameType, tableID , this.lobbyTableArr , "游戏类型和桌号");
        //if(gameType && tableID){
            //console.log(typeof(this.lobbyTableArr[gameType][tableID]));
        var gameItem=this.lobbyTableArr[gameType][tableID];
            // var jsonString=JSON.stringify(this.lobbyTableArr[gameType][tableID]);
            // let gameHallItemModel:GameHallItemModel=(JSON.parse(jsonString));//json字符串转对象
            // console.log("gameHallItemModel"+gameHallItemModel.allways);
       
        this.gameHallItemModel.setTableSnapshot(gameItem["tableSnapshot"]);
        this.gameHallItemModel.setGameType(gameItem["gameType"]);
        this.gameHallItemModel.setGameTable(gameItem["gameTable"]);
        this.gameHallItemModel.setAllWays(gameItem["allways"]);
        this.gameHallItemModel.setLimitRedID(gameItem["limitRedID"]);
        this.gameHallItemModel.setIsShwoView(gameItem["isShowView"]);
        //this.gameHallItemModel.setLimitRedID(limitRedGame);
        return this.gameHallItemModel;
             
        //}
        
    }

    //设置游戏限红的数据
    setLobbyOneTableLimitID(gameType, tableID,limitRedID){
        var gameItem=this.lobbyTableArr[gameType][tableID];
        gameItem["limitRedID"]=limitRedID;
        this.gameHallItemModel.setTableSnapshot(gameItem["tableSnapshot"]);
        this.gameHallItemModel.setGameType(gameItem["gameType"]);
        this.gameHallItemModel.setGameTable(gameItem["gameTable"]);
        this.gameHallItemModel.setAllWays(gameItem["allways"]);
        this.gameHallItemModel.setLimitRedID(gameItem["limitRedID"]);
        this.gameHallItemModel.setIsShwoView(gameItem["isShowView"]);
        return this.gameHallItemModel;
    }

    //清理大厅游戏数据
    clearLobbyTableArr() {
        this.lobbyTableArr = [];
    }
}