/**
 * 游戏数据控制类
 */
class GameDataCtrl {
	public constructor() {
	}
	private confirmBetAmount:{[key:number] : number}= {};
	private unConfirmBetAmount:{[key:number] : number}= {};
	private confirmBetAmount_r:{[key:number] : number}= {};
	//当前选中筹码
	private _currentBetChip:number = 0;

	private static gameDataCtrl:GameDataCtrl;

	private _gameStatus:proto.Game.TableStatus;

	//当前局号
	private _currentInning:number = 0;

	//private _currentStatus:Status = 0;

	//是否已下注，确保有下注的桌不能退出或换桌
	private _isBet:boolean = false;
	//历史数据
	private allGameTableHistory:any = [];
	//是否可以下注
	private _isCanClick:boolean = false;
	static get instance(){
		if(!this.gameDataCtrl){
			this.gameDataCtrl = new GameDataCtrl();
		}
		return this.gameDataCtrl;
	}

	/*当前状态存取*/
	public get gameStatus():proto.Game.TableStatus{
		return this._gameStatus;
	}

	public set gameStatus(gameStatus:proto.Game.TableStatus){
		this._gameStatus = MyUtils.deeCopy(gameStatus,this._gameStatus);
	}
	/**
	 * 当前是否下注
	 */

	public get isBet():boolean{
		return this._isBet;
	}
	
	public set isBet(isBet:boolean){
		this._isBet = isBet;
	}

	/**
	 * 当前局号存取
	 */
	public get currentInning(){
		return this._currentInning;
	}
	public set currentInning(inning:number){
		this._currentInning = inning;
	}

	public get isCanClick():boolean{
		return this._isCanClick
	}
	public setIsCanClick(isCanClick:boolean){
		this._isCanClick = isCanClick;
	}
	/**
	 * 当前状态存取
	 */
	// public get currentStatus(){
	// 	return this._currentStatus;
	// }
	
	// public set currentStatus(status:Status){
	// 	this._currentStatus = status;
	// }

	//获取已确定的下注
	public get getConfirmBetAmount(){
		return this.confirmBetAmount;
	}

	public get getUnConfirmBetAmount(){
		return this.unConfirmBetAmount;
	}

	//当前筹码存取
	public get getCurrentBetChip(){
		return this._currentBetChip;
	}

	public set setCurrentBetChip(chip:number){
		this._currentBetChip = chip;
	}


	//数据累加
	public updateUnConfirmBet(key:number,value:number){
		this.unConfirmBetAmount[key] = Number(this.unConfirmBetAmount[key])+Number(value);
	}


	//设置为特定的值
	public setUnConfirmBetByKey(key:number,value:number){
		this.unConfirmBetAmount[key] = this.unConfirmBetAmount[key] || 0;
		this.unConfirmBetAmount[key] = value;
	}

	public setConfirmBetByKey(key:number,value:number){
		this.confirmBetAmount[key] = this.confirmBetAmount[key] || 0;
		this.confirmBetAmount[key] = value;
	}

	//已下注的总额
	public getUserChipsTotal():number{
		let total:number = 0;
		for (var key in this.confirmBetAmount) {
			total+= Number(this.confirmBetAmount[key]);
		}
		return total;
	}

	public get getConfirmBetAmount_R(){
		return this.confirmBetAmount_r;
	}
	
	public setConfirmBetAmount_R(key,value){
		this.confirmBetAmount_r[key] = value;
	}
	public get setResetData(){
		this.confirmBetAmount_r = {};
		return this.confirmBetAmount_r;
	}
	public get getAllGameTableHistory(){
		return this.allGameTableHistory;
	}
	public setAllGameTableHistory(data:any){
		this.allGameTableHistory.push(data);
	}
}