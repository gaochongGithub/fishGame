class RoadScene extends eui.Component{
	public markRoadScene : MarkRoadScene;

    public bigRoadScene : BigRoadScene;
    public jyRoadScene : JyRoadScene;
    public smallRoadScene : SmallRoadScene;
    public zlRoadScene : ZlRoadScene;

    private text_beadRoad:eui.Label;
    private text_bigRoad:eui.Label;
    private text_bigEyeRoad:eui.Label;
    private text_smallRoad:eui.Label;
    private text_cockroachRoad:eui.Label; 

    constructor(width:number) {
        super();
        this.mask = new egret.Rectangle(0, 0, width*10 + width/2*38, width*6);
        this.markRoadScene = new MarkRoadScene(width, width, 10, 6);
        this.addChild(this.markRoadScene);
        

        this.bigRoadScene = new BigRoadScene(width/2, width/2, 38, 6);
        this.bigRoadScene.x = this.markRoadScene.x + this.markRoadScene.width;
        this.addChild(this.bigRoadScene);
        
        

        this.jyRoadScene = new JyRoadScene(width/2, width/2, 38, 3);
        this.jyRoadScene.x = this.markRoadScene.x + this.markRoadScene.width;
       
        this.jyRoadScene.y = this.bigRoadScene.y + this.bigRoadScene.height;
        this.addChild(this.jyRoadScene);
        function onJyRoadSceneClick() {
            if(this.jyRoadScene.scaleX > 1) {
                egret.Tween.get(this.jyRoadScene).to({scaleX : 1, scaleY : 1}, 300).
                call(this.setChildIndex, this, [this.jyRoadScene, 1]);
                this.jyRoadScene.lineNum *= 2;
            } else {
                egret.Tween.get(this.jyRoadScene).to({scaleX : 2, scaleY : 2}, 300);
                this.setChildIndex(this.jyRoadScene, 10);
                this.jyRoadScene.lineNum /= 2;
            }
            
            this.jyRoadScene.moveAll();
        }
        
        this.jyRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onJyRoadSceneClick, this);
       


        this.smallRoadScene = new SmallRoadScene(width/2, width/2, 19, 3);
        this.smallRoadScene.x = this.markRoadScene.x + this.markRoadScene.width;
        this.smallRoadScene.y = this.jyRoadScene.y + this.jyRoadScene.height;
        this.addChild(this.smallRoadScene);
        function onSmallRoadSceneClick() {
            
            if(this.smallRoadScene.scaleX > 1) {
                egret.Tween.get(this.smallRoadScene).
                to({y :this.jyRoadScene.y + this.jyRoadScene.height, scaleX : 1, scaleY : 1}, 300).
                call(this.setChildIndex, this, [this.smallRoadScene, 1]);
                this.smallRoadScene.lineNum *= 2;
            } else {
                egret.Tween.get(this.smallRoadScene).
                to({y :this.jyRoadScene.y, scaleX : 2, scaleY : 2}, 300);
                this.setChildIndex(this.smallRoadScene, 10);
                this.smallRoadScene.lineNum /= 2;
            }
            // this.smallRoadScene.moveAll();
        }
        this.smallRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onSmallRoadSceneClick, this);
        


        this.zlRoadScene = new ZlRoadScene(width/2, width/2, 19, 3);
        this.zlRoadScene.x = this.smallRoadScene.x + this.smallRoadScene.width;
        this.zlRoadScene.y = this.jyRoadScene.y + this.jyRoadScene.height;
        function onZlRoadSceneClick() {
            if(this.zlRoadScene.scaleX > 1) {
                egret.Tween.get(this.zlRoadScene).
                to({x : this.smallRoadScene.x + this.smallRoadScene.width, y :this.jyRoadScene.y + this.jyRoadScene.height, scaleX : 1, scaleY : 1}, 300).
                call(this.setChildIndex, this, [this.zlRoadScene, 1]);
                this.zlRoadScene.lineNum *= 2;
            } else {
                egret.Tween.get(this.zlRoadScene).
                to({x : this.markRoadScene.x + this.markRoadScene.width, y :this.jyRoadScene.y, scaleX : 2, scaleY : 2}, 300);
                this.setChildIndex(this.zlRoadScene, 10);
                this.zlRoadScene.lineNum /= 2;
            }
            // this.zlRoadScene.moveAll();
        }
        this.zlRoadScene.addEventListener(egret.TouchEvent.TOUCH_TAP, onZlRoadSceneClick, this);
        this.addChild(this.zlRoadScene);
        

        this.customView();
        //this.updateLang();
    }

    public onAddtoStage(): void {
        //EventPoster.getDispatcher().addEventListener(MyEvent.LANG_CHANGE, this.updateLang, this);
        App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE,this.updateLang,this);
        this.updateLang();
    }

    private updateLang() {
        this.text_beadRoad.text = App.LangUtils.getStr('TEXT_Bead_Road');
		this.text_bigRoad.text = App.LangUtils.getStr('TEXT_Big_Road');
		this.text_bigEyeRoad.text = App.LangUtils.getStr('TEXT_Big_ye_Road');
		this.text_smallRoad.text = App.LangUtils.getStr('SMALLTEXT_Small_Road_ROAD');
		this.text_cockroachRoad.text = App.LangUtils.getStr('TEXT_CockRoach_Road')
    }

    public getNextCode():string{
        return this.bigRoadScene.getNextCode();
    }

    public addString(str:string){
        this.markRoadScene.addWithString(str);
        this.bigRoadScene.addWithString(str);
        this.jyRoadScene.addWithString(str);
        this.smallRoadScene.addWithString(str);
        this.zlRoadScene.addWithString(str);
    }
    
    public clear(){
        this.markRoadScene.clear();
        this.bigRoadScene.clear();
        this.jyRoadScene.clear();
        this.smallRoadScene.clear();
        this.zlRoadScene.clear();
    }
    private customView(){
        var label1:eui.Label = new eui.Label();
        label1.text = "珠盘路";
        label1.right = 5;
        label1.bottom = 5;
        label1.textAlign = egret.HorizontalAlign.RIGHT;
        label1.width = 222;
        label1.textColor = 0xE0E0E0;
        label1.size = 25;
        label1.alpha = 0.8;
        this.text_beadRoad = label1;
        this.markRoadScene.addChild(this.text_beadRoad);
        


         var label2:eui.Label = new eui.Label();
        label2.text = "大路";
        label2.right = 5;
        label2.bottom = 5;
        label2.textAlign = egret.HorizontalAlign.RIGHT;
        label2.width = 263;
        label2.textColor = 0xE0E0E0;
        label2.size = 25;
        label2.alpha = 0.8;
        this.text_bigRoad =label2;
        this.bigRoadScene.addChild(this.text_bigRoad);
        


        var label3:eui.Label = new eui.Label();
        label3.text = "大眼仔";
        label3.right = 5;
        label3.bottom = 5;
        label3.textAlign = egret.HorizontalAlign.RIGHT;
        label3.width = 263;
        label3.textColor = 0xE0E0E0;
        label3.size = 25;
        label3.alpha = 0.8;
        this.text_bigEyeRoad = label3;
        this.jyRoadScene.addChild(this.text_bigEyeRoad);

         var label4:eui.Label = new eui.Label();
        label4.text = "小路";
        label4.right = 5;
        label4.bottom = 5;
        label4.textAlign = egret.HorizontalAlign.RIGHT;
        label4.width = 200;
        label4.textColor = 0xE0E0E0;
        label4.size = 25;
        label4.alpha = 0.8;
        this.text_smallRoad = label4;
        this.smallRoadScene.addChild(this.text_smallRoad);


         var label5:eui.Label = new eui.Label();
        label5.text = "曱甴";
        label5.right = 5;
        label5.bottom = 5;
        label5.textAlign = egret.HorizontalAlign.RIGHT;
        label5.width = 259;
        label5.textColor = 0xE0E0E0;
        label5.size = 25;
        label5.alpha = 0.8;
        this.text_cockroachRoad = label5;
        this.zlRoadScene.addChild(this.text_cockroachRoad);

    }

    public askRoad(str:string){
        var isShow;
        if(!isShow) {
                egret.setTimeout(function() {
                    isShow = false;
                }, this, 2500);

                this.markRoadScene.addNextString(str);
                this.bigRoadScene.addNextString(str);
                this.jyRoadScene.addNextString(str);
                this.smallRoadScene.addNextString(str);
                this.zlRoadScene.addNextString(str);
                isShow = true;
            }
    }

}