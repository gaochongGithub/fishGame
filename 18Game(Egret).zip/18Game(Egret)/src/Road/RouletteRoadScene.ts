class RouletteRoadScene extends eui.Component{
	public markRoadScene : MarkRoadScene;
  
    constructor(width:number) {
        super();
        this.mask = new egret.Rectangle(0, 0, width*29, width*6);
        
        this.markRoadScene = new MarkRoadScene(width, width, 29, 6);
        this.markRoadScene.x = 0;
        this.addChild(this.markRoadScene);
    }

    public onAddtoStage(): void {
       
    }

    public addString(str:string){
        this.markRoadScene.addWithString(str,proto.GameType.Roulette);
    }
    
    public clear(){
        this.markRoadScene.clear();
    }
}