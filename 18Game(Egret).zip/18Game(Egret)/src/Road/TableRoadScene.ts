class TableRoadScene extends eui.Component{
	
    public bigRoadScene : BigRoadScene;
  
    constructor(width:number) {
        super();
        this.mask = new egret.Rectangle(0, 0, width*10, width*6);
        
        this.bigRoadScene = new BigRoadScene(width, width, 10, 6);
        this.bigRoadScene.x = 0;
        this.addChild(this.bigRoadScene);
    }

    public onAddtoStage(): void {
       
    }

    public getNextCode():string{
        return this.bigRoadScene.getNextCode();
    }

    public addString(str:string){
        this.bigRoadScene.addWithString(str);
    }
    
    public clear(){
        this.bigRoadScene.clear();
    }
}