/**
 *
 * @author 
 *
 */
class MarkRoadScene extends eui.Component {
    public gridWidth : number = 0;
    public gridHeight : number = 0;
    private lineNum : number = 0;
    private columnNum : number = 0;

    public gridScene: GridScene;
    public markRoad: MarkRoad = new MarkRoad();
    public roadView : eui.Group = new eui.Group();;
    private spMask;
    
    public constructor(gridWidth : number, gridHeight : number, lineNum : number, columnNum : number) {
        super();
        this.width = gridWidth*lineNum;
        this.height = gridHeight*columnNum;
        
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.lineNum = lineNum;
        this.columnNum = columnNum;


        this.initScene();
    }


    private initScene() {
        var bg = new egret.Shape();
        bg.graphics.beginFill(0xffffff);
        bg.graphics.drawRect(0, 0, this.width, this.height);
        bg.graphics.endFill();
        this.addChild(bg);
        
        this.addChild(this.roadView);

        var spMask = new egret.Rectangle(0, 0, this.gridWidth*this.lineNum, this.gridHeight*this.columnNum);
		this.roadView.mask = spMask;
        this.spMask = spMask;

        this.gridScene = new GridScene(this.gridWidth, this.gridHeight, this.lineNum, this.columnNum);;
        this.gridScene.setDrawLine();
        this.addChild(this.gridScene);
    }

    //根据字符来决定
    public addWithString(aString: string,gameType:any = null) {
        if(gameType == proto.GameType.Roulette){
            if(aString == "q"){
                this.clear();
            }else{
                var arr = aString.split(",");
                for(var i=0;i<arr.length;i++){
                    if(arr[i] && arr[i] !== ""){
                        this.addOneMark(arr[i],gameType);
                    }
                }
            }
        }else{
            for (var i = 0; i < aString.length; i++) {
                if (aString[i] == "q") {
                    this.clear();
                    break;
                } else {
                    this.addOneMark(aString[i],gameType);
                }
            }
        }
        
        this.moveAll();
    }

   public addOneMark(markResult: string , gameType:any = null) {
        this.markRoad.addOne()
        if(gameType == proto.GameType.Roulette){
            this.addWithRouletteCharacter(markResult, this.getCurrentRoadX(), this.getCurrentRoadY());
        }else{
            this.addWithOneCharacter(markResult, this.getCurrentRoadX(), this.getCurrentRoadY());
        }
    }

     public addNextString(way : string) {
        var next = new MarkRoad();
        //next = Global.deepCopy(this.markRoad, next);
        next = MyUtils.deeCopy(this.markRoad,next);
        console.log(this.markRoad,next);
        next.addOne()
        var oneMark = this.addWithOneCharacter(way, next.currentX, next.currentY);
        egret.Tween.get(oneMark, {loop : true}).to({alpha : 0}, 800, egret.Ease.quadInOut).to({alpha : 1}, 800, egret.Ease.quadInOut);
        egret.setTimeout(function() {
            this.roadView.removeChild(oneMark);
        }, this, 2400);
        this.roadView.addChild(oneMark);
    }
    

    public addWithOneCharacter(aCharacter: string, currentX : number, currentY : number) {
        var oneMark: eui.Image = new eui.Image();
        var num:number = (aCharacter.charCodeAt(0) - 97);
        // var imageStr:string[] = ["B","B_PP","B_BP","B_BP_PP",
        //                             "P","P_PP","P_BP","P_BP_PP",
        //                             "T","T_PP","T_BP","T_BP_PP"];
        var lang:string = App.LangUtils.kind=="ZH"?"ZH":"EN";
        oneMark.texture = RES.getRes(lang+"_"+aCharacter+"_png");
        oneMark.width = this.gridWidth*9/10;
        oneMark.height = this.gridHeight*9/10;
        oneMark.anchorOffsetX = oneMark.width/2;
        oneMark.anchorOffsetY = oneMark.height/2;
        oneMark.x = currentX*this.gridWidth + this.gridWidth/2;
        oneMark.y = currentY*this.gridHeight + this.gridHeight/2;
        
        this.roadView.addChild(oneMark);
        return oneMark;
    }

    /**
     * 用于问路
     */


    public getCurrentRoadX(): number {
        return this.markRoad.currentX;
    }

    public getCurrentRoadY(): number {
        return this.markRoad.currentY;
    }


    public clear() {
        this.roadView.removeChildren();
        this.markRoad.clear();
        
    }

    public moveAll() {
        this.roadView.x = this.markRoad.currentX > this.lineNum - 2 ? (-(this.markRoad.currentX - this.lineNum +2) * this.gridWidth) : 0;
        this.spMask.x = -this.roadView.x;
        this.roadView.mask = this.spMask;
    }
    //轮盘路单
    public addWithRouletteCharacter(aCharacter: string, currentX : number, currentY : number){
        if(aCharacter == ","){
            return;
        }
        var oneMark: eui.Group = new eui.Group();
        var rect: eui.Rect = new eui.Rect();

        var lable:eui.Label = new eui.Label(aCharacter);
        lable.size = 15;
        lable.horizontalCenter = 0;
        lable.verticalCenter = 0;
        lable.textAlign = egret.HorizontalAlign.JUSTIFY;
        lable.textAlign = egret.VerticalAlign.JUSTIFY;
      
        rect.fillColor = this.getMarkRoadColor(aCharacter);
        rect.width = this.gridWidth*9/10;
        rect.height = this.gridHeight*9/10;
        rect.anchorOffsetX = oneMark.width/2;
        rect.anchorOffsetY = oneMark.height/2;
        rect.horizontalCenter = 0;
        rect.verticalCenter = 0;

        oneMark.width = this.gridWidth*9/10;
        oneMark.height = this.gridHeight*9/10;
        oneMark.anchorOffsetX = oneMark.width/2;
        oneMark.anchorOffsetY = oneMark.height/2;
        oneMark.x = currentX*this.gridWidth + this.gridWidth/2;
        oneMark.y = currentY*this.gridHeight + this.gridHeight/2;
        oneMark.addChild(rect);
        oneMark.addChild(lable);
        this.roadView.addChild(oneMark);
        return oneMark;
    }
    private getMarkRoadColor (char:any){
        var color = 0x000000;
        if(char == 0){
            color = 0x50A548;
        }else if(char>0 && char<11){
            if(char%2 == 0){
                color = 0x000000;
            }else{
                color = 0xC52022;
            }
        }else if(char>10 && char<19){
            if(char%2 == 0){
                color = 0xC52022;
            }else{
                color = 0x000000;
            }
        }else if(char>=19 && char<29){
            if(char%2 == 0){
                color = 0x000000;
            }else{
                color = 0xC52022;
            }
        }else{
            if(char%2 == 0){
                color = 0xC52022;
            }else{
                color = 0x000000;
            }
        }
        return color;
    }
}
