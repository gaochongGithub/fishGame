/**
 *
 * @author 
 *
 */
class JyRoadScene extends eui.Component {
    public gridWidth : number = 0;
    private gridHeight : number = 0;
    public lineNum : number = 0;
    private columnNum : number = 0;

    public gridWidth2 : number = 0;
    private gridHeight2 : number = 0;

    public gridScene: GridScene;

    public roadView : eui.Group = new eui.Group();;
    private spMask;
    public bigRoad: BigRoad = new BigRoad();
    public jyRoad: SmallRoad = new SmallRoad();

    public constructor(gridWidth : number, gridHeight : number, lineNum : number, columnNum : number = 6) {
        super();

        this.width = gridWidth*lineNum;
        this.height = gridHeight*columnNum;
        
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.lineNum = lineNum;
        this.columnNum = columnNum;

        this.gridWidth2= this.gridWidth/2;
        this.gridHeight2 = this.gridHeight/2;
        
        
        this.createSubView();

        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddedToStage, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemovedFromStage, this);
    }

    public haveSamllRoad: boolean = true;
    
    private onAddedToStage() {

    }

    private onRemovedFromStage() {

    }


    private createSubView() {
        var bg = new egret.Shape();
        bg.graphics.beginFill(0xffffff);
        bg.graphics.drawRect(0, 0, this.width, this.height);
        bg.graphics.endFill();
        this.addChild(bg);
        
        this.addChild(this.roadView);
        var spMask = new egret.Rectangle(0, 0, this.gridWidth*this.lineNum, this.gridHeight*this.columnNum);
		this.roadView.mask = spMask;
        this.spMask = spMask;

        this.gridScene = new GridScene(this.gridWidth, this.gridHeight, this.lineNum, this.columnNum);
        this.gridScene.setDrawLine();
        this.addChild(this.gridScene);
    }
    //根据字符来决定
    public addWithString(aString: string) {
        for (var i = 0; i < aString.length; i++) {

            if (aString[i] == "q") {
                this.clear();
                break;
            } else {
                this.addWithOneCharacter(aString[i]);
            }
        }

        this.moveAll();
    }

    private addOneImage(road) {
        var oneMark: eui.Image = new eui.Image();
        oneMark.width = this.gridWidth2;
        oneMark.height = this.gridHeight2;
        oneMark.x = this.gridWidth2 * road.currentX;
        oneMark.y = this.gridHeight2 * road.currentY;
        var imageStr:string ;
        if (road.lastWay >= "a" && road.lastWay <= "d") {
            // 画庄  红
            imageStr = "JY_A_png";
        } else if (road.lastWay >= "e" && road.lastWay <= "h") {
            //画闲   蓝
            imageStr = "JY_E_png";
        }
        oneMark.texture = RES.getRes(imageStr);
        return oneMark;
    }

    public addNextString(way : string) {
        var nextBig = new BigRoad();
        //nextBig = Global.deepCopy(this.bigRoad, nextBig);
        nextBig = MyUtils.deeCopy(this.bigRoad,nextBig);
        var add = nextBig.add(way);

        var nextJyRoad = new SmallRoad();
        //nextJyRoad = Global.deepCopy(this.jyRoad, nextJyRoad);
        nextJyRoad = MyUtils.deeCopy(this.jyRoad,nextJyRoad);
        if (add > 1 && nextJyRoad.addWithOne(nextBig.getJiyanCode()) > 1) {
            var oneMark = this.addOneImage(nextJyRoad);
            egret.Tween.get(oneMark, {loop : true}).to({alpha : 0}, 800, egret.Ease.quadInOut).to({alpha : 1}, 800, egret.Ease.quadInOut);
            egret.setTimeout(function() {
                this.roadView.removeChild(oneMark);
            }, this, 2400);
            this.roadView.addChild(oneMark);
        }
    }
    private addWithOneCharacter(way: string) {
        var add = this.bigRoad.add(way);
        if (add > 1 && this.jyRoad.addWithOne(this.bigRoad.getJiyanCode()) > 1) {
                
            var oneMark: eui.Image = this.addOneImage(this.jyRoad);
            this.roadView.addChild(oneMark);
        }
    }

    // private addWithOneCharacter(way: string) {
    //     var add = this.bigRoad.add(way);
    //     if (this.haveSamllRoad && add > 1) {

    //         if (this.jyRoad.addWithOne(this.bigRoad.getJiyanCode()) > 1) {
                
    //             var oneMark: eui.Image = new eui.Image();
    //             oneMark.width = this.gridWidth2;
    //             oneMark.height = this.gridHeight2;
    //             oneMark.x = this.gridWidth2 * this.jyRoad.currentX;
    //             oneMark.y = this.gridHeight2 * this.jyRoad.currentY;
    //             var imageStr:string ;
    //             if (this.jyRoad.lastWay >= "a" && this.jyRoad.lastWay <= "d") {
    //                 // 画庄  红
    //                 imageStr = "PC_B_JY_png";
    //             } else if (this.jyRoad.lastWay >= "e" && this.jyRoad.lastWay <= "h") {
    //                 //画闲   蓝
    //                 imageStr = "PC_P_JY_png";
    //             }
    //             oneMark.texture = RES.getRes(imageStr);
    //             this.roadView.addChild(oneMark);
    //         }
    //     }
    // }

    public clear() {


        this.bigRoad.clear();

        if (!this.haveSamllRoad) {
            return;
        }
        this.roadView.removeChildren();
        this.jyRoad.clear();
    }

    public moveAll() {
        //console.log(this.jyRoad.currentX , this.lineNum*2 - 2)
        this.roadView.x = this.jyRoad.currentX > this.lineNum*2 - 2 ? (-(this.jyRoad.currentX - this.lineNum*2 + 2) * this.gridWidth2) : 0;
        this.spMask.x = -this.roadView.x;
        this.roadView.mask = this.spMask;
    }

}
