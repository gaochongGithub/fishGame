/**
 * 数据封装，接收
 */
class ByteArrayMsgByProtobuf extends ByteArrayMsg {
    private msgClass: any = null;
    private protoConfig: any = null;
    private protoConfigSymmetry: any = null;


    private heartCount:any = 0;
    /**
     * 构造函数
     */
    public constructor() {
        super();
        this.msgClass = {};
        this.protoConfig = App.ProtoConfig;
        this.protoConfigSymmetry = {};
        var keys = Object.keys(this.protoConfig);
        for (var i: number = 0, len = keys.length; i < len; i++) {
            var key = keys[i];
            var value = this.protoConfig[key];
            this.protoConfigSymmetry[value] = key;
        }
    }

    /**
     * 获取msgID对应的类
     * @param key
     * @returns {any}
     */
    private getMsgClass(key: string): any {
        var cls: any = this.msgClass[key];
        if (cls == null) {
            cls = egret.getDefinitionByName(key);
            this.msgClass[key] = cls;
        }
        return cls;
    }

    /**
     * 获取msgID
     * @param key
     * @returns {any}
     */
    private getMsgID(key: string): number {
        return this.protoConfigSymmetry[key];
    }

    /**
     * 获取msgKey
     * @param msgId
     * @returns {any}
     */
    private getMsgKey(msgId: number) {
        return this.protoConfig[msgId];
    }

    


    private decodeDetail(command:any,bytes:any){
        // console.log("收到消息"+command);
        switch (command) {
            case proto.Command.client_heart_beat_ack:
            
                this.receiveHeart(bytes);
                break;
            case proto.Command.user_lobby_login_ack:
                this.receiveLogin(bytes);
                break;
            case proto.Command.user_lobby_logout_ack:
                this.receiveLogout(bytes);
                break;
            case proto.Command.lobby_player_push:
                this.receiveLobbyPlayerInfo(bytes);
                break;
            case proto.Command.lobby_videourl_push:
                this.receiveLiveVideoUrl(bytes);
                break;
            case proto.Command.lobby_status_push:
                this.receiveLobbyTableInfo(bytes);
                break;
            case proto.Command.lobby_playercount_push:
                this.receivePlayerCountInfo(bytes);
                break;
            case proto.Command.game_join_table_ack : 
				this.receiveJoinTableLogin(bytes);
				break;
            case proto.Command.game_table_status_push:
                this.receiveGameTableStatus(bytes);
                break;
            case proto.Command.game_table_config_push:
                this.receiveGameTableConfig(bytes);
                break;
            case proto.Command.game_table_history_push:
                this.receiveGameTableHistory(bytes);
                break;
            case proto.Command.game_player_push:
                this.receiveGameUserSnapshot(bytes);
                break;
            case proto.Command.game_virtual_table_push:
                this.receiveGamVirtualTable(bytes);
                break;
            case proto.Command.game_virtual_bet_push:
                this.receiveGamVirtualTableBet(bytes);
                break;
            case proto.Command.game_bet_ack:
                this.receiveGameBetInfo(bytes);
                break;
            case proto.Command.report_game_report_ack:
                this.receiveGameRecord(bytes);
                break;
            case proto.Command.report_winlose_ack:
                this.receiveReportWinlose(bytes);
                break;
            case proto.Command.server_message_push:
                this.receiveServerMessagePush(bytes);
                break;
             case proto.Command.server_announce_push:
                this.receiveAnnounce(bytes);
                break;
             case proto.Command.lobby_change_chipgroup_ack:
                this.receiveChangeChip(bytes);
                break;
             case proto.Command.game_chain_prepare_ack:
                this.receiveChainPrePare(bytes);
                break;
            case proto.Command.game_round_count_push:
                this.receiveGameRoundCount(bytes);
             case proto.Command.game_chat_ack:
                this.receiveGameChatAck(bytes);
                break;
             case proto.Command.game_chat_push:
                this.receiveGameChatPush(bytes);
                break;
             case proto.Command.game_tip_ack:
                this.receiveReward(bytes);
                break;
             case proto.Command.game_load_chat_ack:
                this.receiveLoadChat(bytes);
                break;
            default:
                break;
        }
    }
    /**
     * 解析数据包
     */
    //心跳返回
    private getAutoID(bytes):any{
        return proto.AutoID.decode(bytes);
    }

    //获取proto.CommonReley
    private getCommonReply(bytes):any{
        return proto.CommonReply.decode(bytes);
    }

    //获取proto.Str数据
    private getStr(bytes):any{
        return proto.String.decode(bytes);
    }

    //获取Lobby.UserSnapshot数据
    private getLobbyUserSnapshot(bytes):proto.Lobby.UserSnapshot{
        return proto.Lobby.UserSnapshot.decode(bytes);
    }

    //获取Lobby.TableSnapshot数据
    private getLobbyTableSanpshot(bytes):any{
        return proto.Lobby.TableSnapshot.decode(bytes);
    }

    //获取Game.TableStatus数据
    private getGameTableStatus(bytes):any{
        return proto.Game.TableStatus.decode(bytes);
    }

    //获取Game.TableConfig
    private getGameTableConfig(bytes):any{
        return proto.Game.TableConfig.decode(bytes);
    }

    //获取Game.TableHistory
    private getGameTableHistory(bytes):any{
        return proto.Game.TableHistory.decode(bytes);
    }

    //获取Game.UserSnapshot数据
    private getGameUserSanpshot(bytes):any{
        return proto.Game.UserSnapshot.decode(bytes);
    }

    //获取Game.VirtualTable.Table数据
    private getGameVirtualTable(bytes):any{
        return proto.Game.VirtualTable.Table.decode(bytes);
    }

    //获取Game.VirtualTable.Bet数据
    private getGameVirtualTableBet(bytes):any{
        return proto.Game.VirtualTable.Bet.decode(bytes);
    }

    //获取Report.GameResultReply数据
    private getGameResultReply(bytes):any{
        return proto.Report.GameResultReply.decode(bytes);
    }

    //获取Report.WinloseReply数据
    private getWinloseReply(bytes):any{
        return proto.Report.WinLoseReply.decode(bytes);
    }

    //AnnouncePush数据
    private getAnnouncePush(bytes):any{
        return proto.AnnouncePush.decode(bytes);
    }

    //拉取数据返回
    private getPrepareReply(bytes):any{
        return proto.Game.EnterChainTable.decode(bytes);
    }

    //获取是否成功小费
    private getRewardAnchor(bytes):any{
        return proto.CommonReply.decode(bytes);
    }

    //拉取每局下注统计
    private getRoundCount(bytes):any{
        return proto.Game.RoundCount.decode(bytes);
    }

    //聊天
    private getChatVOList(bytes):any{
        return proto.Chat.ChatVOList.decode(bytes);
    }
    //聊天历史
    private getLoadChat(bytes):any{
        return proto.Chat.LoadChatResponse.decode(bytes);
    }

    private getPlayerCount(bytes):any{
        return proto.Lobby.PlayerCount.decode(bytes);
    }

    /**
     * 处理相关业务逻辑
     */

    private receiveLoadChat(bytes){
        var loadChat:proto.Chat.LoadChatResponse = this.getLoadChat(bytes);
       if(loadChat)
            App.MessageCenter.dispatch(LobbyEvent.LOAD_CHAT_ACK,loadChat);
    }

    private receiveChangeChip(bytes){
        var changchip = this.getCommonReply(bytes);
        App.MessageCenter.dispatch(GameEvent.CHANGE_CHIPS_BACK,changchip);
    }

    private receiveHeart(bytes){
        var obj = this.getAutoID(bytes);
        //Log.debug("heartAck",obj);
    }
    //11
    private receiveLogin(bytes){
        var login:proto.CommonReply =this.getCommonReply(bytes);
        if(login)
           App.MessageCenter.dispatch(LobbyEvent.LOGIN_SUCCES,login);
           
       
    }

    private getLoginCode(login){
        // switch(login.code) {
        //     case proto.CommonReply.Code.SUCCESS:
        //         App.MessageCenter.dispatch(LobbyEvent.LOGIN_SUCCES,login);
        //         break;
        //     case proto.CommonReply.Code.ERR_SERVER_INTERNAL_ERROR : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_500");
        //         break;
        //     case proto.CommonReply.Code.ERR_AUTHFAIL : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_401");
        //         break;
        //     case proto.CommonReply.Code.ERR_USER_UNUSABLE : 
        //         App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_6");
        //         break;
        // }
    }

    private receiveLogout(bytes){
        var logout = this.getCommonReply(bytes);
    }
    //600
    private receiveLobbyPlayerInfo(bytes){
       HallDataCtrl.instance.setLobbyPlayer(this.getLobbyUserSnapshot(bytes));
       App.MessageCenter.dispatch(ServerEvent.GET_LOBBY_PLAYER_INFO);
    }
    //601
    private receiveLiveVideoUrl(bytes){
        var liveVideoUrl = this.getStr(bytes);
        //Log.debug("liveVideoUrl",liveVideoUrl);
    }
    //602
    private receiveLobbyTableInfo(bytes){
        var  lobbyTableInfo = this.getLobbyTableSanpshot(bytes);
        if(lobbyTableInfo.tableID && lobbyTableInfo.tableID != 0) {
            LobbyTableInfoCtrl.instance.setLobbyTableInfo(lobbyTableInfo);
    	}
    }
    //603
    private receivePlayerCountInfo(bytes){
        var playerCount:proto.Lobby.PlayerCount = this.getPlayerCount(bytes);
        HallDataCtrl.instance.setPlayerCount(playerCount.count);
        App.MessageCenter.dispatch(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO);
        
    }

    private receiveChainPrePare(bytes){
        var enterchainTable = this.getPrepareReply(bytes);
    }

    private receiveJoinTableLogin(bytes){
        var joinTable = this.getCommonReply(bytes);
    }

    // private receiveGameExit(bytes){
    // }

    private receiveGameTableStatus(bytes){
        var gamestatus = this.getGameTableStatus(bytes);
        App.MessageCenter.dispatch(ServerEvent.GET_GAME_STATUS , gamestatus)
    }

    private receiveGameTableConfig(bytes){
        var  gameTableConfig = this.getGameTableConfig(bytes);
        // console.log(gameTableConfig , "gameTableConfig");
        App.MessageCenter.dispatch(RouletteEvent.GET_GAME_TABLE_CONFIG,gameTableConfig);
    }

    private receiveGameTableHistory(bytes){
        var tableHistory = this.getGameTableHistory(bytes);
         App.MessageCenter.dispatch(ServerEvent.GET_GAME_TABLE_HISTORY,tableHistory);
         
    }

    
    private receiveGameUserSnapshot(bytes){
        var  gameUserInfo = this.getGameUserSanpshot(bytes);
        App.MessageCenter.dispatch(ServerEvent.GET_GAME_USER_INFO , gameUserInfo);
        //Log.debug(gameUserInfo);
    }

    private receiveGamVirtualTable(bytes){
        var virtualTable = this.getGameVirtualTable(bytes);
        // console.log(virtualTable , "进桌获取信息");
        App.MessageCenter.dispatch(ServerEvent.UPDATE_VIRTUAL_TABLE , virtualTable);
    }

    private receiveGamVirtualTableBet(bytes){
        var  virtualTableBet = this.getGameVirtualTableBet(bytes);
        App.MessageCenter.dispatch(ServerEvent.UPDATE_VIRTUAL_TABLE_BET , virtualTableBet);
    }

    private receiveGameBetInfo(bytes){
        var  betInfo = this.getCommonReply(bytes);
        if(betInfo.code == 0){
            // App.MessageCenter.dispatch(GameEvent.CONFIRM_BET_AMOUNT);
            // GameDataCtrl.instance.isBet = true;
        }else{
            //弹出提示内容
            // alert(betInfo.desc)
        }

        switch (betInfo.code) {
            case proto.CommonReply.Code.SUCCESS:
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_0");
                App.MessageCenter.dispatch(GameEvent.CONFIRM_BET_AMOUNT);
                GameDataCtrl.instance.isBet = true;
                break;
            case proto.CommonReply.Code.ERR_EXCEED_LIMIT:
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_7");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
            case proto.CommonReply.Code.ERR_ACCOUT_LOCK:
                App.ToastViewManager.toastBaseView("TEXT_BET_RESULT_5");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
            default:
                App.ToastViewManager.toastBaseView("TEXT_MESSAGE_8");
                App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
                break;
        }
    }

    private receiveGameRecord(bytes){
        var  gameRecord = this.getGameResultReply(bytes);
		App.MessageCenter.dispatch(GameEvent.GET_GAMERECORD,gameRecord);
    }

    private receiveReportWinlose(bytes){
        var  winlose = this.getWinloseReply(bytes);
    }

    private receiveGameRoundCount(bytes){
        var roundCount = this.getRoundCount(bytes);
    }
    
    private receiveServerMessagePush(bytes){
        var command = this.getCommonReply(bytes);
        switch(command.code) {
            case proto.CommonReply.Code.ERR_OTHER_LOGIN:
                App.ToastViewManager.toastServerView("TEXT_OUT");
                break;
            case proto.CommonReply.Code.ERR_LAST_3_GAME:
                App.ToastViewManager.toastTextView("TEXT_Last_3_Times");
                break;
            case proto.CommonReply.Code.ERR_KICKED:
                var game=HallDataCtrl.instance.getLoadGameData;
                App.GameServer.sendLeaveTable(game.getTableID,game.getGameType);
                GameSceneCtrl.instance.toHallScene();
                break;
        }
    }

    private receiveAnnounce(bytes){
        this.getAnnouncePush(bytes);
    }

    private receiveGameChatAck(bytes){
        var  command:proto.CommonReply = this.getCommonReply(bytes);
        if(command)
            App.MessageCenter.dispatch(GameEvent.GAME_CHAT_SUCCES,command);
        
        
    }

    private receiveGameChatPush(bytes){
        var chatVOList:proto.Chat.ChatVOList = this.getChatVOList(bytes);
        if(chatVOList)
            App.MessageCenter.dispatch(GameEvent.GAME_CHAT_PUSH,chatVOList);

    }

    private receiveReward(bytes){
        var result = this.getRewardAnchor(bytes);
        if(result.code == 0){
            App.MessageCenter.dispatch(RouletteEvent.GET_REWARD_ANCHOR);
            App.ToastViewManager.toastTextView("TEXT_REWARD_SUCCESSFUL");
        }else if(result.code == 2){
            App.ToastViewManager.toastTextView("TEXT_BET_RESULT_4");
        }else{
            App.ToastViewManager.toastTextView("TEXT_REWARD_FAILURE");
        }
    }

    /**
     * 消息解析
     * @param msg
     */
    public decode(msg: any): any {
       
        var msgID = msg.readInt();
        var command = msg.readShort();
        var len = msg.byteLength;
       

        var byteArray: egret.ByteArray = new egret.ByteArray();
        var buffer = msg.readBytes(byteArray);

        var obj: any = {};
        
        App.DebugUtils.start("Protobuf Decode");
        //obj.body = proto.AutoID.decode(byteArray.bytes);
        this.decodeDetail(command,byteArray.bytes);
        App.DebugUtils.stop("Protobuf Decode");
        //Log.debug("收到数据：",command,obj);
        return obj;
    }
    /**
     * 消息封装
     * @param msg
     */
    public encode(msg: any): any {
        //var msgID = this.getMsgID(msg.key);
        var msgClass = this.getMsgClass(msg.key);
        var msgBody = msgClass.fromObject(msg.body);
        var msgBuffer = msgClass.encode(msgBody).finish();

        App.DebugUtils.start("Protobuf Encode");
        var bodyBytes: egret.ByteArray = new egret.ByteArray(msgBuffer);
        App.DebugUtils.stop("Protobuf Encode");
        // Log.debug("发送数据：", msg.body);

        var sendMsg: egret.ByteArray = new egret.ByteArray();
        sendMsg.writeInt(this.heartCount);
        sendMsg.writeShort(msg.command);
        sendMsg.writeBytes(bodyBytes);

        this.heartCount++;
        return sendMsg;
    }
}