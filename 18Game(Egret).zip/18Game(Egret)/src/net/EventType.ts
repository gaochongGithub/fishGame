
	class ServerEvent{
		/**
		 * 大厅用户事件
		 */
		public static GET_LOBBY_PLAYER_INFO:string = "GET_LOBBY_PLAYER_INFO";
		/**
		 * 大厅状态事件
		 */
		public static GET_LOBBY_TABLE_INFO:string = "GET_LOBBY_TABLE_INFO";
		/**
		 * 大厅用户人数事件
		 */
		public static GET_LOBBY_PLAYERCOUNT_INFO:string = "GET_LOBBY_PLAYERCOUNT_INFO";
		/**
		 * 游戏状态事件
		 */
		public static GET_GAME_STATUS:string = "GET_GAME_STATUS";
		/**
		 * 游戏桌面信息事件
		 */
		public static GET_GAME_TABLE_HISTORY:string = "GET_GAME_TABLE_HISTORY";
		/**
		 * 游戏用户信息事件
		 */
		public static GET_GAME_USER_INFO:string = "GET_GAME_USER_INFO";
		/**
		 * 游戏桌面配置事件
		 */
		public static GET_GAME_TABLE_CONFIG:string = "GET_GAME_TABLE_CONFIG";
		/**
		 * 游戏包间数据
		 */
		public static UPDATE_VIRTUAL_TABLE:string = "UPDATE_VIRTUAL_TABLE";
		/**
		 * 游戏包间下注数据
		 */
		public static UPDATE_VIRTUAL_TABLE_BET:string = "UPDATE_VIRTUAL_TABLE_BET";
		/**
		 * 下注成功事件
		 */
		public static BET_INFO_SUSSESS:string = "BET_INFO_SUSSESS";
		/**
		 * 下注超过限红事件
		 */
		public static ERR_EXCEED_LIMIT:string = "ERR_EXCEED_LIMIT";
		/**
		 * 下注出错事件
		 */
		public static BET_INFO_ERROR:string = "BET_INFO_ERROR";
		/**
		 * 游戏记录事件
		 */
		public static GET_GAME_RECORD:string = "GET_GAME_RECORD";
		/**
		 * 游戏报告事件
		 */
		public static GET_GAME_REPORTS:string = "GET_GAME_REPORTS";
		/**
		 * 公告事件
		 */
		public static GET_ANNOUNCE:string = "GET_ANNOUNCE";
	}


	class GlobalEvent{
		/**
		 * 改变语言事件
		 */
		public static CHANGE_LANGUAGE:string = "CHANGE_LANGUAGE";

		/**
		 * 超级6
		 */
		public static SET_SUPER6:string = "SET_SUPER6";
		
	}


	class LobbyEvent{
		/**
		 * 增加大厅路单事件
		 */
		public static ADD_LOBBY_ROAD_ITEM:string = "ADD_LOBBY_ROAD_ITEM";
		/**
		 * 登录成功
		 */
		public static LOGIN_SUCCES:string = "LOGIN_SUCCES";
		/**
		 * 选择限红
		 */
		public static SHOW_LIMIT_VIEW:string = "SHOW_LIMIT_VIEW";
		public static LIMIT_CHOOSE:string = "LIMIT_CHOOSE";
		/**
		 * 聊天记录
		 */
		public static LOAD_CHAT_ACK:string = "LOADCHAT_ACK";
		/**
		 * 加载完成事件
		 */
		public static LOAD_GAME_ACK:string = "LOADGAME_ASK";
		/**
		 * 音效音乐修改
		 */
		public static MUISC_SOUND_CHANGE:string = "MUISC_SOUND_CHANGE";

	}


	class GameEvent{
		/**
		 * 游戏洗牌事件
		 */
		public static GAME_STATUS_SHUFFLE:string = "GAME_STATUS_SHUFFLE";
		/**
		 * 游戏开始事件
		 */
		public static GAME_STATUS_START:string = "GAME_STATUS_START";
		/**
		 * 停止下注
		 */
		public static GAME_STATUS_STOP:string = "GAME_STATUS_STOP";
		/**
		 * 发牌事件
		 */
		public static SHOW_POKER:string = "SHOW_POKER";
		/**
		 * 游戏场数事件
		 */
		public static GET_GAME_STAGE_INNING:string = "GET_GAME_STAGE_INNING";
		/**
		 * 游戏倒计时事件
		 */
		public static GET_GAME_TIME:string = "GET_GAME_TIME";
		/**
		 * 游戏结算事件
		 */
		public static GET_GAME_STAGE_PAYOUT:string = "GET_GAME_STAGE_PAYOUT";
		/**
		 * 休息等待状态 
		 */
		public static GAME_STATUS_OK:string = "GAME_STATUS_OK";
		/**
		 * 下注事件
		 */
		public static ADD_BETAREA_AND_BETAMOUNT:string = "ADD_BETAREA_AND_BETAMOUNT";
		/**
		 * 获取当前筹码事件
		 */
		public static GET_CURRENT_BET_CHIP_NUM:string = "GET_CURRENT_BET_CHIP_NUM";
		/**
		 * 设置当前使用的筹码组事件
		 */
		public static SET_USING_CHIP_GROUP:string = "SET_USING_CHIP_GROUP";
		/**
		 * 设置筹码确认按钮能否下注事件
		 */
		public static SET_CHIPS_CONFIRM_BTN:string = "SET_CHIPS_CONFIRM_BTN";
		/**
		 * 取消下注事件
		 */
		public static CANCEL_BET_AMOUNT:string = "CANCEL_BET_AMOUNT";
		/**
		 * 确认下注事件
		 */
		public static CONFIRM_BET_AMOUNT:string = "CONFIRM_BET_AMOUNT";
		/**
		 * 确认是否已经下注
		 */
		public static ASK_IS_BET:string = "ASK_IS_BET";
		/**
		 * 设置筹码成功
		 */
		public static SET_CHIPS_SUCCESS:string = "SET_CHIPS_SUCCESS";
		/**
		 * 获取玩家网络质量
		 */
		public static GET_PLAYER_NETWORK:string = "GET_PLAYER_NETWORK";
		/**
		 * 退出桌号
		 */
		public static QUITE_TABLE:string = "QUITE_TABLE";
		/**
		 * 发送聊天
		 */
		public static GAME_CHAT_PUSH:string = "GAME_CHAT_PUSH";
		/**
		 * 发送聊天成功
		 */
		public static GAME_CHAT_SUCCES:string = "GAME_CHAT_SUCCES";
		/**
		 *发送表情
		 */
		public static GAME_CHAT_BQ:string = "GAME_CHAT_BQ";
		/**
		 *重复下注
		 */
		public static REBET_BET_AMOUNT:string = "REBET_BET_AMOUNT";
		/**
		 *筹码变化
		 */
		public static ALL_CHIPS_CHANGE:string = "ALL_CHIPS_CHANGE";
		/**
		 *筹码修改返回变化
		 */
		public static CHANGE_CHIPS_BACK:string = "CHANGE_CHIPS_BACK";
		/**
		 *记录
		 */
		public static GET_GAMERECORD:string = "GET_GAMERECORD";
		/**
		 * 显示选择筹码界面
		 */
		public static SHOW_ALLCHIPS:string = "SHOW_ALLCHIPS";

		
	}

	class RouletteEvent{
		/**
		 * 游戏状态
		 */
		public static GAME_STATE_START:string = "GAME_STATE_START";
		/**
		 * 下注去是否可点击
		 */
		public static SET_BET_BTN_CAN_CLICK:string = "SET_BET_BTN_CAN_CLICK";
		/**
		 * 游戏状态OK
		 */
		public static GAME_STATUS_OK:string = "GAME_STATUS_OK";
		/**
		 * 获取游戏结果
		 */
		public static GET_GAME_RESULT:string = "GET_GAME_RESULT";
		/**
		 * 获取结果的值
		 */
		public static RESULT_BET_BTN_ADD_MASK:string = "RESULT_BET_BTN_ADD_MASK";
		/**
		 * 下注筹码
		 */
		public static ADD_BETAREA_AND_BETAMOUNT:string = "ADD_BETAREA_AND_BETAMOUNT";
		/**
		 * 取消没有确定的下注筹码
		 */
		public static REMOVE_UNCONFIRM_CHIP:string = "REMOVE_UNCONFIRM_CHIP";
		/**
		 * 确认下注
		 */
		public static CONFIRM_CHIP:string = "CONFIRM_CHIP";
		/**
		 * 停止下注
		 */
		public static GAME_STATE_STOP:string = "GAME_STATE_STOP";
		/**
		 * 获取桌号信息
		 */
		public static GET_GAME_TABLE_CONFIG:string = "GET_GAME_TABLE_CONFIG";
		/**
		 * 发送重复下注数据
		 */
		public static SEND_REPEAT_DATA:string = "SEND_REPEAT_DATA";
		/**
		 * 小费打赏成功
		 */
		public static GET_REWARD_ANCHOR:string = "GET_REWARD_ANCHOR";
		/**
		 * 法式下注区
		 */
		public static FRENCH_CLICK_BET_BTN:string = "FRENCH_CLICK_BET_BTN";
		public static FRENCH_CLICK_END_BET_BTN:string = "FRENCH_CLICK_END_BET_BTN";
		public static FRENCH_CLICK_BET_DATA:string = "FRENCH_CLICK_BET_DATA";
		/**
		 * 手机端法式下注区
		 */
		public static MOBILE_FRENCH_AREA:string = "MOBILE_FRENCH_AREA";
		/**
		 * 点击下注
		 */
		public static BEGIN_CLICK_BET_AREA:string = "GET_CLICK_BET_AREA";
		public static END_CLICK_BET_AREA:string = "END_CLICK_BET_AREA";
	}

	class RecordEvent{
		/**
		 *设置日期表日期事件
		 */
		public static GET_CALENDAR_DATE:string = "GET_CALENDAR_DATE";
		/**
		 *设置日期表日期事件
		 */
		public static SET_CALENDAR_DATE:string = "SET_CALENDAR_DATE";
		/**
		 *设置游戏类型事件
		 */
		public static SET_GAME_TYPE:string = "SET_GAME_TYPE";
		/**
		 *设置游戏记录日期事件
		 */
		public static SET_GAMERECORD_DATA:string = "SET_GAMERECORD_DATA";
		/**
		 *翻页事件
		 */
		public static CHANGE_PAGEINDEX:string = "CHANGE_PAGEINDEX";
		/**
		 *初始化页面事件
		 */
		public static SET_PAGEINDEX:string = "SET_PAGEINDEX";
		/**
		 *设置页面总数事件
		 */
		public static SET_PAGE_TOTALCOUNT:string = "SET_PAGE_TOTALCOUNT";
	}


	class VideoEvent{
		/**
		 * 更新视频事件
		 */
		public static UPDATE_VIDEO:string = "UPDATE_VIDEO";
		/**
		 * 修改视频线路事件
		 */
		public static CHANGE_VIDEO_LINE:string = "CHANGE_VIDEO_LINE";
		/**
		 * 修改视频清晰度
		 */
		public static CHANGE_VIDEO_TYPE:string = "CHANGE_VIDEO_TYPE";
		/**
		 * 播放
		 */
		public static PLAYING_VIDEO:string = "PLAYING_VIDEO";
		/**
		 * 多台模式切换
		 */
		public static TABLE_CHANGE_VIDEO:string = "TABLE_CHANGE_VIDEO";
	}


	class ReportEvent{
		/**
		 * 设置日期表日期事件
		 */
		public static SET_CLICK_DATE:string = "SET_CLICK_DATE";
		/**
		 * 设置开始日期事件
		 */
		public static SET_REPORTS_START_DATE:string = "SET_REPORTS_START_DATE";
		/**
		 * 设置结束日期事件
		 */
		public static SET_REPORTS_END_DATE:string = "SET_REPORTS_END_DATE";
	}

	class MyMouseEvent{
		/**
		 *下注去鼠标点击
		 */
		public static MOUSE_OVER_BET_BTN:string = "MOUSE_OVER_BET_BTN";
		/**
		 *下注去鼠标离去
		 */
		public static MOUSE_OUT_BET_BTN:string = "MOUSE_OUT_BET_BTN";

		/**
		 * 法式下注区
		 */
		public static FRENCH_MOUSE_OVER_BET_BTN:string = "FRENCH_MOUSE_OVER_BET_BTN";
		/**
		 * 法式下注去鼠标离去
		 */
		public static FRENCH_MOUSE_OUT_BET_BTN:string = "FRENCH_MOUSE_OUT_BET_BTN";
		/**
		 * 法式下注区数据
		 */
		public static FRENCH_MOUSE_OVER_BET_DATA:string = "FRENCH_MOUSE_OVER_BET_DATA";
		/**
		 * 法式下注区数据
		 */
		public static FRENCH_MOUSE_OUT_BET_DATA:string = "FRENCH_MOUSE_OUT_BET_DATA";
		
	}
