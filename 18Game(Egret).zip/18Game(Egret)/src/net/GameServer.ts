class GameServer extends SingtonClass{
	public constructor() {
		super();
	}

	public connectServer(){
		App.Socket.connect();
		App.MessageCenter.addListener(SocketConst.SOCKET_CONNECT, () => {
            Log.debug("与服务器连接上");
            App.TimerManager.doTimer(3000, 0,this.sendAutoID, this);
            //this.sendLogin();
        }, this);
	}

	public sendAutoID(){
		var msg: any = {};
        msg.key = "proto.AutoID";
        msg.command = proto.Command.client_heart_beat;
        msg.body = {
            id: 0,
        };
        App.Socket.send(msg);
	}

	public sendLogin(name:string,pwd:string,way:string,ip:string,platform:any,version:string,time:any){
		var msg:any ={};
		msg.key = "proto.UserRequest.LobbyLogin";
		msg.body ={
			name:name,
			passwd:md5.getSingtonInstance().hex_md5(pwd),
			way:way,
			ip:ip,
			platform:platform,
			version:version,
			time:time
		};
		msg.command = proto.Command.user_lobby_login;
		App.Socket.send(msg);
	}

	//发送筹码组
	public sendchipGroup(chipGroup:any,selectedLimit:any){
		var msg:any ={};
		msg.key = "proto.Lobby.ChangeChipGroup";
		msg.body ={
			chipgroup:chipGroup,
			selectedLimit:selectedLimit,
		};
		msg.command = proto.Command.lobby_change_chipgroup;
		App.Socket.send(msg);
	}

	//大厅登出
	public sendLobbyLogout(){
		var msg:any ={};
		msg.key = "proto.UserRequest.LobbyLogout";
		msg.body ={
			
		};
		msg.command = proto.Command.user_lobby_logout;
		App.Socket.send(msg);
	}

	public sendGameLogin(){

	}

	//进入连环桌前拉取数据
	public sendChainPrepare(){

	}

	//进桌
	public sendJoinTable(gameType:proto.GameType,tableID:number,joinType:proto.UserRequest.JoinType){
		var msg:any ={};
		msg.key = "proto.Game.JoinTable";
		msg.body ={
			gameType:gameType,
			tableID:tableID,
			joinType:joinType
		};
		msg.command = proto.Command.game_join_table;
		App.Socket.send(msg);
	}

	//离桌
	public sendLeaveTable(tableID:number,gameType:proto.GameType){
		var msg:any ={};
		msg.key = "proto.Game.LeaveTable";
		msg.body ={
			gameType:gameType,
			tableID:tableID,
		};
		msg.command = proto.Command.game_leave_table;
		App.Socket.send(msg);
	}

	//退出游戏
	public sendGameExit(){

	}

	//下注
	public sendBet(tableID:number,subtype:proto.Game.Subtype,detail:{ [k: string]: number },selectedLimit:number){
		var msg:any ={};
		msg.key = "proto.Game.Bet";
		msg.body ={
			tableID:tableID,
			subtype:subtype,
			detail:detail,
			selectedLimit:selectedLimit
		};
		msg.command = proto.Command.game_bet;
		App.Socket.send(msg);
	}

	//发送Report.GameRecord数据
	public sendGameRecord(starttime:number,endtime,gameType:number,tableID:number,shoe:number,pageSize:number,pageIndex:number){
		var msg:any ={};
		msg.key = "proto.Report.GameResult";
		msg.body ={
			starttime:starttime,
			endtime:endtime,
			gameType:gameType,
			tableID:tableID,
			shoe:shoe,
			pageSize:pageSize,
			pageIndex:pageIndex
		};
		msg.command = proto.Command.report_game_report;
		App.Socket.send(msg);
	}

	//报表查询
	public sendReportWinlose(starttime:number,endtime:number){
		var msg:any ={};
		msg.key = "proto.Report.WinLose";
		msg.body ={
			starttime:starttime,
			endtime:endtime
		};
		msg.command = proto.Command.report_winlose;
		App.Socket.send(msg);
	}

	//发送聊天数据
	public sendChat(tableId:number,message:string){
		var msg:any ={};
		msg.key = "proto.Chat.ChatReq";
		msg.body ={
			tableId:tableId,
			message:message
		};
		msg.command = proto.Command.game_chat;
		App.Socket.send(msg);
	}

	//发送小费
	public sendReward(tableId:number,type:number,amount:number){
		
		var msg:any ={};
		msg.key = "proto.Game.Tip";
		msg.body ={
			tableID:tableId,
			type:type,
			amount:amount
		};
		msg.command = proto.Command.game_tip;
		App.Socket.send(msg);
	}

	//请求历史聊天记录
	public loadChatReq(tableId:number){
		var msg:any ={};
		msg.key = "proto.Chat.LoadChatReq";
		msg.body ={
			tableId:tableId,
		};
		msg.command = proto.Command.game_load_chat;
		App.Socket.send(msg);
	}
}