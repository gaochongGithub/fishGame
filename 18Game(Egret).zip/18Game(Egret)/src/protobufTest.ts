class protobufTest {
	public constructor() {
	}
}