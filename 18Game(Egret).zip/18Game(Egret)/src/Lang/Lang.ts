class Lang {
	public static ZH: string = "ZH";
	public static EN: string = "EN";
	public static JA: string = "JA";
	public static KO: string = "KR";

	//当前语言类型
	public static kind: string = "ZH";

	private static obj: Object = new Object();

	private static setKind(kind) {
		this.kind = kind;
		setCookie("LANGUAGE", this.kind);
	}

	public static init(kind: string): void {
		// Lang.obj[kind] = RES.getRes(kind);
		this.obj = RES.getRes('Lang_json');
		this.setKind(kind);
	}
	//切换语言
	public static switchKind(kind: string): void {
		// if (!Lang.obj[kind]) {
		// 	RES.getResAsync(kind, function (data, key) {
		// 		Lang.obj[kind] = data;
		// 		Lang.kind = kind;
		// 		EventPoster.getDispatcher().dispatchEventWith(MyEvent.LANG_CHANGE);
		// 		egret.log(Lang.getStr('login'));
		// 	}, this);
		// } else {
		// 	if (Lang.kind != kind) {
		// 		EventPoster.getDispatcher().dispatchEventWith(MyEvent.LANG_CHANGE);
		// 	}
		// }

	}

	public static changeLang(kind: string) {
		if (Lang.kind != kind) {
			this.setKind(kind);

			//EventPoster.getDispatcher().dispatchEventWith(MyEvent.LANG_CHANGE);
			App.MessageCenter.dispatch(GlobalEvent.CHANGE_LANGUAGE);
		}
	}

	public static getStr(key): string {
		//return Lang.Const[this.kind + key];
		return this.obj[this.kind][key];
	}

}