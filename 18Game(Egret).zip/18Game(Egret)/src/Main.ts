//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
class Main extends eui.UILayer {
    private uname:any;
    private pwd:any;
    private version:any;
    private chargeUrl:any;
    private loadingView:LoadingUI;


    protected createChildren(): void {
        super.createChildren();
         
        // egret.lifecycle.addLifecycleListener((context) => {
        //     // custom lifecycle plugin
        // })

        // egret.lifecycle.onPause = () => {
        //     egret.ticker.pause();
        // }

        // egret.lifecycle.onResume = () => {
        //     egret.ticker.resume();
        // }

        //inject the custom material parser
        //注入自定义的素材解析器
        
        let assetAdapter = new AssetAdapter();
        egret.registerImplementation("eui.IAssetAdapter", new AssetAdapter());
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());

        
        this.runGame().catch(e => {
            console.log(e);
        })
    }

    private async runGame() {
        await this.loadResource()
        
        //临时注释
         const result = await RES.getResAsync("description_json")
         this.startAnimation(result);
         await platform.login();
         const userInfo = await platform.getUserInfo();
         //console.log(userInfo);

    }

    private async loadResource() {
        try {
            if(egret.Capabilities.isMobile){
                 this.stage.setContentSize(812, 375);
                // this.stage.width=812;
                // this.stage.height=375;
            }else{
                // this.stage.width=1920;
                // this.stage.height=1080;
                 this.stage.setContentSize(1920, 1080);
            }
            this.loadingView = new LoadingUI();
            await RES.loadConfig("resource/default.res.json", "resource/");
            this.stage.addChild(this.loadingView);
            this.loadingView.createView(this.stage);
            await this.loadTheme();
            await RES.loadGroup("preload", 0, this.loadingView);
            
            await RES.loadGroup("hall", 0);
            await RES.loadGroup("gdTips", 0);
            await RES.loadGroup("moblieHall", 0);
            await RES.loadGroup("chat", 0);
            
            await RES.loadGroup("baccarat", 0);
            //轮盘资源
            await RES.loadConfig("resource/resource_roulette.json", "resource/");
            await RES.loadGroup("reward", 0);
            await RES.loadGroup("french_bet", 0);
            await RES.loadGroup("classic_bet", 0);
            await RES.loadGroup("bottom_info", 0);
            
            //通用资源
            await RES.loadConfig("resource/resource_common.json", "resource/");
            await RES.loadGroup("common", 0);
            this.loadingView.setBarCount(90);
            //音效资源
             await RES.loadGroup("sound", 0);
            
            //初始化游戏管理
            GameSceneCtrl.instance.init(this.stage);

			//await RES.loadConfig("resource/global.json", "resource/");
			App.Init();

            App.ToastViewManager.parentLayer=this.stage;

            this.setLocalData();
            App.GameServer.connectServer();
            this.loadingView.setBarCount(100);

            App.MessageCenter.addListener(SocketConst.SOCKET_START_RECONNECT,()=>{
                var name=egret.localStorage.getItem("uname");
                var pwd=egret.localStorage.getItem("pwd");
                var version=egret.localStorage.getItem("version");
                App.GameServer.sendLogin(name, pwd,"-1","",1, this.version,0)
            },this);

            App.MessageCenter.addListener(LobbyEvent.LOGIN_SUCCES,(login:proto.CommonReply) => {
                switch(login.code) {
                    case proto.CommonReply.Code.SUCCESS:
                        egret.localStorage.setItem("uname",this.uname);
                        egret.localStorage.setItem("pwd",this.pwd);
                        egret.localStorage.setItem("version",this.version);
                        this.chargeUrl&&egret.localStorage.setItem("chargeUrl",this.chargeUrl); 
                        
                        this.stage.removeChild(this.loadingView);
                        this.createGameScene();
                        
                        break;
                    case proto.CommonReply.Code.ERR_SERVER_INTERNAL_ERROR : 
                        App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_500");
                        break;
                    case proto.CommonReply.Code.ERR_AUTHFAIL : 
                        App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_401");
                        break;
                    case proto.CommonReply.Code.ERR_USER_UNUSABLE : 
                        App.ToastViewManager.toastServerView("TEXT_LOGIN_RESULT_6");
                        break;
            }
            },this);


            App.MessageCenter.addListener(SocketConst.SOCKET_CONNECT, () => {
                this.loadLogin();
            }, this);
            
        }
        catch (e) {
            console.error(e);
        }
    }


    //设置一些默认配置
    private setLocalData(){
        var lang=egret.localStorage.getItem("lang");
        if(lang){
            App.LangUtils.init(lang);
        }else{
            egret.localStorage.setItem("lang","ZH");
            App.LangUtils.init("ZH");
        }

        var super6=egret.localStorage.getItem("Super6");
        if(!super6)
            egret.localStorage.setItem("Super6","0");

        var isCanPlayVideo=egret.localStorage.getItem("isCanPlayVideo");
        if(!super6)
            egret.localStorage.setItem("isCanPlayVideo","1");

        
        
    }
    //获取url参数
    private getRequest(url):string {
        //var theRequest = new Object();
        var strs="";
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("paramStr")[1].substr(1);
            // for(var i = 0; i < strs.length; i ++) {
            //     theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            // }
        }
        return strs;
    }

    loadLogin() {
        var data:string="";
        if (egret.RuntimeType.WEB){
            // var Request = new Object();
            var url = window.location.search; 
            var data = this.getRequest(url);
            //var data=Request["paramStr"]; 
        }
        var version = "web";
        if (App.DeviceUtils.IsNative)
            version = "app";
        else if(App.DeviceUtils.IsMobile)
            version = "mobile";
        if(!data){
           //App.GameServer.sendLogin("cmkj_test14","aaa111","-1","",1,"web",0); 
           if(App.GlobalData.IsDebug){
               App.GameServer.sendLogin("cmkj_t1013","aaa111","-1","",1,"web",0); 
           }else{
                this.loadingView.setLoginView(this,function(name:string,pwd:string){
                App.GameServer.sendLogin(name, pwd,"-1","",1, this.version,0)
            });
           }
        }else{
            //console.log("paramStr:"+data);
            var userData=App.Base64.decode(data).split("&");
            //console.log("paramStr:"+Base64.decoder(data));
            var lang=userData[0].split("=")[1];
            this.uname=userData[1].split("=")[1];
            this.pwd=userData[2].split("=")[1];
            this.version=version
            var time=userData[3].split("=")[1];
            this.chargeUrl=userData[4].split("=")[1];
            if(this.chargeUrl){
                this.chargeUrl= App.Base64.decode(this.chargeUrl);
            }
            App.GameServer.sendLogin(this.uname, this.pwd,"-1","",1, this.version,time)
        }
        // if (cc.sys.isNative){
        //     cmkj.DataCtrl.setLocalData("isLoginScene",1);
        // }
        // cmkj.EventCtrl.sendNormalEvent(cmkj.EventType.Global.LOADED_URLSUCCESS);
       
    }

    private loadTheme() {
        return new Promise((resolve, reject) => {
            // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            let theme = new eui.Theme("resource/default.thm.json", this.stage);
            theme.addEventListener(eui.UIEvent.COMPLETE, () => {
                resolve();
            }, this);

        })
    }

    private textfield: egret.TextField;
    /**
     * 创建场景界面
     * Create scene interface
     */
    protected createGameScene(): void {
        //启用舞台的鼠标支持
      mouse.enable(this.stage);
      if(App.DeviceUtils.IsMobile){
        GameSceneCtrl.instance.toMobileHallScene();
      }else{
        GameSceneCtrl.instance.toHallScene();
      }

        
       //
    }
    /**
     * 根据name关键字创建一个Bitmap对象。name属性请参考resources/resource.json配置文件的内容。
     * Create a Bitmap object according to name keyword.As for the property of name please refer to the configuration file of resources/resource.json.
     */
    private createBitmapByName(name: string): egret.Bitmap {
        let result = new egret.Bitmap();
        let texture: egret.Texture = RES.getRes(name);
        result.texture = texture;
        return result;
    }
    /**
     * 描述文件加载成功，开始播放动画
     * Description file loading is successful, start to play the animation
     */
    private startAnimation(result: Array<any>): void {
        let parser = new egret.HtmlTextParser();

        let textflowArr = result.map(text => parser.parse(text));
        let textfield = this.textfield;
        let count = -1;
        let change = () => {
            count++;
            if (count >= textflowArr.length) {
                count = 0;
            }
            let textFlow = textflowArr[count];

            // 切换描述内容
            // Switch to described content
            textfield.textFlow = textFlow;
            let tw = egret.Tween.get(textfield);
            tw.to({ "alpha": 1 }, 200);
            tw.wait(2000);
            tw.to({ "alpha": 0 }, 200);
            tw.call(change, this);
        };

        change();
    }

    /**
     * 点击按钮
     * Click the button
     */
    private onButtonClick(e: egret.TouchEvent) {
        let panel = new eui.Panel();
        panel.title = "Title";
        panel.horizontalCenter = 0;
        panel.verticalCenter = 0;
        this.addChild(panel);
    }
}
