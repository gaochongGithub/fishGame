class RecordItem extends ItemParent{
	private itemData:RecordModel;
	private oderDate:eui.Label;
	private oderNum:eui.Label;
	private tableID:eui.Label;
	private shoeId:eui.Label;
	private betsArea:eui.Label;
	private betsAmount:eui.Label;
	private result:eui.Label;
	private winloseAmount:eui.Label;
	private gameType:eui.Label;
	public constructor() {
		super();
	}
	dataChanged() {
		this.itemData=this.data;
		this.oderDate.text=this.itemData.getOderDate;
		this.oderNum.text=this.itemData.getOderNum;
		this.tableID.text=this.itemData.getTableID+"";
		this.shoeId.text=this.itemData.getShoeId+"";
		this.betsArea.text=this.itemData.getBetsArea;
		this.betsAmount.text=this.itemData.getBetsAmount+"";
		this.result.text=this.itemData.getResult;
		this.winloseAmount.text=this.itemData.getWinloseAmount+"";
		this.gameType.text=this.itemData.getGameType;


	}
	
}