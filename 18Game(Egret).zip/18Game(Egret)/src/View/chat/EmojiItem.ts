class EmojiItem extends ItemParent{
	public constructor() {
		super();
	}
	private emoji:eui.Label;

	dataChanged() {
		this.emoji.text=this.data;
	}
	
}