class EmojiView extends ComponentParent {
	private emoji_list:eui.List;
	private emoji_scroller:eui.Scroller;
	private bg:eui.Image;
	public constructor() {
		super();
	}

	itemChange(){
		var data=this.emoji_list.selectedItem;
		App.MessageCenter.dispatch(GameEvent.GAME_CHAT_BQ, data);
	}

	initView(){
		// 原始数组
		let dataArr:any[] = ["😐","😂","😪","😏","😊","😄","😜","😇","😫","😌","😙","😧","😷","😑","😶","😟","😰","😟","😎","😨","😆","😭","😉","😘","😅","😖","😡","😍","😲","😆"];
		// 转成eui数据
		let euiArr:eui.ArrayCollection = new eui.ArrayCollection(dataArr)
		this.emoji_list.dataProvider=euiArr;
		this.emoji_list.itemRenderer=EmojiItem;
		this.emoji_list.addEventListener(eui.ItemTapEvent.ITEM_TAP,this.itemChange,this);
	}
		
}