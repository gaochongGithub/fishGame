class RewardItem extends ItemParent {
	public constructor() {
		super();
	}
}