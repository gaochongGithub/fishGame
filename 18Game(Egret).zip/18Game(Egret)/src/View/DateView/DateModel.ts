class DateModel {
	public constructor() {
	}
	private years:number;
	private month:number;
	private day:number;

	public setYears(years:number){
		this.years=years
	}

	public getYears(){
		return this.years;
	}

	public setMonth(month:number){
		this.month=month
	}

	public getMonth(){
		return this.month;
	}

	public setDay(day:number){
		this.day=day
	}

	public getDay(){
		return this.day;
	}

}