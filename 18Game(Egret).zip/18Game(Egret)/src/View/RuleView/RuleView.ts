class RuleView extends ComponentParent {
	private text_img:eui.Image;
	private closeBtn:eui.Image;
	public constructor() {
		super();
	}


	initEventListener(){
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onCloseBtn,this);
		
	
		
	}

	removeMyEventListener(){
		this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onCloseBtn,this);
	}


	private onCloseBtn(){
		App.ToastViewManager.clearAll();
	}

	initView(){
		this.horizontalCenter=0;
		this.verticalCenter=0;

		if(App.DeviceUtils.IsMobile){
			this.scaleX=0.5;
			this.scaleY=0.5;
		}
		this.initEventListener();
		var game=HallDataCtrl.instance.getLoadGameData;
		if(game){
			switch (game.getGameType){
				case proto.GameType.Baccarat:
					this.text_img.texture=RES.getRes("wz_png");
					break;
				case proto.GameType.Roulette:
					this.text_img.texture=RES.getRes("lp_png");
					break;
				default:
					this.text_img.texture=RES.getRes("wz_png");

			}
		}else{
			this.text_img.texture=RES.getRes("wz_png");
		}
	}
	
}