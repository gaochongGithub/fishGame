class SettingView extends ComponentParent {
	private langCheckBox:eui.CheckBox;
	private musicCheckBox:eui.CheckBox;
	private effectCheckBox:eui.CheckBox;
	private super6CheckBox:eui.CheckBox;
	private closeBtn:eui.Image;
	public constructor() {
		super();
	}

	initEventListener(){
		this.langCheckBox.addEventListener(egret.Event.CHANGE,this.onLangChange,this);
		this.musicCheckBox.addEventListener(egret.Event.CHANGE,this.onMusicChange,this);
		this.effectCheckBox.addEventListener(egret.Event.CHANGE,this.onEffectChange,this);
		this.super6CheckBox.addEventListener(egret.Event.CHANGE,this.super6Change,this);
		this.closeBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onCloseBtn,this);
	}

	removeMyEventListener(){
		this.langCheckBox.removeEventListener(egret.Event.CHANGE,this.onLangChange,this);
		this.musicCheckBox.removeEventListener(egret.Event.CHANGE,this.onMusicChange,this);
		this.effectCheckBox.removeEventListener(egret.Event.CHANGE,this.onEffectChange,this);
		this.super6CheckBox.removeEventListener(egret.Event.CHANGE,this.super6Change,this);
		this.closeBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onCloseBtn,this);
	}


	private onCloseBtn(){
		// if(this.parent){
		// 	this.parent.removeChild(this);
		// }
		App.ToastViewManager.clearAll();
	}

	private onLangChange(e:egret.Event){
		var lang:string;
		this.langCheckBox.selected?lang="ZH":lang="EN";
		App.LangUtils.changeLang(lang);
	}

	private onMusicChange(e:egret.Event){
		App.SoundManager.setBgOn(this.musicCheckBox.selected);
	}

	private onEffectChange(e:egret.Event){
		App.SoundManager.setEffectOn(this.effectCheckBox.selected);
	}

	private super6Change(e:egret.Event){
		egret.localStorage.setItem("Super6",this.super6CheckBox.selected?"1":"0");
		App.MessageCenter.dispatch(GlobalEvent.SET_SUPER6);
	}

	initView(){
		this.horizontalCenter=0;
		this.verticalCenter=0;

		if(App.DeviceUtils.IsMobile){
			this.scaleX=0.8;
			this.scaleY=0.8;
		}

		App.SoundManager.bgIsOn? this.musicCheckBox.selected=true:this.musicCheckBox.selected=false;
		App.SoundManager.effectIsOn? this.effectCheckBox.selected=true:this.effectCheckBox.selected=false;
		var super6=egret.localStorage.getItem("Super6");
		this.super6CheckBox.selected=super6=="1";	
		App.LangUtils.kind=="ZH"?this.langCheckBox.selected=true:this.langCheckBox.selected=false;

	}
	
}