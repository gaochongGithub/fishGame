class LobbyPlayer extends ModelParent{

	public constructor() {
		super();
	}
	balance:number;
	isChat:boolean;
	isTip:boolean;
	limits:boolean;
	moneysort:string;
	name:string;
	nick:string;
	uid:number;
	parentID:number
	playerType:number
	rouletteChips:Object;
	sicoChips:Object;
	videoChips:Object;

	modelCustomPropertyMapper = function () {
       return{
		   "balance":"balance",
			"isChat":"isChat",
			"isTip":"isTip",
			"limits":"limits",
			"moneysort":"moneysort",
			"name":"name",
			"nick":"nick",
			"uid":"uid",
			"parentID":"parentID",
			"playerType":"playerType",
			"rouletteChips":"rouletteChips",
			"sicoChips":"sicoChips",
			"videoChips":"videoChips",
       }
    }

    modelContainerPropertyGenericClass = function () {
       return{
            
       }
    }

	init(data){
		this.modelAddProperty.call(data);
	}
}