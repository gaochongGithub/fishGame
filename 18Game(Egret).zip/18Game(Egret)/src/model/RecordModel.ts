class RecordModel {
	private oderDate:string;
	private oderNum:string;
	private tableID:number;
	private shoeId:string;
	private betsArea:string;
	private betsAmount:string;
	private result:string;
	private winloseAmount:number;
	private gameType:string;

	public setOderDate(oderDate:string){
		this.oderDate=oderDate;
	}

	public get getOderDate(){
		return this.oderDate;
	}

	public setOderNum(oderNum:string){
		this.oderNum=oderNum;
	}

	public get getOderNum(){
		return this.oderNum;
	}

	public setTableID(tableID:number){
		this.tableID=tableID;
	}

	public get getTableID(){
		return this.tableID;
	}

	public setShoeId(shoeId:string){
		this.shoeId=shoeId;
	}

	public get getShoeId(){
		return this.shoeId;
	}

	public setBetsArea(betsArea:string){
		this.betsArea=betsArea;
	}

	public get getBetsArea(){
		return this.betsArea;
	}

	public setBetsAmount(betsAmount:string){
		this.betsAmount=betsAmount;
	}

	public get getBetsAmount(){
		return this.betsAmount;
	}

	public setResult(result:string){
		this.result=result;
	}

	public get getResult(){
		return this.result;
	}

	public setWinloseAmount(winloseAmount:number){
		this.winloseAmount=winloseAmount;
	}

	public get getWinloseAmount(){
		return this.winloseAmount;
	}

	public setGameType(gameType:string){
		this.gameType=gameType;
	}

	public get getGameType(){
		return this.gameType;
	}


}