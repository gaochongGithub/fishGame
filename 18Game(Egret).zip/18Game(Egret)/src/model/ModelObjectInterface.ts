interface ModelObjectInterface {
	//遍历属性
	modelAddProperty:(data:any)=>void;
	//参数转实体参数
	modelCustomPropertyMapper:()=>Object;
	//转类
	modelContainerPropertyGenericClass:()=>Object;


}