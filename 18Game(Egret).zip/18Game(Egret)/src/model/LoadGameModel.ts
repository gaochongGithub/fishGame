class LoadGameModel {
	public constructor() {
	}
	private gameType:number;
    private joinType:number;
	private tableID:number;
	private subType:number;
	private limitRed:string;
	private limitRedID:number;
	private chip:Array<any>;
	private allChip:Array<any>;
	private dealerImage:string;
	private playerType:number;
	private isCanPlayVideo:boolean;

	public setIsCanPlayVideo(isCanPlayVideo:boolean){
		this.isCanPlayVideo=isCanPlayVideo;
	}

	public get getIsCanPlayVideo(){
		return this.isCanPlayVideo;
	}

	public setGameType(gameType:number){
		this.gameType=gameType;
	}

	public get getGameType(){
		return this.gameType;
	}

	public setJoinType(joinType:number){
		this.joinType=joinType
	}

	public get getJoinType(){
		return this.joinType;
	}

	public setSubType(subType:number){
		this.subType=subType
	}

	public get getSubType(){
		return this.subType;
	}

	public setTableID(tableID:number){
		this.tableID=tableID;
	}

	public get getTableID(){
		return this.tableID;
	}

	public setLimitRed(limitRed:string){
		this.limitRed=limitRed;
	}

	public get getLimitRed(){
		return this.limitRed
	}

	public setLimitRedID(limitRedID:number){
		this.limitRedID=limitRedID;
	} 

	public get getLimitRedID(){
		return this.limitRedID;
	}

	public setChip(chip:Array<any>){
		this.chip=chip;
	}

	public get getChip(){
		return this.chip;
	}

	public setAllChip(allChip:Array<any>){
		this.allChip=allChip;
	}

	public get getAllChip(){
		return this.allChip;
	}

	public setDealerImage(dealerImage:string){
		this.dealerImage=dealerImage;
	}

	public get getDealerImage(){
		return this.dealerImage;
	}

	public setPlayerType(playerType:number){
		this.playerType=playerType;

	}

	public get getPlayerType(){
		return this.playerType;
	}
}