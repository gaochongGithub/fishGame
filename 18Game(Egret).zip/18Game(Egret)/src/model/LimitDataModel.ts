class LimitDataModel {
	public constructor() {
	}
	private limitRedID:number;//当前限红id
	private limitRedCount:string;//限红值
	private limitRed:Array<any>;//限红组数据
	private allChips:Array<any>;//限红id的所有筹码
	private chips:Array<any>;//限红id的默认筹码

	public setLimitRedID(limitRedID:number){
		this.limitRedID=limitRedID;
	}

	public get getLimitRedID(){
		return this.limitRedID;
	}

	public setLimitRed(limitRed:Array<any>){
		this.limitRed=limitRed;
	}

	public get getLimitRed(){
		return this.limitRed;
	}


	public setAllChips(allChips:Array<any>){
		this.allChips=allChips;
	}

	public get getAllChips(){
		return this.allChips;
	}

	public setChips(chips:Array<any>){
		this.chips=chips;
	}

	public get getChips(){
		return this.chips;
	}

	public setLimitRedCount(limitRedCount:string){
		this.limitRedCount=limitRedCount;
	}

	public get getLimitRedCounts(){
		return this.limitRedCount;
	}

}