class GameHallItemModel{
	public constructor() {
	}
	private limitRedID:number;
	private gameType:number;
	private gameTable:number;
	private isShowView:boolean=false;
	private tableSnapshot:proto.Lobby.TableSnapshot;
	private allways:string;

	public setLimitRedID(limitRedID:number){
		this.limitRedID=limitRedID;
	}
	public get getLimitRedID(){
		return this.limitRedID;
	}

	public setTableSnapshot(tableSnapshot:proto.Lobby.TableSnapshot){
		this.tableSnapshot=tableSnapshot;
	}
	public get getTableSnapshot(){
		return this.tableSnapshot;
	}

	public setIsShwoView(isShowView:boolean){
		this.isShowView=isShowView;
	}

	public get getIsShowView(){
		return this.isShowView;
	}

	public setGameType(gameType:number){
		this.gameType=gameType;
	}

	public get getGameType(){
		return this.gameType;
	}

	public setGameTable(gameTable:number){
		this.gameTable=gameTable;
	}

	public get getGameTable(){
		return this.gameTable;
	}

	public setAllWays(allways:string){
		this.allways=allways;
	}

	public get getAllWays(){
		return this.allways;
	}


   
}