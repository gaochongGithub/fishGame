class LimitViewModel {
	public constructor() {
	}
	private gameType:number;
	private gameTable:number;
	private limitChoseID:number;//限红组ID
	private limitChoseCount:string;//限红组对应选中的限红值
	private isChose:boolean;//该限红组是否被选中

	public setLimitChoseID(limitChoseID:number){
		this.limitChoseID=limitChoseID;
	}

	public get getLimitChoseID(){
		return this.limitChoseID;
	}

	public setLimitChoseCount(limitChoseCount:string){
		 this.limitChoseCount=limitChoseCount;
	}

	public get getLimitChoseCount(){
		return this.limitChoseCount;
	}

	public setIsChose(isChose:boolean){
		this.isChose=isChose;
	}

	public get getIsChose(){
		return this.isChose;
	}

	public setGameType(gameType:number){
		this.gameType=gameType;
	}

	public get getGameType(){
		return this.gameType;
	}

	public setGameTable(gameTable:number){
		this.gameTable=gameTable;
	}

	public get getGameTable(){
		return this.gameTable;
	}
}