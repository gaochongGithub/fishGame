/**
 * 选择筹码界面
 */
class AllChipsView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/AllChipsViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnConfirm,this);
		this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnCancel,this);
		App.MessageCenter.addListener(GameEvent.ALL_CHIPS_CHANGE,this.chipsChange,this);
		//监听修改筹码后返回
		App.MessageCenter.addListener(GameEvent.CHANGE_CHIPS_BACK,this.getChangChipsBack,this);
		this.init();
	}

	private init(){
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GameEvent.ALL_CHIPS_CHANGE,this.chipsChange,this);
	}

	private getChangChipsBack(data:any){
		
		if(data.code==0){
			let gameType =HallDataCtrl.instance.getLoadGameData.getGameType;

			HallDataCtrl.instance.setChips(gameType,this.checkArr);
			App.MessageCenter.dispatch(GameEvent.SET_USING_CHIP_GROUP);
		}else{
			//提示修改筹码不成功
		}
	}

	private chipsChange(data:any){
		this.checkArr = MyUtils.deeCopy(data,this.checkArr);
	}

	private onClickBtnConfirm(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		let selectedLimitID = loadGameModel.getLimitRedID;
		App.GameServer.sendchipGroup(this.checkArr,selectedLimitID);
		console.log(this.checkArr,selectedLimitID);
		this.visible = false;
	}

	private onClickBtnCancel(){
		this.visible = false;
	}

	private onClickChipBtn(){

	}


	private chipBtn_1:OneBaseChipBtn;
	private chipBtn_2:OneBaseChipBtn;
	private chipBtn_3:OneBaseChipBtn;
	private chipBtn_4:OneBaseChipBtn;
	private chipBtn_5:OneBaseChipBtn;
	private chipBtn_6:OneBaseChipBtn;
	private chipBtn_7:OneBaseChipBtn;
	private chipBtn_8:OneBaseChipBtn;
	private chipBtn_9:OneBaseChipBtn;
	private chipBtn_10:OneBaseChipBtn;

	private btn_confirm:eui.Button;
	private btn_cancel:eui.Button;

	private checkArr:Array<any> = [];

}