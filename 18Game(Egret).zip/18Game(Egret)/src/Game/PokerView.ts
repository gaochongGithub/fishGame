/**
 * 扑克牌显示界面
 */
class PokerView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/PokerViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		
	}

	protected onAddtoStage(event:egret.Event) {
		this.init();
		App.MessageCenter.addListener(GameEvent.SHOW_POKER,this.showPoker,this);
		App.MessageCenter.addListener(GameEvent.GET_GAME_STAGE_PAYOUT,this.getPayoutEvent,this);
		App.MessageCenter.addListener(GameEvent.GAME_STATUS_OK,this.gameStatusOk,this);
		App.MessageCenter.addListener(GameEvent.GAME_STATUS_START,this.gameStatusStart,this);
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GameEvent.SHOW_POKER,this.showPoker,this);
		App.MessageCenter.removeListener(GameEvent.GET_GAME_STAGE_PAYOUT,this.getPayoutEvent,this);
		App.MessageCenter.removeListener(GameEvent.GAME_STATUS_OK,this.gameStatusOk,this);
		App.MessageCenter.removeListener(GameEvent.GAME_STATUS_START,this.gameStatusStart,this);
	}

	private gameStatusStart(){

		this.resetData();
		this.visible = false;

	}

	private gameStatusOk(){
		//数据重置
		//this.visible = false;
		//this.resetData();
	}

	private init(){
		this.visible = false;
		this.cardViewList.push(this.card_player_1);
		this.cardViewList.push(this.card_player_2);
		this.cardViewList.push(this.card_player_3);
		this.cardViewList.push(this.card_banker_1);
		this.cardViewList.push(this.card_banker_2);
		this.cardViewList.push(this.card_banker_3);
	}

	private resetData(){
		this.playerCard = 0;
		this.bankerCard = 0;
		this.playerNumberLabel.text = "";
		this.bankerNumberLabel.text = "";
		for(let i=0;i<this.cardViewList.length;i++){
			this.cardViewList[i].texture = RES.getRes("card_bg_png");
			this.cardViewList[i].visible = false;
		}
		this.group_banker_win.alpha = 0;
		this.group_player_win.alpha = 0;
		this.group_tie_win.alpha = 0;

		this.image_banker_win.alpha = 0;
		this.image_player_win.alpha = 0;
	}
	private playerCard: number = 0;//闲的点数
	private bankerCard: number = 0;//庄的点数

	private showPoker(cards: any){
	
		let cardsList = cards.split("@");
		if(!this.visible){
			this.visible = true
		}
		
		for(let i = 0;i<cardsList.length;i++){
			if (i > 5)
				break;
			if (!this.cardViewList[i].visible && cardsList[i]) {
				this.cardViewList[i].visible = true;
				let value = this.getCardNum(cardsList[i]);
				let type = this.getCardType(cardsList[i]);
				//console.log("--- -------" + "card_" + type + "_" + value + "_png");
				//this.cardViewList[i].texture = RES.getRes("card_" + type + "_" + value + "_png");
				this.showOneCard(this.cardViewList[i], "card_" + type + "_" + value + "_png");
				if (i < 3) {
					this.playerCard += this.getCardValue(cardsList[i]);
					this.playerCard = this.playerCard % 10;
				} else {
					this.bankerCard += this.getCardValue(cardsList[i]);
					this.bankerCard = this.bankerCard % 10;
				}
			}
			this.playerNumberLabel.text = this.playerCard.toString();
			this.bankerNumberLabel.text = this.bankerCard.toString();
		}
		
	}

	//翻牌动画
	private showOneCard(image: eui.Image, str: string) {

		//SoundEffectMgr.playSound("Card_Flip_mp3");
		egret.Tween.get(image, { loop: false })
			.to({ scaleX: 0 }, 500)
			.call(() => { image.texture = RES.getRes(str) })
			.to({ scaleX: 1 }, 500)
			.call(() => { });
	}

	private getPayoutEvent(data:any){
		let result = data.result;
		this.showWinResult(result);
		this.showResult(result);
	}

	private showWinResult(result){
		let resultTypeBanker:string = "abcdijkl";
		let reusltTypePlayer:string = "efghijkl";

		this.matchResult(result,resultTypeBanker,this.image_banker_win);
		this.matchResult(result,reusltTypePlayer,this.image_player_win);
	}

	private showResult(result){
		let resultBanker:string = "abcd";
		let reusltPlayer:string = "efgh";
		let reusltTie:string = "ijkl";
		this.matchResult(result,resultBanker,this.group_banker_win);
		this.matchResult(result,reusltPlayer,this.group_player_win);
		this.matchResult(result,reusltTie,this.group_tie_win);
	}

	private matchResult(result:string,resultAll:string,obj:any){
		for (var i = 0; i < resultAll.length; i++) {
            if(result && resultAll[i] == result) {
                obj.alpha = 1;
                break;
            }
        }
	}


	//最后点数
	private getCardValue(card: string) {

		var d: number = Math.floor(Number(card) / 10)
		if (d > 10) d = 0;
		return d;
	}

	/**
	 * 用于取对应图片(点数)
	 */
	private getCardNum(card: string) {
		if (card == "") return 0;
		var d: number = Math.floor(Number(card) / 10);
		return d;
	}
	/**
	 * 用于取对应图片(花色)
	 */
	private getCardType(card: string) {
		return Number(card) % 10;
	}


	private playerNumberLabel:eui.Label;
	private bankerNumberLabel:eui.Label;
	private card_player_1: eui.Image;
	private card_player_2: eui.Image;
	private card_player_3: eui.Image;
	private card_banker_1: eui.Image;
	private card_banker_2: eui.Image;
	private card_banker_3: eui.Image;
	private cardViewList: Array<eui.Image> = [];
	private image_player_win:eui.Image;
	private image_banker_win:eui.Image;

	private group_player_win:eui.Image;
	private group_banker_win:eui.Image;
	private group_tie_win:eui.Image;

}