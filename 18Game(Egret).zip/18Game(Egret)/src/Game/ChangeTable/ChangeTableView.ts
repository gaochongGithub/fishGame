class ChangeTableView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/ChangeTableViewSkin.exml";
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
	}

	private updateTables() {
		
		var  allTables = [];
		if(this.currentGameType==0){
			allTables = LobbyTableInfoCtrl.instance.getLobbyTableArr();
		}else{
			allTables = LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.currentGameType);
		}
		if(allTables){
			if(!this.myCollection){
				this.myCollection = new eui.ArrayCollection(allTables);
				this.list_all.dataProvider = this.myCollection;
				this.list_all.itemRenderer = OneTableItem;
				console.log("tableArr",allTables);
			}else{
				this.myCollection.replaceAll(allTables);
			}
		}
	}

	private changeType(){
		var  allTables = [];
		if(this.currentGameType==0){
			allTables = LobbyTableInfoCtrl.instance.getLobbyTableArr();
		}else{
			allTables = LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.currentGameType);
		}
		if(allTables){
			this.myCollection = new eui.ArrayCollection(allTables);
			this.list_all.dataProvider = this.myCollection;
			this.list_all.itemRenderer = OneTableItem;
		}
	}

	private onAddtoStage(): void {
		this.groupC.addEventListener(egret.TouchEvent.TOUCH_TAP,this.hideView,this);
		App.MessageCenter.addListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM,this.updateTables,this);
		this.btn_all.addEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
		this.btn_baccarat.addEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
		this.btn_roulette.addEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
		this.updateTables();        
	}

	private onRemoveFromStage():void {
		this.groupC.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.hideView,this);
		App.MessageCenter.removeListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM,this.updateTables,this);

		this.btn_all.removeEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
		this.btn_baccarat.removeEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
		this.btn_roulette.removeEventListener(eui.UIEvent.CHANGE,this.onChangeGameType,this);
	}

	private onChangeGameType(e:egret.Event){
		var radioButton = <eui.RadioButton>e.target;
		if(this.currentGameType!= radioButton.value){
			this.currentGameType = radioButton.value;
			this.changeType();
		}
	}

	private hideView(){
		this.visible = false;
	}

	private scroller_top:eui.Scroller;
	private groupC:eui.Group;

	private list_all:eui.List;
	private scroller_game_all:eui.Scroller;
	
	private myCollection:eui.ArrayCollection;

	//当前显示那种列表，0表示所有 11百家乐  13轮盘
	private currentGameType:number = 0;

	private btn_all:eui.RadioButton;
	private btn_baccarat:eui.RadioButton;
	private btn_roulette:eui.RadioButton;
}