class OneTypeItem {
	public constructor() {
	}
}