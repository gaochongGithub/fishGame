class OneTableItem extends eui.ItemRenderer{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/OneTableItemSkin.exml";
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		
	}

	protected dataChanged(): void {
		this.label_table.text = this.data.getGameTable;

		switch (this.data.getGameType) {
			case proto.GameType.Baccarat:
				this.label_gameName.text = App.LangUtils.getStr("TEXT_BACCARAT");
				break;
			case proto.GameType.Roulette:
				this.label_gameName.text = App.LangUtils.getStr("TEXT_Roulette");
				break;
			default:
				break;
		}
		
		this.group_shuffle.visible = this.data.getTableSnapshot.status == Status.Shuffle?true:false;

		var tableID = HallDataCtrl.instance.getLoadGameData.getTableID;
		this.group_isCurrentPosition.visible = tableID ==this.data.getGameTable?true:false;

		this._roadScene.clear();
		this._roadScene.addString(this.data.getAllWays);
		// console.log(this.data.getGameTable,this.data.getAllWays);
	}

	private onAddtoStage(): void {
		this._roadScene = new TableRoadScene(25);
		this.group_road.addChild(this._roadScene);
		this.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtn,this);

	}

	private onRemoveFromStage():void {
		this.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtn,this);
	}

	private onMouseOverSelf() {
		
	}
	private onMouseOutSelf() {
		
	}

	private onClickBtn(){
		if(GameDataCtrl.instance.isBet==false){
			HallDataCtrl.instance.getLoadGameData.setTableID(this.data.getGameTable);
			HallDataCtrl.instance.getLoadGameData.setGameType(this.data.getGameType);
			GameSceneCtrl.instance.toGameScene(this.data.gameType);
		}else{
			App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
		}
	}

	private _roadScene:TableRoadScene;
	private label_gameName:eui.Label;
	private label_table:eui.Label;
	private group_shuffle:eui.Group;
	private group_isCurrentPosition:eui.Group;
	private group_road:eui.Group;

}