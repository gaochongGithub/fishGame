class ServerToastView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/common/toast/ServerToastViewSkin.exml"
	}

	public childrenCreated() {
		this.horizontalCenter = 0;
		this.verticalCenter = 0;
		this.btn_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnCLose,this);
	}
	private onClickBtnCLose(){
		 if(!App.DeviceUtils.IsNative) {
            window.opener=null;
            window.open('','_self');
            window.close();
            window.history.back();
            window.location.reload();
		}
	}

	public setTitle(title:string):void{
		this.label_title.langStr = title;
	}

	public setContent(content:string):void{
		this.label_content.langStr = content;
	}

	private label_title: LangLabel;
	private label_content:LangLabel;
	private btn_close:eui.Button;
}