class ResultToastView extends DeletSelfView{
	public constructor() {
		super();
		this.skinName = "resource/skins/common/toast/ResultToastViewSkin.exml"
	}
	private result_type:eui.Image;
	private result_label:LangLabel;
	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}


	public setContent(text:string,resultType:any,imgName:any=null){
		let gameType = HallDataCtrl.instance.getLoadGameData.getGameType;
		if(gameType == proto.GameType.Baccarat){
			this.result_label.text = App.LangUtils.getResultStr(text)+" "+resultType;
		}else{
			this.result_label.text = App.LangUtils.getStr(text)+" "+resultType;
		}
		
		this.result_type.texture = RES.getRes(imgName);
	}
}