class BaseToastView extends DeletSelfView{
	public constructor() {
		super();
		this.skinName = "resource/skins/common/toast/BaseToastViewSkin.exml"
	}
	public init(title:string,resultType:number){
		switch (resultType) {
			case 0:
				this.setBgImage("bankerWin_png");
				break;
			case 1:
				this.setBgImage("playerWin_png");
				break;
			case 2:
				this.setBgImage("tieWin_png");
				break;	
			default:
				break;
		}
		this.setTitle(title);
	}

	public setTitle(title:string):void{
		this.label_title.langStr = title;
	}

	public setBgImage(imageName:string){
		this.image_bg.texture = RES.getRes(imageName);
	}
	private label_title: LangLabel;
    private image_bg: eui.Image;
}