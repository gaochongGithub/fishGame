class DeletSelfView extends eui.Component{
    private isAutoRemove:boolean;
    private timer: egret.Timer;
    private viewWidth:number;
	private viewHeight:number;
	public constructor(isAutoRemove:boolean=true) {
		super();
        this.isAutoRemove=isAutoRemove;
	}
    protected childrenCreated() {
        if(App.DeviceUtils.IsMobile){
			this.viewWidth = 812;
			this.viewHeight = 375;
		}else{
			this.viewWidth = 1920;
			this.viewHeight = 1080;
		}
       this.updataPosition();
    
    //    var rect=new eui.Rect;
	// 	rect.fillColor=0X000000;
	// 	rect.width=this.width;
	// 	rect.height=this.height;
	// 	//this.isShowBackRect?this.rect.alpha=0.9:this.rect.alpha=0;
	// 	this.addChild(rect);
        // rect.addEventListener(egret.TouchEvent.TOUCH_BEGIN, ()=>{
        //     this.onbg_btn();
        // }, this);
        if(this.isAutoRemove){
            this.timer = new egret.Timer(2000, 1);
		    this.timer.addEventListener(egret.TimerEvent.TIMER, this.onbg_btn, this);
		    this.timer.start();
        }
        
	}

    updataPosition(){
        this.x=this.viewWidth/2-this.width/2;
        this.y=this.viewHeight/2-this.height/2;
    }

    private onbg_btn() {
		if (this.parent) {
			this.parent.removeChild(this);
		}
	}

}