class TextToastView extends DeletSelfView{
	public constructor() {
		super();
		this.initText();
	}
	private textLabel:LangLabel;
	private initText(){
		this.textLabel = new LangLabel();
		this.textLabel.size = 35;
		this.textLabel.textColor = 0xffffff;
		this.textLabel.lineSpacing = 40;
		this.textLabel.textAlign = egret.HorizontalAlign.JUSTIFY;
		this.addChild(this.textLabel);
	}
	public setContent(text:string){
		this.textLabel.langStr = text;
	}
}