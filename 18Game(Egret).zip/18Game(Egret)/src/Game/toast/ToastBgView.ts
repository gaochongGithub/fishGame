class ToastBgView extends eui.Group{
	public constructor(isAutoRemove:boolean,isShowBackRect:boolean) {
		super();
		this.isAutoRemove = isAutoRemove;
		this.isShowBackRect = isShowBackRect;
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.customView();
	}
	
	private timer: egret.Timer;
	private zong_bg: eui.Group;
	private zone_bg_image: eui.Image;
	private rect:eui.Rect;
	public isAutoRemove: boolean = false;
	public isShowBackRect: boolean = false;
	

	protected onAddtoStage(event:egret.Event) {

	}
	
	protected onRemoveStage(event:egret.Event) {
		this.timer.stop();
		this.timer = null;
	}
	public childrenCreated() {
		
		this.rect.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.autoRemove, this);

	}

	private customView(){
		if(App.DeviceUtils.IsMobile){
			this.width = 812;
			this.height = 375;
		}else{
			this.width = 1920;
			this.height = 1080;
		}
		
		this.horizontalCenter = 0;
		this.verticalCenter = 0;

		this.rect=new eui.Rect;
		this.rect.fillColor=0X000000;
		this.rect.width=this.width;
		this.rect.height=this.height;
		this.isShowBackRect?this.rect.alpha=0.9:this.rect.alpha=0;
		this.addChild(this.rect);

		// this.zone_bg_image = new eui.Image();
		// this.zone_bg_image.texture = RES.getRes("bg_loading_png");
		// this.zone_bg_image.width = this.width;
		// this.zone_bg_image.height = this.height;
		// this.zone_bg_image.alpha = 0.5;
		//this.addChild(this.zone_bg_image);

		this.timer = new egret.Timer(2000, 1);
		this.timer.addEventListener(egret.TimerEvent.TIMER, this.onbg_btn, this);
		this.timer.start();
	}

	private onbg_btn() {
		if (this.parent&&this.isAutoRemove) {
			this.parent.removeChild(this);
		}
	}

	private autoRemove(){
		if (this.parent&&this.isAutoRemove) {
			this.parent.removeChild(this);
		}
	} 
}
