class ConfirmCancelButton extends eui.Component{

	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/ConfirmCancelButtonSkin.exml";
		
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.hideBtns();
	}

	private onRemoveFromStage() {
		
		App.MessageCenter.removeListener(GameEvent.CANCEL_BET_AMOUNT,this.hideBtns,this);
		App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.showBtns,this);
		App.MessageCenter.removeListener(GameEvent.GAME_STATUS_STOP,this.hideBtns,this);

		App.MessageCenter.removeListener(GameEvent.CONFIRM_BET_AMOUNT,this.hideBtns,this);
		App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.addBetAmount,this);
		this.btn_cancel.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnCancel,this);
		this.btn_confirm.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnConfirm,this);
	}

	private onAddtoStage(): void {
		
		App.MessageCenter.addListener(GameEvent.CANCEL_BET_AMOUNT,this.hideBtns,this);
		App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.showBtns,this);
		App.MessageCenter.addListener(GameEvent.GAME_STATUS_STOP,this.hideBtns,this);

		App.MessageCenter.addListener(GameEvent.CONFIRM_BET_AMOUNT,this.hideBtns,this);
		App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.addBetAmount,this);
		this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnCancel,this);
		this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnConfirm,this);
		this.hideBtns();
	}

	private onClickBtnCancel(){
		//播放声音


		App.MessageCenter.dispatch(GameEvent.CANCEL_BET_AMOUNT);
		this.clearBetInfo();
	}

	private onClickBtnConfirm(){

		let tableID = HallDataCtrl.instance.getLoadGameData.getTableID;
		let subType = HallDataCtrl.instance.getLoadGameData.getSubType;
		//let betInfo = GameDataCtrl.instance.getUnConfirmBetAmount;
		let limitRedID = HallDataCtrl.instance.getLoadGameData.getLimitRedID;

		//检测否各个下注区的金额大于0
		var betInfoBigThen0 = false;
        for (var key in this.betInfo) {

			if(this.betInfo[key] < 1)
				delete this.betInfo[key];
        }
		//检测是否小于最低下注额
		if(!this.checkMoreThanMinLimit){
			return;
		}

		App.GameServer.sendBet(tableID,subType,this.betInfo,limitRedID);
	
		this.clearBetInfo();

	}

	private showBtns(){
		this.btn_cancel.enabled = true;
		this.btn_confirm.enabled = true;
	}

	private hideBtns(){
		this.btn_cancel.enabled = false;
		this.btn_confirm.enabled = false;
	}



	private addBetAmount(data:any){
		var key = data;
		var value = GameDataCtrl.instance.getCurrentBetChip;
		this.betInfo[key] = this.betInfo[key]||0;
		this.betInfo[key] = this.betInfo[key]+value;
	}

	//检测下注金额是否大于最小限红
	private checkMoreThanMinLimit(){

		let betInfo = GameDataCtrl.instance.getUnConfirmBetAmount;
		let limitStr = HallDataCtrl.instance.getLoadGameData.getLimitRed;
		let minLimit:number = 0;
		let arr = limitStr.split("-");
		if(arr[0]){
			minLimit = Number(arr[0]);
		}else{
			return false;
		}

		for (var key in betInfo) {
			if(betInfo[key]<minLimit){
				App.ToastViewManager.toastBaseView("TEXT_MESSAGE_9");
				return false;
			}
		}
		return true;
	}

	private clearBetInfo(){
		this.betInfo = {};
	}

	private btn_cancel:eui.Button;
	private btn_confirm:eui.Button;

	private betInfo:any = {};
}