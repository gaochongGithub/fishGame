class RebetButton extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/RebetBtnSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(GameEvent.GAME_STATUS_START,this.gameStatusStart,this);
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO,this.confirmBetAmount,this);
		App.MessageCenter.addListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.addBetAmount,this);
		App.MessageCenter.addListener(GameEvent.CANCEL_BET_AMOUNT,this.receiveCancelBetAmount,this);
		App.MessageCenter.addListener(GameEvent.GAME_STATUS_STOP,this.hideBtn,this);
		this.btn_rebet.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtn,this);
		this.hideBtn(); 
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GameEvent.GAME_STATUS_START,this.gameStatusStart,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO,this.confirmBetAmount,this);
		App.MessageCenter.removeListener(GameEvent.ADD_BETAREA_AND_BETAMOUNT,this.addBetAmount,this);
		App.MessageCenter.removeListener(GameEvent.CANCEL_BET_AMOUNT,this.receiveCancelBetAmount,this);
		App.MessageCenter.removeListener(GameEvent.GAME_STATUS_STOP,this.hideBtn,this);
		this.btn_rebet.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtn,this);
	}

	private onClickBtn(){
		//是否已下过注
		if(this.hadBet){
			return;
		}

		if(this.checkMoreThanBalance()){
			//soundM
			//toastM
			return;
		}

		App.MessageCenter.dispatch(GameEvent.REBET_BET_AMOUNT,this.preBetInfo);
	}

	private addBetAmount(){
		this.hadBet = true;
		this.hideBtn();
	}

	

	private receiveCancelBetAmount(){
		if(this.canReset){
			this.hadBet = false;
			if((JSON.stringify(this.preBetInfo)!="{}")){
				this.showBtn();
			}
		}
	}

	private gameStatusStart(){
		this.canReset = true;
		this.hadBet = false;
		this.clearPreTempBetInfo();
		if((JSON.stringify(this.preBetInfo)!="{}")){
			this.showBtn();
		}
	}

	private confirmBetAmount(data:any){
		let betInfo = data.betinfo
		this.canReset = false;
		this.preTempBetInfo = MyUtils.deeCopy(betInfo,this.preTempBetInfo);
		this.setPreBetInfo();
	}

	private hideBtn(){
		this.btn_rebet.enabled = false;
	}

	private showBtn(){
		this.btn_rebet.enabled = true;
	}
	private setPreBetInfo(){
		for (var key in this.preTempBetInfo) {
			this.preBetInfo[key] = this.preTempBetInfo[key];
		}

		for (var key in this.preBetInfo) {
			if(this.preTempBetInfo[key]){
				this.preBetInfo[key] = this.preTempBetInfo[key];
			}else{
				this.preBetInfo[key] = null;
			}
		}
	}
	private clearPreTempBetInfo(){
		this.preTempBetInfo = {};
	}
	
	private checkMoreThanBalance(){
		var total = 0;
        for(var key in this.preBetInfo) {
            if (this.preBetInfo[key]) {
                total += this.preBetInfo[key];
            }
        }
        if(total > HallDataCtrl.instance.getLobbyPlayer.balance) {
            return true;
        }
        return false;
	}

	private hadBet:boolean = false;
	private canReset:boolean = false;
	private preTempBetInfo:{[key:number] : number} = {};
	private preBetInfo:{[key:number] : number} = {};
	private btn_rebet:eui.Button;

}