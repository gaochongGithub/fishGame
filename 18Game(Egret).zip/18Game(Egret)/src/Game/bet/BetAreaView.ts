/**
 * 百家乐下注区
 */
class BetAreaView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/BetAreaViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(GlobalEvent.SET_SUPER6,this.setSuperSix,this);
		this.setSuperSix();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GlobalEvent.SET_SUPER6,this.setSuperSix,this);
	}

	private setSuperSix(){
		var super6=egret.localStorage.getItem("Super6");
		this.group_superSix.visible = super6 == "1"?true:false;
		this.betBtn_tie.visible = super6=="1"?false:true;
	}

	private group_superSix:eui.Group;
	private betBtn_tie:BetButton;
}