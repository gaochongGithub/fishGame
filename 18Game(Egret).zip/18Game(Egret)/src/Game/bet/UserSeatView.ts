class UserSeatView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/UserSeatViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}
	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);
		this.hideNameBalance();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);
	}

	private updateVirtualTable(table:proto.Game.VirtualTable.Table){
		for (var key in table.seats) {
			if(table.seats[key].seatID == this.pos_index+1&&table.seats[key].uid!=0){
				this.showNameBalance();
				if(HallDataCtrl.instance.getLobbyPlayer.name == table.seats[key].uname){
					this.label_name.text = MyUtils.userCut_Previouss(table.seats[key].uname);
				}else{
					this.label_name.text = MyUtils.textAbbreviation(table.seats[key].uname,2);
				}
				this.label_balance.text = (MyUtils.numFormatToThousand(table.seats[key].balance)||0).toString();
			}
		}
	}

	private updateSeat(){
		this.label_name.text = "";
		this.label_balance.text = "";
	}
	private showNameBalance(){
		this.group_name.visible = true;
		this.group_balance.visible = true;
	}

	private hideNameBalance(){
		this.group_name.visible = false;
		this.group_balance.visible = false;
	}

	private label_name:eui.Label;
	private label_balance:eui.Label;

	public pos_index:number = 0;

	private group_name:eui.Group;
	private group_balance:eui.Group;
}