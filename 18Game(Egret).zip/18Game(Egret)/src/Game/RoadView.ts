/**
 * 路子界面
 */
class RoadView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/RoadViewSkin.exml";
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		
	}

	private onRemoveFromStage() {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY,this.updateRoad,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.updateShuffle,this);

		this.group_ask_banker.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.bankerAskRoad,this);
		this.group_ask_player.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.playerAskROad,this);

		this.btn_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnSetting,this);
	}

	private onAddtoStage(): void {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY,this.updateRoad,this);
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.updateShuffle,this);
		this.group_ask_banker.addEventListener(egret.TouchEvent.TOUCH_TAP,this.bankerAskRoad,this);
		this.group_ask_player.addEventListener(egret.TouchEvent.TOUCH_TAP,this.playerAskROad,this);

		this.btn_setting.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnSetting,this);

	}

	private updateShuffle(){
		this.group_shuffle.visible = GameDataCtrl.instance.gameStatus.status==Status.Shuffle;
	}

	private updateRoad(data:any){
		
		let  roadScene:RoadScene = new RoadScene(27);
		this._roadScene  = roadScene;
		this.group_road.addChild(this._roadScene);

		let gameWay:string = data.way;
		if (gameWay.substring(0, 1) == "q") {
			this.allWay = "";
		} else {	
			this.allWay = this.allWay + gameWay;
		}
		this._roadScene.clear();
		this._roadScene.addString(this.allWay);
		
		let countsArray:Array<string> = data.counts.split("^")
		this.label_player.text = countsArray[0];
		this.label_banker.text = countsArray[1];
		this.label_tie.text = countsArray[2];
		this.label_playerPair.text = countsArray[3];
		this.label_bankerPair.text = countsArray[4];
		this.label_total.text = countsArray[5];



		let nextRoadStr:string = this._roadScene.getNextCode();
		if (nextRoadStr[0] == "a") {
			this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_A_png");
			this.ask_player_1.texture = RES.getRes("Ask_BigRoad_E_png");
		} else if (nextRoadStr[0] == "e") {
			this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_E_png");
			this.ask_player_1.texture = RES.getRes("Ask_BigRoad_A_png");
		}

		if (nextRoadStr[1] == "a") {
			this.ask_banker_2.texture = RES.getRes("Bead_A_png");
			this.ask_player_2.texture = RES.getRes("Bead_E_png");
		} else if (nextRoadStr[1] == "e") {
			this.ask_banker_2.texture = RES.getRes("Bead_E_png");
			this.ask_player_2.texture = RES.getRes("Bead_A_png");
		}


		if (nextRoadStr[2] == "a") {
			this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_A_png");
			this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_E_png");
		} else if (nextRoadStr[2] == "e") {
			this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_E_png");
			this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_A_png");
		}
	}

	private bankerAskRoad(){
		this._roadScene.askRoad("a");
	}

	private playerAskROad(){
		this._roadScene.askRoad("e");
	}

	private onClickBtnSetting(){
		//弹出设置界面
		App.ToastViewManager.toast(new SettingView,false,true);
	}

	private onClickBtnRefresh(){
		//刷新视频
	}
	

	private _roadScene: RoadScene;
	private label_banker:eui.Label;
	private label_player:eui.Label;
	private label_tie:eui.Label;
	private label_bankerPair:eui.Label;
	private label_playerPair:eui.Label;
	private label_total:eui.Label;

	private group_ask_banker:eui.Group;
	private group_ask_player:eui.Group;
	private group_road:eui.Group;

	private ask_banker_1:eui.Image;
	private ask_banker_2:eui.Image;
	private ask_banker_3:eui.Image;

	private ask_player_1:eui.Image;
	private ask_player_2:eui.Image;
	private ask_player_3:eui.Image;

	private btn_refresh:eui.Button;
	private btn_setting:eui.Button;


	private allWay: string = "";
	private group_shuffle:eui.Group;
}