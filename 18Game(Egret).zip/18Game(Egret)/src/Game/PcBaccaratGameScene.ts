/**
 * 百家乐主场景
 */
class PcBaccaratGameScene extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/PcBaccaratGameSceneSkin.exml";
	    this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
	}

	private isStart:boolean = false;
	private isStop:boolean = false;

	private betArea:BetAreaView;
	private pokerView:PokerView;
	private roadView:RoadView;
	private userInfoView:UserInfoView;
	private betInfoView:BetInfoView;
	private statusView:StatusView;
	private optionView:OptionView;
	private chipsView:ChipsView;
	private allChipsView:AllChipsView;
	private changeTableView:ChangeTableView;
	private btn_showRoom:eui.Button;

	private onRemoveFromStage() {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
		App.MessageCenter.removeListener(GameEvent.SHOW_ALLCHIPS,this.showAllChips,this);
		App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
		this.btn_showRoom.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowRoom,this);
	}

	private onAddtoStage(): void {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
		App.MessageCenter.addListener(GameEvent.SHOW_ALLCHIPS,this.showAllChips,this);
		App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);

		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
		this.btn_showRoom.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowRoom,this);
		this.joinTable();
	}

	private getGameUserInfoEvent(gameUserInfo:any){
		 if(GameDataCtrl.instance.gameStatus.status == Status.Payout){
			 var  winlose = gameUserInfo.winlose;
			 var  winStr = ""
			 if(Number(winlose)>=0){
				 winStr = App.LangUtils.getStr("TEXT_TABLE_WIN");
			 }else{
				 winStr = App.LangUtils.getStr("TEXT_TABLE_LOSE");
			 }
			 App.ToastViewManager.toastResultView(this.gameReuslt,winStr+winlose,this.imageWinStr);

		 }
	}

	private updateVirtualTable(table:proto.Game.VirtualTable.Table){
		for(var key in table.seats){
            if(HallDataCtrl.instance.getLobbyPlayer.uid == table.seats[key].uid){
                if (JSON.stringify(table.seats[key].betinfo) !== '{}' && GameDataCtrl.instance.gameStatus.status!== 3) {
                    GameDataCtrl.instance.isBet = true;
                }
            }
        }
	}
	private joinTable(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		let gameType = loadGameModel.getGameType;
		let tableID = loadGameModel.getTableID;
		let joinType:number = Number(loadGameModel.getJoinType); 
		App.GameServer.sendJoinTable(gameType,tableID,joinType);
	}

	private getGameStatus(gameStatus:any){
		App.MessageCenter.dispatch(GameEvent.GET_GAME_TIME,gameStatus.time);
		App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_INNING,{stage : gameStatus.stage, inning : gameStatus.inning});
		let status = gameStatus.status;
		GameDataCtrl.instance.gameStatus = gameStatus;
		switch (status) {
			case Status.Shuffle:
				App.ToastViewManager.toastBaseView("TEXT_SHUFFLE");
				break;
			case Status.Start:
				this.getStatusStart();
				break;
			case Status.Stop:
				this.getStatusStop(gameStatus.poker);
				break;
			case Status.Payout:
				this.getStatusPayout(gameStatus);
				break;
			case Status.OK:
				
				break;
			case Status.Invalied:
				
				break;
			default:
				break;
		}
	}

	private getStatusShuffle(){
		App.MessageCenter.dispatch(GameEvent.GAME_STATUS_SHUFFLE);
		App.ToastViewManager.toastBaseView("TEXT_SHUFFLE");
	}

	private getStatusStart(){
		if(!this.isStart){
			this.isStart = true;
			App.ToastViewManager.toastBaseView("TEXT_MESSAGE_1");
			App.MessageCenter.dispatch(GameEvent.GAME_STATUS_START);

			//播放音频

			//下注状态重置
		}
	}

	private getStatusStop(poker){
		if(!this.isStop){
			this.isStop = true;
			App.ToastViewManager.toastBaseView("TEXT_MESSAGE_2");
			App.MessageCenter.dispatch(GameEvent.GAME_STATUS_STOP);
			//this.pokerView.visible = true;
		}
		App.MessageCenter.dispatch(GameEvent.SHOW_POKER,poker)
		
	}

	private getStatusPayout(data:any){
		this.isStart = false;
		this.isStop = false;
		var hasBet = GameDataCtrl.instance.isBet;
		GameDataCtrl.instance.isBet = false;
		App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_PAYOUT,data);

		var result = data.result;
		this.gameReuslt = result;
		var imageStr = "";
		if(result == "a" || result == "b" || result == "c" || result == "d"){
            imageStr = "bankeWin_png";
		}else if(result == "e" || result == "f" || result == "g" || result == "h"){
			imageStr = "playerWin_png";
		}else if(result == "i" || result == "j" || result == "k" || result == "l"){
			imageStr = "tieWin_png";
		}else{
			return;
		}
		this.imageWinStr = imageStr; 
		if(hasBet==false){
			App.ToastViewManager.toastResultView(result,"",imageStr);
		}
		
	}

	private getStatusOK(){
		App.MessageCenter.dispatch(GameEvent.GAME_STATUS_OK);
	}
	
	private getStatusInvalid(){
		//无效状态
	}

	//清除delay
	private clearDelay(){

	}

	private showAllChips(){
		this.allChipsView.visible = !this.allChipsView.visible;
	}

	private onClickBtnShowRoom(){
		this.changeTableView.visible = !this.changeTableView.visible;
	}

	private imageWinStr:string = "";
	private gameReuslt:string = "";

}