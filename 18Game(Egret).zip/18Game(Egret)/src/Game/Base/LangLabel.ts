class LangLabel extends eui.Label{
	public constructor() {
		super();
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}
	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE,this.updateLang,this);
		this.updateLang();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE,this.updateLang,this);
	}

	protected updateLang(){
		if(this.langStr){
			//this.text = Lang.getStr(this.langStr);
			this.text = App.LangUtils.getStr(this.langStr);
		}
		
	}
	
	public langStr:string = "";
	// public setLangStr(str){
	// 	this.langStr = str;
	// }

	
}