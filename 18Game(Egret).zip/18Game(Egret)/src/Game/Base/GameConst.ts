class GameConst {
	// public constructor() {
	// }
	public static delayBetTime:number = 3000;
	public static dalayTime :number= 8000;

	public static rateMap:{[key:number] : number} = {101:1,102:1,103:8,104:11,105:11,106:8,107:5,108:5,109:1,110:1};
}
enum Status{
	Shuffle = 0,
	Start = 1,
	Stop = 2,
	Payout = 3,
	OK = 4,
	Invalied = 5
}