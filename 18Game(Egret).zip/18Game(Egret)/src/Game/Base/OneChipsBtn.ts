/**
 * 筹码界面单个筹码
 */
class OneChipsBtn extends eui.RadioButton{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/OneChipsBtnSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		this.addEventListener(eui.UIEvent.CHANGE,this.onClickBtn,this);
		App.MessageCenter.addListener(GameEvent.SET_USING_CHIP_GROUP,this.updateChips,this);
		this.initChipNum();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(GameEvent.SET_USING_CHIP_GROUP,this.updateChips,this);
		this.removeEventListener(eui.UIEvent.CHANGE,this.onClickBtn,this);
		
	}

	private initChipNum(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		let chips = loadGameModel.getChip;
		let allChips = loadGameModel.getAllChip;
		if(App.DeviceUtils.IsMobile){
			this.chipNum = Number(allChips[this.chipIndex]);
		}else{
			this.chipNum = Number(chips[this.chipIndex]);
		}
		this.label_chipNum.text = this.chipNum.toString();
		

		for(let i=0;i<allChips.length;i++){
			if(allChips[i] == this.chipNum){
				let key = (i==9?10:"0"+(i+1));
				this.image_up.source = RES.getRes("chips_normal_"+key+"_png");
				this.image_upAndSelected.source = RES.getRes("chips_select_"+key+"_png");
				break;
			}	
		}
		if(this.chipIndex==0){
			this.selected = true;
			GameDataCtrl.instance.setCurrentBetChip = this.chipNum;
		}
	}

	private updateChips(){
		this.initChipNum();
	}

	private onClickBtn(){
		App.MessageCenter.dispatch(GameEvent.GET_CURRENT_BET_CHIP_NUM,this.chipNum);
		GameDataCtrl.instance.setCurrentBetChip = this.chipNum;
	}

	private chipNum:number = 0;
	private label_chipNum:eui.BitmapLabel;
	public chipIndex:number = 0;
	private image_up:eui.Image;
	private image_upAndSelected:eui.Image;
}	