/**
 * 选择筹码界面的单个筹码
 */
class OneBaseChipBtn extends eui.CheckBox{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/OneBaseChipBtnSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		
	}

	protected onAddtoStage(event:egret.Event) {
		this.addEventListener(eui.UIEvent.CHANGE,this.onClickBtn,this);
		App.MessageCenter.addListener(GameEvent.ALL_CHIPS_CHANGE,this.chipsChange,this);
		this.initChipNum();
	}

	protected onRemoveStage(event:egret.Event) {
		this.removeEventListener(eui.UIEvent.CHANGE,this.onClickBtn,this);
		App.MessageCenter.removeListener(GameEvent.ALL_CHIPS_CHANGE,this.chipsChange,this);
	}

	private chipsChange(data:any){
		this.checkArr = MyUtils.deeCopy(data,this.checkArr);
		for(let i=0;i<this.checkArr.length;i++){
			if(this.checkArr[i] == this.chipNum){
				this.selected = true;
				break;
			}else{
				this.selected = false;
			}
		}
	}
	private onClickBtn(){
		this.checkArr.sort((n1,n2) => {
			return n1-n2;
		});

		if(this.chipNum&&this.selected){
			if(this.checkArr.length>4){
				this.checkArr.splice(0,1);
				this.checkArr.push(this.chipNum);
			}else{
				this.checkArr.push(this.chipNum);
			}
		}else{
			for(let i=0;i<this.checkArr.length;i++){
				if(this.checkArr[i] == this.chipNum){
					this.checkArr.splice(i,1);
				}
			}
		}

		App.MessageCenter.dispatch(GameEvent.ALL_CHIPS_CHANGE,this.checkArr);
	}

	private initChipNum(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		let chips = loadGameModel.getChip;
		let allChips:Array<any> =  loadGameModel.getAllChip;
		
		this.chipNum = allChips[this.chipIndex];
		this.label_chipNum.text = this.chipNum.toString();

		for(let i=0;i<chips.length;i++){
			this.checkArr[i] = chips[i];
		}

		for(let i=0;i<chips.length;i++){
			if(this.chipNum == chips[i]){
				this.selected = true;
			}
		}
	}
	
	private chipNum:number;
	private label_chipNum:eui.Label;
	public chipIndex:number = 0;

	private indexArr:Array<any> = [];
	private checkArr:Array<any> = [];

}