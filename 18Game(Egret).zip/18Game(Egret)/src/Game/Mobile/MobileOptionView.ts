/**
 * 手机版功能界面 记录 规则 退出
 */
class MobileOptionView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/MobileOptionViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		this.btn_deposit.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnDeposit,this);
		this.btn_record.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnRecord,this);
		this.btn_client.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnClient,this);
		this.btn_rule.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnRule,this);
		this.btn_exit.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnExit,this);


		this.btn_setting.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnSetting,this);
		this.group_hide.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickHide,this);
	}
	
	protected onRemoveStage(event:egret.Event) {
		this.btn_deposit.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnDeposit,this);
		this.btn_record.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnRecord,this);
		this.btn_client.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnClient,this);
		this.btn_rule.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnRule,this);
		this.btn_exit.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnExit,this);

		this.btn_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnSetting,this);
		this.group_hide.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickHide,this);
	}

	private onClickBtnDeposit(){	
		//存款
	}

	private onClickBtnRecord(){
		//游戏记录
		App.ToastViewManager.toast(new RecordView(),false,true);
	}

	private onClickBtnClient(){
		//客服
	}

	private onClickBtnRule(){
		//游戏规则
		App.ToastViewManager.toast(new RuleView,false,true);

	}
	
	private onClickBtnExit(){
		if(GameDataCtrl.instance.isBet == false){
			GameSceneCtrl.instance.toMobileHallScene();
		}else{
			App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
		}
	}


	private onClickBtnSetting(){
		App.ToastViewManager.toast(new SettingView,false,true);
	}

	private onClickHide(){
		this.visible = false;
	}

	private btn_deposit:eui.Button;
	private btn_record:eui.Button;
	private btn_client:eui.Button;
	private btn_rule:eui.Button;
	private btn_exit:eui.Button;

	private btn_setting:eui.Button;
	private group_hide:eui.Group;
}