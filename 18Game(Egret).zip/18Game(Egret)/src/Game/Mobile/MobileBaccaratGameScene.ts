/**
 * 百家乐手机版游戏主场景
 */
class MobileBaccaratGameScene extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/MobileBaccaratGameSceneSkin.exml";
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
	}

	private onRemoveFromStage() {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
		App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);

		this.group_info.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showRoadAndInfo,this);
		this.group_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showOption,this);
		this.group_chat.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showChat,this);
	}

	private onAddtoStage(): void {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
		App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVirtualTable,this);
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);

		this.group_info.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showRoadAndInfo,this);
		this.group_setting.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showOption,this);
		this.group_chat.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showChat,this);
		this.joinTable();
	}

	private getGameUserInfoEvent(gameUserInfo:any){
		 if(GameDataCtrl.instance.gameStatus.status == Status.Payout){
			 var  winlose = gameUserInfo.winlose;
			 var  winStr = ""
			 if(Number(winlose)>=0){
				 winStr = App.LangUtils.getStr("TEXT_TABLE_WIN");
			 }else{
				 winStr = App.LangUtils.getStr("TEXT_TABLE_LOSE");
			 }
			 App.ToastViewManager.toastResultView(this.gameReuslt,winStr+winlose,this.imageWinStr);

		 }
	}

	private updateVirtualTable(table:proto.Game.VirtualTable.Table){
		for(var key in table.seats){
            if(HallDataCtrl.instance.getLobbyPlayer.uid == table.seats[key].uid){
                if (JSON.stringify(table.seats[key].betinfo) !== '{}' && GameDataCtrl.instance.gameStatus.status!== 3) {
                    GameDataCtrl.instance.isBet = true;
                }
            }
        }
	}

	private joinTable(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		let gameType = loadGameModel.getGameType;
		let tableID = loadGameModel.getTableID;
		let joinType:number = Number(loadGameModel.getJoinType); 
		App.GameServer.sendJoinTable(gameType,tableID,joinType);
	}

	private getGameStatus(gameStatus:any){
		App.MessageCenter.dispatch(GameEvent.GET_GAME_TIME,gameStatus.time);
		App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_INNING,{stage : gameStatus.stage, inning : gameStatus.inning});
		let status = gameStatus.status;
		GameDataCtrl.instance.gameStatus = gameStatus;
		switch (status) {
			case Status.Shuffle:
				App.ToastViewManager.toastTextView("TEXT_SHUFFLE");
				break;
			case Status.Start:
				this.getStatusStart();
				break;
			case Status.Stop:
				this.getStatusStop(gameStatus.poker);
				break;
			case Status.Payout:
				this.getStatusPayout(gameStatus);
				break;
			case Status.OK:
				
				break;
			case Status.Invalied:
				
				break;
			default:
				break;
		}
	}

	private getStatusShuffle(){
		App.MessageCenter.dispatch(GameEvent.GAME_STATUS_SHUFFLE);
		App.ToastViewManager.toastTextView("TEXT_SHUFFLE");
	}

	private getStatusStart(){
		if(!this.isStart){
			this.isStart = true;
			App.ToastViewManager.toastTextView("TEXT_MESSAGE_1");
			App.MessageCenter.dispatch(GameEvent.GAME_STATUS_START);

			//播放音频

			//下注状态重置
		}
	}

	//停止下注
	private getStatusStop(poker){
		if(!this.isStop){
			this.isStop = true;
			App.ToastViewManager.toastTextView("TEXT_MESSAGE_2");
			App.MessageCenter.dispatch(GameEvent.GAME_STATUS_STOP);
			//this.pokerView.visible = true;
		}
		App.MessageCenter.dispatch(GameEvent.SHOW_POKER,poker)
		
	}

	//结算消息
	private getStatusPayout(data:any){
		this.isStart = false;
		this.isStop = false;
		var hasBet = GameDataCtrl.instance.isBet;
		GameDataCtrl.instance.isBet = false;
		App.MessageCenter.dispatch(GameEvent.GET_GAME_STAGE_PAYOUT,data);

		var result = data.result;
		this.gameReuslt = result;
		var imageStr = "";
		if(result == "a" || result == "b" || result == "c" || result == "d"){
            imageStr = "bankeWin_png";
		}else if(result == "e" || result == "f" || result == "g" || result == "h"){
			imageStr = "playerWin_png";
		}else if(result == "i" || result == "j" || result == "k" || result == "l"){
			imageStr = "tieWin_png";
		}else{
			return;
		}
		this.imageWinStr = imageStr; 
		if(hasBet==false){
			App.ToastViewManager.toastResultView(result,"",imageStr);
		}
		
	}

	private getStatusOK(){
		App.MessageCenter.dispatch(GameEvent.GAME_STATUS_OK);
	}
	
	private getStatusInvalid(){
		//无效状态
	}

	private showRoadAndInfo(){
		this.roadAndBetInfoView.visible = !this.roadAndBetInfoView.visible;
	}

	private showChat(){
		this.chatView.visible = !this.chatView.visible;
	}

	private showOption(){
		this.optionView.visible = !this.optionView.visible;
	}

	//清除delay
	private clearDelay(){

	}

	private isStart:boolean = false;
	private isStop:boolean = false;


	private group_info:eui.Group;
	private group_chat:eui.Group;
	private group_setting:eui.Group;

	private betArea:BetAreaView;
	
	private userInfoView:UserInfoView;
	private betInfoView:BetInfoView;
	private statusView:StatusView;
	private chipsView:ChipsView;
	
	private optionView:MobileOptionView;
	private pokerView:PokerView;
	private roadAndBetInfoView:MobileRoadAndBetInfoView;
	
	private imageWinStr:string = "";
	private gameReuslt:string = "";

	private chatView:chat;
}