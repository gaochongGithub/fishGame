/**
 * 手机版路子和下注信息
 */
class MobileRoadAndBetInfoView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/MobileBetInfoAndRoadSkin.exml";
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
	}
	private onRemoveFromStage() {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY,this.updateRoad,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.updateShuffle,this);
		this.group_ask_banker.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.bankerAskRoad,this);
		this.group_ask_player.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.playerAskROad,this);

		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.setChipAndPeopleLabel,this);

		this.group_hide.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.hideView,this);

		this.image_left.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickChangeView,this);
		this.image_right.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickChangeView,this);
	}

	private onAddtoStage(): void {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY,this.updateRoad,this);
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.updateShuffle,this);
		this.group_ask_banker.addEventListener(egret.TouchEvent.TOUCH_TAP,this.bankerAskRoad,this);
		this.group_ask_player.addEventListener(egret.TouchEvent.TOUCH_TAP,this.playerAskROad,this);

		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.setChipAndPeopleLabel,this);
		this.initLimit();

		this.group_hide.addEventListener(egret.TouchEvent.TOUCH_TAP,this.hideView,this);

		this.image_left.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickChangeView,this);
		this.image_right.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickChangeView,this);
	}

	private updateShuffle(){
		this.group_shuffle.visible = GameDataCtrl.instance.gameStatus.status==Status.Shuffle;
	}

	private updateRoad(data:any){
		
		let  roadScene:RoadScene = new RoadScene(25);
		this._roadScene  = roadScene;
		this.group_road.addChild(this._roadScene);

		let gameWay:string = data.way;
		if (gameWay.substring(0, 1) == "q") {
			this.allWay = "";
		} else {	
			this.allWay = this.allWay + gameWay;
		}
		this._roadScene.clear();
		this._roadScene.addString(this.allWay);
		
		let countsArray:Array<string> = data.counts.split("^")
		this.label_player.text = countsArray[0];
		this.label_banker.text = countsArray[1];
		this.label_tie.text = countsArray[2];
		this.label_playerPair.text = countsArray[3];
		this.label_bankerPair.text = countsArray[4];
		this.label_total_road.text = countsArray[5];



		let nextRoadStr:string = this._roadScene.getNextCode();
		if (nextRoadStr[0] == "a") {
			this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_A_png");
			this.ask_player_1.texture = RES.getRes("Ask_BigRoad_E_png");
		} else if (nextRoadStr[0] == "e") {
			this.ask_banker_1.texture = RES.getRes("Ask_BigRoad_E_png");
			this.ask_player_1.texture = RES.getRes("Ask_BigRoad_A_png");
		}

		if (nextRoadStr[1] == "a") {
			this.ask_banker_2.texture = RES.getRes("Bead_A_png");
			this.ask_player_2.texture = RES.getRes("Bead_E_png");
		} else if (nextRoadStr[1] == "e") {
			this.ask_banker_2.texture = RES.getRes("Bead_E_png");
			this.ask_player_2.texture = RES.getRes("Bead_A_png");
		}


		if (nextRoadStr[2] == "a") {
			this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_A_png");
			this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_E_png");
		} else if (nextRoadStr[2] == "e") {
			this.ask_banker_3.texture = RES.getRes("Ask_Cockcroach_E_png");
			this.ask_player_3.texture = RES.getRes("Ask_Cockcroach_A_png");
		}
	}

	private bankerAskRoad(){
		this._roadScene.askRoad("a");
	}

	private playerAskROad(){
		this._roadScene.askRoad("e");
	}

	/**
	 * 路子
	 */
	private _roadScene: RoadScene;
	private label_banker:eui.Label;
	private label_player:eui.Label;
	private label_tie:eui.Label;
	private label_bankerPair:eui.Label;
	private label_playerPair:eui.Label;
	private label_total_road:eui.Label;

	private group_ask_banker:eui.Group;
	private group_ask_player:eui.Group;
	private group_road:eui.Group;

	private ask_banker_1:eui.Image;
	private ask_banker_2:eui.Image;
	private ask_banker_3:eui.Image;

	private ask_player_1:eui.Image;
	private ask_player_2:eui.Image;
	private ask_player_3:eui.Image;


	private allWay: string = "";
	private group_shuffle:eui.Group;

	/**
	 * 下注信息
	 */

	private initLimit(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		this.label_limit.text = loadGameModel.getLimitRed;
	}

	private setChipAndPeopleLabel(data:any){

		let betInfo = data.betinfo;
		
		this.label_table.text = data.tableID;
		this.label_shoe.text = data.stage+"-"+data.inning;


		var obj = GameDataCtrl.instance.getConfirmBetAmount;
        var total = 0;
        
        for(var key in obj) {
            if (obj[key]) {
                total += obj[key];
            }
        }

		this.label_total.text = (total||0).toString();
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		if(loadGameModel.getGameType == proto.GameType.Baccarat){
			this.setBetLabel(this.player_bet,this.player_people,101,betInfo);
			this.setBetLabel(this.banker_bet,this.banker_people,102,betInfo);
			this.setBetLabel(this.tie_bet,this.tie_people,103,betInfo);
			this.setBetLabel(this.playerPair_bet,this.playerPair_people,104,betInfo);
			this.setBetLabel(this.bankerPair_bet,this.bankerPair_people,105,betInfo);
			this.setBetLabel(this.superSix_bet,this.superSix_people,106,betInfo);
			this.setBetLabel(this.anyPair_bet,this.anyPair_people,107,betInfo);
			this.setBetLabel(this.perfectPair_bet,this.perfectPair_people,108,betInfo);
			this.setBetLabel(this.big_bet,this.big_people,109,betInfo);
			this.setBetLabel(this.small_bet,this.small_people,110,betInfo);
		}

	}

	private setBetLabel(betLabel:eui.Label,peopleLabel:eui.Label,key:any,betInfo:any){
		betLabel.text = (betInfo[key]&&betInfo[key].amount)||0;
		peopleLabel.text = (betInfo[key]&&betInfo[key].player_count)||0;
	}

	private label_table:eui.Label;
	private label_shoe:eui.Label;
	private label_limit:eui.Label;
	private label_total:eui.Label;

	private player_bet:eui.Label;
	private banker_bet:eui.Label;
	private tie_bet:eui.Label;
	private playerPair_bet:eui.Label;
	private bankerPair_bet:eui.Label;
	private perfectPair_bet:eui.Label;
	private anyPair_bet:eui.Label;
	private big_bet:eui.Label;
	private small_bet:eui.Label;
	private superSix_bet:eui.Label;

	private player_people:eui.Label;
	private banker_people:eui.Label;
	private tie_people:eui.Label;
	private playerPair_people:eui.Label;
	private bankerPair_people:eui.Label;
	private perfectPair_people:eui.Label;
	private anyPair_people:eui.Label;
	private big_people:eui.Label;
	private small_people:eui.Label;
	private superSix_people:eui.Label;


	
	private group_betInfo:eui.Group;
	private group_hide:eui.Group;

	private image_left:eui.Image;
	private image_right:eui.Image;

	private hideView(){
		this.visible = false;
	}

	private onClickChangeView(){
		this.group_road.visible = !this.group_road.visible;
		this.group_betInfo.visible = !this.group_road.visible
	}
}