class MobileChipsView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/MobileChipsViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		
		this.initChipNum();
	}

	protected onRemoveStage(event:egret.Event) {
		
		
	}

	private initChipNum(){
		
	}

	private onClickBtnShowAllChips(){
		//App.MessageCenter.dispatch(GameEvent.SHOW_ALLCHIPS);
	}
	private chipNum:number;
	private label_chipNum:eui.Label;
	public chipIndex:number = 0;
}