class ChipsView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/ChipsViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		this.btn_showAllChips.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowAllChips,this);
		
		this.initChipNum();
	}

	protected onRemoveStage(event:egret.Event) {
		this.btn_showAllChips.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowAllChips,this);
		
	}

	private initChipNum(){
		
	}

	private onClickBtnShowAllChips(){
		App.MessageCenter.dispatch(GameEvent.SHOW_ALLCHIPS);
	}
	private chipNum:number;
	private label_chipNum:eui.Label;
	public chipIndex:number = 0;

	private btn_showAllChips;
}