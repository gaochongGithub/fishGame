class BetInfoView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/BetInfoViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.setChipAndPeopleLabel,this);
		this.initLimit();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.setChipAndPeopleLabel,this);
	}

	private initLimit(){
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		this.label_limit.text = loadGameModel.getLimitRed;
	}

	private setChipAndPeopleLabel(data:any){

		let betInfo = data.betinfo;
		
		this.label_table.text = data.tableID;
		this.label_shoe.text = data.stage+"-"+data.inning;


		var obj = GameDataCtrl.instance.getConfirmBetAmount;
        var total = 0;
        
        for(var key in obj) {
            if (obj[key]) {
                total += obj[key];
            }
        }

		this.label_total.text = (total||0).toString();
		let loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		if(loadGameModel.getGameType == proto.GameType.Baccarat){
			this.setBetLabel(this.player_bet,this.player_people,101,betInfo);
			this.setBetLabel(this.banker_bet,this.banker_people,102,betInfo);
			this.setBetLabel(this.tie_bet,this.tie_people,103,betInfo);
			this.setBetLabel(this.playerPair_bet,this.playerPair_people,104,betInfo);
			this.setBetLabel(this.bankerPair_bet,this.bankerPair_people,105,betInfo);
			this.setBetLabel(this.superSix_bet,this.superSix_people,106,betInfo);
			this.setBetLabel(this.anyPair_bet,this.anyPair_people,107,betInfo);
			this.setBetLabel(this.perfectPair_bet,this.perfectPair_people,108,betInfo);
			this.setBetLabel(this.big_bet,this.big_people,109,betInfo);
			this.setBetLabel(this.small_bet,this.small_people,110,betInfo);
		}

	}

	private setBetLabel(betLabel:eui.Label,peopleLabel:eui.Label,key:any,betInfo:any){
		betLabel.text = (betInfo[key]&&betInfo[key].amount)||0;
		peopleLabel.text = (betInfo[key]&&betInfo[key].player_count)||0;
	}

	private label_table:eui.Label;
	private label_shoe:eui.Label;
	private label_limit:eui.Label;
	private label_total:eui.Label;

	private player_bet:eui.Label;
	private banker_bet:eui.Label;
	private tie_bet:eui.Label;
	private playerPair_bet:eui.Label;
	private bankerPair_bet:eui.Label;
	private perfectPair_bet:eui.Label;
	private anyPair_bet:eui.Label;
	private big_bet:eui.Label;
	private small_bet:eui.Label;
	private superSix_bet:eui.Label;

	private player_people:eui.Label;
	private banker_people:eui.Label;
	private tie_people:eui.Label;
	private playerPair_people:eui.Label;
	private bankerPair_people:eui.Label;
	private perfectPair_people:eui.Label;
	private anyPair_people:eui.Label;
	private big_people:eui.Label;
	private small_people:eui.Label;
	private superSix_people:eui.Label;


	

}