/**
 * 状态显示，pc Mobile通用
 */
class StatusView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/StatusViewSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
	}

	private getGameStatus(data:any){
		let status = data.status;
		//console.log("状态"+status);
		switch (status) {
			case Status.Shuffle:
				//App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
					this.hideTime();
					this.shuffleDelay();
				//},this);
				break;
			case Status.Start:
				this.getGameStatusStart(data);
				break;
			case Status.Stop:
				this.getGameStatusStop();
				break;
			case Status.Payout:
				this.getGameStatusPayout();
				break;
			case Status.OK:
				//App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
					this.hideTime();
					this.restDelay();
				//},this);
				break;
			case Status.Invalied:
				
				break;
			default:
				break;
		}
	}

	

	private getGameStatusStart(getGameStatus:any){
		if(!this.isStart){
			//this.clearDelay();
			this.isStart = true;
			this.startDelay();
		}
		//App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
			
			this.getCountDownTimeEvent(getGameStatus.time);
			
		//},this);

		
	}


	private getGameStatusStop(){
		if(!this.isStop){
			this.isStop = true;
		}
		//App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
			this.hideTime();
			this.stopDelay();
		//},this);
	}

	private getGameStatusPayout(){
		this.isStart = false;
		//App.TimerManager.doTimer(GameConst.delayBetTime,1,() => { 
			this.hideTime();
			this.payoutDelay();
		//},this);
	}


	private hideTime(){
		this.image_status.horizontalCenter = 0;
		this.label_time.visible = false;
	}

	private getCountDownTimeEvent(time:number){
		this.label_time.text = time.toString();
		if(time <= 10&&time>0){
			this.label_time.textColor = 0xFF0000;
			egret.Tween.get(this.label_time, { loop: false })
			.to({ scaleX: 1.8,scaleY:1.8 }, 200)
			.to({ scaleX: 1,scaleY:1 }, 200)
			.call(() => { });
		}else{
			this.label_time.textColor = 0xFFFFFF;
		}
	}

	private shuffleDelay(){
		this.image_status.texture = RES.getRes("status_shuffle_png");
	}

	private startDelay(){
		this.image_status.horizontalCenter = -40;
		this.label_time.visible = true;
		this.image_status.texture = RES.getRes("status_begin_png");
	}

	private stopDelay(){
		this.image_status.texture = RES.getRes("status_poker_png");
	}

	private payoutDelay(){
		this.image_status.texture = RES.getRes("status_payout_png");
	}

	private restDelay(){
		this.image_status.texture = RES.getRes("status_rest_png");
	}

	private clearDelay(){
		App.TimerManager.removeAll(this);
	}


	private isStart:boolean = false;
	private isStop:boolean = false;

	private image_status:eui.Image;
	private label_time:eui.Label;



}