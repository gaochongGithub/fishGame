class UserInfoView extends eui.Component{
	public constructor() {
		super();
		this.skinName = "resource/skins/baccarat/UserInfoViewSkin.exml"
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		
	}

	protected onAddtoStage(event:egret.Event) {
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
		//App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_CONFIG,this.getGameUserInfoEvent,this);
		this.initData();
	}

	protected onRemoveStage(event:egret.Event) {
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
		//App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_CONFIG,this.getGameUserInfoEvent,this);
		
	}

	private	initData(){
		var lobbyPlayer:proto.Lobby.UserSnapshot = HallDataCtrl.instance.getLobbyPlayer;
		this.label_name.text = MyUtils.userCut_Previouss(lobbyPlayer.name);
		this.label_balance.text =  "¥ "+MyUtils.numFormatToThousand(lobbyPlayer.balance);
	}

	private setLobbyPlayerInfo(lobbyPlayerInfo:any){
		if(lobbyPlayerInfo.name){
			if(this.label_name){
				this.label_name.text = lobbyPlayerInfo.name;
			}
		}

		if(this.label_balance){
			this.label_balance.text = lobbyPlayerInfo.balance;
		}

		if(this.label_test){
			this.label_test.visible = lobbyPlayerInfo.isTestMember;
		}
	}

	private getGameUserInfoEvent(data:any){
		if(this.label_name){
			this.label_name.text = MyUtils.userCut_Previouss(data.name);
		}

		if(this.label_balance){
			//这里要延迟更新
            this.label_balance.text = "¥ "+MyUtils.numFormatToThousand(data.balance);
		}

		if(this.label_test){
			this.label_test.visible = data.isTestMember;
		}
	}

	private label_name:eui.Label;
	private label_balance:eui.Label;
	private label_test:eui.Label;
}