/**
 * Created by yangsong on 15-1-26.
 */
class Keyboard {
    public static LEFT:number = 37;
    public static RIGHT:number = 39;
    public static UP:number = 38;
    public static DOWN:number = 40;
    public static W:number = 87;
    public static A:number = 65;
    public static S:number = 83;
    public static D:number = 68;
    public static J:number = 74;
    public static K:number = 75;
    public static L:number = 76;
    public static U:number = 85;
    public static I:number = 73;
    public static O:number = 79;
    public static P:number = 80;
    public static SPACE:number = 32;

    public constructor() {

    }
}