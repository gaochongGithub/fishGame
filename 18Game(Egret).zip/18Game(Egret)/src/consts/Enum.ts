// TypeScript file
var SicboBetKey={
    sum_4:401,
    sum_5:402,
    sum_6:403,

    sum_7:404,
    sum_8:405,
    sum_9:406,

    sum_10:407,
    sum_11:408,
    sum_12:409,

    sum_13:410,
    sum_14:411,
    sum_15:412,

    sum_16:413,
    sum_17:414,
    
    big:415,
    small:416,

    dice_1:417,
    dice_2:418,
    dice_3:419,

    dice_4:420,
    dice_5:421,
    dice_6:422,

    pair_11:423,
    pair_22:424,
    pair_33:425,
    
    pair_44:426,
    pair_55:427,
    pair_66:428,

    triple_111:429,
    triple_222:430,
    triple_333:431,
    
    triple_444:432,
    triple_555:433,
    triple_666:434,

    anyTriple:435,

    combination_12:436,
    combination_13:437,
    combination_14:438,

    combination_15:439,
    combination_16:440,
    combination_23:441,

    combination_24:442,
    combination_25:443,
    combination_26:444,

    combination_34:445,
    combination_35:446,
    combination_36:447,
    
    combination_45:448,
    combination_46:449,
    combination_56:450,

    odd:451,
    even:452,
    
}