class MoblieHallScene extends HallScene {
	private radioBtnView:eui.Group;
	private gameBtn:eui.Group;
	private right_btn:eui.Image;
	private data:GameHallItemModel
	private gameItemView:GameItemView;
	private toastView:eui.Group;
	public constructor() {
		super();
	}

	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}


	protected childrenCreated():void
	{
		super.childrenCreated();
	 }
	
	initEventListener(){
		this.gameBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showRadioBtn,this);
		this.game_list.addEventListener(eui.ItemTapEvent.ITEM_TAP,this.ItemSelect,this);
		App.MessageCenter.addListener(LobbyEvent.SHOW_LIMIT_VIEW,this.limitShowChange,this);
		App.MessageCenter.addListener(LobbyEvent.LIMIT_CHOOSE,this.limitChose,this);
		App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE,this.onLanguageChange,this);
		this.toastView.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
	}

	removeMyEventListener(){
		this.gameBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showRadioBtn,this);
		this.game_list.removeEventListener(eui.ItemTapEvent.ITEM_TAP,this.ItemSelect,this);
		this.toastView.removeEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
		App.MessageCenter.removeListener(LobbyEvent.SHOW_LIMIT_VIEW,this.limitShowChange,this);
		App.MessageCenter.removeListener(LobbyEvent.LIMIT_CHOOSE,this.limitChose,this);
		App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE,this.onLanguageChange,this);
	}

	private limitChose(limitViewModel:LimitViewModel){
		// if(this.data.gameTable==limitViewModel.getGameTable){
		// 	this.data.limitRedID=limitViewModel.getLimitChoseID;
		var data=LobbyTableInfoCtrl.instance.setLobbyOneTableLimitID(limitViewModel.getGameType,limitViewModel.getGameTable,limitViewModel.getLimitChoseID);
		if(data){
			data.setIsShwoView(false);
			this.gameItemView.dataChanged(data,false,false);
		}
	}

	private touchBegin(evt:egret.TouchEvent){
		this.toastView.visible=false;
		if(this.gameItemView){
			this.removeChild(this.gameItemView);
			this.gameItemView=null;
		}
	}


	private onLanguageChange(){
		if(this.gameItemView){
			var data=LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType,this.data.getGameTable);
			this.gameItemView.dataChanged(data,false,true);
		}
	}

	private limitShowChange(isShowView:boolean){
		var data=LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType,this.data.getGameTable);
		if(data){
			data.setIsShwoView(isShowView);
			this.gameItemView.dataChanged(data,false,false);
		}
	}

	ItemSelect(){
		this.data=this.game_list.selectedItem;
		var data=LobbyTableInfoCtrl.instance.getLobbyOneTable(this.gameType,this.data.getGameTable);
		if(data){
			this.gameItemView=new GameItemView();
			this.gameItemView.verticalCenter=0;
			this.toastView.visible=true;			
			this.addChild(this.gameItemView);
			this.gameItemView.dataChanged(data,true,false);
		}
	}

	showRadioBtn(){
		if(this.radioBtnView.left==-664){
			this.right_btn.visible=false;
			egret.Tween.get(this.radioBtnView).to({left:150}, 300, egret.Ease.sineIn);
		}else if(this.radioBtnView.left==150){
			egret.Tween.get(this.radioBtnView).to({left:-664}, 300, egret.Ease.sineIn);
			this.right_btn.visible=true;
		}
		
	}

	initView(){
		this.skinName=MoblieHallSceneSkin;
	}

	

}