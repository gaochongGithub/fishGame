class LImitRadioBtn extends ItemParent {
	private radioText:eui.Label;
	private radioBtn:eui.CheckBox;
	public constructor() {
		super();
	}

	initEventListener(){
		this.radioBtn.addEventListener(eui.UIEvent.CHANGE, (e) => {
			this.data.setIsChose(this.radioBtn.selected);
			App.MessageCenter.dispatch(LobbyEvent.LIMIT_CHOOSE,this.data);
		}, this)
		
	}

	removeMyEventListener(){
		
	}

	dataChanged() {
		this.radioText.text=this.data.getLimitChoseCount;
		this.radioBtn.selected=this.data.isChose;
	}
}