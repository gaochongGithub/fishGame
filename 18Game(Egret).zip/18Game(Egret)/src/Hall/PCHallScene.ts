class PCHallScene extends HallScene{
	private playerCount:eui.Label;
	private eq_group:eui.Group;
	private downAndLogin:eui.Image;
	public constructor() {
		super();
		
	}

	initView(){
		this.skinName=HallSceneSkin;
		
	}

	initEventListener(){
		App.MessageCenter.addListener(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO,this.upDataPlayerCount,this);
		this.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
		this.downAndLogin.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showEqView,this);
	}

	showEqView(){
		this.createdEQView();
	}

	
	private touchBegin(evt:egret.TouchEvent){
		if(this.eq_group){
			this.removeChild(this.eq_group);
			this.eq_group=null;

		}
	}

	removeMyEventListener(){
		App.MessageCenter.removeListener(ServerEvent.GET_LOBBY_PLAYERCOUNT_INFO,this.upDataPlayerCount,this);
		this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN,this.touchBegin,this);
		this.downAndLogin.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showEqView,this)
	}

	upDataPlayerCount(){
		this.playerCount.text=HallDataCtrl.instance.getPlayerCount+"";
	}

	

	// gameRadioChange(e:egret.Event){
	// 	var radioButton = <eui.RadioButton>e.target;
	// 	this.gameType=radioButton.value
	// 	// console.log("radioButton.value222"+radioButton.value);
	// }

	// addRoadItem(){
	// 	var lobbyTableInfo=LobbyTableInfoCtrl.getLobbyTableInfoCtrl.getLobbyTableArrByGameType(this.gameType);
	// 	if(lobbyTableInfo){
	// 		if(!this.euiArr){
	// 			//插入轮播广告 暂时无数据
	// 			lobbyTableInfo.splice(1, 0, {})
	// 			this.euiArr = new eui.ArrayCollection(lobbyTableInfo);
	// 			this.game_list.dataProvider=this.euiArr;
	// 			this.game_list.itemRenderer=GameItem;
	// 		}else{
	// 			this.game_list.dataProviderRefreshed();
	// 		}
	// 	}	
	// }

	childrenCreated():void
	{
		super.childrenCreated();
		this.upDataPlayerCount();
		
		
	}

	createdEQView(){
		var uname=egret.localStorage.getItem("uname");
        var pwd=egret.localStorage.getItem("pwd");
        var data=App.Base64.encode("uname="+uname+"&"+"pwd="+pwd);
        //cmkj.Utils.QRCreate(this.qwNode, "http://www.baidu.com?paramStr=dW5hbWUlM0RjbWtqX3Rlc3QyMSUyNnB3ZCUzRGVhYmQ4Y2U5NDA0NTA3YWE4YzIyNzE0ZDNmNWVhZGE5");
		
		this.eq_group=new eui.Group();
		this.eq_group.width=300;
		this.eq_group.height=300;
		this.eq_group.x=this.width/2-this.eq_group.width/2;
		this.eq_group.y=this.height/2-this.eq_group.height/2;

		var eq_bg:eui.Image=new eui.Image();
		eq_bg.texture=RES.getRes("whiteBg_png");
		eq_bg.width=300;
		eq_bg.height=300;
		eq_bg.scale9Grid=new egret.Rectangle(4,4,4,4);

		var  sprite:egret.Sprite = qr.QRCode.create(App.GlobalData.DownLoadUrl+"?paramStr="+data,0,300,300);
		sprite.x=this.eq_group.width/2-sprite.width/2;
		sprite.y=this.eq_group.height/2-sprite.height/2;
		this.eq_group.addChild(eq_bg);
		this.eq_group.addChild(sprite);

		this.addChild(this.eq_group);
	}


	
		
}