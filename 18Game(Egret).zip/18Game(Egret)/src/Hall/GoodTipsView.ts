class GoodTipsView extends ItemParent {
	private good_tips:eui.Image;
	public constructor() {
		super();
		
	}

	initEventListener(){
		App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE,this.dataChanged,this);
	}

	removeMyEventListener(){
		App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE,this.dataChanged,this);
		
	}

	dataChanged() {
		if(App.LangUtils.kind=="ZH"){
			this.good_tips.texture=RES.getRes("goodTips"+this.data+"_png");
		}else{
			this.good_tips.texture=RES.getRes("goodTips"+this.data+"_en_png");
		}
		
	}
	
}