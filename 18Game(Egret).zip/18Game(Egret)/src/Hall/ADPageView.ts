class ADPageView extends eui.Scroller{
	private ad_scroller:eui.Scroller;
	private ad_list:eui.List;
	private ad_timer: egret.Timer
	private ad_pageIndex:number;
	private ad_touchStartX:number;
	private ad_touchEndX:number;
	private ad_pageCount:number=5;
	private euiArr:eui.ArrayCollection;
	public constructor() {
		super();
	}

	private adTouchBegin(evt:egret.TouchEvent){
		this.ad_timer.stop();
		this.ad_touchStartX=evt.localX;
	}

	private adTouchCancel(evt:egret.TouchEvent){
		this.ad_touchEndX=evt.localX;
		if(this.ad_touchStartX>this.ad_touchEndX){
			if(this.ad_pageIndex<this.ad_pageCount){
				this.ad_pageIndex++;
			}
			
		}else{
			if(this.ad_pageIndex>0){
				this.ad_pageIndex--;
			}
			
		}
		egret.Tween.get(this.ad_scroller.viewport).to({scrollH:this.ad_pageIndex*810}, 300, egret.Ease.sineIn );
		this.ad_timer.start();
	}

	private adTouchEnd(evt:egret.TouchEvent){
		this.ad_touchEndX=evt.localX;
		this.ad_timer.start();
	}

	private adScrolMove(evt:egret.TouchEvent){
		//this.ad_scroller.viewport.scrollH=evt.localX;
	}



	private adTimerFunc(event: egret.Event) {
		if(this.ad_pageIndex>this.ad_pageCount){
			this.ad_pageIndex=0
		}
		this.ad_pageIndex++;
		egret.Tween.get(this.ad_scroller.viewport).to({scrollH:this.ad_pageIndex*810}, 300, egret.Ease.sineIn );
	}

	public dataChanged(dataArr:any[]){
			// 转成eui数据
		if(!this.euiArr){
			this.euiArr=new eui.ArrayCollection(dataArr);
			this.ad_list.dataProvider=this.euiArr;
			this.ad_list.itemRenderer=ADView;
		}else{
			this.euiArr.replaceAll(dataArr);
		}
		if(!this.ad_timer){
			this.ad_timer = new egret.Timer(2000, 0);

        	this.ad_timer.addEventListener(egret.TimerEvent.TIMER, this.adTimerFunc, this);
        
        	this.ad_timer.start();

			this.ad_pageIndex=0

				
			this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_MOVE,this.adScrolMove,this);
			this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.adTouchBegin,this);
			this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_CANCEL,this.adTouchCancel,this);
			this.ad_scroller.addEventListener(egret.TouchEvent.TOUCH_END,this.adTouchEnd,this);
		}
	}
	
}