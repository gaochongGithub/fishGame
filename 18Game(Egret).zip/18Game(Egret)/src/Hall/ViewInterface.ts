interface ViewInterface {
	initEventListener();
	removeMyEventListener();
	onRemoveStage(event:egret.Event);
	initView();
}