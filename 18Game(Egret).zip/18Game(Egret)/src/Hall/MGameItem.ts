class MGameItem extends ItemParent {
	private game_name:eui.Label;
	private player_count:eui.Label;
	private coin_count:eui.Label;
	private laddy_name:eui.Label
	private laddy_head:eui.Image;
	private itemData:GameHallItemModel;
	private tips_pageview:GoodTipsPageView;
	private imgLoader:egret.ImageLoader;
	public constructor() {
		super();
	}
	// 当数据改变时，更新视图
	dataChanged() {
		this.itemData=this.data;
		switch (this.itemData.getTableSnapshot.gameType){
			case proto.GameType.Baccarat:
				this.game_name.text=App.LangUtils.getStr("TEXT_BACCARAT")+":"+this.itemData.getTableSnapshot.tableID;
			break;
			case proto.GameType.Roulette:
				this.game_name.text=App.LangUtils.getStr("TEXT_Roulette")+":"+this.itemData.getTableSnapshot.tableID;
			break;
		}
		this.player_count.text=this.itemData.getTableSnapshot.playerCount.toString();
		this.coin_count.text=this.itemData.getTableSnapshot.playerTotalBlance.toString();
		var reusltArr = GoodTips.instance.checkTips(this.itemData.getTableSnapshot.tableID, this.itemData.getAllWays);
		let dataArr=new Array<any>();
		for (var index of reusltArr) { 
    		var goodTipsType = index.type;
			if(goodTipsType!=-1){
				dataArr.push(Math.floor(goodTipsType)); 
			}
		}
		if(dataArr.length>0){
			this.tips_pageview.dataChanged(dataArr);
			this.tips_pageview.visible=true;
		}else{
			this.tips_pageview.visible=false;
		}
		
		this.laddy_name.text=this.itemData.getTableSnapshot.dealer;
        let url = this.itemData.getTableSnapshot.dealerImage;
		this.imgLoader = new egret.ImageLoader();
        this.imgLoader.crossOrigin = "anonymous";// 跨域请求
        this.imgLoader.load(url);// 去除链接中的转义字符‘\’        
        this.imgLoader.once(egret.Event.COMPLETE, (evt: egret.Event)=>{
            if (evt.currentTarget.data) {
                let texture = new egret.Texture();
				texture.bitmapData = evt.currentTarget.data;
				this.laddy_head.source=texture;
                // texture.bitmapData = evt.currentTarget.data;
                // let bitmap = new egret.Bitmap(texture);
                // bitmap.x = 200;
                // bitmap.y = 200;
                // this.addChild(bitmap);
            }
        }, this);
	}
	
}