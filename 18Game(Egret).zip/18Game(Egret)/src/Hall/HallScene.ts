abstract class HallScene extends SceneParent {
	protected gameItem:GameItem;
	protected game_list:eui.List;
	protected game_scroller:eui.Scroller;
	protected rechage_btn:eui.Button;
	protected name_text:eui.Label;
	protected gold_text:eui.Label;
	protected bGameRadio:eui.RadioButton;
	protected lGameRadio:eui.RadioButton;
	protected videoBtn:eui.CheckBox;
	protected soundBtn:eui.CheckBox;
	protected ruleBtn:eui.Button;
	protected settingBtn:eui.Button;
	protected exitBtn:eui.Button;
	protected gameServer:any;
	private euiArr:eui.ArrayCollection;
	protected gameType:any;
	public constructor() {
		super();
	}

	
	//add一些监听事件
	abstract initEventListener():void;

	//remove一些监听事件
	abstract removeMyEventListener():void;

	//初始化界面
	abstract initView():void;

	//初始化一些可以由父类实现的共同监听事件
	private initCommonEventListener(){
		this.rechage_btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onReChangeBtn, this);
		App.MessageCenter.addListener(ServerEvent.GET_LOBBY_PLAYER_INFO,this.upDataPlayerInfo,this);
		this.bGameRadio.addEventListener(egret.Event.CHANGE,this.gameRadioChange,this);
		this.lGameRadio.addEventListener(egret.Event.CHANGE,this.gameRadioChange,this);
		App.MessageCenter.addListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM,this.addRoadItem,this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.settingBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onSettingBtn,this);
		this.ruleBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onRuleBtn,this);
		this.videoBtn.addEventListener(egret.Event.CHANGE,this.onVideoChange,this);
		this.soundBtn.addEventListener(egret.Event.CHANGE,this.onSoundBtnChange,this);
		App.MessageCenter.addListener(LobbyEvent.MUISC_SOUND_CHANGE,this.onSoundChange,this);
		this.exitBtn.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickLoginOutBtn,this)
		
	}

	private removeCommonEventListener(){
		this.rechage_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onReChangeBtn, this);
		App.MessageCenter.removeListener(ServerEvent.GET_LOBBY_PLAYER_INFO,this.upDataPlayerInfo,this);
		this.bGameRadio.removeEventListener(egret.Event.CHANGE,this.gameRadioChange,this);
		this.lGameRadio.removeEventListener(egret.Event.CHANGE,this.gameRadioChange,this);
		App.MessageCenter.removeListener(LobbyEvent.ADD_LOBBY_ROAD_ITEM,this.addRoadItem,this);
		this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.settingBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onSettingBtn,this);
		this.ruleBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onRuleBtn,this);
		this.videoBtn.removeEventListener(egret.Event.CHANGE,this.onVideoChange,this);
		this.soundBtn.removeEventListener(egret.Event.CHANGE,this.onSoundBtnChange,this);
		App.MessageCenter.removeListener(LobbyEvent.MUISC_SOUND_CHANGE,this.onSoundChange,this);
		this.exitBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickLoginOutBtn,this)
	}

	protected onRemoveStage(event:egret.Event) {
		this.removeMyEventListener();
		this.removeCommonEventListener();
		
	}

	private onVideoChange(){
		egret.localStorage.setItem("isCanPlayVideo",this.videoBtn.selected?"1":"0");
	}

	private onSoundBtnChange(){
		if(this.soundBtn.selected){
			App.SoundManager.setBgOn(true);
			App.SoundManager.setEffectOn(true);
		}else{
			App.SoundManager.setBgOn(false);
			App.SoundManager.setEffectOn(false);
		}

	}

	private onSoundChange(){
		this.soundBtn.selected=App.SoundManager.bgIsOn||App.SoundManager.effectIsOn;	
	}

	private onSettingBtn(){
		App.ToastViewManager.toast(new SettingView,false,true);
	}

	private onRuleBtn(){
		App.ToastViewManager.toast(new RuleView,false,true);
	}

	private upDataPlayerInfo(){
		var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
		this.name_text.text=playerInfo.name;
		this.gold_text.text="￥ "+playerInfo.balance;

	}


	addRoadItem(){
		var lobbyTableInfo=LobbyTableInfoCtrl.instance.getLobbyTableArrByGameType(this.gameType);
		if(lobbyTableInfo){
			if(!this.euiArr){
				//插入轮播广告 暂时无数据
				if(App.DeviceUtils.IsMobile){
					this.game_list.itemRenderer=MGameItem;
				}else{
					lobbyTableInfo.splice(1, 0, {})
					this.game_list.itemRenderer=GameItem;
				}
				this.euiArr = new eui.ArrayCollection(lobbyTableInfo);
				this.game_list.dataProvider=this.euiArr;
				
			}else{
				if(!App.DeviceUtils.IsMobile)
					lobbyTableInfo.splice(1, 0, {})
				this.euiArr.replaceAll(lobbyTableInfo);
			}
		}	
	}


	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}

	protected onReChangeBtn(event: egret.TouchEvent){
		// var chats=new chat();
		// this.addChild(chats);
		// chats.horizontalCenter=0;
		// chats.verticalCenter=0;
		//App.LangUtils.changeLang("EN");
		// var data=LobbyTableInfoCtrl.instance.getLobbyOneTable(11,1);
		// console.log("LobbyTableInfoCtrl"+data.getTableSnapshot.counts)
		// var aa=new TimeCompentView(this);
		// this.addChild(aa);
		//var aa=new SettingView();
		//this.addChild(aa);

		//App.ToastViewManager.toast(new SettingView,false);
		// var lobbyTableInfo=LobbyTableInfoCtrl.instance.getLobbyTableArr();

		 App.ToastViewManager.toast(new RecordView(),false,true);

		// if (!App.DeviceUtils.IsNative){
		// 	var url = egret.localStorage.getItem("chargeUrl"); 
		// 	url&&window.open(url);
        // }

	}

	protected onScrollerChange(){

	}

	protected childrenCreated():void
	{
		super.childrenCreated();
		this.initView();
		this.initCommonEventListener();
		this.initEventListener();
		this.upDataPlayerInfo();
		this.gameType=proto.GameType.Baccarat;
		this.onSoundChange();
		var isCanPlayVideo=egret.localStorage.getItem("isCanPlayVideo");
		this.videoBtn.selected=isCanPlayVideo=="1";
		this.addRoadItem();
		
	}

	gameRadioChange(e:egret.Event){
		 var radioButton = <eui.RadioButton>e.target;
		 switch (Number(radioButton.value)){
			 case proto.GameType.Baccarat:
			 	this.gameType=proto.GameType.Baccarat;
				 this.addRoadItem();
			  	break;
			case proto.GameType.Roulette:
				this.gameType=proto.GameType.Roulette;
				this.addRoadItem();
				break;
		}
	}

	onClickLoginOutBtn(){
        if(!App.DeviceUtils.IsNative) {
            window.opener=null;
            window.open('','_self');
            window.close();
            window.history.back();
            window.location.reload();
		}
	}
	
}