class ComponentParent extends eui.Component implements eui.UIComponent, ViewInterface{
	public constructor() {
		super();
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
	}

	//注册消息
	initEventListener(){

	}
	//移除消息
	removeMyEventListener(){
	}
	//移除消息
	onRemoveStage(event:egret.Event){
		this.removeMyEventListener();
	}
	
	initView(){}

	protected childrenCreated():void
	{
		super.childrenCreated();
		this.initEventListener();
		this.initView();

	}

	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);

	}
	
}