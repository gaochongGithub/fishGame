class ADView extends ItemParent {
	public constructor() {
		super();
		
	}
	initView(){
		this.skinName=ADViewSkin;
	}
	
}