class GoodTipsPageView extends eui.Scroller implements  eui.UIComponent {
	private tips_scroller:eui.Scroller;
	private tips_list:eui.List;
	private tips_timer: egret.Timer
	private tips_pageIndex:number;
	private tips_touchStartY:number;
	private tips_touchEndY:number;
	private tips_pageCount:number;
	private euiArr:eui.ArrayCollection;
	public constructor() {
		super();
	}

	private tipsTouchBegin(evt:egret.TouchEvent){
		this.tips_timer.stop();
		this.tips_touchStartY=evt.localY;
	}

	private tipsTouchCancel(evt:egret.TouchEvent){
		this.tips_touchEndY=evt.localY;
		if(this.tips_touchStartY>this.tips_touchEndY){
			if(this.tips_pageIndex<this.tips_pageCount){
				this.tips_pageIndex++;
			}
			
		}else{
			if(this.tips_pageIndex>0){
				this.tips_pageIndex--;
			}
			
		}
		egret.Tween.get(this.tips_scroller.viewport).to({scrollV:this.tips_pageIndex*46}, 300, egret.Ease.sineIn );
		this.tips_timer.start();
	}

	private tipsTouchEnd(evt:egret.TouchEvent){
		this.tips_touchEndY=evt.localY;
		this.tips_timer.start();
	}

	private tipsScrolMove(evt:egret.TouchEvent){
		//this.ad_scroller.viewport.scrollH=evt.localX;
	}



	private tipsTimerFunc(event: egret.Event) {
		this.tips_pageIndex++;
		if(this.tips_pageIndex>=this.tips_pageCount){
			this.tips_pageIndex=0
		}
		
		egret.Tween.get(this.tips_scroller.viewport).to({scrollV:this.tips_pageIndex*46}, 300, egret.Ease.sineIn );
	}

	public dataChanged(dataArr:any[]){
			// 转成eui数据
		this.tips_pageCount=dataArr.length;
		if(!this.euiArr){
			this.euiArr=new eui.ArrayCollection(dataArr);
			this.tips_list.dataProvider=this.euiArr;
			this.tips_list.itemRenderer=GoodTipsView;
		}else{
			this.euiArr.replaceAll(dataArr);
		}

		if(!this.tips_timer){
			this.tips_timer = new egret.Timer(2000, 0);

        	this.tips_timer.addEventListener(egret.TimerEvent.TIMER, this.tipsTimerFunc, this);
        
        	this.tips_timer.start();

			this.tips_pageIndex=0

				
			// this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_MOVE,this.tipsScrolMove,this);
			// this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.tipsTouchBegin,this);
			// this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_CANCEL,this.tipsTouchCancel,this);
			// this.tips_scroller.addEventListener(egret.TouchEvent.TOUCH_END,this.tipsTouchEnd,this);
		}
	}
}