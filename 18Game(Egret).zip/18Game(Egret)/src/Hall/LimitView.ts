class LimitView extends ComponentParent {
	private limit_list:eui.List;
	private dataArr=new Array<LimitViewModel>();
	private euiArr:eui.ArrayCollection;
	public constructor() {
		super();
	}
	public setLimitData(gameType:number,limitID:number,tableID:number){
		var limitRed=HallDataCtrl.instance.getGameLimitRed(gameType);
		this.dataArr=[];
		for (var key in limitRed) {
			var limitObject=limitRed[key];
			var limitViewModel=new LimitViewModel();
			if(limitObject.getLimitRedID==limitID){
				limitViewModel.setIsChose(true);
			}else{
				limitViewModel.setIsChose(false);
			}
			limitViewModel.setLimitChoseID(limitObject.getLimitRedID);
			limitViewModel.setLimitChoseCount(limitObject.getLimitRedCounts);
			limitViewModel.setGameType(gameType);
			limitViewModel.setGameTable(tableID);
			this.dataArr.push(limitViewModel);
		}
		var sortArray=this.dataArr.sort(this.compare);
		if(!this.euiArr){
			this.euiArr= new eui.ArrayCollection(sortArray); 
			this.limit_list.dataProvider=this.euiArr;
			this.limit_list.itemRenderer=LImitRadioBtn;
		 }else{
			
			this.euiArr.replaceAll(sortArray);
		}
		
	}
	//排序
	private compare(obj1,obj2){
		var data1=obj1.getLimitChoseCount.split("-");
        var data2=obj2.getLimitChoseCount.split("-");

        if(Number(data1[0])==Number(data2[0])){
            var val1=Number(data1[1]);
            var val2=Number(data2[1])
        }else{
            var val1=Number(data1[0]);
            var val2=Number(data2[0])
        }
    	if(val1 < val2){
        	return -1;
    	}else if(val1 > val2){
    		return 1;
        }else{
        	return 0;
    	}
    }
}