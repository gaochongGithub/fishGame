class GameItemView extends ComponentParent{

	private player_count:eui.Label;
	private coin_count:eui.Label;
	private game_name:eui.Label;
	private zhuan_count:eui.Label;
	private xian_count:eui.Label;
	private laddy_head:eui.Image;
	private laddy_name:eui.Label;
	private limitBtn:eui.Group;
	private eGameBtn:eui.Button;
	private tips_pageview:GoodTipsPageView;
	private imgLoader:egret.ImageLoader;
	private limitView:LimitView;
	private data:any;
	private limitBtnText:eui.Label;
	private itemData:GameHallItemModel;
	private roadView:eui.Group;
	private roadScene:RoadScene;
	private rouletteRoadScene:RouletteRoadScene;
	private shuffle:eui.Group;
	private zhuan_layout:eui.Group;
	private xian_layout:eui.Group;
	public constructor() {
		super();
	}

	initEventListener(){
		this.limitBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onLimitChose, this);
		this.eGameBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.toGameScene, this);

	}

	removeMyEventListener(){
		this.limitBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onLimitChose, this);
		this.eGameBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.toGameScene, this);
	}


	private onLimitChose(event: egret.TouchEvent){
		var isShow:boolean=this.limitView.visible;
		this.itemData.setIsShwoView(!isShow);
		App.MessageCenter.dispatch(LobbyEvent.SHOW_LIMIT_VIEW,!isShow);
	}

	//跳转游戏
	private toGameScene(event: egret.TouchEvent){
		let loadGameModel=new LoadGameModel();
		var gameType=Number(this.itemData.getTableSnapshot.gameType);
		var limitID=Number(this.itemData.getLimitRedID);
		var gameModel=HallDataCtrl.instance.getLimitIDLimitRed(gameType,limitID);
		loadGameModel.setAllChip(gameModel.getAllChips);
		loadGameModel.setChip(gameModel.getChips);
		loadGameModel.setDealerImage(this.itemData.getTableSnapshot.dealerImage);
		loadGameModel.setGameType(gameType);
		loadGameModel.setLimitRed(gameModel.getLimitRedCounts);
		loadGameModel.setLimitRedID(limitID);
		loadGameModel.setTableID(this.itemData.getTableSnapshot.tableID);
		loadGameModel.setJoinType(proto.UserRequest.JoinType.Common);
		var isCanPlayVideo=egret.localStorage.getItem("isCanPlayVideo");
		loadGameModel.setIsCanPlayVideo(isCanPlayVideo=="1");
		var playerType=HallDataCtrl.instance.getLobbyPlayer.playerType;
		loadGameModel.setPlayerType(playerType);
		if(gameType==proto.GameType.Roulette)
			loadGameModel.setSubType(proto.Game.Subtype.Roulette);
		else
			loadGameModel.setSubType(proto.Game.Subtype.ClassicBaccarat);
		 HallDataCtrl.instance.setLoadGameData(loadGameModel);
		 GameSceneCtrl.instance.toGameScene(gameType);
		 App.SoundManager.playBg("bgmusic_mp3");
		 
		  //App.SoundManage("bgmusic_mp3");
		//App.GameServer.sendJoinTable(gameType,this.itemData.getTableSnapshot.tableID,proto.UserRequest.JoinType.VipTable);
	}

	initView(){

		this.roadScene=new RoadScene(22);
		this.rouletteRoadScene=new RouletteRoadScene(22);
		this.roadView.addChild(this.rouletteRoadScene);
		this.roadView.addChild(this.roadScene);
		this.roadView.setChildIndex(this.shuffle,100);
	}


	public dataChanged(data:GameHallItemModel,isChageItemData:boolean,isChangeLanguage:boolean){
		if(data.getTableSnapshot.gameType==proto.GameType.Baccarat){
			this.rouletteRoadScene.visible=false;
			this.roadScene.visible=true;
		}else{
			this.rouletteRoadScene.visible=true;
			this.roadScene.visible=false;
		}
		if(isChangeLanguage){
			switch (this.itemData.getTableSnapshot.gameType){
				case proto.GameType.Baccarat:
					this.game_name.text=App.LangUtils.getStr("TEXT_BACCARAT")+":"+this.itemData.getTableSnapshot.tableID;
				break;
				case proto.GameType.Roulette:
					this.game_name.text=App.LangUtils.getStr("TEXT_Roulette")+":"+this.itemData.getTableSnapshot.tableID;
				break;
			}
			if(data.getTableSnapshot.gameType==proto.GameType.Baccarat){
				this.roadScene.clear();
				this.roadScene.addString(this.itemData.getAllWays);
			}else{
				this.rouletteRoadScene.clear();
				this.rouletteRoadScene.addString(this.itemData.getAllWays);
			}
			
			return;
		}

		this.itemData=data;
		if(this.itemData.getIsShowView){
			this.limitView.visible=true;
		}else{
			this.limitView.visible=false;
		}
		var limitID=this.itemData.getLimitRedID;
		var gameModel=HallDataCtrl.instance.getLimitIDLimitRed(this.itemData.getTableSnapshot.gameType,limitID);
		this.limitBtnText.text=gameModel.getLimitRedCounts;
		this.limitView.setLimitData(this.itemData.getTableSnapshot.gameType,limitID,this.itemData.getTableSnapshot.tableID);
		//减少不必要的界面刷新,只刷新限红相关
		if(!isChageItemData)
			return;

		if(data.getTableSnapshot.gameType==proto.GameType.Baccarat){
			this.roadScene.clear();
			this.roadScene.addString(this.itemData.getAllWays);
		}else{
			this.rouletteRoadScene.clear();
			this.rouletteRoadScene.addString(this.itemData.getAllWays);
		}

		if(this.itemData.getTableSnapshot.status==0){
			this.shuffle.visible=true;
		}else{
			this.shuffle.visible=false;
		}
		
		switch (this.itemData.getTableSnapshot.gameType){
			case proto.GameType.Baccarat:
				this.game_name.text=App.LangUtils.getStr("TEXT_BACCARAT")+":"+this.itemData.getTableSnapshot.tableID;
				this.zhuan_layout.visible=true;
				this.xian_layout.visible=true;
			break;
			case proto.GameType.Roulette:
				this.game_name.text=App.LangUtils.getStr("TEXT_Roulette")+":"+this.itemData.getTableSnapshot.tableID;
				this.zhuan_layout.visible=false;
				this.xian_layout.visible=false;
			break;
		}
		this.player_count.text=this.itemData.getTableSnapshot.playerCount.toString();
		this.coin_count.text=this.itemData.getTableSnapshot.playerTotalBlance.toString()
		var betinfo=this.itemData.getTableSnapshot.betinfo;
        for(var i in betinfo){
            if(Number(i)==proto.Game.BettingArea.BaccaratPlayer)
                this.zhuan_count.text=betinfo[i].player_count + "/" + betinfo[i].amount;
            if(Number(i)==proto.Game.BettingArea.BaccaratBanker)
                this.xian_count.text=betinfo[i].player_count + "/" + betinfo[i].amount;
        }
		var reusltArr = GoodTips.instance.checkTips(this.itemData.getTableSnapshot.tableID, this.itemData.getAllWays);
		let dataArr=new Array<any>();
		for (var index of reusltArr) { 
    		var goodTipsType = index.type;
			if(goodTipsType!=-1){
				dataArr.push(Math.floor(goodTipsType)); 
			}
		}
		if(dataArr.length>0){
			this.tips_pageview.dataChanged(dataArr);
			this.tips_pageview.visible=true;
		}else{
			this.tips_pageview.visible=false;
		}
		
		this.laddy_name.text=this.itemData.getTableSnapshot.dealer;
        let url = this.itemData.getTableSnapshot.dealerImage;
		this.imgLoader = new egret.ImageLoader();
        this.imgLoader.crossOrigin = "anonymous";// 跨域请求
        this.imgLoader.load(url);      
        this.imgLoader.once(egret.Event.COMPLETE, (evt: egret.Event)=>{
            if (evt.currentTarget.data) {
                let texture = new egret.Texture();
				texture.bitmapData = evt.currentTarget.data;
				this.laddy_head.source=texture;
            }
        }, this);
	}

}