class GameItem extends ItemParent {
	private adPageview:ADPageView;
	private gameItemView:GameItemView;

	public constructor() {
		super();
		
		
	}

	initEventListener(){
		App.MessageCenter.addListener(LobbyEvent.SHOW_LIMIT_VIEW,this.limitShowChange,this);
		App.MessageCenter.addListener(LobbyEvent.LIMIT_CHOOSE,this.limitChose,this);
		App.MessageCenter.addListener(GlobalEvent.CHANGE_LANGUAGE,this.onLanguageChange,this);
	}

	removeMyEventListener(){
		App.MessageCenter.removeListener(GlobalEvent.CHANGE_LANGUAGE,this.onLanguageChange,this);
	}

	

	onLanguageChange(){
		if(this.gameItemView){
			this.gameItemView.dataChanged(this.data,false,true);
		}
		
	}

	private limitChose(limitViewModel:LimitViewModel){
		if(this.data.gameTable==limitViewModel.getGameTable){
			this.data.isShowView=false;
			this.data.limitRedID=limitViewModel.getLimitChoseID;
			this.gameItemView.dataChanged(this.data,false,false);
		}
		
		
	}

	private limitShowChange(){
		if(this.gameItemView){
			this.gameItemView.dataChanged(this.data,false,false);
		}
		
	}



	// 当数据改变时，更新视图
	dataChanged() {
		if(!this.data.getTableSnapshot){
			this.skinName=ADItem;
			// 原始数组
			let dataArr:any[] = [
				{type: '0', name: '亚特伍德'},
				{type: '1', name: '亚特伍德1'},
				{type: '0', name: '亚特伍德2'},
				{type: '0', name: '亚特伍德3'},
				{type: '0', name: '亚特伍德4'},
				{type: '0', name: '亚特伍德5'},
				{type: '0', name: '亚特伍德6'},
	
			]
			this.adPageview.dataChanged(dataArr);
		}else{
			this.skinName=GameItemSkin;
			this.gameItemView.dataChanged(this.data,true,false);
		 }
	}
	
}