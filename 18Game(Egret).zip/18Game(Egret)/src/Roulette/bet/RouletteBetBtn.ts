class RouletteBetBtn extends eui.Component implements  eui.UIComponent {
	private btn_confirm:eui.Button;
	private btn_cancel:eui.Button;
	private unConfirmBetAmount={};
	public constructor() {
		super();
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	private BetAreaAndAmountTable = {};
	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}
	protected childrenCreated():void
	{
		super.childrenCreated();
	}
	private onAddtoStage(event:egret.Event) {
		this.btn_confirm.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickConfirmBtn, this);
		this.btn_cancel.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickCancelBtn, this);
		App.MessageCenter.addListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAreaAndBetAmount, this);
		App.MessageCenter.addListener(RouletteEvent.GAME_STATE_STOP , this.gameStatesStop , this);
		//重复下注
        App.MessageCenter.addListener(RouletteEvent.SEND_REPEAT_DATA , this.addBetAreaAndBetAmount , this);
	}
	private onRemoveFromStage(event:egret.Event) {
		App.MessageCenter.removeListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT, this.addBetAreaAndBetAmount, this);
		App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_STOP , this.gameStatesStop , this);
		App.MessageCenter.removeListener(RouletteEvent.SEND_REPEAT_DATA , this.addBetAreaAndBetAmount , this);
		this.btn_confirm.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickConfirmBtn, this);
		this.btn_cancel.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickCancelBtn, this);
	}
	/**
	 * 点击确认按钮
	 */
	private onClickConfirmBtn() {
		this.btn_confirm.enabled = false;
		this.btn_cancel.enabled = false;
		App.MessageCenter.dispatch(RouletteEvent.CONFIRM_CHIP);
		this.sendBetMessage();
	}
	/**
	 * 点击取消下注按钮
	 */
	private onClickCancelBtn() {
		this.btn_confirm.enabled = false;
		this.btn_cancel.enabled = false;
		this.cancelChipinBetArea();
	}
	private gameStatesStop(){
		this.btn_confirm.enabled = false;
		this.btn_cancel.enabled = false;
		this.cleaBetAreaAbdBetAmount();
	}
	/**
	 * 添加下注信息
	 */
	private addBetAreaAndBetAmount(event:any) {
		var betAreaAndBetAmount:any = event;
		// this.BetAreaAndAmountTable[betAreaAndBetAmount.betAmount] = betAreaAndBetAmount.betAmount;
		var tempBetAmount = betAreaAndBetAmount.betAmount;
		var total = 0;
		for(var key in betAreaAndBetAmount){
			this.BetAreaAndAmountTable[key] = betAreaAndBetAmount[key];
			total +=betAreaAndBetAmount[key];
		}
		if(total > 0){
			this.btn_confirm.enabled = true;
			this.btn_cancel.enabled = true;
		}
		
	}
	private pivot(arr){
		for(var i in arr){    
	        for(var j in arr){
	            if(arr[i].betArea == arr[j].betArea && i!=j){
	              arr[i].betAmount= arr[j].betAmount
	              arr.splice(j,1)
	            }else{
	                arr[i]
	            }
	        }
	    }
	    return arr
	}
	/**
	 * 移除临时下注信息
	 */
	private removeBetAreaAndBetAmount() {
		App.MessageCenter.dispatch(RouletteEvent.REMOVE_UNCONFIRM_CHIP);
		this.cleaBetAreaAbdBetAmount();
	}
	/**
	 * 发送下注信息
	 */
	private sendBetMessage() {
		let model = HallDataCtrl.instance.getLoadGameData;
		let limitID = model.getLimitRedID;
		let tableId = model.getTableID;
		GameServer.getSingtonInstance().sendBet(tableId , proto.Game.Subtype.Roulette , this.BetAreaAndAmountTable , limitID);
		this.cleaBetAreaAbdBetAmount();
	}
	/**
	 * 清空下注数据
	 */
	private cleaBetAreaAbdBetAmount() {
		this.BetAreaAndAmountTable = {};
	}
	/**
	 * 取消下注区域的筹码
	 */
	private cancelChipinBetArea() {
		this.removeBetAreaAndBetAmount();
	}
}