class NumBetButton extends RouletteBetButton{
	public constructor() {
		super();
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddedToStage, this);
    	this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemovedFromStage, this);
	}
	private num:number = 0;             //该按钮的数值
    private isEven:boolean = true;        //是否偶数
    private isRed:boolean = true;       //红还是黑
    private isLarge:boolean = true;         //大还是小
    private range:number = 0;           //范围(1-12,13-24,25-36)
    private remainder:number = 0;          //倍数

	 private onAddedToStage() {
        App.MessageCenter.addListener(RouletteEvent.GET_GAME_RESULT, this.getGameResult, this);
    }

    private onRemovedFromStage() {
          App.MessageCenter.removeListener(RouletteEvent.GET_GAME_RESULT, this.getGameResult, this);
    }
    /**
     * 获取结果
     */
    private getGameResult(event:any) {
        var result = event;
        if (result == this.num) {
            this.sendOtherEventId();
        }
    }
     /**
     * 设置按钮数值
     */
    public setNum(num:number, x:number, y:number, width:number, height:number) {
        this.num = num;
        // this.setTextBtn(x, y, width, height, imageName, num.toString());
    
        var isRed = (this.getBtnColor(num) == "red")?true:false;
        this.setNumType(isRed)
    }
    /**
	 * 返回1-9和19-23的按钮背景
	 */
	private getBgName1To9And19To23(index) {
		if (index%2 == 0) {
			return  "black";
		} else {
			return  "red";
		}
	}

	/**
	 * 返回11-18和29-36的按钮背景
	 */
	private getBgName11To18And29To36(index) {
		if (index%2 != 0) {
			return  "black";
		} else {
			return  "red";
		}
	}

    /**
     * 获取背景色
     */
    public getBgImagename(num) {
        var imageName = ""
        if (num <= 9 || ( num >= 19 && num <= 27 ) ) {
            imageName = this.getBgName1To9And19To23(num);
        } else if( num == 10 || num == 28) {
            imageName = "black";
        } else if( num <= 18 || ( num >= 29 && num <= 36 ) ) {
            imageName = this.getBgName11To18And29To36(num);
        }
        return imageName;
    }
	//获取按钮颜色
	public getBtnColor(i:number){
		var imageName = ""
		if(i>0 && i<11){
			if(i%2 == 0){
				imageName = "black";
			}else{
				imageName = "red";
			}
		}else if(i>10 && i<=19){
            if(i == 13){
                imageName = "red";
            }else{
                if(i%2 == 0){
                    imageName = "red";
                }else{
                    imageName = "black";
                }
            }
			
		}else if(i>19 && i<29){
			if(i%2 == 0){
				imageName = "black";
			}else{
				imageName = "red";
			}
		}else{
			if(i%2 == 0){
				imageName = "red";
			}else{
				imageName = "black";
			}
		}
		return imageName;
	}
    /**
     * 设置数值类型
     */
    private setNumType(isRed:boolean) {
        this.setNumIsEven();
        this.setNumIsRed(isRed);
        this.setNumIsLarge();
        this.setNumRange();
        this.setNumRemainder();
    }
    private setNumIsEven() {
        var isEven = (this.num%2 == 0);
        this.isEven = isEven
    }
    private setNumIsRed(isRed) {
        this.isRed = isRed;
    }

    private setNumIsLarge() {
        this.isLarge = (this.num >=19);
    }

    private setNumRange() {
        var range = Math.ceil(this.num/12);
        this.range = range;
    }

    private setNumRemainder() {
        var remainder = this.num%3;
        this.remainder = remainder;
    }
	/**
     * 设置信息返回时该按钮的响应范围
     */
    private sendOtherEventId() {
        var otherEventIdTable:string[] = [];
        // this.backImage.alpha = 1;
        egret.Tween.get(this.backImage,{loop:false}).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500);
        if (this.isEven) {
            otherEventIdTable.push("653");
        } else {
            otherEventIdTable.push("656");
        }

        if (this.isRed) {
            otherEventIdTable.push("654");
        } else {
            otherEventIdTable.push("655");
        }

        if (this.isLarge) {
            otherEventIdTable.push("657");
        } else {
            otherEventIdTable.push("652");
        }

        otherEventIdTable.push((648+this.range).toString());
        var remainder = (646+(3-this.remainder)%3).toString()
        otherEventIdTable.push(remainder);
        App.MessageCenter.dispatch(RouletteEvent.RESULT_BET_BTN_ADD_MASK,otherEventIdTable);
        // var event = egret.Event.create(egret.Event, Events.RESULT_BET_BTN_ADD_MASK);
        // event.data = otherEventIdTable;
        // EventDispatcher.getInstance().dispatchEvent(event);
    }
}