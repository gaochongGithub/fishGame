class RouletteRepeatBtn extends eui.Component implements  eui.UIComponent {
	private repeatTotal:number = 0;
	private btn_rebet:eui.Button;
	private isConfirm:boolean = false;
	private isStop:boolean = false;
	public constructor() {
		super();
		this.skinName = ""
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	private onAddtoStage(event:egret.Event){
		this.btn_rebet.addEventListener(egret.TouchEvent.TOUCH_TAP , this.onClick , this)
		//获取用户信息
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO , this.confirmBetAmount , this)
		//游戏状态
		App.MessageCenter.addListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
		//点击确认
		App.MessageCenter.addListener(RouletteEvent.CONFIRM_CHIP , this.confirmFunc , this);
		//点击取消
		App.MessageCenter.addListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP , this.cancelFunc , this);
		//点击下注区
		App.MessageCenter.addListener(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT , this.clickBetArea , this)
	}
	private onRemoveFromStage(){
		this.btn_rebet.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.onClick , this)
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO , this.confirmBetAmount , this)
		App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
		App.MessageCenter.removeListener(RouletteEvent.CONFIRM_CHIP , this.confirmFunc , this);
		App.MessageCenter.removeListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP , this.cancelFunc , this);
	}
	private gameStateStart(isTrue){
		this.isConfirm = false;
		this.isStop = !isTrue;
		this.btn_rebet.enabled = false;
		if((isTrue && JSON.stringify(GameDataCtrl.instance.getConfirmBetAmount_R) != "{}")){
			this.btn_rebet.enabled = true;
		}else{
			this.btn_rebet.enabled = false;
		}
	}
	private confirmFunc(){
		this.isConfirm = true;
		this.btn_rebet.enabled = false;
	}
	private cancelFunc(){
		if(this.isConfirm){
			this.btn_rebet.enabled = false;
		}else{
			if(JSON.stringify(GameDataCtrl.instance.getConfirmBetAmount_R) != "{}"){
				this.btn_rebet.enabled = true;
			}
		}
	}
	private confirmBetAmount(data:any){
		this.repeatTotal = data.totalbet;
		GameDataCtrl.instance.setResetData;

		for(var key in data.betinfo){
			GameDataCtrl.instance.setConfirmBetAmount_R(key , data.betinfo[key]);
		}
	}
	private onClick(){
		if(this.checkMaxLimit()){
			this.btn_rebet.enabled = false;
			App.MessageCenter.dispatch(RouletteEvent.SEND_REPEAT_DATA , GameDataCtrl.instance.getConfirmBetAmount_R)
		}else{
			App.ToastViewManager.toastTextView("TEXT_MESSAGE_6");
            return ;
		}
	}
	/**
     * 检查是否超出余额
     */
    private checkMaxLimit() {
        // var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
        // var limit = loadGameModel.getLimitRed;
        // var getMaxBetLimit = limit.split("-");
		var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
        if(this.repeatTotal > playerInfo.balance) {
            return false;
        }
        return true;
    }
	private clickBetArea(){
		this.btn_rebet.enabled = false;
	}
}