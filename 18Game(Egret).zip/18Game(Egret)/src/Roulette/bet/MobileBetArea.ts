class MobileBetArea extends eui.Component implements  eui.UIComponent {
	private center_group:eui.Group;
	private btn_group:eui.Group;
	private right_group:eui.Group;
	private donze_group:eui.Group;
	private bottom_group:eui.Group;
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/bet/MobileBetArea.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE , this.onAddtoStage , this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	protected childrenCreated():void
	{
		super.childrenCreated();
	}
	private onAddtoStage(){
		this.btn_group.touchEnabled = false;
		//数字按钮
		this.addBetNumBtn();
		//添加打按钮
		this.addDozenBtn();
		//添加下部按钮
		this.addBottom();
		//添加右侧按钮
		this.addRightBetBtn();
		this.addLinesUpDown2BetBtn();
        this.addLinesLeftRight2BetBtn();
        this.add1Column3BetBtn();
        this.addLinesTopDownLeftDown4BetBtn();
        this.add2Column6BetBtn();
	}
	private onRemoveFromStage(){

	}
	private addBetNumBtn(){
		for(var i=0;i<=36;i++){
			var betButton:NumBetButton = new NumBetButton();
			var width:number = 65;
			var height:number = 65;
			var margin = 1.5;//间距
			var x:number = 61+(Math.floor((i-1)/3) *(width + margin));
			var y:number = 133-(((i-1)%3) *(width + margin));
			var img = betButton.getBgImagename(i)+"_bg_png";
			var moveImg = "move_bg_png";
			var id = 500+i;
			if(i == 0){
				id = 537;
				width = 55;
				height = 198;
				x = 3;
				y = 0;
				img = "zero_bg_png";
				moveImg = "move_zero_bg_png"
			}
			var eventId = id.toString();
			betButton.setTextBtn( x, y , width , height , img , i.toString());
			betButton.setMobileShow(moveImg);
			betButton.setEventIdAndOthers(eventId, [eventId]);
			betButton.setId(id);
			betButton.setInfluenceNum(1);
			this.center_group.addChild(betButton);
		}
	}
	//添加打按钮
	private addDozenBtn(){
		for(var i=0;i<3;i++){
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 649 + i;
			var width:number = 265;
			var height:number = 50;
			var manger = 1.5;
			betButton.setId(id);
			var text:string = "";
			switch(i) {
			case 0:
				text = "TEXT_Dozen1";
				break;
			case 1:
				text = "TEXT_Dozen2";
				break;
			case 2:
				text = "TEXT_Dozen3";
				break;
			}
			betButton.setTextBtn(i*(width+manger) , 0 , width , height ,"right_bg_png" , text , true);
			betButton.setMobileShow("move_bg_png");
			var eventId = id.toString();
			var otherEventIdTable:string[] = [];
			for (var j = i*12+1; j <= (i+1)*12; j++) {
				otherEventIdTable[(j+500).toString()] = (j+500).toString();
			}
			otherEventIdTable[eventId] = eventId;
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(12);
			this.donze_group.addChild(betButton);
		}
	}
	//添加列按钮
	private addBottom(){
		for(var i=0;i<6;i++){
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 652 + i;
			betButton.setId(id);
			var eventId = id.toString();
			var width:number = 131.5;
			var height:number = 47;
			var text:string = "";
			var otherEventIdTable:string[] = [];
			switch(i) {
			case 0:
				text = "TEXT_Small";
				for (var j = 1; j <= 18; j++) {
					otherEventIdTable[(j+500).toString()] = (j+500).toString();
				}
				break;
			case 1:
				text = "TEXT_Double";
				for (var j = 1; j <= 36; j++) {
					if (j%2 == 0) {
						otherEventIdTable[(j+500).toString()] = (j+500).toString();
					}
				}
				break;
			case 2:
				text = "TEXT_Red";
				var numBetbutton:NumBetButton = new NumBetButton();
				for (var j = 1; j <= 36; j++) {
					if (numBetbutton.getBtnColor(j) == "red") {
						otherEventIdTable[(j+500).toString()] = (j+500).toString();
					}
				}
				break;
			case 3:
				text = "TEXT_Black";
				for (var j = 1; j <= 36; j++) {
					if (numBetbutton.getBtnColor(j) == "black") {
						otherEventIdTable[(j+500).toString()] = (j+500).toString();
					}
				}
				break;
			case 4:
				text = "TEXT_Single";
				for (var j = 1; j <= 36; j++) {
					if (j%2 != 0) {
						otherEventIdTable[(j+500).toString()] = (j+500).toString();
					}
				}
				break;
			case 5:
				text = "TEXT_Big";
				for (var j = 19; j <= 36; j++) {
					otherEventIdTable[(j+500).toString()] = (j+500).toString();
				}
				break;
			}
			betButton.setTextBtn(i*(width+1.5), 0 , width , height ,"right_bg_png" , text , true);
			betButton.setMobileShow("move_bg_png");
			otherEventIdTable[eventId] = eventId;
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(18);
			this.bottom_group.addChild(betButton);
		}
	}
	private addRightBetBtn(){
		for (var i = 1; i <= 3; i++) {
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 645 + i;
			betButton.setId(id);
			var eventId = id.toString();
			var width:number = 65;
			var height:number = 65;
			var manger:number = 1.5;
			var x = 0;
			var y = (height+manger)*(i-1);
			var text = "1:2";

			var otherEventIdTable:string[] = [];
			for (var j = 1; j <= 36; j++) {
				if ((j)%3 == (4-i)%3) {
					otherEventIdTable[(j+500).toString()] = (j+500).toString();
				}
			}
			otherEventIdTable[eventId] = eventId;
			
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(12);
			betButton.setTextBtn(x, y, width, height, "right_bg_png", text);
			betButton.setMobileShow("move_bg_png");
			// betButton.setTextVertical();
			this.right_group.addChild(betButton);
		}
	}
	private addLinesUpDown2BetBtn(){
		for (var i = 1; i <= 2; i++) {
			this.addLineLeftRight2BetBtn(i);
		}
	}
	//增加一行上下两个按钮
	private addLineLeftRight2BetBtn(line){
		for(var i=0;i<12;i++){
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 550+(line-1)*12 + 12*(line-1) + i;
			betButton.setId(id);
			var eventId = id.toString();
			betButton.setInfo( 67 + (i*66.5) , 60 + ((line-1)*66.5) , 47 , 18 ,"invisible_png");
			var num1 = i*3 + (3 - line) + 500;
			var otherEventIdTable:string[] = [];
			for (var j = num1; j <= num1+1; j++) {
				otherEventIdTable[j.toString()] = j.toString();
			}
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(17);
			this.btn_group.addChild(betButton);
		}

	}
	//一行三列
	private add1Column3BetBtn(){
		for(var i=0;i<12;i++){
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 600+i; 
			betButton.setId(id);
			var eventId = id.toString();
			betButton.setInfo( 67 + (i*66.5) , -10 , 47 , 18 ,"invisible_png");//invisible_png
			var otherEventIdTable:string[] = [];
			for (var j = 1; j <= 3; j++) {
				var ohternEventId = (i*3+j+500).toString();
				otherEventIdTable[ohternEventId] = ohternEventId;
			}
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(11);
			this.btn_group.addChild(betButton);
		}
	}
	/**
	 * 增加多行左右2个按钮
	 */
	private addLinesLeftRight2BetBtn(){
		for (var i = 1; i <= 3; i++) {
			this.addLineUpDown2BetBtn(i);
		}
	}
	//左右一行按钮 如2,4
	private addLineUpDown2BetBtn(line){
		for (var i = 0; i < 12; i++) {
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 538+(line-1)*12 + 12*(line-1) + i;
			betButton.setId(id);
			var eventId = id.toString();
			console.log();
			betButton.setInfo( 50 + (i*66.5) , 20 + ((line-1)*66.5) , 16 , 31 ,"invisible_png");
			var num1 = i*3 + (4 - line) - 3 + 500;
			var otherEventIdTable:string[] = [];
			for (var j = num1; j <= num1+3; j+=3) {
				if (j > 500) {
					otherEventIdTable[j.toString()] = j.toString();
				} else {
					otherEventIdTable["537"] = "537";
				}
			}
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setInfluenceNum(17);
			this.btn_group.addChild(betButton);
		}
		
	}
	private addLinesTopDownLeftDown4BetBtn() {
		for (var i = 1; i <=2; i++) {
			this.addLineTopDownLeftDown4BetBtn(i);
		}
	}
	//增加一行上下左右4个
	private addLineTopDownLeftDown4BetBtn(line){
		for (var i = 0; i < 12; i++) {
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 612+(line-1)*12 + i-line;
			if (i == 0) {
				id = 598 + line - 1;
			}
			var eventId = id.toString();
			var num = i*3 + (3 - line) - 3 + 500;
			var otherEventIdTable:string[] = [];
			var odds = 8;
			for (var j = num; j <= num+1; j++) {
				var otherEventId = j.toString();
				if (j > 500) {
					otherEventIdTable[otherEventId] = otherEventId;
					betButton.setInfluenceNum(4);
				} else {
					otherEventIdTable["537"] = "537";
					betButton.setInfluenceNum(3);
					odds = 11;
				}
			}
			for (var j = num+3; j <= num+4; j++) {
				var otherEventId = j.toString();
				otherEventIdTable[otherEventId] = otherEventId;
			}
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setId(id);
			betButton.setInfo( 50 + (i*66.3) , 60 + ((line-1)*66.5) , 21 , 21 ,"invisible_png");
			betButton.setInfluenceNum(odds);
			this.btn_group.addChild(betButton);
		}
	}
	//增加上或下6个
    private add2Column6BetBtn() {
		for (var i = 0; i < 12; i++) {
			var betButton:RouletteBetButton = new RouletteBetButton();
			var id = 634 + i;
			var eventId = id.toString();
			var otherEventIdTable:string[] = [];
			for (var j = 1; j <= 6; j++) {
				var othernEventId = (i*3+j+500-3);
				var otherEventIdString = othernEventId.toString();
				if (othernEventId > 500) {
					betButton.setInfluenceNum(5);
					otherEventIdTable[otherEventIdString] = otherEventIdString;
				} else {
					betButton.setInfluenceNum(8);
					otherEventIdTable["537"] = "537";
				}
			}
			betButton.setEventIdAndOthers(eventId, otherEventIdTable);
			betButton.setId(id);
			betButton.setInfo( 50 + (i*66.3) , -10 , 21 , 21 ,"invisible_png");
			this.btn_group.addChild(betButton);
		}	
	}
}