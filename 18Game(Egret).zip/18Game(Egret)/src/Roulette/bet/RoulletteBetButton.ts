class RouletteBetButton extends eui.Button{
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/bet/BetButtonSkin.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	private id:number = 0;  //按钮Id
	public backImage:eui.Image; //按钮图片
    public moveShow:eui.Image;//触摸图片
	public text:LangLabel;
	private influenceNum:number = 0;            //码数

	private eventId:string = "";            //自己的遮罩事件Id
    private otherEventIdTable:string[] = [];            //显示其他按钮遮罩的事件Id数组
	private event_MOUSE_OVER_BET_BTN:egret.Event;           //滑到按钮事件
    private event_MOUSE_OUT_BET_BIN:egret.Event;            //滑出按钮事件
    private event_CLICL_BEGIN_BTN:egret.Event;
    private event_CLICL_END_BTN:egret.Event;
    private labelType:boolean = false;
	private square:egret.Shape;
	private canShowMask:boolean = false;            //是否能显示遮罩

    private canClick:boolean = false;           //
    private currentChipBg:eui.Image;            //筹码图片
    private currentChipTotalLabel:eui.Label;  //筹码
    private currentChipTotal:number = 0;            //当前下注总筹码
    private currentBetChip:number = 0;
    private confirmBetMoney:number = 0;         //确认的金额
    
    private unConfirmBetAmount={};
    private repeatBetAmount = {};
	private onAddtoStage(event:egret.Event){
        var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
        if(App.DeviceUtils.IsMobile){
            this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onClickSelf, this);
            this.addEventListener(egret.TouchEvent.TOUCH_END, this.onClickEndSelf, this);
            App.MessageCenter.addListener(RouletteEvent.BEGIN_CLICK_BET_AREA , this.listenBeginClick , this);
            App.MessageCenter.addListener(RouletteEvent.END_CLICK_BET_AREA , this.listenEndClick , this)
        }else{
            this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OVER, this.onMouseOverSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OUT, this.onMouseOutSelf, this);
            //监听鼠标状态
            App.MessageCenter.addListener(MyMouseEvent.MOUSE_OVER_BET_BTN, this.listenMouseOver, this);
            App.MessageCenter.addListener(MyMouseEvent.MOUSE_OUT_BET_BTN, this.listenMouseOut, this);
        }
    
        //游戏状态
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        App.MessageCenter.addListener(RouletteEvent.GAME_STATUS_OK , this.removeChip , this);
        //设置是否可以点击
        App.MessageCenter.addListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        //游戏结果
        App.MessageCenter.addListener(RouletteEvent.RESULT_BET_BTN_ADD_MASK, this.addResultMask, this);
        //点击确认
        App.MessageCenter.addListener(RouletteEvent.CONFIRM_CHIP , this.confirmChip , this);
        //移除未确认筹码
        App.MessageCenter.addListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP , this.removeUnconfirmChip , this);
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_STOP , this.removeUnconfirmChip , this);
        //进桌信息
        App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVipTable , this);
        //重复下注
        App.MessageCenter.addListener(RouletteEvent.SEND_REPEAT_DATA , this.repeatChipsData , this)
        App.MessageCenter.addListener(RouletteEvent.FRENCH_CLICK_BET_DATA,this.frenchBetClick , this);
	}
	private onRemoveFromStage(){
        // this.removeEventListener(egret.TouchEvent.TOUCH_END, this.onClickEndSelf, this);
		App.MessageCenter.removeListener(MyMouseEvent.MOUSE_OVER_BET_BTN, this.listenMouseOver, this);
        App.MessageCenter.removeListener(MyMouseEvent.MOUSE_OUT_BET_BTN, this.listenMouseOut, this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        App.MessageCenter.removeListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        App.MessageCenter.removeListener(RouletteEvent.RESULT_BET_BTN_ADD_MASK, this.addResultMask, this);
        App.MessageCenter.removeListener(RouletteEvent.CONFIRM_CHIP , this.confirmChip , this);
        App.MessageCenter.removeListener(RouletteEvent.REMOVE_UNCONFIRM_CHIP , this.removeUnconfirmChip , this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_STOP , this.removeUnconfirmChip , this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATUS_OK , this.removeChip , this);
        App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVipTable , this)
        App.MessageCenter.removeListener(RouletteEvent.SEND_REPEAT_DATA , this.repeatChipsData , this)
	}
    /**
     * 游戏状开始态
     */
    private gameStateStart(event:any) {
        this.canShowMask = event;
        if(App.DeviceUtils.IsMobile){
            this.backImage.alpha = 1;
        }else{
            this.backImage.alpha = 0;
        }
        this.moveShow.alpha = 0;
    }
    private updateVipTable(data:any){
        var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
        for(var i in data.seats){
            
            if(data.seats[i].uid == playerInfo.uid){
                this.addChips(data.seats[i].betinfo);
            }
            
        }
        
    }
    private addChips(betinfo){
        for(var key in betinfo){
            if(key == this.eventId){
                this.confirmBetMoney = betinfo[key];
                this.setChip(betinfo[key]);
            }
        }
    }
    private repeatChipsData(betinfo){
        this.repeatBetAmount = betinfo;
        for(var key in betinfo){
            if(key == this.eventId){
                this.currentChipTotal = betinfo[key];
                this.setChip(betinfo[key]);
            }
        }
    }
    private frenchBetClick(data:any){
        for(var key in data){
            if(this.id == data[key]){
                if (this.checkMaxLimit()) {
                    this.currentChipTotal = this.getCurrentChipTotal();
                    this.currentBetChip = this.getCurrentChip();
                } else {
                    App.ToastViewManager.toastTextView("TEXT_MESSAGE_6");
                    return ;
                }
                this.setChip(this.currentChipTotal);
                var betData = {}
                betData[this.id] = this.currentBetChip;
                App.MessageCenter.dispatch(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT,betData);
            }
            
        }
    }
    /**
     * 不能显示遮罩
     */
    private canNotShowMask() {
        this.canShowMask = false;
        this.backImage.alpha = 0;
        this.moveShow.alpha = 0;
    }
    private setCanClick(event:any){
        this.canClick = event;
        GameDataCtrl.instance.setIsCanClick(event);
    }
	public setId(id:number){
		this.id = id;
	}
	public setInfo(x:number,y:number,width:number,height:number,bgName:string){
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
        // this.backImage.scale9Grid = new egret.Rectangle(1,1,width,height);
		this.backImage.texture = RES.getRes(bgName);
		this.backImage.left = 0;
        this.backImage.right = 0;
        this.backImage.top = 0;
        this.backImage.bottom = 0;
	}
    public setMobileShow(move){
        if(App.DeviceUtils.IsMobile){
            // this.backImage.alpha = 1;
            this.moveShow.alpha = 0;
            this.moveShow.texture = RES.getRes(move);
            this.moveShow.left = 0;
            this.moveShow.right = 0;
            this.moveShow.top = 0;
            this.moveShow.bottom = 0;
            // if(move !== false){
                
            // }
        }
    }
	public setSkexX(x:number){
		this.skewX = x;
	}
	public setZindex(num:number){
		this.zIndex = num;
	}
	private onClickSelf(Event:egret.Event){
        if (this.canClick) {
            if(App.DeviceUtils.IsMobile){
                App.MessageCenter.dispatch(this.event_CLICL_BEGIN_BTN.type , this.event_CLICL_BEGIN_BTN.data);
                this.moveShow.alpha = 1;
            }
            // this.backImage.alpha = 1;
            if (this.checkMaxLimit()) {
                this.currentChipTotal = this.getCurrentChipTotal();
                this.currentBetChip = this.getCurrentChip();
            } else {
                App.ToastViewManager.toastTextView("TEXT_MESSAGE_6");
                return ;
            }
            this.setChip(this.currentChipTotal);
            var data = {}
            data[this.id] = this.currentBetChip;
            App.MessageCenter.dispatch(RouletteEvent.ADD_BETAREA_AND_BETAMOUNT,data);

        }
	}
    private onClickEndSelf(){
        App.MessageCenter.dispatch(this.event_CLICL_END_BTN.type , this.event_CLICL_END_BTN.data);
    }
    private listenBeginClick(event:egret.Event){
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.eventId == element) {
                        this.moveShow.alpha = 1;
                    }
                }
            }
        }
    }
    private listenEndClick(event:egret.Event){
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.eventId == element) {
                        this.moveShow.alpha = 0;
                    }
                }
            }
        }
    }
    /**
     * 增加筹码
     */
    private setChip(chipMoney:number) {
        this.setChipBg(chipMoney);
        this.setChipLabel(chipMoney);
    }
    /**
     * 设置筹码背景
     */
    private setChipBg(chipMoney:number) {
        var index = this.getChipBgIndex(chipMoney);
        if (!this.currentChipBg) {
            this.currentChipBg = new eui.Image(RES.getRes("chips_normal_0" + index + "_png"));
            this.currentChipBg.scaleX = 0.6;
            this.currentChipBg.scaleY = 0.5;
            this.currentChipBg.horizontalCenter = 0;
            this.currentChipBg.verticalCenter = 0;
            this.addChild(this.currentChipBg);
        } else {
            this.currentChipBg.texture = RES.getRes("chips_normal_0" + index + "_png");
        }
    }
     /**
     * 设置筹码值
     */
    private setChipLabel(chipMoney:number) {
        if (!this.currentChipTotalLabel) {
            this.currentChipTotalLabel = new eui.Label(chipMoney.toString());
            this.currentChipTotalLabel.horizontalCenter = 0;
            this.currentChipTotalLabel.verticalCenter = -20;
            this.addChild(this.currentChipTotalLabel);
        } else {
            this.currentChipTotalLabel.text = chipMoney.toString();
            
        }
        this.currentChipTotalLabel.stroke= 2;
        this.currentChipTotalLabel.strokeColor = 0x000000;
    }
    /**
     * 确认筹码
     */
    private confirmChip() {
        this.currentBetChip = 0;
        if (this.currentChipTotal > 0) {
            this.confirmBetMoney = this.currentChipTotal;
        }
    }
    /**
     * 选择筹码背景
     */
    private getChipBgIndex(chipMoney:number) {
        // var allChipTable = UserInfo.getInstance().allChipTable
        var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
        var allChipTable = loadGameModel.getAllChip;//[10,50,100,500,1000,2000,3000,4000,5000,6000];
        for ( var i = allChipTable.length - 1; i >= 0 ; i--) {
            if (chipMoney >= allChipTable[i]) {
                return i+1;
            }
        }
        return 1;
    }
    
    /**
     * 移除所有筹码
     */
    private removeChip() {
        this.confirmBetMoney = 0;
        this.removeUnconfirmChip();
       
    }
    /**
     * 移除未确认的筹码
     */
    private removeUnconfirmChip() {
        this.repeatBetAmount = {};
        if (this.confirmBetMoney == 0) {
            this.removeChipData();
        } else {
            this.setChip(this.confirmBetMoney);
        }
    }
    public removeChipData(){
        this.removeChipBg();
        this.removeChipLabel();
    }
    /**
     * 移除筹码背景
     */
    private removeChipBg() {
        if (this.currentChipBg && this.currentChipBg.parent) {
            this.currentChipBg.parent.removeChild(this.currentChipBg);
            this.currentChipBg = null;
        }
    }

    /**
     * 移除筹码值
     */
    private removeChipLabel() {
        if (this.currentChipTotalLabel && this.currentChipTotalLabel.parent) {
            this.currentChipTotalLabel.parent.removeChild(this.currentChipTotalLabel);
            this.currentChipTotalLabel = null;
        }
        this.currentChipTotal = 0;
    }

	/**
     * 设置文本按钮的信息
     */
    public setTextBtn(x:number, y:number, width:number, height:number, bgName:string, text:string , lang:any = false) {
        this.setInfo(x, y, width, height, bgName);
        this.moveShow.alpha = 0;
        this.text = new LangLabel();
        if(lang){
            this.text.langStr = text;
            // this.text.stroke = 1;
            // this.text.strokeColor = 0xff0000;
        }else{
            this.text.text = text;
        }
        this.text.horizontalCenter = 0;
        this.text.verticalCenter = 0;
        this.addChild(this.text); 
        if(App.DeviceUtils.IsMobile){
            this.backImage.alpha = 1;
            this.text.size = 20;
        }else{
            this.backImage.alpha = 0;
            this.text.size = 35;
        }
          
    }
	/**
     * 设置码数
     */
    public setInfluenceNum(influenceNum:number) {
        this.influenceNum = influenceNum;
    }
	/**
     * 设置其他按钮的事件组
     */
    public setOtherEventIdTable(otherEventIdTable:string[]) {
        this.otherEventIdTable = otherEventIdTable;
        this.event_MOUSE_OVER_BET_BTN = new egret.Event(MyMouseEvent.MOUSE_OVER_BET_BTN);
		this.event_MOUSE_OVER_BET_BTN.data = this.otherEventIdTable;

        this.event_MOUSE_OUT_BET_BIN = new egret.Event(MyMouseEvent.MOUSE_OUT_BET_BTN);
		this.event_MOUSE_OUT_BET_BIN.data = this.otherEventIdTable;

        this.event_CLICL_BEGIN_BTN = new egret.Event(RouletteEvent.BEGIN_CLICK_BET_AREA);
        this.event_CLICL_BEGIN_BTN.data = this.otherEventIdTable;

        this.event_CLICL_END_BTN = new egret.Event(RouletteEvent.END_CLICK_BET_AREA);
        this.event_CLICL_END_BTN.data = this.otherEventIdTable;
    }
	/**
     * 事件id
     */
    public setEventId(eventId:string) {
        this.eventId = eventId;
    }
	/**
     * 设置自己事件的id和其他组的id
     */
    public setEventIdAndOthers(eventId:string, otherEventIdTable:string[]) {
        this.setOtherEventIdTable(otherEventIdTable);
        this.setEventId(eventId);
    }
	 /**
     * 鼠标在按钮内
     */
	private onMouseOverSelf(){
        App.MessageCenter.dispatch(this.event_MOUSE_OVER_BET_BTN.type,this.event_MOUSE_OVER_BET_BTN.data);
	}
	/**
     * 鼠标在按钮外
     */
	private onMouseOutSelf(){
         App.MessageCenter.dispatch(this.event_MOUSE_OUT_BET_BIN.type,this.event_MOUSE_OUT_BET_BIN.data);
	}
	/**
     * 监听添加鼠标滑入事件
     */
    public listenMouseOver(event:egret.Event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.eventId == element) {
                        this.backImage.alpha = 1;
                    }
                }
            }
        }
    }
    /**
     * 监听移除鼠标滑出事件
     */
    public listenMouseOut(event:egret.Event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.eventId == element) {
                        this.backImage.alpha = 0;
                    }
                }
            }
        }
    }
    /**
     * 返回结果增加遮罩
     */
    public addResultMask(event:any) {
        var otherEventIdTable:string[] = event;
        for (var key in otherEventIdTable) {
            if (otherEventIdTable.hasOwnProperty(key)) {
                var element = otherEventIdTable[key];
                if (this.eventId == element) {
                    // this.backImage.alpha = 1;
                    if(App.DeviceUtils.IsMobile){
                        egret.Tween.get(this.moveShow,{loop:false}).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500);
                    }else
                    egret.Tween.get(this.backImage,{loop:false}).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500).to({ alpha: 1}, 500).to({ alpha: 0}, 500);
                }
            }
        }
    }
	/**
     * 添加遮罩
     */
    public addMask() {
        if (!this.square.parent) {
            this.addChild(this.square);
        }
    }
	/**
     * 移除遮罩
     */
    public removeMask() {
        if (this.square.parent) {
            this.square.parent.removeChild(this.square);
        }
    }
	/**
     * 设置遮罩
     */
    private setMask() {
        this.square = new egret.Shape();
        this.square.graphics.beginFill(0xffffff);
        this.square.graphics.drawRoundRect(0,0,this.width,this.height, 20, 20);
        this.square.alpha = 0.5;
        this.square.graphics.endFill();
    }
    /**
     * 设置当前的筹码值
     */
    private getCurrentChipTotal() {
        var currentChipTotal = this.currentChipTotal + GameDataCtrl.instance.getCurrentBetChip;//BetArea.currentChipValue;
        return currentChipTotal;
    }
    private getCurrentChip(){
        var currentBetChip = this.currentBetChip + GameDataCtrl.instance.getCurrentBetChip;
        return currentBetChip;
    }
    /**
     * 检查是否超出最大限红
     */
    private checkMaxLimit() {
        var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
        var limit = loadGameModel.getLimitRed;
        var getMaxBetLimit = limit.split("-");
        var maxLimit = Number(getMaxBetLimit[1])*this.influenceNum;//;//UserInfo.getInstance().getMaxBetLimit()*
        if(this.getCurrentChipTotal() > maxLimit) {
            return false;
        }
        return true;
    }
}