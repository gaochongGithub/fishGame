class BetButtonFrenchSkin extends eui.Button{
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/bet/BetButtonFrench.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	betNumLength:number = 37; //中间按钮的数量0-36
	private event_FRENCH_MOUSE_OVER_BET_BTN:egret.Event;           //滑到按钮事件
    private event_FRENCH_MOUSE_OUT_BET_BIN:egret.Event;            //滑出按钮事件
    private event_FRENCH_BEGIN_BET_BTN:egret.Event;           //点击按钮事件
    private event_FRENCH_END_BET_BTN:egret.Event;
	public myId:number = 0;  //按钮Id
	private myIndex:number = 0; //index
	private backImage:eui.Image; //按钮图片
	private otherEventIdTable:string[] = [];            //显示其他按钮遮罩的事件Id数组
    private otherFrenchData:string[] = [];
    private clickFrenchData:string[] = [];
	// public textLabel:eui.Label;
	private canClick:boolean = false;  //是否可以点击
	private canShowMask:boolean = false;  //是否显示高亮
	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}


	protected childrenCreated():void
	{
		super.childrenCreated();
	}
	private onAddtoStage(event:egret.Event){
		this.setOtherEventIdTable(this.initData(this.myIndex));
		this.backImage.alpha = 0;
		if(App.DeviceUtils.IsMobile){
            this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onClickSelf, this);
            this.addEventListener(egret.TouchEvent.TOUCH_END, this.onClickEndSelf, this);
            App.MessageCenter.addListener(RouletteEvent.FRENCH_CLICK_END_BET_BTN , this.onClickEndFrench , this)
            
        }else{
            this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OVER, this.onMouseOverSelf, this);
            this.addEventListener(mouse.MouseEvent.MOUSE_OUT, this.onMouseOutSelf, this);
        }
		
        App.MessageCenter.addListener(RouletteEvent.FRENCH_CLICK_BET_BTN , this.onClickFrench , this)
		App.MessageCenter.addListener(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA, this.listenMouseOver, this);
        App.MessageCenter.addListener(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA, this.listenMouseOut, this);
        
         //设置是否可以点击
        App.MessageCenter.addListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        //游戏状态
        App.MessageCenter.addListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        //点击确认
        App.MessageCenter.addListener(RouletteEvent.CONFIRM_CHIP , this.confirmChip , this);
        
	}
	private onRemoveFromStage(){
		App.MessageCenter.removeListener(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA, this.listenMouseOver, this);
        App.MessageCenter.removeListener(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA, this.listenMouseOut, this);
        App.MessageCenter.removeListener(RouletteEvent.SET_BET_BTN_CAN_CLICK, this.setCanClick, this);
        App.MessageCenter.removeListener(RouletteEvent.GAME_STATE_START, this.gameStateStart, this);
        App.MessageCenter.removeListener(RouletteEvent.CONFIRM_CHIP , this.confirmChip , this);
	}
	private initData(index:number){
		if(index == 0){
            this.otherEventIdTable[index+this.betNumLength-2] = (index+this.betNumLength-2).toString();
            this.otherEventIdTable[index+this.betNumLength-1] = (index+this.betNumLength-1).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index+1] = (index+1).toString();
            this.otherEventIdTable[index+2] = (index+2).toString();
        }else if(index == 1){
            this.otherEventIdTable[index+(this.betNumLength-2)] = (index+(this.betNumLength-2)).toString();
            this.otherEventIdTable[index-1] = (index-1).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index+1] = (index+1).toString();
            this.otherEventIdTable[index+2] = (index+2).toString();
        }else if(index == this.betNumLength-1){
            this.otherEventIdTable[index-1] = (index-1).toString();
            this.otherEventIdTable[index-2] = (index-2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index-(this.betNumLength-1)] = (index-(this.betNumLength-1)).toString();
            this.otherEventIdTable[index-(this.betNumLength-2)] = (index-(this.betNumLength-2)).toString();
        }else if(index == this.betNumLength-2){
            this.otherEventIdTable[index-1] = (index-1).toString();
            this.otherEventIdTable[index-2] = (index-2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index+1] = (index+1).toString();
            this.otherEventIdTable[index-(this.betNumLength-2)] = (index-(this.betNumLength-2)).toString();
        }else if(index == 37){
            for(var i=27;i<=37;i++){
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[0] = "0";
            this.otherEventIdTable[1] = "1";
        }else if(index == 38){
            for(var i=2;i<=6;i++){
                this.otherEventIdTable[i] = i.toString();
            }
            for(var i=24;i<=26;i++){
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[38] = "38";
        }else if(index == 39){
            for(var i=7;i<=23;i++){
                this.otherEventIdTable[i] = i.toString();
            }
            
            this.otherEventIdTable[39] = "39";
            this.otherEventIdTable[40] = "40";
        }else if(index == 40){
            for(var i=12;i<=18;i++){
                this.otherEventIdTable[i] = i.toString();
            }
            this.otherEventIdTable[40] = "40";
        }else{
            this.otherEventIdTable[index-1] = (index-1).toString();
            this.otherEventIdTable[index-2] = (index-2).toString();
            this.otherEventIdTable[index] = (index).toString();
            this.otherEventIdTable[index+1] = (index+1).toString();
            this.otherEventIdTable[index+2] = (index+2).toString();
        }
        
        return this.otherEventIdTable;
	}
	/**
     * 设置其他按钮的事件组
     */
    public setOtherEventIdTable(otherEventIdTable:string[]) {
        this.otherEventIdTable = otherEventIdTable;
        this.event_FRENCH_MOUSE_OVER_BET_BTN = new egret.Event(MyMouseEvent.FRENCH_MOUSE_OVER_BET_DATA);
		this.event_FRENCH_MOUSE_OVER_BET_BTN.data = this.otherEventIdTable;

        this.event_FRENCH_MOUSE_OUT_BET_BIN = new egret.Event(MyMouseEvent.FRENCH_MOUSE_OUT_BET_DATA);
		this.event_FRENCH_MOUSE_OUT_BET_BIN.data = this.otherEventIdTable;

        this.event_FRENCH_BEGIN_BET_BTN = new egret.Event(RouletteEvent.FRENCH_CLICK_BET_BTN);
        this.event_FRENCH_BEGIN_BET_BTN.data = this.otherEventIdTable;

        this.event_FRENCH_END_BET_BTN = new egret.Event(RouletteEvent.FRENCH_CLICK_END_BET_BTN);
        this.event_FRENCH_END_BET_BTN.data = this.otherEventIdTable;
    }
	private onClickSelf(Event:egret.Event){
        App.MessageCenter.dispatch(this.event_FRENCH_BEGIN_BET_BTN.type,this.initData(this.myIndex));
	}
    private onClickEndSelf(){
        App.MessageCenter.dispatch(this.event_FRENCH_END_BET_BTN.type,this.initData(this.myIndex));
    }
    private onClickFrench(event:any){
        var otherEventIdTable = event;
        if (GameDataCtrl.instance.isCanClick) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        if(App.DeviceUtils.IsMobile){
                            this.backImage.alpha = 1;
                        }
                        // App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OVER_BET_BTN,this.otherFrenchData);
                        var data = {}
                        data[this.myId] = this.myId;
                        App.MessageCenter.dispatch(RouletteEvent.FRENCH_CLICK_BET_DATA,data);
                    }
                }
            }
        }
    }
    private onClickEndFrench(event:any){
        var otherEventIdTable = event;
        if (GameDataCtrl.instance.isCanClick) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.backImage.alpha = 0;
                    }
                }
            }
        }
    }
	/**
     * 鼠标在按钮内
     */
	private onMouseOverSelf(){
        App.MessageCenter.dispatch(this.event_FRENCH_MOUSE_OVER_BET_BTN.type,this.initData(this.myIndex));
	}
	/**
     * 鼠标在按钮外
     */
	private onMouseOutSelf(){
        App.MessageCenter.dispatch(this.event_FRENCH_MOUSE_OUT_BET_BIN.type,this.initData(this.myIndex));
	}
	/**
     * 监听添加鼠标滑入事件
     */
    public listenMouseOver(event:egret.Event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.otherFrenchData[this.myId] = this.myId.toString();
                        App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OVER_BET_BTN,this.otherFrenchData);
                        this.backImage.alpha = 1;
                    }
                }
            }
        }
    }
    /**
     * 监听移除鼠标滑出事件
     */
    public listenMouseOut(event:egret.Event) {
        var otherEventIdTable = event;
        if (this.canShowMask) {
            for (var key in otherEventIdTable) {
                if (otherEventIdTable.hasOwnProperty(key)) {
                    var element = otherEventIdTable[key];
                    if (this.myIndex == element) {
                        this.backImage.alpha = 0;
                        this.otherFrenchData[this.myId] = this.myId.toString();
                        App.MessageCenter.dispatch(MyMouseEvent.MOUSE_OUT_BET_BTN,this.otherFrenchData);
                    }
                }
            }
        }
    }
    private setCanClick(event:any){
        this.canClick = event;
    }
    /**
     * 游戏状开始态
     */
    private gameStateStart(event:any) {
        this.canShowMask = event;
        this.backImage.alpha = 0;
    }
    private confirmChip(){
        
    }
}