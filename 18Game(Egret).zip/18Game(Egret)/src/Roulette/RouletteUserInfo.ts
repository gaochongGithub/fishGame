class RouletteUserInfo extends eui.Component implements  eui.UIComponent {
	private name_label:eui.Label;//名称
	private balance_label:eui.Label;//余额
	private tableId_label:eui.Label;//桌台编号
	private id_label:eui.Label;//游戏局号
	private limit_label:eui.Label;//限红
	private total_bet_label:eui.Label;//下注总额
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/RouletteUserInfo.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE ,this.onAddToStage , this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	private onAddToStage(event:egret.Event){
	
		this.removeEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
		this.initData();
		App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG , this.getGameTableConfig , this)
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
		//下注后信息
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO , this.confirmBetAmount , this)
	}
	private onRemoveFromStage(){
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO , this.confirmBetAmount , this)
	}
	private initData(){
		var loadGameModel:LoadGameModel=HallDataCtrl.instance.getLoadGameData;
		var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
		this.name_label.text = playerInfo.name;
		this.balance_label.text = "¥"+playerInfo.balance;
		this.limit_label.text = loadGameModel.getLimitRed;
	}
	private getGameTableConfig(data:any){
		this.tableId_label.text = data.name;
	}
	private getGameStatus(data){
		this.id_label.text = data.status + "-" + data.inning;
	}
	private confirmBetAmount(data:any){
		this.balance_label.text = "¥"+data.balance;
		this.total_bet_label.text = data.totalbet;
	}
}