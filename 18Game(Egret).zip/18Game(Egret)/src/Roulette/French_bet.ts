class French_bet extends eui.Component implements  eui.UIComponent {
	private resultTable = [];
	private allGameTableHistory = [];
	private label_group:eui.Group;
	private gameTableHistory:string = "";
	private hot_group:eui.Group;
	private cold_group:eui.Group;
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/bet/French_bet.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE , this.onAddtoStage , this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	}
	private Bet_Area:eui.Group;
	protected partAdded(partName:string,instance:any):void
	{
		super.partAdded(partName,instance);
	}


	protected childrenCreated():void
	{
		super.childrenCreated();
	}
	private onAddtoStage(event:egret.Event){
		this.clickBet();
		App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY , this.getGameTableHistory , this)
	}
	private onRemoveFromStage(){
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY , this.getGameTableHistory , this)
	}
	private clickBet(){
		
	}
	private onClickSelf(event:egret.Event) {
		
		// var btn:eui.Button = event.target;
		// console.log("onClickSelf" , btn);
	}
	//获取历史数据
	private getGameTableHistory(data:any){
        
		if(this.resultTable.length >= 12){
            this.resultTable.pop();
        }
		var str = data.way;
        var arr = str.split(",");
        var arr1 = str.split(",");
		this.getWinNum(arr);
		for(var i=0;i<arr.length;i++){
            this.gameTableHistory += ","+arr[i];
            if(i <= 11){
                if(arr.length <= 1){
                    this.resultTable.unshift(arr1.pop());
                }else{
                    this.resultTable.push(arr1.pop());
                }
                
            }
        }
        this.fillIn(this.resultTable);
		
    }
	//将数据填入label
	private fillIn(resultTable){
        for(var i = 0; i < 12; i++){
			if(resultTable[i] !== undefined){
				var label = this.label_group.getChildByName("road_label_"+i) as eui.Label;
				label.text = resultTable[i];
				if(Number(resultTable[i]) == 0){
					label.textColor = 0x1BD745;
				}else{
					label.textColor = this.getBgImagename(Number(resultTable[i]));
				}
				
			}
		}
    }
	//获取win的数字
	private getWinNum(arr){
		for(var i=0;i<arr.length;i++){
            this.allGameTableHistory.push(Number(arr[i]));
        }
		this.secodFunc(this.allGameTableHistory);
        var testData = [];
        for(var i=0;i<36;i++){
            testData.push(i);
        }
        this.testFunc(testData , this.allGameTableHistory);
	}
	//第三的方法
	private secodFunc(arr){
		var obj = {};
        arr.forEach(function(item){
            obj[item] = (obj[item] || 0) +1;
        });
        var list = [];
        for(var key in obj){
            list.push(key+","+obj[key]);
        }
        list.sort((a,b)=> Number(a.split(",")[1]) - Number(b.split(",")[1]));
        // this.resultList = list;
        this.fillInMaxResuldType(list);
	}
	private testFunc(arr1, arr2){
		var temp = arr1.concat(arr2);
        var rel = {};
        var end = [];
        for(var i = 0;i < temp.length; i ++){
            temp[i] in rel ? rel[temp[i]] ++ : rel[temp[i]] = 1;
        }
        for(var x in rel){
            if(rel[x] == 1){
                end.push(x);
            }
        }
        if(end.length > 0){
            this.fillInMinResuldType(end);
        }
	}
	//热门数据
	private fillInMaxResuldType(list){
		for(var i=0;i<3;i++){
			var num = list[list.length - (i+1)].split(",")[0];
			var num1 = list[list.length - (i+1)].split(",")[1];
			var color; 
			if(num == 0){
				color = 0x1BD745;
			}
			color = this.getBgImagename(num);
			if(this.getBgImagename(num) == 0xB9B9B9){
				color = 0x000000;
			}
			var rect = this.hot_group.getChildByName("hot_rect_"+i) as eui.Rect;
			rect.fillColor = color;
			var hotLab = this.hot_group.getChildByName("hot_label_"+i) as eui.Label;
			hotLab.text = num;
			var hotNum = this.hot_group.getChildByName("hot_number_"+i) as eui.Label;
			hotNum.text = num1;
        }
	}
	//冷门数据
	private fillInMinResuldType(arr){
		if(arr.length <= 3){
            for(var i=0;i<arr.length;i++){
                var num = arr[i].split(",")[0];
				var num1 = arr[i].split(",")[1];
				var color; 
				if(num == 0){
					color = 0x1BD745;
				}
				color = this.getBgImagename(num);
				if(this.getBgImagename(num) == 0xB9B9B9){
					color = 0x000000;
				}
				var rect = this.cold_group.getChildByName("cold_rect_"+i) as eui.Rect;
				rect.fillColor = color;
				var hotLab = this.cold_group.getChildByName("cold_label_"+i) as eui.Label;
				hotLab.text = num;
				var hotNum = this.cold_group.getChildByName("cold_number_"+i) as eui.Label;
				hotNum.text = num1 || "0";
            }
        }else{
            for(var i=0;i<3;i++){
                var num = arr[i].split(",")[0];
				var num1 = arr[i].split(",")[1];
				var color; 
				if(num == 0){
					color = 0x1BD745;
				}
				color = this.getBgImagename(num);
				if(this.getBgImagename(num) == 0xB9B9B9){
					color = 0x000000;
				}
				var rect = this.cold_group.getChildByName("cold_rect_"+i) as eui.Rect;
				rect.fillColor = color;
				var hotLab = this.cold_group.getChildByName("cold_label_"+i) as eui.Label;
				hotLab.text = num;
				var hotNum = this.cold_group.getChildByName("cold_number_"+i) as eui.Label;
				hotNum.text = "0";
            }
        }
	}
	/**
     * 获取背景色
     */
    public getBgImagename(num) {
        var imageName;
        if (num <= 9 || ( num >= 19 && num <= 27 ) ) {
            imageName = this.getBgName1To9And19To23(num);
        } else if( num == 10 || num == 28) {
            imageName = 0xB9B9B9;//
        } else if( num <= 18 || ( num >= 29 && num <= 36 ) ) {
            imageName = this.getBgName11To18And29To36(num);
		}
        return imageName;
    }
	/**
	 * 返回1-9和19-23的按钮背景
	 */
	private getBgName1To9And19To23(index) {
		if (index%2 == 0) {
			return  0xB9B9B9;
		} else {
			return  0xFF0000;
		}
	}

	/**
	 * 返回11-18和29-36的按钮背景
	 */
	private getBgName11To18And29To36(index) {
		if (index%2 != 0) {
			return  0xB9B9B9;
		} else {
			return  0xFF0000;
		}
	}
}