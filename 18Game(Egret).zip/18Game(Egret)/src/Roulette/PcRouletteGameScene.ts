class PcRouletteGameScene extends RouletteScene {
	private allChipsView:AllChipsView;
	private btn_showRoom:eui.Button;
	private changeTableView:ChangeTableView;
	private statusView:StatusView;
	private resultView:RouletteResult;
	public constructor() {
		super();
	}
	initView(){
		this.skinName = "resource/skins/roulette/PcRouletteGameScene.exml";
		console.log(this.statusView , "不思量");
		this.addGroup();
	}
	initEventListener(){
		App.MessageCenter.addListener(GameEvent.SHOW_ALLCHIPS,this.showAllChips,this);
		this.btn_showRoom.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowRoom,this);
	}
	removeMyEventListener(){
		App.MessageCenter.removeListener(GameEvent.SHOW_ALLCHIPS,this.showAllChips,this);
		this.btn_showRoom.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onClickBtnShowRoom,this);
	}
	private showAllChips(){
		this.setChildIndex(this.allChipsView , 10);
		this.allChipsView.visible = !this.allChipsView.visible;
	}
	private onClickBtnShowRoom(){
		this.setChildIndex(this.changeTableView , 11);
		this.changeTableView.visible = !this.changeTableView.visible;
	}

	private addGroup(){
		let bet:BetArea = new BetArea();
		bet.horizontalCenter = 0;
		bet.bottom = 199;
		
		this.addChild(bet);
		//添加下区域
		let BottomInfo:Bottom_info = new Bottom_info();
		BottomInfo.horizontalCenter = 0;
		BottomInfo.bottom = 0;
		this.addChild(BottomInfo);
		//添加右侧下注区
		let FrenchBet:French_bet = new French_bet();
		FrenchBet.verticalCenter = -240;
		FrenchBet.right = 0;
		FrenchBet.bottom = 0;
		this.addChild(FrenchBet);
		
	}
	
}