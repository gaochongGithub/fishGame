abstract class RouletteScene  extends eui.Component implements  eui.UIComponent{
	private isStart:boolean = false;
	private rouletteResule:RouletteResult;
	private isBet:boolean = false;              //是否下注
	private status:number = 0;
	public statusData:any;
	public constructor() {
		super();
	}
	protected childrenCreated():void{
		this.initCommonEventListener();
		this.initView();
		this.initEventListener();
	}
	protected onRemoveStage(event:egret.Event) {
		this.removeMyEventListener();
		this.removeCommonEventListener();
		
	}
	//add一些监听事件
	abstract initEventListener():void;

	//remove一些监听事件
	abstract removeMyEventListener():void;

	//初始化界面
	abstract initView():void;
	//初始化一些可以由父类实现的共同监听事件
	private initCommonEventListener(){
		//进桌
		GameServer.getSingtonInstance().sendJoinTable(proto.GameType.Roulette , 300 , proto.UserRequest.JoinType.Common);
		//接收服务器游戏状态
		App.MessageCenter.addListener(ServerEvent.GET_GAME_STATUS, this.getGameStatus, this);
		App.MessageCenter.addListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVipTable , this);
		//接收确认下注事件
		App.MessageCenter.addListener(GameEvent.CONFIRM_BET_AMOUNT,this.receiveConfirmBetAmountEvent , this);
		App.MessageCenter.addListener(GameEvent.ASK_IS_BET , this.sendIsBet , this);
		//接收游戏用户信息
		App.MessageCenter.addListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
	}
	private removeCommonEventListener(){
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_STATUS,this.getGameStatus,this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO,this.getGameUserInfoEvent,this);
		App.MessageCenter.removeListener(ServerEvent.UPDATE_VIRTUAL_TABLE,this.updateVipTable , this);
		App.MessageCenter.removeListener(GameEvent.CONFIRM_BET_AMOUNT,this.receiveConfirmBetAmountEvent , this);
	}
	private getGameStatus(data:any){
		var gameStatus = data.status;
		this.statusData = data;
		this.status = gameStatus;
		switch (gameStatus) {
			case Status.Shuffle:
				this.getGameStateShuffle();
				break;
			case Status.Start:
				this.getGameStateStart();
				break;
			case Status.Stop:
				this.getGameStateStop();
				break;
			case Status.Payout:
				this.getGameStateResult(data.result);
				break;
			case Status.OK:
				this.getGameStateOk();
				break;
			case Status.Invalied:
				console.log("");
				break;
			default:
				break;
		}
		
	}
	//洗牌
	private getGameStateShuffle(){
		//"洗牌"
		//alert("洗牌");
		App.ToastViewManager.toastTextView("TEXT_SHUFFLE");
	}
	//开始下注
	private getGameStateStart(){
		if(!this.isStart){
			this.isStart = true;
			App.ToastViewManager.toastTextView("TEXT_STATUS_1");
			App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_START , this.isStart);
			App.MessageCenter.dispatch(RouletteEvent.SET_BET_BTN_CAN_CLICK , true);
		}
	}
	private getGameStateStop(){
		App.ToastViewManager.toastTextView("TEXT_MESSAGE_2");
		this.isStart = false;
		App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_START , this.isStart);
		App.MessageCenter.dispatch(RouletteEvent.SET_BET_BTN_CAN_CLICK , false);
		App.MessageCenter.dispatch(RouletteEvent.GAME_STATE_STOP);
	}
	/**
	 * 获取结果
	 */
	private getGameStateResult(result:number) {
		this.isBet = false;
		App.MessageCenter.dispatch(RouletteEvent.GET_GAME_RESULT , result);
		this.rouletteResule = new RouletteResult();
		if(App.DeviceUtils.IsMobile){
			this.rouletteResule.scaleX = 0.6;
			this.rouletteResule.scaleY = 0.6;
		}
		this.rouletteResule.horizontalCenter = 0;
		this.rouletteResule.top = 0;
		// this.setChildIndex(this.rouletteResule , 1);
		this.addChild(this.rouletteResule);
	}
	//获取数据
	private getGameUserInfoEvent(data:any){
		if(this.status == Status.Payout){
			var winlose = data.winlose;
                winlose = winlose > 0 ? "+" + winlose : winlose;
				var text;
				if(winlose >= 0){
					text = "TEXT_TABLE_WIN";
				}else{
					text = "TEXT_TABLE_LOSE";
					winlose = Math.abs(winlose);
				}
				App.ToastViewManager.toastResultView(text,winlose);
		}
	}
	
	private getGameStateOk(){
		this.removeChild(this.rouletteResule);
		App.MessageCenter.dispatch(RouletteEvent.GAME_STATUS_OK);
	}
	private updateVipTable(data:any){
        var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
        for(var i in data.seats){
            if(data.seats[i].uid == playerInfo.uid){
                if (JSON.stringify(data.seats[i].betinfo) !== '{}'&& this.status !== 3) {// 
                    this.isBet = true;
                }
            }
            
        }
    }
	//接收确认下注事件
    private receiveConfirmBetAmountEvent() {
        this.isBet = true;
    }
	private sendIsBet(event:any){
		event.AskIsBet(this.isBet)
	}
}