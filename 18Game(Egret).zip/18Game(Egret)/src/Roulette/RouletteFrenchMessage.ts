class RouletteFrenchMessage {
	public constructor() {
	}
}