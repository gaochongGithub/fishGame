class MobileRoulette extends RouletteScene {
	private user_name_label:eui.Label;
	private user_balance_label:eui.Label;
	private optionView:MobileOptionView;
	private bet_btn_group:eui.Group;
	private show_out_group:eui.Group;
	private seting_group:eui.Group;
	private record_group:eui.Group;
	private chat_group:eui.Group;
	private is_chat:eui.Rect;
	private rotation_img:eui.Image;
	private bet_area:eui.Group;
	private moveNum:number = 279;
	private isMove:boolean = false;//是否在移动
	private frenchArea:MobileFrenchBetArea;
	private historyData:any;
	private frenchDataInfo:any = {};
	private resultTable = [];
	public constructor() {
		super();
	}
	initView(){
		this.skinName = "resource/skins/roulette/MobileRoulette.exml";
		this.addGroup();
	}
	initEventListener(){
		this.show_out_group.addEventListener(egret.TouchEvent.TOUCH_TAP , this.isShowBrea , this);
		this.chat_group.addEventListener(egret.TouchEvent.TOUCH_TAP , this.loadChatPanel , this);
		this.seting_group.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showOption,this);
		this.record_group.addEventListener(egret.TouchEvent.TOUCH_TAP , this.showFrenchBetArea , this);
		App.MessageCenter.addListener(RouletteEvent.MOBILE_FRENCH_AREA , this.showFrenchBetArea , this);
		App.MessageCenter.addListener(ServerEvent.GET_GAME_TABLE_HISTORY , this.getGameTableHistory , this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_USER_INFO , this.confirmBetAmount , this)
		App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG , this.getGameTableConfig , this);
		App.MessageCenter.addListener(GameEvent.GAME_CHAT_PUSH,this.onChatMsgPush , this);//是否有消息
		
	}
	removeMyEventListener(){
		this.show_out_group.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.isShowBrea , this);
		this.record_group.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.showFrenchBetArea , this);
		this.seting_group.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showOption,this);
		App.MessageCenter.removeListener(RouletteEvent.MOBILE_FRENCH_AREA , this.showFrenchBetArea , this);
		App.MessageCenter.removeListener(ServerEvent.GET_GAME_TABLE_HISTORY , this.getGameTableHistory , this)
		App.MessageCenter.removeListener(RouletteEvent.GET_GAME_TABLE_CONFIG , this.getGameTableConfig , this);
	}
	private addGroup(){
		var playerInfo=HallDataCtrl.instance.getLobbyPlayer;
		var name = playerInfo.name.split("_");
		this.user_name_label.text = name[1];
		this.user_balance_label.text = "¥"+playerInfo.balance;
		var repeatBtn:RouletteRepeatBtn = new RouletteRepeatBtn();
		var betBtn:RouletteBetBtn = new RouletteBetBtn();
		this.setScale(repeatBtn);
		this.setScale(betBtn);
		this.bet_btn_group.addChild(repeatBtn);
		this.bet_btn_group.addChild(betBtn);
		var reward = new RewardAnchor();
		reward.top = 0;
		reward.left = 10;
		this.setScale(reward);
		this.addChild(reward);
		var betArea:MobileBetArea = new MobileBetArea();
		betArea.scaleX = 0.60;
		betArea.scaleY = 0.60;
		betArea.horizontalCenter = 0;
		betArea.verticalCenter = -20;
		// this.setScale(betArea);
		this.bet_area.addChild(betArea);
		
	}
	private setScale(node){
		node.scaleX = 0.75;
		node.scaleY = 0.75;
	}
	//点击伸缩下注区域
	private isShowBrea(){
		egret.Tween.get(this.bet_area,{loop:false,onChange:this.onChange}).to({x:0,y:this.moveNum},300,egret.Ease.sineIn).call(this.onComplete , this);
	}
	private loadChatPanel(){
		this.is_chat.alpha = 0;
		this.addChild(new chat());
	}
	private showOption(){
		this.optionView.visible = !this.optionView.visible;
	}
	private onChange(){
		this.isMove = !this.isMove;
	}
	private onComplete(){
		this.isMove = !this.isMove;
		if(this.moveNum > 100){
			this.moveNum = 79;
		}else{
			this.moveNum = 299;
		}
		if(this.rotation_img.rotation == 0){
			this.rotation_img.rotation = 180;
			this.rotation_img.y = 30;
		}else{
			this.rotation_img.rotation = 0;
			this.rotation_img.y = 17;
		}
	}
	private getGameTableHistory(data:any){
		this.historyData = data;
		var str = data.way;
        var arr = str.split(",");
        var arr1 = str.split(",");
		if(this.resultTable.length >= 12){
            this.resultTable.pop();
        }

		for(var i=0;i<arr.length;i++){
            if(i <= 11){
                if(arr.length <= 1){
                    this.resultTable.unshift(arr1.pop());
                }else{
                    this.resultTable.push(arr1.pop());
                }
            }
        }
		for(var i=0;i<arr.length;i++){
			GameDataCtrl.instance.setAllGameTableHistory(Number(arr[i]));
        }
		
	}
	private confirmBetAmount(data:any){
		this.frenchDataInfo["gameTotalBet"] = data.totalbet;
	}
	private getGameTableConfig(data:any){
		this.frenchDataInfo["tableId"] = data.name;
	}
	private showFrenchBetArea(){
		if(!this.frenchArea){
			this.frenchDataInfo["gameNum"] = this.statusData.status + "-" + this.statusData.inning
			this.frenchArea = new MobileFrenchBetArea();
			this.frenchArea.verticalCenter = -20;
			this.frenchArea.getGameTableHistory(this.resultTable);
			this.frenchArea.setLabelInfo(this.frenchDataInfo);
			this.bet_area.addChild(this.frenchArea);
		}else{
			this.bet_area.removeChild(this.frenchArea);
			this.frenchArea = null;
		}
	}
	private onChatMsgPush(data:any){
		if(data.chatVOS.length > 0){
			this.is_chat.alpha = 1;
        }else{
			this.is_chat.alpha = 0;
		}
		 
	}
}