class MobileFrenchMessage extends eui.Component implements  eui.UIComponent{
	public constructor() {
		super();
	}
}