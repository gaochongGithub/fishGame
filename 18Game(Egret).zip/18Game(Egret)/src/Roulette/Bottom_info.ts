class Bottom_info extends eui.Component implements  eui.UIComponent {
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/Bottom_info.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
	
	}
	private bet_confirm_group:eui.Group;
	private deposit_btn:eui.Button;
	private record_btn:eui.Button;
	private rule_btn:eui.Button;
	private exit_btn:eui.Button;
	private setting_btn:eui.Button;
	private onAddtoStage(event:egret.Event){
		this.init();
		this.record_btn.addEventListener(egret.TouchEvent.TOUCH_TAP , this.openRecord , this)
		this.rule_btn.addEventListener(egret.TouchEvent.TOUCH_TAP , this.openRule , this)
		this.exit_btn.addEventListener(egret.TouchEvent.TOUCH_TAP , this.exitGame , this);
		this.setting_btn.addEventListener(egret.TouchEvent.TOUCH_TAP , this.settingGame , this);
	}
	private onRemoveFromStage(){
		this.record_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.openRecord , this)
		this.rule_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.openRule , this)
		this.exit_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.exitGame , this)
	}
	private exitGame(){
		App.MessageCenter.dispatch(GameEvent.ASK_IS_BET , this)
		
	}
	private AskIsBet(isBet){
		if(!isBet){
			GameSceneCtrl.instance.toHallScene();
			let model = HallDataCtrl.instance.getLoadGameData;
			let tableId = model.getTableID;
			GameServer.getSingtonInstance().sendLeaveTable(tableId,proto.GameType.Roulette);
		}else{
			App.ToastViewManager.toastBaseView("BET_QUICK_NOTICE");
		}
	}
	private openRecord(){
		App.ToastViewManager.toast(new RecordView() , false);
	}
	private openRule(){
		App.ToastViewManager.toast(new RuleView() , false);
	}
	private settingGame(){
		App.ToastViewManager.toast(new SettingView() , false);
	}
	private init(){
		//添加下注按钮
		this.bet_confirm_group.addChild(new RouletteRepeatBtn());
		this.bet_confirm_group.addChild(new RouletteBetBtn());
		let reward = new RewardAnchor();
		reward.x = 1050;
		reward.y = 0;
		this.addChild(reward);;//1080 10
		let info:RouletteUserInfo = new RouletteUserInfo();
		info.x = 130;
		info.y = 15;
		this.addChild(info);
		//添加聊天
		var chats=new chat();
		chats.x = 1200;
		chats.y = 13;
		this.addChild(chats);
		var chips = new ChipsView();
		chips.bottom = 5;
		chips.horizontalCenter = -60;
		this.addChild(chips);
	}
}