class RewardAnchor extends eui.Component implements  eui.UIComponent{
	private type_label:eui.Label;
	private name_label:eui.Label;
	private user_image:eui.Image;
	private btn_group:eui.Group;
	private imgLoader:egret.ImageLoader;
	private ancharData;
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/RewardAnchor.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		
	}
	private onAddtoStage(event:egret.Event){
		this.btn_group.addEventListener(egret.TouchEvent.TOUCH_TAP , this.onClick , this)
		App.MessageCenter.addListener(RouletteEvent.GET_GAME_TABLE_CONFIG , this.getGameTableConfig , this)
	}
	private onRemoveFromStage(){
		App.MessageCenter.removeListener(RouletteEvent.GET_GAME_TABLE_CONFIG , this.getGameTableConfig , this)
	}
	private getGameTableConfig(data:any){
		this.ancharData = data;
		this.type_label.text = "荷官";
		this.name_label.text = data.dealer;
		// this.user_image.texture = data.dealerImage;
		this.imgLoader = new egret.ImageLoader();
        this.imgLoader.crossOrigin = "anonymous";// 跨域请求
        this.imgLoader.load(data.dealerImage);// 去除链接中的转义字符‘\’        
        this.imgLoader.once(egret.Event.COMPLETE, (evt: egret.Event)=>{
            if (evt.currentTarget.data) {
                let texture = new egret.Texture();
				texture.bitmapData = evt.currentTarget.data;
				this.user_image.source=texture;
                // texture.bitmapData = evt.currentTarget.data;
                // let bitmap = new egret.Bitmap(texture);
                // bitmap.x = 200;
                // bitmap.y = 200;
                // this.addChild(bitmap);
            }
        }, this);
	}
	private onClick(){
		let moneyReward:RewardMoney = new RewardMoney();
		moneyReward.horizontalCenter = 0;
		moneyReward.verticalCenter = 0;
		moneyReward.getData(this.ancharData);
		if(App.DeviceUtils.IsMobile){
			moneyReward.scaleX = 0.75;
			moneyReward.scaleY = 0.75;
		}
		App.ToastViewManager.toast(moneyReward , false , false);
		
		// this.parent.parent.addChild(moneyReward);
	}
}