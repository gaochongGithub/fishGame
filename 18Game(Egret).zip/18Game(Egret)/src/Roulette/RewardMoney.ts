class RewardMoney extends eui.Component implements  eui.UIComponent{
	private btn_group:eui.Group;
	private number_input:eui.TextInput;
	private name_label:eui.Label;
	private cancel_btn:eui.Button;
	private send_data:eui.Button;
	private rewardData;
	public constructor() {
		super();
		this.skinName = "resource/skins/roulette/RewardMoney.exml";
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddtoStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
		
	}
	private onAddtoStage(){
		this.cancel_btn.addEventListener(egret.TouchEvent.TOUCH_TAP , this.onClick , this)
		this.send_data.addEventListener(egret.TouchEvent.TOUCH_TAP , this.sendData , this);
		App.MessageCenter.addListener(RouletteEvent.GET_REWARD_ANCHOR , this.onClick , this);
	}
	private onRemoveFromStage(){
		this.cancel_btn.removeEventListener(egret.TouchEvent.TOUCH_TAP , this.onClick , this)
		App.MessageCenter.removeListener(RouletteEvent.GET_REWARD_ANCHOR , this.onClick , this);
	}
	private onClick(){
		App.ToastViewManager.clearAll();
		App.ToastViewManager.toastTextView("TEXT_REWARD_SUCCESSFUL");
	}

	private sendData(){
		let type;
		if(this.rewardData.tvName == ""){
			type = 0;
		}else{
			type = 1;
		}
		if(this.number_input.text !== "" && this.textChanged(Number(this.number_input.text))){
			GameServer.getSingtonInstance().sendReward(this.rewardData.tableID , type , Number(this.number_input.text));
		}
	}
	private textChanged(editbox){
        var reg = /^([1-9][0-9]*)$/;
        if (!reg.test(editbox)){
            this.number_input.text ="";
            return false;
        }
		return true;
    }
	public getData(data){
		this.rewardData = data;
		this.name_label.text = data.dealer;
	}
}