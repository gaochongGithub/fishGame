/**
 * Created by yangsong on 15-1-23.
 * 引擎扩展类
 */
class EgretExpandUtils extends SingtonClass {
    /**
     * 构造函数
     */
    public constructor() {
        super();
    }

    /**
     * 初始化函数
     */
    public init(): void {
    }
}