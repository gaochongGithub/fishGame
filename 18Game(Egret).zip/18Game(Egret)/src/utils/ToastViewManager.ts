class ToastViewManager extends SingtonClass{
	public constructor() {
		super();
		this._parentLayer = null;
		
	}
	private _parentLayer:egret.DisplayObjectContainer;
	private toastBg:ToastBgView;
	private baseToastView:BaseToastView
	private serverToastView:ServerToastView;
	private textToastView:TextToastView;
	private resultToastView:ResultToastView;
	public set parentLayer(layer:egret.DisplayObjectContainer){
		this._parentLayer = layer;
	}

	public get parentLayer():egret.DisplayObjectContainer{
		return this._parentLayer;
	}
	//带底框弹出
	public toastBaseView(title:string){
		this.baseToastView = new BaseToastView();
		this.baseToastView.setTitle(title);
		this.parentLayer.addChild(this.baseToastView);
		// this.toast(this.baseToastView,true);
	}
	//开牌结果输赢
	public toastResultView(title:string,resultType:any,imgName:any=null){//imgName 图片名称
		this.resultToastView = new ResultToastView();
		this.resultToastView.setContent(title,resultType,imgName);
		// this.toast(this.resultToastView,true,false);
		this.parentLayer.addChild(this.resultToastView);
	}
	//服务器弹框
	public toastServerView(title:string){
		this.serverToastView = new ServerToastView();
		this.serverToastView.setContent(title);
		this.toast(this.serverToastView,false,true);
	}
	//文字弹框
	public toastTextView(title:string){
		this.textToastView = new TextToastView();
		this.textToastView.setContent(title);
		//this.toast(this.textToastView,true,false);
		this.parentLayer.addChild(this.textToastView);
		this.textToastView.updataPosition();

	}
	public toast(view:any,isAutoRemove:boolean,isShowBackRect:boolean=false){
		this.toastBg = new ToastBgView(isAutoRemove,isShowBackRect);
		this.toastBg.addChild(view);
		this.parentLayer.addChild(this.toastBg);
		
	}

	public clearAll():void{
		this.toastBg&&this.parentLayer.removeChild(this.toastBg);
	}
}