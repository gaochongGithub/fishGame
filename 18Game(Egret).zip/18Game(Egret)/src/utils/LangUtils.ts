class LangUtils extends SingtonClass{
	 /**
     * 构造函数
     */
    public constructor() {
		super();
		this._obj = new Object();
		this._kind = "ZH";
		this._resultObj = new Object();
	}
	private _obj:Object;
	//当前语言类型
	private _kind: string;
	private _resultObj:Object;

	public set kind(kind:string) {
		this._kind = kind;
		//setCookie("LANGUAGE", this._kind);
	}

	public get kind():string{
        return this._kind;
    }

	public init(kind: string): void {
		// Lang.obj[kind] = RES.getRes(kind);
		this._obj = RES.getRes('Lang_json');
		this._resultObj = RES.getRes('baccaratResult_json');
		this.kind = kind;
	}
	
	public changeLang(kind: string) {
		if (this._kind != kind) {
			this.kind = kind;
			App.MessageCenter.dispatch(GlobalEvent.CHANGE_LANGUAGE);
			egret.localStorage.setItem("lang",kind);
		}
	}

	public getStr(key): string {
		return this._obj[key][this._kind];
	}

	public getResultStr(result:string):string{
		return  this._resultObj[result][this._kind];
	}
}