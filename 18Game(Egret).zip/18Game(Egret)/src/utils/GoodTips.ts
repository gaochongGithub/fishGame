class GoodTips {
	public constructor() {
	}
	private static goodTips:GoodTips;
	static get instance(){
		if(!this.goodTips){
			this.goodTips=new GoodTips();
		}
		return this.goodTips;
	}
	private hasGoodTips:boolean = false;

	checkTips(a, b) {
        var resultArr = [];
        this.hasGoodTips=false;
        
        var result =  this.setBigRoadmap(b,a);
   
        if(result){
            resultArr.push(result);
        }

        var result2 = this.parseOtherRoad(b, a);
    

        if(result2){
            resultArr.push(result2);
        }
    

        if(this.hasGoodTips==false){
            //cmkj.EventCtrl.sendDataEvent("GoodTips", {type : -1, table : a});
            resultArr.push( {type : -1, table : a});
        }

        return resultArr;
    
    };

    setBigRoadmap(a, b) {
    var icon_count = 31;
    var col_number = [0, 0, 0, 0, 0, 0];
    var col_mem = [];

    col_number[0] = 0;



    // var B_total = 0;
    // var P_total = 0;
    // var T_total = 0;
    var strData = a;
    strData = this.stringReplaceAll(strData, "a", "200|");
    strData = this.stringReplaceAll(strData, "b", "220|");
    strData = this.stringReplaceAll(strData, "c", "210|");
    strData = this.stringReplaceAll(strData, "d", "230|");
    strData = this.stringReplaceAll(strData, "e", "100|");
    strData = this.stringReplaceAll(strData, "f", "120|");
    strData = this.stringReplaceAll(strData, "g", "110|");
    strData = this.stringReplaceAll(strData, "h", "130|");
    strData = this.stringReplaceAll(strData, "i", "300|");
    strData = this.stringReplaceAll(strData, "j", "300|");
    strData = this.stringReplaceAll(strData, "k", "300|");
    strData = this.stringReplaceAll(strData, "l", "300|");

    var strTmp = strData.replace(/:/g, "").substr(0, strData.length - 1);
    var arrPart = strTmp.split("|");
    // var arrTmp1 = [];
    // var arrTmp2 = [];
    // var arrTmp3 = [];
    // var arrTmp4 = [];
    // var arrTmp5 = [];
    // var arrTmp6 = [];
    // var arrTmp7 = [];
    // var arrTmp8 = [];
    // var arrTmp9 = [];
    // var arrTmp10 = [];
    // var arrTmp11 = [];
    // var arrTmp12 = [];
    // var arrTmp13 = [];
    // var arrTmp14 = [];
    // var arrTmp15 = [];
    // var arrTmp16 = [];
    // var arrTmp17 = [];
    // var arrTmp18 = [];
    // var arrTmp19 = [];
    var arrTmp = [];
    
    //console.log("arr",arrTmp,arrPart);
    for (var j = 0; j < 19; j++) {
        arrTmp[j] = [];
    }

    
    var i = 0;
    var intTmp_Ori = 0;
    var intTmp = 0;
    var intTmp2 = 0;
    var intTmp_F = 0;
    var bNextMove = false;
    var isBefore = false;
    var isHead = false;
    var equalSix = -1;
    var nArray1 = 0;
    var nArray2 = 0;
    var nArray3 = 0;
    var nArray4 = 0;
    var nY = 0, nX = 0;

    intTmp_Ori = parseInt(arrPart[0]);
    intTmp = 10 * intTmp_Ori/100 + 0;



    for (i = 0; i < arrPart.length; i++)
    {
        for (var l = 1; l < 19; l++) {
            if (arrTmp[0].length > arrTmp[l].length)
                arrTmp[l][arrTmp[0].length] = [];
        }

        if (i == 0 && (arrPart[i] / 100) != 3) {
            intTmp_Ori = arrPart[i];	
            intTmp = parseInt((intTmp_Ori / 10).toString() + "0");
            intTmp_F = intTmp / 100;
            bNextMove = false;
        }
        else if (i == 0 && (arrPart[i] / 100) == 3) {
            intTmp2++;
            intTmp_F = intTmp / 100;
            isHead = true;
        }
        else	
        {
            if ((arrPart[i] / 100) == 3) {
                if (intTmp2 < 9) intTmp2++;			
                intTmp = parseInt((intTmp_Ori / 10).toString() + intTmp2.toString());
                bNextMove = false;
            }
            else if ((arrPart[i] / 100) != intTmp_F && intTmp_F != 3) {

                if (!isHead)
                    nArray1++;
                
                nArray2 = 0;
                nArray3 = 0;
                intTmp_Ori = arrPart[i];
                if (isHead)
                    isHead = false;
                else
                    intTmp2 = 0;

                intTmp = parseInt((intTmp_Ori / 10).toString() + intTmp2.toString());
                intTmp_F = intTmp / 100;
                bNextMove = false;
            }
            else if ((arrPart[i] / 100) == intTmp_F || intTmp_F == 3) {

                if (intTmp_F == 3) nArray2--;
                bNextMove = true;

                intTmp2 = 0;
                intTmp_Ori = arrPart[i];
                intTmp = parseInt((intTmp_Ori / 10).toString() + "0");
                intTmp_F = intTmp / 100;
            }
        }

        if (intTmp_F == 3) continue;

        if (bNextMove) {
            nArray2++;
        }
        if (nArray2==0) {
            arrTmp[0][nArray1] = intTmp.toString().substr(0,1);
        }   
        arrTmp[1][nArray1] = nArray2;

        // CHECKING FOR GOOD TIPS FUNCTION  
        //cc.log(arrTmp,arrTmp[1][nArray1],arrTmp[0][nArray1]);

        if(i < arrPart.length-1){
            continue;
        }
        
        if (arrTmp[1][nArray1]>=3) 
        {
            if (arrTmp[0][nArray1]=="2")
            {               
                this.createGoodTips(1, b);      //<<---- GOOD TIPS 1
                return({type : 1, table : b});
            }
            else if (arrTmp[0][nArray1]=="1") 
            {	
                this.createGoodTips(2, b);      //<<---- GOOD TIPS 2
                return({type : 2, table : b});
            }
        }
        
        if (arrTmp[0][nArray1]=="1"&&arrTmp[1][nArray1]==0&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==0&&arrTmp[1][nArray1-3]==0&&arrTmp[1][nArray1-4]>=3&&nArray1>=4)
        {          		
            this.createGoodTips(3, b);          //<<---- GOOD TIPS 3
            return({type : 3, table : b});
        }

        if (arrTmp[0][nArray1]=="2"&&arrTmp[1][nArray1]==0&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==0&&arrTmp[1][nArray1-3]==0&&arrTmp[1][nArray1-4]>=3&&nArray1>=4)
        {          		
            this.createGoodTips(3, b);          //<<---- GOOD TIPS 3
            return({type : 3, table : b});
        }

        if (arrTmp[0][nArray1]=="1"&&arrTmp[1][nArray1]==0&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==0&&arrTmp[1][nArray1-3]==0&&nArray1>=3)
        {	
            this.createGoodTips(4, b);          //<<---- GOOD TIPS 4
            return({type : 4, table : b});
        }

        if (arrTmp[0][nArray1]=="1"&&arrTmp[1][nArray1]==1&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==1&&arrTmp[1][nArray1-3]==0&&nArray1>=3)
        {
            this.createGoodTips(5, b);          //<<---- GOOD TIPS 5
            return({type : 5, table : b});
        }

        if (arrTmp[0][nArray1]=="2"&&arrTmp[1][nArray1]==1&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==1&&arrTmp[1][nArray1-3]==0&&nArray1>=3)
        {
            this.createGoodTips(6, b);          //<<---- GOOD TIPS 6
            return({type : 6, table : b});
        }

        if (arrTmp[0][nArray1]=="2"&&arrTmp[1][nArray1]==0&&arrTmp[1][nArray1-1]==0&&arrTmp[1][nArray1-2]==0&&arrTmp[1][nArray1-3]==0&&nArray1>=3)
        {	
            this.createGoodTips(4, b);          //<<---- GOOD TIPS 4
            return({type : 4, table : b});
        }
    
    }
};

parseOtherRoad = function (a, b) {
    var strData = a;

    strData=this.stringReplaceAll(strData,"a","200|");
    strData=this.stringReplaceAll(strData,"b","200|");
    strData=this.stringReplaceAll(strData,"c","200|");
    strData=this.stringReplaceAll(strData,"d","200|");
    strData=this.stringReplaceAll(strData,"e","100|");
    strData=this.stringReplaceAll(strData,"f","100|");
    strData=this.stringReplaceAll(strData,"g","100|");
    strData=this.stringReplaceAll(strData,"h","100|");
    strData=this.stringReplaceAll(strData,"i","300|");
    strData=this.stringReplaceAll(strData,"j","300|");
    strData=this.stringReplaceAll(strData,"k","300|");
    strData=this.stringReplaceAll(strData,"l","300|");
    strData+="100|";

    var strTmp = strData.replace(/:/g,"").substr(0,strData.length-1);
    var arrPart = strTmp.split("|");	
    var arrTmp = [];
    for(var j=0;j<50;j++){
        arrTmp[j]=[];
    }
    var arrTmpLength = [];

    var i=0;
    var intTmp_Ori = 0;		
    var intTmp = 0;			
    var bNextMove = false;
    var nArray1 = 0;		
    var nArray2 = 0;		
    var nY=0,nX=0;

    intTmp_Ori = parseInt(arrPart[0]);
    intTmp = intTmp_Ori/100;

    for (i = 0; i < arrPart.length; i++)
    {
        if ( i == 0 )
        {
            intTmp_Ori = parseInt(arrPart[i]);
            intTmp = intTmp_Ori/100;
            bNextMove = false;
        }
        else	
        {
            if ((arrPart[i]/100) == 3 )
            {
                bNextMove = false;
            }
            else if (arrPart[i]/100!= intTmp && intTmp != 3 )
            {
                arrTmpLength[nArray1]=nArray2;
                nArray1++;
                nArray2 = 0;
                intTmp_Ori = parseInt(arrPart[i]);
                intTmp = intTmp_Ori/100;
                bNextMove = false;
            }
            else if ((arrPart[i])/100 == intTmp || intTmp == 3)
            {
                if (intTmp == 3) nArray2--;
                bNextMove = true;
                intTmp_Ori = parseInt(arrPart[i]);
                intTmp = intTmp_Ori/100;
            }
        }
        
        if ( bNextMove ) {
            nArray2++;
        }

        if( !arrTmp[nArray2][nArray1] ) {
            arrTmp[nArray2][nArray1] = [];
        }
        
        arrTmp[nArray2][nArray1] = intTmp;
    }
    
    return this.setBigEyeRoad(arrTmp, arrTmpLength, nArray1, nArray2, nY, nX, b);
};
setBigEyeRoad(arrTmp, arrTmpLength, nArray1, nArray2, nY, nX, b) {
    var col_number = 0;
    var col_mem = 0;
    
    var arrTmp101 = [];
    var arrTmp102 = [];
    var arrTmp103 = [];
    var arrTmp104 = [];
    var arrTmp105 = [];
    var arrTmp106 = [];
    var arrTmp107 = [];
    var arrTmp108 = [];
    var arrTmp109 = [];
    var arrTmp110 = [];
    var arrTmp111 = [];
    var arrTmp112 = [];
    var arrTmp113 = [];
    var arrTmp114 = [];
    var arrTmp115 = [];
    var arrTmp116 = [];
    var arrTmp117 = [];
    var arrTmp118 = [];
    var arrTmp119 = [];
    var arr1Tmp = [arrTmp101, arrTmp102, arrTmp103, arrTmp104 ,arrTmp105, arrTmp106, arrTmp107, arrTmp108, arrTmp109, arrTmp110, arrTmp111, arrTmp112,arrTmp113,arrTmp114,arrTmp115,arrTmp116,arrTmp117,arrTmp118,arrTmp119];
    var arrResult13 = [];		
    var BfResult;
    var xx = 0;
    var yy = 0;			
    var zz = 0;			

    var isBefore = false;
    var equalSix = -1;
    var nArray4 = 0;
    var x = 0;
    var y = 0;
    var xxx = 0;
    var xStart = 0;
    var yStart = 0;
    var yLastp = 0;
    var RCount = 0;

    var nStart = 0;
    var nEnd = 0;
    var intData = 0;

    if ( (nArray1 > 0 && nArray2 > 0) || nArray1 > 1)	
    {
        if ( arrTmp[1][1] != undefined )
        {
            xStart = 1;
            yStart = 1;
        }
        else
        {
            xStart = 2;
            yStart = 0;
        }
        
        for ( x = xStart; x <= nArray1 ; x++)		
        {
            if (x==xStart)
                y=yStart;
            else
                y=0;

            for (; y < 19; y++)		
            {

                if (arrTmp[y][x]==undefined)
                    break;
                if (y==0)
                {
                    if (arrTmpLength[x-1]==arrTmpLength[x-2])
                    {
                        arrResult13[RCount] = 2;
                    }
                    else
                    {
                        arrResult13[RCount] = 1;
                    }

                }
                else
                {
                  
                    if (arrTmp[y][x-1] != undefined)
                    {
                        arrResult13[RCount] = 2;
                    }
                    else
                    {
                        if (arrTmp[y][x-1]==arrTmp[y-1][x-1])
                        {
                            arrResult13[RCount] = 2;
                        }
                        else
                        {
                            arrResult13[RCount] = 1;
                        }

                    }
                }
                RCount++;

            }
        }

        var i = 0;

        for (i = 0; i < RCount-1; i++) {
            if(i == 0)
            {
                xx = 0;
                yy = 0;
                zz = 0;
            }
            else if ( parseInt(arrResult13[i]) != BfResult )
            {
                xx++;			
                yy = 0;
                zz = 0;
            }
            else	
            {
                yy++;
            }

            BfResult = parseInt(arrResult13[i]);
            if (yy==0) {
                arr1Tmp[0][xx] = BfResult;
            }

            arr1Tmp[1][xx] = yy;   	
        }

        if (arr1Tmp[0][xx]=="2"&&arr1Tmp[1][xx]==3&&arr1Tmp[0][xx-1]=="1"&&arr1Tmp[1][xx-1]==1&&arr1Tmp[0][xx-2]=="2"&&arr1Tmp[1][xx-2]==2&&arr1Tmp[0][xx-3]=="1"&&arr1Tmp[1][xx-3]==0)
        {
            this.createGoodTips(7, b);          //<<---- GOOD TIPS 7
            return({type : 7, table : b});
        }else if(arr1Tmp[0][xx]=="1"&&arr1Tmp[1][xx]==3&&arr1Tmp[0][xx-1]=="2"&&arr1Tmp[1][xx-1]==1&&arr1Tmp[0][xx-2]=="1"&&arr1Tmp[1][xx-2]==2&&arr1Tmp[0][xx-3]=="2"&&arr1Tmp[1][xx-3]==0){
            this.createGoodTips(7, b);
            return({type : 7, table : b});
        }

        var arrResult23 = [];	
        BfResult = 0;
        xx = 0;
        yy = 0;			
        zz = 0;
        isBefore=false;
        equalSix=-1;
        nArray4 = 0;

        x = 0;
        y = 0;
        xxx = 0;
        xStart = 0;
        yStart = 0;
        RCount = 0;

        nStart = 0;
        nEnd = 0;	
        intData = 0;
        nY=0;nX=0;

        var arrTmp201 = [];
        var arrTmp202 = [];
        var arrTmp203 = [];
        var arrTmp204 = [];
        var arrTmp205 = [];
        var arrTmp206 = [];
        var arrTmp207 = [];
        var arrTmp208 = [];
        var arrTmp209 = [];
        var arrTmp210 = [];
        var arrTmp211 = [];
        var arrTmp212 = [];
        var arrTmp213 = [];
        var arrTmp214 = [];
        var arrTmp215 = [];
        var arrTmp216 = [];
        var arrTmp217 = [];
        var arrTmp218 = [];
        var arrTmp219 = [];			
        var arr2Tmp = [arrTmp201, arrTmp202, arrTmp203, arrTmp204 ,arrTmp205, arrTmp206, arrTmp207, arrTmp208, arrTmp209, arrTmp210, arrTmp211, arrTmp212,arrTmp213,arrTmp214,arrTmp215,arrTmp216,arrTmp217,arrTmp218,arrTmp219];							

        if ( (nArray1 > 1 && nArray2 > 0) || nArray1 > 2)		//3번째칸 2번째줄부터 시작됨...
        {	
            if ( arrTmp[1][2] != undefined )
            {
                xStart = 2;
                yStart = 1;
            }
            else
            {
                xStart = 3;
                yStart = 0;
            }

         
            for ( x = xStart; x <= nArray1 ; x++)		
            {
                if (x==xStart)
                    y=yStart;
                else
                    y=0;

                for (; y < 19; y++)			
                {			

                    if (arrTmp[y][x]==undefined)
                        break;
                    if (y==0)
                    {								
                        if (arrTmpLength[x-1]==arrTmpLength[x-3])
                        {									
                            arrResult23[RCount] = 2;
                        }
                        else 
                        {								    
                            arrResult23[RCount] = 1;
                        }

                    }
                    else
                    {
                        
                        if (arrTmp[y][x-2] != undefined)
                        {						
                            arrResult23[RCount] = 2;
                        }
                        else
                        {
                            if (arrTmp[y][x-2]==arrTmp[y-1][x-2])
                            {									
                                arrResult23[RCount] = 2;
                            }
                            else
                            { 								   	
                                arrResult23[RCount] = 1;
                            }

                        }
                    }			
                    RCount++;

                }
            }
           
            for (i = 0; i < RCount-1; i++)		
            {
                if(i == 0)
                {
                    xx = 0;
                    yy = 1;
                    zz = 0;
                }
                else if ( parseInt(arrResult23[i]) != BfResult )	
                {
                    xx++;				
                    yy = 1;
                    zz = 0;
                }
                else	
                {
                    yy++;
                }
                BfResult = parseInt(arrResult23[i]);
                if (yy==1)				
                    arr2Tmp[0][xx] = BfResult;

                arr2Tmp[1][xx] = yy;  
            }
        }
       
        var arrResult33 =  [];	
        BfResult = 0;
        xx = 0;
        yy = 0;			
        zz = 0;
        isBefore=false;
        equalSix=-1;
        nArray4 = 0;

        x = 0;
        y = 0;
        xxx = 0;
        xStart = 0;
        yStart = 0;
        RCount = 0;

        nStart = 0;
        nEnd = 0;	
        intData = 0;
        nY=0;nX=0;

        var arrTmp301= [];
        var arrTmp302= [];
        var arrTmp303= [];
        var arrTmp304= [];
        var arrTmp305= [];
        var arrTmp306= [];
        var arrTmp307= [];
        var arrTmp308= [];
        var arrTmp309= [];
        var arrTmp310= [];
        var arrTmp311= [];
        var arrTmp312= [];
        var arrTmp313= [];
        var arrTmp314= [];
        var arrTmp315= [];
        var arrTmp316= [];
        var arrTmp317= [];
        var arrTmp318= [];
        var arrTmp319= [];			
        var arr3Tmp = [arrTmp301, arrTmp302, arrTmp303, arrTmp304 ,arrTmp305, arrTmp306, arrTmp307, arrTmp308, arrTmp309, arrTmp310, arrTmp311, arrTmp312,arrTmp313,arrTmp314,arrTmp315,arrTmp316,arrTmp317,arrTmp318,arrTmp319];							
        if ( (nArray1 > 1 && nArray2 > 0) || nArray1 > 2)		//3번째칸 2번째줄부터 시작됨...
        {	
            if ( arrTmp[1][3] != undefined )
            {
                xStart = 3;
                yStart = 1;
            }
            else
            {
                xStart = 4;
                yStart = 0;
            }
          
            for ( x = xStart; x <= nArray1 ; x++)	
            {
                if (x==xStart)
                    y=yStart;
                else
                    y=0;

                for (; y < 19; y++)			
                {			

                    if (arrTmp[y][x]==undefined)
                        break;
                    if (y==0)
                    {								
                        if (arrTmpLength[x-1]==arrTmpLength[x-4])
                        {									
                            arrResult33[RCount] = 2;
                        }
                        else 
                        {								    
                            arrResult33[RCount] = 1;
                        }

                    }
                    else
                    {
                        
                        if (arrTmp[y][x-3] != undefined)
                        {						
                            arrResult33[RCount] = 2;
                        }
                        else
                        {
                            if (arrTmp[y][x-3]==arrTmp[y-1][x-3])
                            {									
                                arrResult33[RCount] = 2;
                            }
                            else
                            { 								   	
                                arrResult33[RCount] = 1;
                            }

                        }
                    }			
                    RCount++;

                }
            }
            
            for (i = 0; i < RCount-1; i++)
            {
                if(i == 0)
                {
                    xx = 0;
                    yy = 1;
                    zz = 0;
                }
                else if ( parseInt(arrResult33[i]) != BfResult )
                {
                    xx++;	
                    yy = 1;
                    zz = 0;
                }
                else
                {
                    yy++;
                }
                BfResult = parseInt(arrResult33[i]);
                if (yy==1)				
                    arr3Tmp[0][xx] = BfResult;

                arr3Tmp[1][xx] = yy;   				



            }				
        }	
        if (arr3Tmp[1][xx]>3)
        {

            this.createGoodTips(8, b);          //<<---- GOOD TIPS 8
            return({type : 8, table : b});
        }
    }
};
stringReplaceAll(a, b, c) {
    return a.split(b).join(c);
};
createGoodTips (type, table) {
    // cc.log("sendTips",table,type);
    this.hasGoodTips = true;
    //cmkj.EventCtrl.sendDataEvent("GoodTips", {type : type, table : table});
}
}